"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_admin_invoice_schemes_List_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/invoice_schemes/Add.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/invoice_schemes/Add.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  data: function data() {
    return {
      dialog: false,
      type: null,
      name: null,
      prefix: '',
      start_from: 1,
      is_default: false,
      no_of_digits_items: [1, 2, 3, 4, 5, 6, 7, 8, 9],
      no_of_digits: 1,
      preview_text: null
    };
  },
  methods: {
    preview: function preview() {
      if (this.type == 'custom') {
        this.preview_text = '#' + this.prefix;
      } else if (this.type == 'year') {
        this.preview_text = '#' + moment().format('YYYY');
      }
      this.preview_text = this.preview_text + '-' + _.padStart(this.start_from, this.no_of_digits, 0);
    },
    create: function create() {
      var self = this;
      self.dialog = true;
      self.type = null;
      self.name = null;
      self.prefix = '';
      self.start_from = 1;
      self.is_default = false;
      self.no_of_digits = 1;
      self.preview_text = null;
      self.$validator.reset();
    },
    store: function (_store) {
      function store() {
        return _store.apply(this, arguments);
      }
      store.toString = function () {
        return _store.toString();
      };
      return store;
    }(function () {
      var self = this;
      var data = {
        name: self.name,
        scheme_type: self.type,
        prefix: self.prefix,
        start_number: self.start_from,
        total_digits: self.no_of_digits,
        is_default: self.is_default
      };
      self.$validator.validateAll().then(function (result) {
        if (result == true) {
          axios.post('/admin/invoice-scheme', data).then(function (response) {
            self.dialog = false;
            self.$store.commit('showSnackbar', {
              message: response.data.msg,
              color: response.data.success
            });
            if (response.data.success === true) {
              self.$eventBus.$emit('updateInvoiceSchemeTable');
            }
          })["catch"](function (err) {
            console.log(err.response.status);
            if (err.response.status === 401) {
              store.dispatch('auth/handleResponse', err.response);
            }
          });
        }
      });
    })
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/invoice_schemes/Edit.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/invoice_schemes/Edit.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  data: function data() {
    return {
      dialog: false,
      type: null,
      name: null,
      prefix: '',
      start_from: 1,
      is_default: '',
      no_of_digits_items: [1, 2, 3, 4, 5, 6, 7, 8, 9],
      no_of_digits: 1,
      preview_text: null,
      invoiceSchemeId: null
    };
  },
  methods: {
    preview: function preview() {
      if (this.type == 'custom') {
        this.preview_text = '#' + this.prefix;
      } else if (this.type == 'year') {
        this.preview_text = '#' + moment().format('YYYY');
      }
      this.preview_text = this.preview_text + '-' + _.padStart(this.start_from, this.no_of_digits, 0);
    },
    edit: function edit(data) {
      var self = this;
      self.invoiceSchemeId = data.id;
      self.$validator.reset();
      axios.get('/admin/invoice-scheme/' + data.id + '/edit').then(function (response) {
        self.name = response.data.name;
        self.type = response.data.scheme_type;
        self.prefix = response.data.prefix;
        self.start_from = response.data.start_number;
        self.is_default = response.data.is_default;
        self.no_of_digits = response.data.total_digits;
        self.preview();
        self.dialog = true;
      })["catch"](function (error) {
        console.log(error);
      });
    },
    store: function (_store) {
      function store() {
        return _store.apply(this, arguments);
      }
      store.toString = function () {
        return _store.toString();
      };
      return store;
    }(function () {
      var self = this;
      var data = {
        name: self.name,
        scheme_type: self.type,
        prefix: self.prefix,
        start_number: self.start_from,
        total_digits: self.no_of_digits,
        is_default: self.is_default
      };
      self.$validator.validateAll().then(function (result) {
        if (result == true) {
          axios.put('/admin/invoice-scheme/' + self.invoiceSchemeId, data).then(function (response) {
            self.dialog = false;
            self.$store.commit('showSnackbar', {
              message: response.data.msg,
              color: response.data.success
            });
            if (response.data.success === true) {
              self.$eventBus.$emit('updateInvoiceSchemeTable');
            }
          })["catch"](function (err) {
            console.log(err.response.status);
            if (err.response.status === 401) {
              store.dispatch('auth/handleResponse', err.response);
            }
          });
        }
      });
    })
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/invoice_schemes/List.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/invoice_schemes/List.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Add__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Add */ "./resources/js/admin/invoice_schemes/Add.vue");
/* harmony import */ var _Edit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Edit */ "./resources/js/admin/invoice_schemes/Edit.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  components: {
    InvoiceSchemeAdd: _Add__WEBPACK_IMPORTED_MODULE_0__["default"],
    InvoiceSchemeEdit: _Edit__WEBPACK_IMPORTED_MODULE_1__["default"]
  },
  data: function data() {
    var self = this;
    return {
      total_items: 0,
      loading: true,
      pagination: {
        totalItems: 0
      },
      headers: [{
        text: self.trans('messages.action'),
        value: false,
        align: 'left',
        sortable: false
      }, {
        text: self.trans('messages.name'),
        value: 'name',
        align: 'left',
        sortable: true
      }, {
        text: self.trans('messages.prefix'),
        value: 'prefix',
        align: 'left',
        sortable: true
      }, {
        text: self.trans('messages.start_from'),
        value: 'start_number',
        align: 'left',
        sortable: true
      }, {
        text: self.trans('messages.invoice_count'),
        value: 'invoice_count',
        align: 'left',
        sortable: true
      }, {
        text: self.trans('messages.no_of_digits'),
        value: 'total_digits',
        align: 'left',
        sortable: true
      }],
      items: [],
      year_prefix: '#' + moment().format('YYYY')
    };
  },
  created: function created() {
    var self = this;
    self.$eventBus.$on('updateInvoiceSchemeTable', function (data) {
      self.getInvoiceSchemeFromApi();
    });
  },
  beforeDestroy: function beforeDestroy() {
    var self = this;
    self.$eventBus.$off('updateInvoiceSchemeTable');
  },
  watch: {
    pagination: {
      handler: function handler() {
        this.getInvoiceSchemeFromApi();
      }
    }
  },
  methods: {
    getInvoiceSchemeFromApi: function getInvoiceSchemeFromApi() {
      var self = this;
      self.loading = true;
      var _self$pagination = self.pagination,
        sortBy = _self$pagination.sortBy,
        descending = _self$pagination.descending,
        page = _self$pagination.page,
        rowsPerPage = _self$pagination.rowsPerPage;
      var params = {
        sort_by: sortBy,
        descending: descending,
        page: page,
        rowsPerPage: rowsPerPage
      };
      axios.get('/admin/invoice-scheme', {
        params: params
      }).then(function (response) {
        self.total_items = response.data.total;
        self.items = response.data.data;
        self.loading = false;
      })["catch"](function (error) {
        console.log(error);
      });
    },
    deleteInvoiceScheme: function deleteInvoiceScheme(invoice_scheme) {
      var self = this;
      self.$store.commit('showDialog', {
        type: 'confirm',
        icon: 'warning',
        title: self.trans('messages.are_you_sure'),
        message: self.trans('messages.you_cant_restore_it'),
        okCb: function okCb() {
          axios["delete"]('admin/invoice-scheme/' + invoice_scheme.id).then(function (response) {
            self.$store.commit('showSnackbar', {
              message: response.data.msg,
              color: response.data.success
            });
            if (response.data.success === true) {
              self.getInvoiceSchemeFromApi();
            }
          })["catch"](function (err) {
            console.log(err.response.status);
            if (err.response.status === 401) {
              store.dispatch('auth/handleResponse', err.response);
            }
          });
        },
        cancelCb: function cancelCb() {
          console.log('CANCEL');
        }
      });
    },
    edit: function edit(invoice_scheme) {
      var data = {
        id: invoice_scheme.id
      };
      this.$refs.invoiceSchemeEdit.edit(data);
    }
  }
});

/***/ }),

/***/ "./resources/js/admin/invoice_schemes/Add.vue":
/*!****************************************************!*\
  !*** ./resources/js/admin/invoice_schemes/Add.vue ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Add_vue_vue_type_template_id_77319a00___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Add.vue?vue&type=template&id=77319a00& */ "./resources/js/admin/invoice_schemes/Add.vue?vue&type=template&id=77319a00&");
/* harmony import */ var _Add_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Add.vue?vue&type=script&lang=js& */ "./resources/js/admin/invoice_schemes/Add.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Add_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Add_vue_vue_type_template_id_77319a00___WEBPACK_IMPORTED_MODULE_0__.render,
  _Add_vue_vue_type_template_id_77319a00___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/admin/invoice_schemes/Add.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/admin/invoice_schemes/Edit.vue":
/*!*****************************************************!*\
  !*** ./resources/js/admin/invoice_schemes/Edit.vue ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Edit_vue_vue_type_template_id_1ac84d3b___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Edit.vue?vue&type=template&id=1ac84d3b& */ "./resources/js/admin/invoice_schemes/Edit.vue?vue&type=template&id=1ac84d3b&");
/* harmony import */ var _Edit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Edit.vue?vue&type=script&lang=js& */ "./resources/js/admin/invoice_schemes/Edit.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Edit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Edit_vue_vue_type_template_id_1ac84d3b___WEBPACK_IMPORTED_MODULE_0__.render,
  _Edit_vue_vue_type_template_id_1ac84d3b___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/admin/invoice_schemes/Edit.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/admin/invoice_schemes/List.vue":
/*!*****************************************************!*\
  !*** ./resources/js/admin/invoice_schemes/List.vue ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _List_vue_vue_type_template_id_0b8025cf___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./List.vue?vue&type=template&id=0b8025cf& */ "./resources/js/admin/invoice_schemes/List.vue?vue&type=template&id=0b8025cf&");
/* harmony import */ var _List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./List.vue?vue&type=script&lang=js& */ "./resources/js/admin/invoice_schemes/List.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _List_vue_vue_type_template_id_0b8025cf___WEBPACK_IMPORTED_MODULE_0__.render,
  _List_vue_vue_type_template_id_0b8025cf___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/admin/invoice_schemes/List.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/admin/invoice_schemes/Add.vue?vue&type=script&lang=js&":
/*!*****************************************************************************!*\
  !*** ./resources/js/admin/invoice_schemes/Add.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Add_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Add.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/invoice_schemes/Add.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Add_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/admin/invoice_schemes/Edit.vue?vue&type=script&lang=js&":
/*!******************************************************************************!*\
  !*** ./resources/js/admin/invoice_schemes/Edit.vue?vue&type=script&lang=js& ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Edit.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/invoice_schemes/Edit.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/admin/invoice_schemes/List.vue?vue&type=script&lang=js&":
/*!******************************************************************************!*\
  !*** ./resources/js/admin/invoice_schemes/List.vue?vue&type=script&lang=js& ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./List.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/invoice_schemes/List.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/admin/invoice_schemes/Add.vue?vue&type=template&id=77319a00&":
/*!***********************************************************************************!*\
  !*** ./resources/js/admin/invoice_schemes/Add.vue?vue&type=template&id=77319a00& ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Add_vue_vue_type_template_id_77319a00___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Add_vue_vue_type_template_id_77319a00___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Add_vue_vue_type_template_id_77319a00___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Add.vue?vue&type=template&id=77319a00& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/invoice_schemes/Add.vue?vue&type=template&id=77319a00&");


/***/ }),

/***/ "./resources/js/admin/invoice_schemes/Edit.vue?vue&type=template&id=1ac84d3b&":
/*!************************************************************************************!*\
  !*** ./resources/js/admin/invoice_schemes/Edit.vue?vue&type=template&id=1ac84d3b& ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_template_id_1ac84d3b___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_template_id_1ac84d3b___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_template_id_1ac84d3b___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Edit.vue?vue&type=template&id=1ac84d3b& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/invoice_schemes/Edit.vue?vue&type=template&id=1ac84d3b&");


/***/ }),

/***/ "./resources/js/admin/invoice_schemes/List.vue?vue&type=template&id=0b8025cf&":
/*!************************************************************************************!*\
  !*** ./resources/js/admin/invoice_schemes/List.vue?vue&type=template&id=0b8025cf& ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_0b8025cf___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_0b8025cf___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_0b8025cf___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./List.vue?vue&type=template&id=0b8025cf& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/invoice_schemes/List.vue?vue&type=template&id=0b8025cf&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/invoice_schemes/Add.vue?vue&type=template&id=77319a00&":
/*!**************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/invoice_schemes/Add.vue?vue&type=template&id=77319a00& ***!
  \**************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "v-layout",
    { attrs: { row: "", "justify-center": "" } },
    [
      _c(
        "v-dialog",
        {
          attrs: { width: "800" },
          model: {
            value: _vm.dialog,
            callback: function ($$v) {
              _vm.dialog = $$v
            },
            expression: "dialog",
          },
        },
        [
          _c(
            "v-card",
            [
              _c(
                "v-card-title",
                [
                  _c("v-icon", { attrs: { medium: "" } }, [_vm._v("money")]),
                  _vm._v(" "),
                  _c("span", { staticClass: "headline" }, [
                    _vm._v(
                      "\n                    " +
                        _vm._s(_vm.trans("messages.new_scheme")) +
                        "\n                "
                    ),
                  ]),
                  _vm._v(" "),
                  _c("v-spacer"),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      attrs: { flat: "", icon: "" },
                      on: {
                        click: function ($event) {
                          _vm.dialog = false
                        },
                      },
                    },
                    [_c("v-icon", [_vm._v("clear")])],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("v-divider"),
              _vm._v(" "),
              _c(
                "v-card-text",
                [
                  _c(
                    "v-container",
                    { attrs: { "grid-list-md": "" } },
                    [
                      _c(
                        "v-layout",
                        { attrs: { row: "", wrap: "" } },
                        [
                          _c(
                            "v-flex",
                            { attrs: { xs8: "", sm8: "", md8: "" } },
                            [
                              _c(
                                "v-radio-group",
                                {
                                  attrs: { row: "" },
                                  on: { change: _vm.preview },
                                  model: {
                                    value: _vm.type,
                                    callback: function ($$v) {
                                      _vm.type = $$v
                                    },
                                    expression: "type",
                                  },
                                },
                                [
                                  _c("v-radio", {
                                    attrs: {
                                      label: _vm.trans(
                                        "messages.custom_prefix"
                                      ),
                                      value: "custom",
                                    },
                                  }),
                                  _vm._v(" "),
                                  _c("v-radio", {
                                    attrs: {
                                      label: _vm.trans("messages.year_prefix"),
                                      value: "year",
                                    },
                                  }),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _vm.preview_text
                            ? _c(
                                "v-flex",
                                { attrs: { xs4: "", sm4: "", md4: "" } },
                                [
                                  _c(
                                    "v-card",
                                    {
                                      staticClass: "white--text",
                                      attrs: { color: "blue-grey darken-2" },
                                    },
                                    [
                                      _c(
                                        "v-card-title",
                                        { attrs: { "primary-title": "" } },
                                        [
                                          _c("span", [
                                            _vm._v(_vm._s(_vm.preview_text)),
                                          ]),
                                        ]
                                      ),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              )
                            : _vm._e(),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm12: "", md12: "" } },
                            [
                              _c("v-text-field", {
                                directives: [
                                  {
                                    name: "validate",
                                    rawName: "v-validate",
                                    value: "required",
                                    expression: "'required'",
                                  },
                                ],
                                attrs: {
                                  label: _vm.trans("messages.name"),
                                  "data-vv-name": "name",
                                  "data-vv-as": _vm.trans("messages.name"),
                                  "error-messages": _vm.errors.collect("name"),
                                  required: "",
                                },
                                on: { change: _vm.preview },
                                model: {
                                  value: _vm.name,
                                  callback: function ($$v) {
                                    _vm.name = $$v
                                  },
                                  expression: "name",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs6: "", sm6: "", md6: "" } },
                            [
                              _c("v-text-field", {
                                directives: [
                                  {
                                    name: "validate",
                                    rawName: "v-validate",
                                    value: "required",
                                    expression: "'required'",
                                  },
                                ],
                                attrs: {
                                  label: _vm.trans("messages.prefix"),
                                  "data-vv-name": "prefix",
                                  "data-vv-as": _vm.trans("messages.prefix"),
                                  "error-messages":
                                    _vm.errors.collect("prefix"),
                                  required: "",
                                  disabled: _vm.type == "year",
                                },
                                on: { change: _vm.preview },
                                model: {
                                  value: _vm.prefix,
                                  callback: function ($$v) {
                                    _vm.prefix = $$v
                                  },
                                  expression: "prefix",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs6: "", sm6: "", md6: "" } },
                            [
                              _c("v-text-field", {
                                directives: [
                                  {
                                    name: "validate",
                                    rawName: "v-validate",
                                    value: "required",
                                    expression: "'required'",
                                  },
                                ],
                                attrs: {
                                  label: _vm.trans("messages.start_from"),
                                  "data-vv-name": "start_from",
                                  "data-vv-as": _vm.trans(
                                    "messages.start_from"
                                  ),
                                  "error-messages":
                                    _vm.errors.collect("start_from"),
                                  required: "",
                                },
                                on: { change: _vm.preview },
                                model: {
                                  value: _vm.start_from,
                                  callback: function ($$v) {
                                    _vm.start_from = $$v
                                  },
                                  expression: "start_from",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs6: "", sm6: "", md6: "" } },
                            [
                              _c("v-select", {
                                attrs: {
                                  items: _vm.no_of_digits_items,
                                  label: _vm.trans("messages.no_of_digits"),
                                },
                                on: { change: _vm.preview },
                                model: {
                                  value: _vm.no_of_digits,
                                  callback: function ($$v) {
                                    _vm.no_of_digits = $$v
                                  },
                                  expression: "no_of_digits",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs6: "", sm6: "", md6: "" } },
                            [
                              _c("v-checkbox", {
                                attrs: {
                                  label: _vm.trans("messages.is_default"),
                                },
                                model: {
                                  value: _vm.is_default,
                                  callback: function ($$v) {
                                    _vm.is_default = $$v
                                  },
                                  expression: "is_default",
                                },
                              }),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("v-divider"),
              _vm._v(" "),
              _c(
                "v-card-actions",
                [
                  _c("v-spacer"),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      attrs: { color: "green darken-1", flat: "" },
                      on: {
                        click: function ($event) {
                          _vm.dialog = false
                        },
                      },
                    },
                    [
                      _vm._v(
                        "\n                    " +
                          _vm._s(_vm.trans("messages.close")) +
                          "\n                "
                      ),
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    { attrs: { color: "success" }, on: { click: _vm.store } },
                    [_vm._v(" " + _vm._s(_vm.trans("messages.save")) + " ")]
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/invoice_schemes/Edit.vue?vue&type=template&id=1ac84d3b&":
/*!***************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/invoice_schemes/Edit.vue?vue&type=template&id=1ac84d3b& ***!
  \***************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "v-layout",
    { attrs: { row: "", "justify-center": "" } },
    [
      _c(
        "v-dialog",
        {
          attrs: { width: "800" },
          model: {
            value: _vm.dialog,
            callback: function ($$v) {
              _vm.dialog = $$v
            },
            expression: "dialog",
          },
        },
        [
          _c(
            "v-card",
            [
              _c(
                "v-card-title",
                [
                  _c("v-icon", { attrs: { medium: "" } }, [_vm._v("money")]),
                  _vm._v(" "),
                  _c("span", { staticClass: "headline" }, [
                    _vm._v(
                      "\n                    " +
                        _vm._s(_vm.trans("messages.edit_scheme")) +
                        "\n                "
                    ),
                  ]),
                  _vm._v(" "),
                  _c("v-spacer"),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      attrs: { flat: "", icon: "" },
                      on: {
                        click: function ($event) {
                          _vm.dialog = false
                        },
                      },
                    },
                    [_c("v-icon", [_vm._v("clear")])],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("v-divider"),
              _vm._v(" "),
              _c(
                "v-card-text",
                [
                  _c(
                    "v-container",
                    { attrs: { "grid-list-md": "" } },
                    [
                      _c(
                        "v-layout",
                        { attrs: { row: "", wrap: "" } },
                        [
                          _c(
                            "v-flex",
                            { attrs: { xs8: "", sm8: "", md8: "" } },
                            [
                              _c(
                                "v-radio-group",
                                {
                                  attrs: { row: "" },
                                  on: { change: _vm.preview },
                                  model: {
                                    value: _vm.type,
                                    callback: function ($$v) {
                                      _vm.type = $$v
                                    },
                                    expression: "type",
                                  },
                                },
                                [
                                  _c("v-radio", {
                                    attrs: {
                                      label: _vm.trans(
                                        "messages.custom_prefix"
                                      ),
                                      value: "custom",
                                    },
                                  }),
                                  _vm._v(" "),
                                  _c("v-radio", {
                                    attrs: {
                                      label: _vm.trans("messages.year_prefix"),
                                      value: "year",
                                    },
                                  }),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _vm.preview_text
                            ? _c(
                                "v-flex",
                                { attrs: { xs4: "", sm4: "", md4: "" } },
                                [
                                  _c(
                                    "v-card",
                                    {
                                      staticClass: "white--text",
                                      attrs: { color: "blue-grey darken-2" },
                                    },
                                    [
                                      _c(
                                        "v-card-title",
                                        { attrs: { "primary-title": "" } },
                                        [
                                          _c("span", [
                                            _vm._v(_vm._s(_vm.preview_text)),
                                          ]),
                                        ]
                                      ),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              )
                            : _vm._e(),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm12: "", md12: "" } },
                            [
                              _c("v-text-field", {
                                directives: [
                                  {
                                    name: "validate",
                                    rawName: "v-validate",
                                    value: "required",
                                    expression: "'required'",
                                  },
                                ],
                                attrs: {
                                  label: _vm.trans("messages.name"),
                                  "data-vv-name": "name",
                                  "data-vv-as": _vm.trans("messages.name"),
                                  "error-messages": _vm.errors.collect("name"),
                                  required: "",
                                },
                                on: { change: _vm.preview },
                                model: {
                                  value: _vm.name,
                                  callback: function ($$v) {
                                    _vm.name = $$v
                                  },
                                  expression: "name",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs6: "", sm6: "", md6: "" } },
                            [
                              _c("v-text-field", {
                                directives: [
                                  {
                                    name: "validate",
                                    rawName: "v-validate",
                                    value: "required",
                                    expression: "'required'",
                                  },
                                ],
                                attrs: {
                                  label: _vm.trans("messages.prefix"),
                                  "data-vv-name": "prefix",
                                  "data-vv-as": _vm.trans("messages.prefix"),
                                  "error-messages":
                                    _vm.errors.collect("prefix"),
                                  required: "",
                                  disabled: _vm.type == "year",
                                },
                                on: { change: _vm.preview },
                                model: {
                                  value: _vm.prefix,
                                  callback: function ($$v) {
                                    _vm.prefix = $$v
                                  },
                                  expression: "prefix",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs6: "", sm6: "", md6: "" } },
                            [
                              _c("v-text-field", {
                                directives: [
                                  {
                                    name: "validate",
                                    rawName: "v-validate",
                                    value: "required",
                                    expression: "'required'",
                                  },
                                ],
                                attrs: {
                                  label: _vm.trans("messages.start_from"),
                                  "data-vv-name": "start_from",
                                  "data-vv-as": _vm.trans(
                                    "messages.start_from"
                                  ),
                                  "error-messages":
                                    _vm.errors.collect("start_from"),
                                  required: "",
                                },
                                on: { change: _vm.preview },
                                model: {
                                  value: _vm.start_from,
                                  callback: function ($$v) {
                                    _vm.start_from = $$v
                                  },
                                  expression: "start_from",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs6: "", sm6: "", md6: "" } },
                            [
                              _c("v-select", {
                                attrs: {
                                  items: _vm.no_of_digits_items,
                                  label: _vm.trans("messages.no_of_digits"),
                                },
                                on: { change: _vm.preview },
                                model: {
                                  value: _vm.no_of_digits,
                                  callback: function ($$v) {
                                    _vm.no_of_digits = $$v
                                  },
                                  expression: "no_of_digits",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs6: "", sm6: "", md6: "" } },
                            [
                              _c("v-checkbox", {
                                attrs: {
                                  label: _vm.trans("messages.is_default"),
                                },
                                model: {
                                  value: _vm.is_default,
                                  callback: function ($$v) {
                                    _vm.is_default = $$v
                                  },
                                  expression: "is_default",
                                },
                              }),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("v-divider"),
              _vm._v(" "),
              _c(
                "v-card-actions",
                [
                  _c("v-spacer"),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      attrs: { color: "green darken-1", flat: "" },
                      on: {
                        click: function ($event) {
                          _vm.dialog = false
                        },
                      },
                    },
                    [
                      _vm._v(
                        "\n                    " +
                          _vm._s(_vm.trans("messages.close")) +
                          "\n                "
                      ),
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    { attrs: { color: "success" }, on: { click: _vm.store } },
                    [_vm._v(" " + _vm._s(_vm.trans("messages.update")) + " ")]
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/invoice_schemes/List.vue?vue&type=template&id=0b8025cf&":
/*!***************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/invoice_schemes/List.vue?vue&type=template&id=0b8025cf& ***!
  \***************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "component-wrap" },
    [
      _c("InvoiceSchemeAdd", { ref: "invoiceSchemeAdd" }),
      _vm._v(" "),
      _c("InvoiceSchemeEdit", { ref: "invoiceSchemeEdit" }),
      _vm._v(" "),
      _c(
        "v-card",
        [
          _c(
            "v-card-title",
            [
              _c("div", [
                _c("div", { staticClass: "headline" }, [
                  _vm._v(
                    "\n                    " +
                      _vm._s(_vm.trans("messages.all_invoice_schemes")) +
                      "\n                "
                  ),
                ]),
              ]),
              _vm._v(" "),
              _c("v-spacer"),
              _vm._v(" "),
              _vm.$can("invoice_scheme.create")
                ? _c(
                    "v-btn",
                    {
                      staticClass: "primary lighten-1",
                      attrs: { dark: "" },
                      on: {
                        click: function ($event) {
                          return _vm.$refs.invoiceSchemeAdd.create()
                        },
                      },
                    },
                    [
                      _vm._v(
                        "\n                " +
                          _vm._s(_vm.trans("messages.new_scheme")) +
                          "\n                "
                      ),
                      _c("v-icon", { attrs: { right: "", dark: "" } }, [
                        _vm._v("add"),
                      ]),
                    ],
                    1
                  )
                : _vm._e(),
            ],
            1
          ),
          _vm._v(" "),
          _c("v-divider"),
          _vm._v(" "),
          _c("v-data-table", {
            staticClass: "elevation-3 w-full",
            attrs: {
              headers: _vm.headers,
              pagination: _vm.pagination,
              "total-items": _vm.total_items,
              loading: _vm.loading,
              items: _vm.items,
            },
            on: {
              "update:pagination": function ($event) {
                _vm.pagination = $event
              },
            },
            scopedSlots: _vm._u([
              {
                key: "headerCell",
                fn: function (props) {
                  return [
                    props.header.value == "name"
                      ? _c("span", [
                          _vm._v(
                            "\n                    " +
                              _vm._s(props.header.text) +
                              "\n                "
                          ),
                        ])
                      : props.header.value == "prefix"
                      ? _c("span", [
                          _vm._v(
                            "\n                    " +
                              _vm._s(props.header.text) +
                              "\n                "
                          ),
                        ])
                      : props.header.value == "start_number"
                      ? _c("span", [
                          _vm._v(
                            "\n                    " +
                              _vm._s(props.header.text) +
                              "\n                "
                          ),
                        ])
                      : props.header.value == "invoice_count"
                      ? _c("span", [
                          _vm._v(
                            "\n                    " +
                              _vm._s(props.header.text) +
                              "\n                "
                          ),
                        ])
                      : props.header.value == "total_digits"
                      ? _c("span", [
                          _vm._v(
                            "\n                    " +
                              _vm._s(props.header.text) +
                              "\n                "
                          ),
                        ])
                      : _c("span", [_vm._v(_vm._s(props.header.text))]),
                  ]
                },
              },
              {
                key: "items",
                fn: function (props) {
                  return [
                    _c(
                      "td",
                      [
                        _c(
                          "v-menu",
                          [
                            _c(
                              "v-btn",
                              {
                                attrs: { slot: "activator", icon: "" },
                                slot: "activator",
                              },
                              [_c("v-icon", [_vm._v("more_vert")])],
                              1
                            ),
                            _vm._v(" "),
                            _c(
                              "v-list",
                              [
                                _c(
                                  "v-list-tile",
                                  {
                                    on: {
                                      click: function ($event) {
                                        return _vm.edit(props.item)
                                      },
                                    },
                                  },
                                  [
                                    _c(
                                      "v-list-tile-title",
                                      [
                                        _c(
                                          "v-icon",
                                          {
                                            staticClass: "mr-2",
                                            attrs: { small: "" },
                                          },
                                          [_vm._v(" edit ")]
                                        ),
                                        _vm._v(
                                          "\n                                    " +
                                            _vm._s(_vm.trans("messages.edit")) +
                                            "\n                                "
                                        ),
                                      ],
                                      1
                                    ),
                                  ],
                                  1
                                ),
                                _vm._v(" "),
                                _c(
                                  "v-list-tile",
                                  {
                                    on: {
                                      click: function ($event) {
                                        return _vm.deleteInvoiceScheme(
                                          props.item
                                        )
                                      },
                                    },
                                  },
                                  [
                                    _c(
                                      "v-list-tile-title",
                                      [
                                        _c(
                                          "v-icon",
                                          {
                                            staticClass: "mr-2",
                                            attrs: { small: "" },
                                          },
                                          [_vm._v(" delete_forever ")]
                                        ),
                                        _vm._v(
                                          "\n                                    " +
                                            _vm._s(
                                              _vm.trans("messages.delete")
                                            ) +
                                            "\n                                "
                                        ),
                                      ],
                                      1
                                    ),
                                  ],
                                  1
                                ),
                              ],
                              1
                            ),
                          ],
                          1
                        ),
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "td",
                      [
                        _vm._v(
                          "\n                    " +
                            _vm._s(props.item.name) +
                            "\n                    "
                        ),
                        props.item.is_default == 1
                          ? _c(
                              "v-chip",
                              {
                                attrs: {
                                  color: "green",
                                  "text-color": "white",
                                  small: "",
                                },
                              },
                              [_vm._v(_vm._s(_vm.trans("messages.default")))]
                            )
                          : _vm._e(),
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c("td", [
                      _vm._v(
                        "\n                    " +
                          _vm._s(
                            props.item.scheme_type == "year"
                              ? _vm.year_prefix
                              : props.item.prefix
                          ) +
                          "\n                "
                      ),
                    ]),
                    _vm._v(" "),
                    _c("td", [_vm._v(_vm._s(props.item.start_number))]),
                    _vm._v(" "),
                    _c("td", [_vm._v(_vm._s(props.item.invoice_count))]),
                    _vm._v(" "),
                    _c("td", [_vm._v(_vm._s(props.item.total_digits))]),
                  ]
                },
              },
            ]),
          }),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);