"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_admin_invoices_List_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/invoices/InvoiceReminder.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/invoices/InvoiceReminder.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  data: function data() {
    return {
      dialog: false,
      transaction_id: null,
      project_id: null,
      form_fields: [],
      loading: false
    };
  },
  methods: {
    create: function create(data) {
      var self = this;
      self.transaction_id = data.transaction_id;
      self.project_id = data.project_id;
      axios.get('invoices/get-invoice-reminder', {
        params: {
          transaction_id: data.transaction_id,
          project_id: data.project_id
        }
      }).then(function (response) {
        self.form_fields = response.data;
        self.form_fields.attachment = response.data.attachment.toString();
        self.dialog = true;
      })["catch"](function (error) {
        console.log(error);
      });
    },
    sendNotification: function sendNotification() {
      var self = this;
      var data = _.pick(self.form_fields, ['email', 'subject', 'body', 'attachment']);
      data.transaction_id = self.transaction_id;
      self.$validator.validateAll().then(function (result) {
        if (result == true) {
          self.loading = true;
          axios.post('invoices/post-invoice-reminder', data).then(function (response) {
            self.loading = false;
            self.$store.commit('showSnackbar', {
              message: response.data.msg,
              color: response.data.success
            });
            if (response.data.success === true) {
              self.dialog = false;
            }
          })["catch"](function (err) {
            console.log(err.response.status);
            if (err.response.status === 401) {
              store.dispatch('auth/handleResponse', err.response);
            }
          });
        }
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/invoices/List.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/invoices/List.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _common_projects_invoices_Show__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../common/projects/invoices/Show */ "./resources/js/common/projects/invoices/Show.vue");
/* harmony import */ var _common_projects_invoices_payment_InvoicePayment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../common/projects/invoices/payment/InvoicePayment */ "./resources/js/common/projects/invoices/payment/InvoicePayment.vue");
/* harmony import */ var _invoices_InvoiceReminder__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../invoices/InvoiceReminder */ "./resources/js/admin/invoices/InvoiceReminder.vue");
/* harmony import */ var _common_projects_invoices_payment_ViewPayment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../common/projects/invoices/payment/ViewPayment */ "./resources/js/common/projects/invoices/payment/ViewPayment.vue");
/* harmony import */ var _status_StatusLabel__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../status/StatusLabel */ "./resources/js/admin/status/StatusLabel.vue");
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../store */ "./resources/js/store/index.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//







/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  components: {
    InvoiceShow: _common_projects_invoices_Show__WEBPACK_IMPORTED_MODULE_0__["default"],
    InvoicePayment: _common_projects_invoices_payment_InvoicePayment__WEBPACK_IMPORTED_MODULE_1__["default"],
    InvoiceReminder: _invoices_InvoiceReminder__WEBPACK_IMPORTED_MODULE_2__["default"],
    ViewPayment: _common_projects_invoices_payment_ViewPayment__WEBPACK_IMPORTED_MODULE_3__["default"],
    StatusLabel: _status_StatusLabel__WEBPACK_IMPORTED_MODULE_4__["default"]
  },
  data: function data() {
    var self = this;
    return {
      projectId: null,
      total_items: 0,
      loading: true,
      pagination: {
        totalItems: 0
      },
      headers: [{
        text: self.trans('messages.action'),
        value: false,
        align: 'left',
        sortable: false
      }, {
        text: self.trans('data.id'),
        value: 'id',
        align: 'left',
        sortable: true
      }, {
        text: self.trans('messages.date'),
        value: 'invoice_date',
        align: 'left',
        sortable: true
      }, {
        text: self.trans('messages.invoice_number'),
        value: 'invoice_number',
        align: 'left',
        sortable: true
      }, {
        text: self.trans('messages.project'),
        value: 'project',
        align: 'left',
        sortable: true
      }, {
        text: self.trans('messages.customer'),
        value: 'customer',
        align: 'left',
        sortable: true
      }, {
        text: self.trans('messages.payment_status'),
        value: 'payment_status',
        align: 'left',
        sortable: true
      }, {
        text: self.trans('messages.due_date'),
        value: 'due_date',
        align: 'left',
        sortable: true
      }],
      items: [],
      filters: [],
      projectList: [],
      customers: [],
      paymentStatuses: [],
      tabs: 'tab-1',
      invoiceStats: [],
      currency: [],
      paid_amount: 0
    };
  },
  created: function created() {
    var self = this;
    self.getFilterData();
    self.getStatistics();
    self.$eventBus.$on('updatePaymentTransaction', function (data) {
      self.getInvoiceFromApi();
      self.getStatistics();
    });
  },
  beforeDestroy: function beforeDestroy() {
    var self = this;
    self.$eventBus.$off('updatePaymentTransaction');
  },
  watch: {
    pagination: {
      handler: function handler() {
        this.getInvoiceFromApi();
      }
    }
  },
  methods: {
    getInvoiceFromApi: function getInvoiceFromApi() {
      var self = this;
      self.loading = true;
      var _self$pagination = self.pagination,
        sortBy = _self$pagination.sortBy,
        descending = _self$pagination.descending,
        page = _self$pagination.page,
        rowsPerPage = _self$pagination.rowsPerPage;
      var params = {
        sort_by: sortBy,
        descending: descending,
        page: page,
        rowsPerPage: rowsPerPage,
        project_id: self.projectId
      };
      if (self.filters.project_id) {
        params['project_id'] = self.filters.project_id;
      }
      if (self.filters.payment_status) {
        params['payment_status'] = self.filters.payment_status;
      }
      if (self.filters.customer_id) {
        params['customer_id'] = self.filters.customer_id;
      }
      axios.get('/invoices', {
        params: params
      }).then(function (response) {
        self.total_items = response.data.transactions.total;
        self.items = response.data.transactions.data;
        self.loading = false;
      })["catch"](function (err) {
        console.log(err.response.status);
        if (err.response.status === 401) {
          _store__WEBPACK_IMPORTED_MODULE_5__["default"].dispatch('auth/handleResponse', err.response);
        }
      });
    },
    deleteInvoice: function deleteInvoice(invoice) {
      var self = this;
      self.$store.commit('showDialog', {
        type: 'confirm',
        icon: 'warning',
        title: self.trans('messages.are_you_sure'),
        message: self.trans('messages.you_cant_restore_it'),
        okCb: function okCb() {
          axios["delete"]('/invoices/' + invoice.id, {
            params: {
              project_id: invoice.project_id
            }
          }).then(function (response) {
            self.$store.commit('showSnackbar', {
              message: response.data.msg,
              color: response.data.success
            });
            if (response.data.success === true) {
              self.getInvoiceFromApi();
              self.getStatistics();
            }
          })["catch"](function (err) {
            console.log(err.response.status);
            if (err.response.status === 401) {
              _store__WEBPACK_IMPORTED_MODULE_5__["default"].dispatch('auth/handleResponse', err.response);
            }
          });
        },
        cancelCb: function cancelCb() {
          console.log('CANCEL');
        }
      });
    },
    view: function view(invoice) {
      var self = this;
      var data = {
        transaction_id: invoice.id,
        project_id: invoice.project_id
      };
      self.$refs.invoiceShow.view(data);
    },
    edit: function edit(invoice) {
      var self = this;
      self.$router.push({
        name: 'invoices.edit',
        params: {
          id: invoice.id,
          project_id: invoice.project_id
        }
      });
    },
    payDueAmountForInvoice: function payDueAmountForInvoice(item) {
      var self = this;
      var data = {
        transaction_id: item.id,
        type: 'invoice'
      };
      self.$refs.invoicePayment.create(data);
    },
    getFilterData: function getFilterData() {
      var self = this;
      axios.get('invoices/get-filter-data').then(function (response) {
        self.projectList = response.data.projects;
        self.customers = response.data.customers;
        self.paymentStatuses = response.data.payment_statuses;
      })["catch"](function (err) {
        console.log(err.response.status);
        if (err.response.status === 401) {
          _store__WEBPACK_IMPORTED_MODULE_5__["default"].dispatch('auth/handleResponse', err.response);
        }
      });
    },
    filterChanged: function filterChanged() {
      var self = this;
      self.getInvoiceFromApi();
    },
    convertToInvoice: function convertToInvoice(item) {
      var self = this;
      axios.get('invoices/' + item.id + '/convert-to-invoice', {
        params: {
          project_id: item.project_id
        }
      }).then(function (response) {
        self.$store.commit('showSnackbar', {
          message: response.data.msg,
          color: response.data.success
        });
        if (response.data.success === true) {
          self.getInvoiceFromApi();
          self.getStatistics();
        }
      })["catch"](function (err) {
        console.log(err.response.status);
        if (err.response.status === 401) {
          _store__WEBPACK_IMPORTED_MODULE_5__["default"].dispatch('auth/handleResponse', err.response);
        }
      });
    },
    sendReminder: function sendReminder(item) {
      var data = {
        transaction_id: item.id,
        project_id: item.project_id
      };
      this.$refs.invoiceReminder.create(data);
    },
    viewPayment: function viewPayment(transaction_id) {
      var data = {
        transaction_id: transaction_id,
        type: 'invoice'
      };
      this.$refs.viewPayment.view(data);
    },
    getStatistics: function getStatistics() {
      var self = this;
      if (self.$can('superadmin')) {
        axios.get('/invoice-statistics').then(function (response) {
          self.invoiceStats = response.data.payment_stats;
          self.currency = response.data.currency;
          self.paid_amount = response.data.paid_amount.paid_amount;
        })["catch"](function (err) {
          console.log(err.response.status);
          if (err.response.status === 401) {
            _store__WEBPACK_IMPORTED_MODULE_5__["default"].dispatch('auth/handleResponse', err.response);
          }
        });
      }
    },
    totalTransactionCount: function totalTransactionCount(transactions) {
      var total = 0;
      _.forEach(transactions, function (transaction) {
        total = _.add(total, parseInt(transaction.payment_status_count));
      });
      return total;
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/status/StatusLabel.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/status/StatusLabel.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  props: ['status'],
  methods: {
    color: function color(status) {
      if (status === 'approved' || status === 'paid' || status === 'closed') {
        return 'green lighten-1';
      } else if (status === 'cancelled' || status === 'due' || status === 'new' || status === 'urgent') {
        return 'red accent-2';
      } else if (status === 'pending' || status === 'partial') {
        return 'cyan lighten-2';
      } else if (status === 'open') {
        return 'pink lighten-1';
      } else if (status === 'low') {
        return 'yellow darken-4';
      } else if (status === 'medium') {
        return 'deep-orange lighten-2';
      } else if (status === 'high') {
        return 'red accent-1';
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/invoices/payment/InvoicePayment.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/invoices/payment/InvoicePayment.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _admin_popover_Popover__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../admin/popover/Popover */ "./resources/js/admin/popover/Popover.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  components: {
    Popover: _admin_popover_Popover__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  data: function data() {
    return {
      dialog: false,
      paid_on: null,
      transaction_id: null,
      transaction_total: null,
      payment_details: null,
      conversion_rate: null,
      show_conversion_rate: null,
      final_amount: null,
      max_val: null,
      loading: false
    };
  },
  methods: {
    create: function create(invoice_params) {
      var self = this;
      self.$validator.reset();
      self.payment_details = null;
      self.transaction_total = null;
      self.paid_on = null;
      self.conversion_rate = null;
      self.final_amount = null;
      self.transaction_id = invoice_params.transaction_id;
      axios.get('/transaction-payments/create', {
        params: {
          transaction_id: invoice_params.transaction_id,
          type: invoice_params.type
        }
      }).then(function (response) {
        self.transaction_total = response.data.transaction_total;
        self.max_val = response.data.transaction_total;
        self.show_conversion_rate = response.data.conversion_rate;
        self.dialog = true;
      })["catch"](function (error) {
        console.log(error);
      });
    },
    calculateFinalAmount: function calculateFinalAmount() {
      var self = this;
      var final_amount = _.multiply(self.transaction_total, self.conversion_rate);
      self.final_amount = _.floor(final_amount, 2);
    },
    calculateConversionRate: function calculateConversionRate() {
      var self = this;
      var rate = _.divide(self.final_amount, self.transaction_total);
      self.conversion_rate = _.floor(rate);
    },
    store: function (_store) {
      function store() {
        return _store.apply(this, arguments);
      }
      store.toString = function () {
        return _store.toString();
      };
      return store;
    }(function () {
      var self = this;
      var data = {
        transaction_id: self.transaction_id,
        amount: self.transaction_total,
        paid_on: self.paid_on,
        payment_details: self.payment_details,
        conversion_rate: self.conversion_rate
      };
      self.$validator.validateAll().then(function (result) {
        if (result == true) {
          self.loading = true;
          axios.post('/transaction-payments', data).then(function (response) {
            self.loading = false;
            self.dialog = false;
            self.$store.commit('showSnackbar', {
              message: response.data.msg,
              color: response.data.success
            });
            if (response.data.success === true) {
              self.$eventBus.$emit('updatePaymentTransaction');
            }
          })["catch"](function (err) {
            console.log(err.response.status);
            if (err.response.status === 401) {
              store.dispatch('auth/handleResponse', err.response);
            }
          });
        }
      });
    })
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/invoices/payment/ViewPayment.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/invoices/payment/ViewPayment.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  data: function data() {
    return {
      dialog: false,
      transaction: [],
      payments: [],
      employee: [],
      project: [],
      customer: [],
      customer_currency: [],
      business_currency: []
    };
  },
  methods: {
    view: function view(invoice_params) {
      var self = this;
      axios.get('/transaction-payments/' + invoice_params.transaction_id, {
        params: {
          type: invoice_params.type
        }
      }).then(function (response) {
        self.transaction = response.data.transaction;
        self.payments = response.data.transaction.payments;
        self.project = response.data.transaction.project;
        self.employee = response.data.transaction.expense_for;
        self.customer = response.data.transaction.customer;
        self.customer_currency = response.data.currency.customer;
        self.business_currency = response.data.currency.business;
        self.dialog = true;
      })["catch"](function (error) {
        console.log(error);
      });
    }
  }
});

/***/ }),

/***/ "./resources/js/admin/invoices/InvoiceReminder.vue":
/*!*********************************************************!*\
  !*** ./resources/js/admin/invoices/InvoiceReminder.vue ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _InvoiceReminder_vue_vue_type_template_id_2c873b34___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./InvoiceReminder.vue?vue&type=template&id=2c873b34& */ "./resources/js/admin/invoices/InvoiceReminder.vue?vue&type=template&id=2c873b34&");
/* harmony import */ var _InvoiceReminder_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./InvoiceReminder.vue?vue&type=script&lang=js& */ "./resources/js/admin/invoices/InvoiceReminder.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _InvoiceReminder_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _InvoiceReminder_vue_vue_type_template_id_2c873b34___WEBPACK_IMPORTED_MODULE_0__.render,
  _InvoiceReminder_vue_vue_type_template_id_2c873b34___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/admin/invoices/InvoiceReminder.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/admin/invoices/List.vue":
/*!**********************************************!*\
  !*** ./resources/js/admin/invoices/List.vue ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _List_vue_vue_type_template_id_a934f20e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./List.vue?vue&type=template&id=a934f20e& */ "./resources/js/admin/invoices/List.vue?vue&type=template&id=a934f20e&");
/* harmony import */ var _List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./List.vue?vue&type=script&lang=js& */ "./resources/js/admin/invoices/List.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _List_vue_vue_type_template_id_a934f20e___WEBPACK_IMPORTED_MODULE_0__.render,
  _List_vue_vue_type_template_id_a934f20e___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/admin/invoices/List.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/admin/status/StatusLabel.vue":
/*!***************************************************!*\
  !*** ./resources/js/admin/status/StatusLabel.vue ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _StatusLabel_vue_vue_type_template_id_2169abba___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./StatusLabel.vue?vue&type=template&id=2169abba& */ "./resources/js/admin/status/StatusLabel.vue?vue&type=template&id=2169abba&");
/* harmony import */ var _StatusLabel_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./StatusLabel.vue?vue&type=script&lang=js& */ "./resources/js/admin/status/StatusLabel.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _StatusLabel_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _StatusLabel_vue_vue_type_template_id_2169abba___WEBPACK_IMPORTED_MODULE_0__.render,
  _StatusLabel_vue_vue_type_template_id_2169abba___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/admin/status/StatusLabel.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/common/projects/invoices/payment/InvoicePayment.vue":
/*!**************************************************************************!*\
  !*** ./resources/js/common/projects/invoices/payment/InvoicePayment.vue ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _InvoicePayment_vue_vue_type_template_id_d154f0a8___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./InvoicePayment.vue?vue&type=template&id=d154f0a8& */ "./resources/js/common/projects/invoices/payment/InvoicePayment.vue?vue&type=template&id=d154f0a8&");
/* harmony import */ var _InvoicePayment_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./InvoicePayment.vue?vue&type=script&lang=js& */ "./resources/js/common/projects/invoices/payment/InvoicePayment.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _InvoicePayment_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _InvoicePayment_vue_vue_type_template_id_d154f0a8___WEBPACK_IMPORTED_MODULE_0__.render,
  _InvoicePayment_vue_vue_type_template_id_d154f0a8___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/common/projects/invoices/payment/InvoicePayment.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/common/projects/invoices/payment/ViewPayment.vue":
/*!***********************************************************************!*\
  !*** ./resources/js/common/projects/invoices/payment/ViewPayment.vue ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _ViewPayment_vue_vue_type_template_id_62673fc4___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ViewPayment.vue?vue&type=template&id=62673fc4& */ "./resources/js/common/projects/invoices/payment/ViewPayment.vue?vue&type=template&id=62673fc4&");
/* harmony import */ var _ViewPayment_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ViewPayment.vue?vue&type=script&lang=js& */ "./resources/js/common/projects/invoices/payment/ViewPayment.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _ViewPayment_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _ViewPayment_vue_vue_type_template_id_62673fc4___WEBPACK_IMPORTED_MODULE_0__.render,
  _ViewPayment_vue_vue_type_template_id_62673fc4___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/common/projects/invoices/payment/ViewPayment.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/admin/invoices/InvoiceReminder.vue?vue&type=script&lang=js&":
/*!**********************************************************************************!*\
  !*** ./resources/js/admin/invoices/InvoiceReminder.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InvoiceReminder_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./InvoiceReminder.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/invoices/InvoiceReminder.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InvoiceReminder_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/admin/invoices/List.vue?vue&type=script&lang=js&":
/*!***********************************************************************!*\
  !*** ./resources/js/admin/invoices/List.vue?vue&type=script&lang=js& ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./List.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/invoices/List.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/admin/status/StatusLabel.vue?vue&type=script&lang=js&":
/*!****************************************************************************!*\
  !*** ./resources/js/admin/status/StatusLabel.vue?vue&type=script&lang=js& ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_StatusLabel_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StatusLabel.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/status/StatusLabel.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_StatusLabel_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/common/projects/invoices/payment/InvoicePayment.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************!*\
  !*** ./resources/js/common/projects/invoices/payment/InvoicePayment.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InvoicePayment_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./InvoicePayment.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/invoices/payment/InvoicePayment.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InvoicePayment_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/common/projects/invoices/payment/ViewPayment.vue?vue&type=script&lang=js&":
/*!************************************************************************************************!*\
  !*** ./resources/js/common/projects/invoices/payment/ViewPayment.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ViewPayment_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./ViewPayment.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/invoices/payment/ViewPayment.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ViewPayment_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/admin/invoices/InvoiceReminder.vue?vue&type=template&id=2c873b34&":
/*!****************************************************************************************!*\
  !*** ./resources/js/admin/invoices/InvoiceReminder.vue?vue&type=template&id=2c873b34& ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_InvoiceReminder_vue_vue_type_template_id_2c873b34___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_InvoiceReminder_vue_vue_type_template_id_2c873b34___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_InvoiceReminder_vue_vue_type_template_id_2c873b34___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./InvoiceReminder.vue?vue&type=template&id=2c873b34& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/invoices/InvoiceReminder.vue?vue&type=template&id=2c873b34&");


/***/ }),

/***/ "./resources/js/admin/invoices/List.vue?vue&type=template&id=a934f20e&":
/*!*****************************************************************************!*\
  !*** ./resources/js/admin/invoices/List.vue?vue&type=template&id=a934f20e& ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_a934f20e___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_a934f20e___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_a934f20e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./List.vue?vue&type=template&id=a934f20e& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/invoices/List.vue?vue&type=template&id=a934f20e&");


/***/ }),

/***/ "./resources/js/admin/status/StatusLabel.vue?vue&type=template&id=2169abba&":
/*!**********************************************************************************!*\
  !*** ./resources/js/admin/status/StatusLabel.vue?vue&type=template&id=2169abba& ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StatusLabel_vue_vue_type_template_id_2169abba___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StatusLabel_vue_vue_type_template_id_2169abba___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StatusLabel_vue_vue_type_template_id_2169abba___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StatusLabel.vue?vue&type=template&id=2169abba& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/status/StatusLabel.vue?vue&type=template&id=2169abba&");


/***/ }),

/***/ "./resources/js/common/projects/invoices/payment/InvoicePayment.vue?vue&type=template&id=d154f0a8&":
/*!*********************************************************************************************************!*\
  !*** ./resources/js/common/projects/invoices/payment/InvoicePayment.vue?vue&type=template&id=d154f0a8& ***!
  \*********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_InvoicePayment_vue_vue_type_template_id_d154f0a8___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_InvoicePayment_vue_vue_type_template_id_d154f0a8___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_InvoicePayment_vue_vue_type_template_id_d154f0a8___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./InvoicePayment.vue?vue&type=template&id=d154f0a8& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/invoices/payment/InvoicePayment.vue?vue&type=template&id=d154f0a8&");


/***/ }),

/***/ "./resources/js/common/projects/invoices/payment/ViewPayment.vue?vue&type=template&id=62673fc4&":
/*!******************************************************************************************************!*\
  !*** ./resources/js/common/projects/invoices/payment/ViewPayment.vue?vue&type=template&id=62673fc4& ***!
  \******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ViewPayment_vue_vue_type_template_id_62673fc4___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ViewPayment_vue_vue_type_template_id_62673fc4___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ViewPayment_vue_vue_type_template_id_62673fc4___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./ViewPayment.vue?vue&type=template&id=62673fc4& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/invoices/payment/ViewPayment.vue?vue&type=template&id=62673fc4&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/invoices/InvoiceReminder.vue?vue&type=template&id=2c873b34&":
/*!*******************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/invoices/InvoiceReminder.vue?vue&type=template&id=2c873b34& ***!
  \*******************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "v-layout",
    { attrs: { row: "", "justify-center": "" } },
    [
      _c(
        "v-dialog",
        {
          model: {
            value: _vm.dialog,
            callback: function ($$v) {
              _vm.dialog = $$v
            },
            expression: "dialog",
          },
        },
        [
          _c(
            "v-card",
            [
              _c(
                "v-card-title",
                [
                  _c(
                    "span",
                    { staticClass: "headline" },
                    [
                      _c("v-icon", [_vm._v("receipt")]),
                      _vm._v(
                        "\n                    " +
                          _vm._s(_vm.trans("messages.send_invoice_reminder")) +
                          "\n                "
                      ),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("v-spacer"),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      attrs: { flat: "", icon: "", small: "" },
                      on: {
                        click: function ($event) {
                          _vm.dialog = false
                        },
                      },
                    },
                    [_c("v-icon", [_vm._v("clear")])],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("v-divider"),
              _vm._v(" "),
              _c(
                "v-card-text",
                [
                  _c(
                    "v-container",
                    { attrs: { "grid-list-md": "" } },
                    [
                      _c(
                        "v-layout",
                        { attrs: { wrap: "" } },
                        [
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm12: "", md12: "" } },
                            [
                              _c("v-text-field", {
                                directives: [
                                  {
                                    name: "validate",
                                    rawName: "v-validate",
                                    value: "required",
                                    expression: "'required'",
                                  },
                                ],
                                attrs: {
                                  label: _vm.trans("messages.email"),
                                  "data-vv-name": "email",
                                  "data-vv-as": _vm.trans("messages.email"),
                                  "error-messages": _vm.errors.collect("email"),
                                  required: "",
                                },
                                model: {
                                  value: _vm.form_fields.email,
                                  callback: function ($$v) {
                                    _vm.$set(_vm.form_fields, "email", $$v)
                                  },
                                  expression: "form_fields.email",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm12: "", md12: "" } },
                            [
                              _c("v-text-field", {
                                directives: [
                                  {
                                    name: "validate",
                                    rawName: "v-validate",
                                    value: "required",
                                    expression: "'required'",
                                  },
                                ],
                                attrs: {
                                  label: _vm.trans("messages.email_subject"),
                                  "data-vv-name": "email_subject",
                                  "data-vv-as": _vm.trans(
                                    "messages.email_subject"
                                  ),
                                  "error-messages":
                                    _vm.errors.collect("email_subject"),
                                  required: "",
                                },
                                model: {
                                  value: _vm.form_fields.subject,
                                  callback: function ($$v) {
                                    _vm.$set(_vm.form_fields, "subject", $$v)
                                  },
                                  expression: "form_fields.subject",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm12: "", md12: "" } },
                            [
                              _vm._v(
                                "\n                            " +
                                  _vm._s(_vm.trans("messages.email_body")) +
                                  "\n                            "
                              ),
                              _c("quill-editor", {
                                model: {
                                  value: _vm.form_fields.body,
                                  callback: function ($$v) {
                                    _vm.$set(_vm.form_fields, "body", $$v)
                                  },
                                  expression: "form_fields.body",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm4: "", md4: "" } },
                            [
                              _c("v-checkbox", {
                                attrs: {
                                  label: _vm.trans("messages.attach_pdf"),
                                  color: "primary",
                                  value: "1",
                                  "hide-details": "",
                                },
                                model: {
                                  value: _vm.form_fields.attachment,
                                  callback: function ($$v) {
                                    _vm.$set(_vm.form_fields, "attachment", $$v)
                                  },
                                  expression: "form_fields.attachment",
                                },
                              }),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "v-card-actions",
                [
                  _c("v-spacer"),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      attrs: { flat: "" },
                      on: {
                        click: function ($event) {
                          _vm.dialog = false
                        },
                      },
                    },
                    [
                      _vm._v(
                        "\n                    " +
                          _vm._s(_vm.trans("messages.close")) +
                          "\n                "
                      ),
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      attrs: {
                        flat: "",
                        loading: _vm.loading,
                        disabled: _vm.loading,
                      },
                      on: { click: _vm.sendNotification },
                    },
                    [
                      _vm._v(
                        "\n                    " +
                          _vm._s(_vm.trans("messages.send")) +
                          "\n                "
                      ),
                    ]
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/invoices/List.vue?vue&type=template&id=a934f20e&":
/*!********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/invoices/List.vue?vue&type=template&id=a934f20e& ***!
  \********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "component-wrap" },
    [
      _c("InvoiceShow", { ref: "invoiceShow" }),
      _vm._v(" "),
      _c("InvoicePayment", { ref: "invoicePayment" }),
      _vm._v(" "),
      _c("InvoiceReminder", { ref: "invoiceReminder" }),
      _vm._v(" "),
      _c("ViewPayment", { ref: "viewPayment" }),
      _vm._v(" "),
      _c(
        "v-tabs",
        {
          staticClass: "elevation-3",
          attrs: { "fixed-tabs": "", height: "47" },
          model: {
            value: _vm.tabs,
            callback: function ($$v) {
              _vm.tabs = $$v
            },
            expression: "tabs",
          },
        },
        [
          _vm.$can("superadmin")
            ? _c(
                "v-tab",
                { attrs: { href: "#tab-1" }, on: { click: _vm.getStatistics } },
                [
                  _c("v-icon", [_vm._v("bar_chart")]),
                  _vm._v(
                    "\n            " +
                      _vm._s(_vm.trans("messages.statistics")) +
                      "\n        "
                  ),
                ],
                1
              )
            : _vm._e(),
          _vm._v(" "),
          _c(
            "v-tab",
            { attrs: { href: "#tab-2" } },
            [
              _c("v-icon", [_vm._v("filter_list")]),
              _vm._v(
                "\n            " +
                  _vm._s(_vm.trans("messages.filters")) +
                  "\n        "
              ),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "v-tabs-items",
        {
          model: {
            value: _vm.tabs,
            callback: function ($$v) {
              _vm.tabs = $$v
            },
            expression: "tabs",
          },
        },
        [
          _c("v-divider"),
          _vm._v(" "),
          _vm.$can("superadmin")
            ? _c(
                "v-tab-item",
                { attrs: { value: "tab-1" } },
                [
                  _c(
                    "v-card",
                    { staticClass: "elevation-2", attrs: { flat: "" } },
                    [
                      _c(
                        "v-card-text",
                        [
                          _c(
                            "v-container",
                            { attrs: { "grid-list-md": "" } },
                            [
                              _c(
                                "v-layout",
                                { attrs: { row: "", wrap: "" } },
                                [
                                  _c(
                                    "v-flex",
                                    { attrs: { xs12: "", sm3: "", md3: "" } },
                                    [
                                      _c(
                                        "span",
                                        {
                                          staticClass:
                                            "subheading font-weight-medium primary--text",
                                        },
                                        [
                                          _vm._v(
                                            "\n                                    " +
                                              _vm._s(
                                                _vm.trans("messages.total")
                                              ) +
                                              ":\n                                    " +
                                              _vm._s(
                                                _vm.totalTransactionCount(
                                                  _vm.invoiceStats
                                                )
                                              ) +
                                              "\n                                "
                                          ),
                                        ]
                                      ),
                                    ]
                                  ),
                                  _vm._v(" "),
                                  _vm._l(
                                    _vm.invoiceStats,
                                    function (payment, index) {
                                      return _c(
                                        "v-flex",
                                        {
                                          key: index,
                                          attrs: { xs12: "", sm3: "", md3: "" },
                                        },
                                        [
                                          _vm._.includes(
                                            ["due"],
                                            payment.payment_status
                                          )
                                            ? _c(
                                                "span",
                                                {
                                                  staticClass:
                                                    "subheading font-weight-medium error--text",
                                                },
                                                [
                                                  _vm._v(
                                                    "\n                                    " +
                                                      _vm._s(
                                                        _vm.trans(
                                                          "messages.due"
                                                        )
                                                      ) +
                                                      ":\n                                    " +
                                                      _vm._s(
                                                        payment.payment_status_count
                                                      ) +
                                                      "\n                                "
                                                  ),
                                                ]
                                              )
                                            : _vm._e(),
                                          _vm._v(" "),
                                          _vm._.includes(
                                            ["partial"],
                                            payment.payment_status
                                          )
                                            ? _c(
                                                "span",
                                                {
                                                  staticClass:
                                                    "subheading font-weight-medium cyan--text",
                                                },
                                                [
                                                  _vm._v(
                                                    "\n                                    " +
                                                      _vm._s(
                                                        _vm.trans(
                                                          "messages.partial"
                                                        )
                                                      ) +
                                                      ":\n                                    " +
                                                      _vm._s(
                                                        payment.payment_status_count
                                                      ) +
                                                      "\n                                "
                                                  ),
                                                ]
                                              )
                                            : _vm._e(),
                                          _vm._v(" "),
                                          _vm._.includes(
                                            ["paid"],
                                            payment.payment_status
                                          )
                                            ? _c(
                                                "span",
                                                {
                                                  staticClass:
                                                    "subheading font-weight-medium success--text",
                                                },
                                                [
                                                  _vm._v(
                                                    "\n                                    " +
                                                      _vm._s(
                                                        _vm.trans(
                                                          "messages.paid"
                                                        )
                                                      ) +
                                                      ":\n                                    " +
                                                      _vm._s(
                                                        payment.payment_status_count
                                                      ) +
                                                      "\n                                "
                                                  ),
                                                ]
                                              )
                                            : _vm._e(),
                                        ]
                                      )
                                    }
                                  ),
                                  _vm._v(" "),
                                  _c(
                                    "v-flex",
                                    { attrs: { xs12: "", sm3: "", md3: "" } },
                                    [
                                      _c(
                                        "span",
                                        {
                                          staticClass:
                                            "subheading font-weight-medium success--text",
                                        },
                                        [
                                          _vm._v(
                                            "\n                                    " +
                                              _vm._s(
                                                _vm.trans(
                                                  "messages.paid_amount"
                                                )
                                              ) +
                                              ":\n                                    " +
                                              _vm._s(
                                                _vm._f("formatMoney")(
                                                  _vm.paid_amount,
                                                  _vm.currency.symbol
                                                )
                                              ) +
                                              "\n                                "
                                          ),
                                        ]
                                      ),
                                    ]
                                  ),
                                ],
                                2
                              ),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              )
            : _vm._e(),
          _vm._v(" "),
          _c(
            "v-tab-item",
            { attrs: { value: "tab-2" } },
            [
              _c(
                "v-card",
                { staticClass: "elevation-2", attrs: { flat: "" } },
                [
                  _c(
                    "v-card-text",
                    [
                      _c(
                        "v-container",
                        { attrs: { "grid-list-md": "" } },
                        [
                          _c(
                            "v-layout",
                            { attrs: { row: "", wrap: "" } },
                            [
                              _c(
                                "v-flex",
                                { attrs: { xs12: "", md4: "" } },
                                [
                                  _c("v-autocomplete", {
                                    attrs: {
                                      "item-text": "name",
                                      "item-value": "id",
                                      items: _vm.projectList,
                                      label: _vm.trans("messages.project"),
                                    },
                                    on: { change: _vm.filterChanged },
                                    model: {
                                      value: _vm.filters.project_id,
                                      callback: function ($$v) {
                                        _vm.$set(_vm.filters, "project_id", $$v)
                                      },
                                      expression: "filters.project_id",
                                    },
                                  }),
                                ],
                                1
                              ),
                              _vm._v(" "),
                              _c(
                                "v-flex",
                                { attrs: { xs12: "", md4: "" } },
                                [
                                  _c("v-autocomplete", {
                                    attrs: {
                                      "item-text": "company",
                                      "item-value": "id",
                                      items: _vm.customers,
                                      label: _vm.trans("messages.customer"),
                                    },
                                    on: { change: _vm.filterChanged },
                                    model: {
                                      value: _vm.filters.customer_id,
                                      callback: function ($$v) {
                                        _vm.$set(
                                          _vm.filters,
                                          "customer_id",
                                          $$v
                                        )
                                      },
                                      expression: "filters.customer_id",
                                    },
                                  }),
                                ],
                                1
                              ),
                              _vm._v(" "),
                              _c(
                                "v-flex",
                                { attrs: { xs12: "", md4: "" } },
                                [
                                  _c("v-autocomplete", {
                                    attrs: {
                                      "item-text": "label",
                                      "item-value": "value",
                                      items: _vm.paymentStatuses,
                                      label: _vm.trans(
                                        "messages.payment_status"
                                      ),
                                    },
                                    on: { change: _vm.filterChanged },
                                    model: {
                                      value: _vm.filters.payment_status,
                                      callback: function ($$v) {
                                        _vm.$set(
                                          _vm.filters,
                                          "payment_status",
                                          $$v
                                        )
                                      },
                                      expression: "filters.payment_status",
                                    },
                                  }),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "v-card",
        { staticClass: "mt-3" },
        [
          _c(
            "v-card-title",
            [
              _c("div", [
                _vm._v(
                  "\n\n                    " +
                    _vm._s(_vm.trans("messages.all_invoices")) +
                    "\n\n            "
                ),
              ]),
              _vm._v(" "),
              _c("v-spacer"),
              _vm._v(" "),
              _vm.$can("project." + _vm.projectId + ".invoice.create")
                ? _c(
                    "v-btn",
                    {
                      staticClass: "primary lighten-1",
                      on: {
                        click: function ($event) {
                          return _vm.$router.push({
                            name: "sales.invoices.create",
                          })
                        },
                      },
                    },
                    [
                      _vm._v(
                        "\n                " +
                          _vm._s(_vm.trans("messages.new_invoice")) +
                          "\n                "
                      ),
                      _c("v-icon", { attrs: { right: "" } }, [_vm._v("add")]),
                    ],
                    1
                  )
                : _vm._e(),
            ],
            1
          ),
          _vm._v(" "),
          _c("v-divider"),
          _vm._v(" "),
          _c("v-data-table", {
            staticClass: "elevation-3 w-full",
            attrs: {
              headers: _vm.headers,
              pagination: _vm.pagination,
              "total-items": _vm.total_items,
              loading: _vm.loading,
              items: _vm.items,
            },
            on: {
              "update:pagination": function ($event) {
                _vm.pagination = $event
              },
            },
            scopedSlots: _vm._u([
              {
                key: "headerCell",
                fn: function (props) {
                  return [
                    props.header.value == "invoice_date"
                      ? _c(
                          "span",
                          [
                            _c("v-icon", [_vm._v("date_range")]),
                            _vm._v(
                              " " +
                                _vm._s(props.header.text) +
                                "\n                "
                            ),
                          ],
                          1
                        )
                      : props.header.value == "invoice_number"
                      ? _c(
                          "span",
                          [
                            _c("v-icon", [_vm._v("receipt")]),
                            _vm._v(
                              " " +
                                _vm._s(props.header.text) +
                                "\n                "
                            ),
                          ],
                          1
                        )
                      : props.header.value == "customer"
                      ? _c(
                          "span",
                          [
                            _c("v-icon", [_vm._v("business_center")]),
                            _vm._v(
                              " " +
                                _vm._s(props.header.text) +
                                "\n                "
                            ),
                          ],
                          1
                        )
                      : props.header.value == "due_date"
                      ? _c(
                          "span",
                          [
                            _c("v-icon", [_vm._v("date_range")]),
                            _vm._v(
                              " " +
                                _vm._s(props.header.text) +
                                "\n                "
                            ),
                          ],
                          1
                        )
                      : _c("span", [_vm._v(_vm._s(props.header.text))]),
                  ]
                },
              },
              {
                key: "items",
                fn: function (props) {
                  return [
                    _c(
                      "td",
                      [
                        _c(
                          "v-menu",
                          [
                            _c(
                              "v-btn",
                              {
                                attrs: { slot: "activator", icon: "" },
                                slot: "activator",
                              },
                              [_c("v-icon", [_vm._v("more_vert")])],
                              1
                            ),
                            _vm._v(" "),
                            _c(
                              "v-list",
                              [
                                _vm.$can(
                                  "project." + _vm.projectId + ".invoice.view"
                                )
                                  ? _c(
                                      "v-list-tile",
                                      {
                                        on: {
                                          click: function ($event) {
                                            return _vm.view(props.item)
                                          },
                                        },
                                      },
                                      [
                                        _c(
                                          "v-list-tile-title",
                                          [
                                            _c(
                                              "v-icon",
                                              {
                                                staticClass: "mr-2",
                                                attrs: { small: "" },
                                              },
                                              [_vm._v(" visibility ")]
                                            ),
                                            _vm._v(
                                              "\n                                    " +
                                                _vm._s(
                                                  _vm.trans("messages.view")
                                                ) +
                                                "\n                                "
                                            ),
                                          ],
                                          1
                                        ),
                                      ],
                                      1
                                    )
                                  : _vm._e(),
                                _vm._v(" "),
                                _vm.$can(
                                  "project." + _vm.projectId + ".invoice.edit"
                                )
                                  ? _c(
                                      "v-list-tile",
                                      {
                                        on: {
                                          click: function ($event) {
                                            return _vm.edit(props.item)
                                          },
                                        },
                                      },
                                      [
                                        _c(
                                          "v-list-tile-title",
                                          [
                                            _c(
                                              "v-icon",
                                              {
                                                staticClass: "mr-2",
                                                attrs: { small: "" },
                                              },
                                              [_vm._v(" edit ")]
                                            ),
                                            _vm._v(
                                              "\n                                    " +
                                                _vm._s(
                                                  _vm.trans("messages.edit")
                                                ) +
                                                "\n                                "
                                            ),
                                          ],
                                          1
                                        ),
                                      ],
                                      1
                                    )
                                  : _vm._e(),
                                _vm._v(" "),
                                _c(
                                  "v-list-tile",
                                  { attrs: { href: props.item.download_url } },
                                  [
                                    _c(
                                      "v-list-tile-title",
                                      [
                                        _c(
                                          "v-icon",
                                          {
                                            staticClass: "mr-2",
                                            attrs: { small: "" },
                                          },
                                          [_vm._v(" save_alt ")]
                                        ),
                                        _vm._v(
                                          "\n                                    " +
                                            _vm._s(
                                              _vm.trans(
                                                "messages.download_invoice"
                                              )
                                            ) +
                                            "\n                                "
                                        ),
                                      ],
                                      1
                                    ),
                                  ],
                                  1
                                ),
                                _vm._v(" "),
                                _vm.$can(
                                  "project." + _vm.projectId + ".invoice.delete"
                                )
                                  ? _c(
                                      "v-list-tile",
                                      {
                                        on: {
                                          click: function ($event) {
                                            return _vm.deleteInvoice(props.item)
                                          },
                                        },
                                      },
                                      [
                                        _c(
                                          "v-list-tile-title",
                                          [
                                            _c(
                                              "v-icon",
                                              {
                                                staticClass: "mr-2",
                                                attrs: { small: "" },
                                              },
                                              [_vm._v(" delete_forever ")]
                                            ),
                                            _vm._v(
                                              "\n                                    " +
                                                _vm._s(
                                                  _vm.trans("messages.delete")
                                                ) +
                                                "\n                                "
                                            ),
                                          ],
                                          1
                                        ),
                                      ],
                                      1
                                    )
                                  : _vm._e(),
                                _vm._v(" "),
                                props.item.payment_status !== "paid" &&
                                props.item.type === "final"
                                  ? _c(
                                      "v-list-tile",
                                      {
                                        on: {
                                          click: function ($event) {
                                            return _vm.payDueAmountForInvoice(
                                              props.item
                                            )
                                          },
                                        },
                                      },
                                      [
                                        _c(
                                          "v-list-tile-title",
                                          [
                                            _c(
                                              "v-icon",
                                              {
                                                staticClass: "mr-2",
                                                attrs: { small: "" },
                                              },
                                              [_vm._v(" credit_card ")]
                                            ),
                                            _vm._v(
                                              "\n                                    " +
                                                _vm._s(
                                                  _vm.trans(
                                                    "messages.pay_due_amount"
                                                  )
                                                ) +
                                                "\n                                "
                                            ),
                                          ],
                                          1
                                        ),
                                      ],
                                      1
                                    )
                                  : _vm._e(),
                                _vm._v(" "),
                                props.item.payment_status !== "due" &&
                                _vm.$can(
                                  "project." + _vm.projectId + ".invoice.create"
                                )
                                  ? _c(
                                      "v-list-tile",
                                      {
                                        on: {
                                          click: function ($event) {
                                            return _vm.viewPayment(
                                              props.item.id
                                            )
                                          },
                                        },
                                      },
                                      [
                                        _c(
                                          "v-list-tile-title",
                                          [
                                            _c(
                                              "v-icon",
                                              {
                                                staticClass: "mr-2",
                                                attrs: { small: "" },
                                              },
                                              [_vm._v(" visibility ")]
                                            ),
                                            _vm._v(
                                              "\n                                    " +
                                                _vm._s(
                                                  _vm.trans(
                                                    "messages.view_payment"
                                                  )
                                                ) +
                                                "\n                                "
                                            ),
                                          ],
                                          1
                                        ),
                                      ],
                                      1
                                    )
                                  : _vm._e(),
                                _vm._v(" "),
                                _vm.$can(
                                  "project." + _vm.projectId + ".invoice.create"
                                ) && props.item.type !== "final"
                                  ? _c(
                                      "v-list-tile",
                                      {
                                        on: {
                                          click: function ($event) {
                                            return _vm.convertToInvoice(
                                              props.item
                                            )
                                          },
                                        },
                                      },
                                      [
                                        _c(
                                          "v-list-tile-title",
                                          [
                                            _c(
                                              "v-icon",
                                              {
                                                staticClass: "mr-2",
                                                attrs: { small: "" },
                                              },
                                              [_vm._v(" redo ")]
                                            ),
                                            _vm._v(
                                              "\n                                    " +
                                                _vm._s(
                                                  _vm.trans(
                                                    "messages.convert_to_invoice"
                                                  )
                                                ) +
                                                "\n                                "
                                            ),
                                          ],
                                          1
                                        ),
                                      ],
                                      1
                                    )
                                  : _vm._e(),
                                _vm._v(" "),
                                props.item.payment_status !== "paid" &&
                                props.item.type === "final"
                                  ? _c(
                                      "v-list-tile",
                                      {
                                        on: {
                                          click: function ($event) {
                                            return _vm.sendReminder(props.item)
                                          },
                                        },
                                      },
                                      [
                                        _c(
                                          "v-list-tile-title",
                                          [
                                            _c(
                                              "v-icon",
                                              {
                                                staticClass: "mr-2",
                                                attrs: { small: "" },
                                              },
                                              [_vm._v(" send ")]
                                            ),
                                            _vm._v(
                                              "\n                                    " +
                                                _vm._s(
                                                  _vm.trans(
                                                    "messages.send_reminder"
                                                  )
                                                ) +
                                                "\n                                "
                                            ),
                                          ],
                                          1
                                        ),
                                      ],
                                      1
                                    )
                                  : _vm._e(),
                              ],
                              1
                            ),
                          ],
                          1
                        ),
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c("td", [_vm._v(_vm._s(props.item.id))]),
                    _vm._v(" "),
                    _c("td", [
                      _vm._v(
                        _vm._s(_vm._f("formatDate")(props.item.invoice_date))
                      ),
                    ]),
                    _vm._v(" "),
                    _c("td", [_vm._v(_vm._s(props.item.invoice_number))]),
                    _vm._v(" "),
                    _c("td", [_vm._v(_vm._s(props.item.project))]),
                    _vm._v(" "),
                    _c("td", [_vm._v(_vm._s(props.item.customer))]),
                    _vm._v(" "),
                    _c(
                      "td",
                      [
                        props.item.type !== "draft"
                          ? _c("status-label", {
                              attrs: { status: props.item.payment_status },
                            })
                          : _vm._e(),
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c("td", [
                      _vm._v(_vm._s(_vm._f("formatDate")(props.item.due_date))),
                    ]),
                  ]
                },
              },
            ]),
          }),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/status/StatusLabel.vue?vue&type=template&id=2169abba&":
/*!*************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/status/StatusLabel.vue?vue&type=template&id=2169abba& ***!
  \*************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "v-chip",
    { attrs: { label: "", small: "", color: _vm.color(_vm.status) } },
    [_c("small", [_vm._v(_vm._s(_vm.trans("messages." + _vm.status)))])]
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/invoices/payment/InvoicePayment.vue?vue&type=template&id=d154f0a8&":
/*!************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/invoices/payment/InvoicePayment.vue?vue&type=template&id=d154f0a8& ***!
  \************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "component-wrap" },
    [
      _c(
        "v-layout",
        { attrs: { row: "", "justify-center": "" } },
        [
          _c(
            "v-dialog",
            {
              attrs: { "max-width": "700" },
              model: {
                value: _vm.dialog,
                callback: function ($$v) {
                  _vm.dialog = $$v
                },
                expression: "dialog",
              },
            },
            [
              _c(
                "v-card",
                [
                  _c(
                    "v-card-title",
                    [
                      _c("v-icon", { attrs: { medium: "" } }, [
                        _vm._v("money"),
                      ]),
                      _vm._v(" "),
                      _c("span", { staticClass: "headline" }, [
                        _vm._v(
                          "\n                        " +
                            _vm._s(_vm.trans("messages.payment")) +
                            "\n                    "
                        ),
                      ]),
                      _vm._v(" "),
                      _c("v-spacer"),
                      _vm._v(" "),
                      _c(
                        "v-btn",
                        {
                          attrs: { flat: "", small: "", icon: "" },
                          on: {
                            click: function ($event) {
                              _vm.dialog = false
                            },
                          },
                        },
                        [_c("v-icon", [_vm._v("clear")])],
                        1
                      ),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("v-divider"),
                  _vm._v(" "),
                  _c(
                    "v-card-text",
                    [
                      _c(
                        "v-container",
                        { attrs: { "grid-list-md": "" } },
                        [
                          _c(
                            "v-layout",
                            { attrs: { wrap: "" } },
                            [
                              _c(
                                "v-flex",
                                { attrs: { xs12: "", sm6: "", md6: "" } },
                                [
                                  _c("v-text-field", {
                                    directives: [
                                      {
                                        name: "validate",
                                        rawName: "v-validate",
                                        value: "max_value:" + _vm.max_val,
                                        expression: "'max_value:' + max_val",
                                      },
                                    ],
                                    attrs: {
                                      type: "number",
                                      label: _vm.trans("messages.amount"),
                                      "data-vv-name": "amount",
                                      "data-vv-as":
                                        _vm.trans("messages.amount"),
                                      "error-messages":
                                        _vm.errors.collect("amount"),
                                      required: "",
                                    },
                                    model: {
                                      value: _vm.transaction_total,
                                      callback: function ($$v) {
                                        _vm.transaction_total = $$v
                                      },
                                      expression: "transaction_total",
                                    },
                                  }),
                                ],
                                1
                              ),
                              _vm._v(" "),
                              _vm.show_conversion_rate == "true"
                                ? _c(
                                    "v-flex",
                                    { attrs: { xs12: "", sm6: "", md6: "" } },
                                    [
                                      _c(
                                        "v-text-field",
                                        {
                                          directives: [
                                            {
                                              name: "validate",
                                              rawName: "v-validate",
                                              value: "required",
                                              expression: "'required'",
                                            },
                                          ],
                                          attrs: {
                                            type: "number",
                                            label: _vm.trans(
                                              "messages.conversion_rate"
                                            ),
                                            "data-vv-name": "conversion_rate",
                                            "data-vv-as": _vm.trans(
                                              "messages.conversion_rate"
                                            ),
                                            "error-messages":
                                              _vm.errors.collect(
                                                "conversion_rate"
                                              ),
                                            required: "",
                                          },
                                          on: {
                                            change: _vm.calculateFinalAmount,
                                          },
                                          model: {
                                            value: _vm.conversion_rate,
                                            callback: function ($$v) {
                                              _vm.conversion_rate = $$v
                                            },
                                            expression: "conversion_rate",
                                          },
                                        },
                                        [
                                          _c("Popover", {
                                            attrs: {
                                              slot: "append",
                                              helptext: _vm.trans(
                                                "messages.tooltip_conversion_rate"
                                              ),
                                            },
                                            slot: "append",
                                          }),
                                        ],
                                        1
                                      ),
                                    ],
                                    1
                                  )
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.show_conversion_rate == "true"
                                ? _c(
                                    "v-flex",
                                    { attrs: { xs12: "", sm6: "", md6: "" } },
                                    [
                                      _c(
                                        "v-text-field",
                                        {
                                          directives: [
                                            {
                                              name: "validate",
                                              rawName: "v-validate",
                                              value: "required",
                                              expression: "'required'",
                                            },
                                          ],
                                          attrs: {
                                            type: "number",
                                            label: _vm.trans(
                                              "messages.final_amount"
                                            ),
                                            "data-vv-name": "final_amount",
                                            "data-vv-as": _vm.trans(
                                              "messages.final_amount"
                                            ),
                                            "error-messages":
                                              _vm.errors.collect(
                                                "final_amount"
                                              ),
                                            required: "",
                                          },
                                          on: {
                                            change: _vm.calculateConversionRate,
                                          },
                                          model: {
                                            value: _vm.final_amount,
                                            callback: function ($$v) {
                                              _vm.final_amount = $$v
                                            },
                                            expression: "final_amount",
                                          },
                                        },
                                        [
                                          _c("Popover", {
                                            attrs: {
                                              slot: "append",
                                              helptext: _vm.trans(
                                                "messages.tooltip_final_amount"
                                              ),
                                            },
                                            slot: "append",
                                          }),
                                        ],
                                        1
                                      ),
                                    ],
                                    1
                                  )
                                : _vm._e(),
                              _vm._v(" "),
                              _c(
                                "v-flex",
                                { attrs: { xs12: "", sm6: "", md6: "" } },
                                [
                                  _c(
                                    "div",
                                    {
                                      staticClass:
                                        "v-input v-text-field theme--light",
                                    },
                                    [
                                      _c(
                                        "div",
                                        { staticClass: "v-input__control" },
                                        [
                                          _c(
                                            "div",
                                            { staticClass: "v-input__slot" },
                                            [
                                              _c(
                                                "div",
                                                {
                                                  staticClass:
                                                    "v-text-field__slot",
                                                },
                                                [
                                                  _c(
                                                    "label",
                                                    {
                                                      staticClass:
                                                        "v-label v-label--active theme--light flat_picker_label",
                                                      attrs: {
                                                        "aria-hidden": "true",
                                                      },
                                                    },
                                                    [
                                                      _vm._v(
                                                        "\n                                                    " +
                                                          _vm._s(
                                                            _vm.trans(
                                                              "messages.paid_on"
                                                            )
                                                          ) +
                                                          "\n                                                "
                                                      ),
                                                    ]
                                                  ),
                                                  _vm._v(" "),
                                                  _c("flat-pickr", {
                                                    directives: [
                                                      {
                                                        name: "validate",
                                                        rawName: "v-validate",
                                                        value: "required",
                                                        expression:
                                                          "'required'",
                                                      },
                                                    ],
                                                    attrs: {
                                                      name: "paid_on",
                                                      required: "",
                                                      config:
                                                        _vm.flatPickerDate(),
                                                      "data-vv-as":
                                                        _vm.trans(
                                                          "messages.paid_on"
                                                        ),
                                                    },
                                                    model: {
                                                      value: _vm.paid_on,
                                                      callback: function ($$v) {
                                                        _vm.paid_on = $$v
                                                      },
                                                      expression: "paid_on",
                                                    },
                                                  }),
                                                ],
                                                1
                                              ),
                                            ]
                                          ),
                                          _vm._v(" "),
                                          _c(
                                            "div",
                                            {
                                              staticClass:
                                                "v-messages theme--light error--text",
                                            },
                                            [
                                              _vm._v(
                                                "\n                                            " +
                                                  _vm._s(
                                                    _vm.errors.first("paid_on")
                                                  ) +
                                                  "\n                                        "
                                              ),
                                            ]
                                          ),
                                        ]
                                      ),
                                    ]
                                  ),
                                ]
                              ),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-layout",
                            { attrs: { wrap: "" } },
                            [
                              _c(
                                "v-flex",
                                { attrs: { xs12: "", sm12: "", md12: "" } },
                                [
                                  _c("v-textarea", {
                                    attrs: {
                                      rows: "3",
                                      label: _vm.trans(
                                        "messages.payment_details"
                                      ),
                                    },
                                    model: {
                                      value: _vm.payment_details,
                                      callback: function ($$v) {
                                        _vm.payment_details = $$v
                                      },
                                      expression: "payment_details",
                                    },
                                  }),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "v-card-actions",
                    [
                      _c("v-spacer"),
                      _vm._v(" "),
                      _c(
                        "v-btn",
                        {
                          attrs: { color: "green darken-1", flat: "" },
                          on: {
                            click: function ($event) {
                              _vm.dialog = false
                            },
                          },
                        },
                        [
                          _vm._v(
                            "\n                        " +
                              _vm._s(_vm.trans("messages.close")) +
                              "\n                    "
                          ),
                        ]
                      ),
                      _vm._v(" "),
                      _c(
                        "v-btn",
                        {
                          attrs: {
                            color: "success",
                            loading: _vm.loading,
                            disabled: _vm.loading,
                          },
                          on: { click: _vm.store },
                        },
                        [
                          _vm._v(
                            "\n                        " +
                              _vm._s(_vm.trans("messages.pay")) +
                              "\n                    "
                          ),
                        ]
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/invoices/payment/ViewPayment.vue?vue&type=template&id=62673fc4&":
/*!*********************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/invoices/payment/ViewPayment.vue?vue&type=template&id=62673fc4& ***!
  \*********************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "component-wrap" },
    [
      _c(
        "v-layout",
        { attrs: { row: "", "justify-center": "" } },
        [
          _c(
            "v-dialog",
            {
              attrs: { "max-width": "700" },
              model: {
                value: _vm.dialog,
                callback: function ($$v) {
                  _vm.dialog = $$v
                },
                expression: "dialog",
              },
            },
            [
              _c(
                "v-card",
                [
                  _c(
                    "v-card-title",
                    [
                      _c("v-icon", { attrs: { medium: "" } }, [
                        _vm._v("money"),
                      ]),
                      _vm._v(" "),
                      _c("span", { staticClass: "headline" }, [
                        _vm._v(
                          " " + _vm._s(_vm.trans("messages.view_payment")) + " "
                        ),
                      ]),
                      _vm._v(" "),
                      _c("v-spacer"),
                      _vm._v(" "),
                      _c(
                        "v-btn",
                        {
                          attrs: { flat: "", small: "", icon: "" },
                          on: {
                            click: function ($event) {
                              _vm.dialog = false
                            },
                          },
                        },
                        [_c("v-icon", [_vm._v("clear")])],
                        1
                      ),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("v-divider"),
                  _vm._v(" "),
                  _c(
                    "v-card-text",
                    [
                      _c(
                        "v-container",
                        { attrs: { "grid-list-md": "" } },
                        [
                          _c(
                            "v-layout",
                            { attrs: { wrap: "" } },
                            [
                              _c(
                                "v-flex",
                                { attrs: { xs12: "", sm4: "", md4: "" } },
                                [
                                  _vm.transaction.ref_no
                                    ? _c("div", [
                                        _c("strong", [
                                          _vm._v(
                                            " " +
                                              _vm._s(
                                                _vm.trans("messages.ref_no")
                                              ) +
                                              ": "
                                          ),
                                        ]),
                                        _vm._v(" "),
                                        _c("span", [
                                          _vm._v(
                                            " " + _vm._s(_vm.transaction.ref_no)
                                          ),
                                        ]),
                                        _vm._v(" "),
                                        _c("br"),
                                      ])
                                    : _vm._e(),
                                  _vm._v(" "),
                                  _c("strong", [
                                    _vm._v(
                                      " " +
                                        _vm._s(
                                          _vm.trans("messages.payment_status")
                                        ) +
                                        ": "
                                    ),
                                  ]),
                                  _vm._v(
                                    "\n                                " +
                                      _vm._s(
                                        _vm.trans(
                                          "messages." +
                                            _vm.transaction.payment_status
                                        )
                                      ) +
                                      "\n                                "
                                  ),
                                  _c("br"),
                                  _vm._v(" "),
                                  _c("strong", [
                                    _vm._v(
                                      " " +
                                        _vm._s(_vm.trans("messages.date")) +
                                        " : "
                                    ),
                                  ]),
                                  _vm._v(" "),
                                  _c("span", [
                                    _vm._v(
                                      "\n                                    " +
                                        _vm._s(
                                          _vm._f("formatDate")(
                                            _vm.transaction.transaction_date
                                          )
                                        ) +
                                        "\n                                "
                                    ),
                                  ]),
                                  _vm._v(" "),
                                  _c("br"),
                                  _vm._v(" "),
                                  _vm.transaction.type == "invoice"
                                    ? _c("div", [
                                        _c("strong", [
                                          _vm._v(
                                            " " +
                                              _vm._s(
                                                _vm.trans(
                                                  "messages.total_amount"
                                                )
                                              ) +
                                              " : "
                                          ),
                                        ]),
                                        _vm._v(" "),
                                        _c("span", [
                                          _vm._v(
                                            "\n                                        " +
                                              _vm._s(
                                                _vm._f("formatMoney")(
                                                  _vm.transaction.total,
                                                  _vm.customer_currency.symbol
                                                )
                                              ) +
                                              "\n                                    "
                                          ),
                                        ]),
                                        _vm._v(" "),
                                        _c("br"),
                                      ])
                                    : _vm._e(),
                                  _vm._v(" "),
                                  _vm.transaction.type == "expense"
                                    ? _c("div", [
                                        _c("strong", [
                                          _vm._v(
                                            " " +
                                              _vm._s(
                                                _vm.trans(
                                                  "messages.total_amount"
                                                )
                                              ) +
                                              " : "
                                          ),
                                        ]),
                                        _vm._v(" "),
                                        _c("span", [
                                          _vm._v(
                                            "\n                                        " +
                                              _vm._s(
                                                _vm._f("formatMoney")(
                                                  _vm.transaction.total,
                                                  _vm.business_currency.symbol
                                                )
                                              ) +
                                              "\n                                    "
                                          ),
                                        ]),
                                        _vm._v(" "),
                                        _c("br"),
                                      ])
                                    : _vm._e(),
                                  _vm._v(" "),
                                  !_vm._.isNull(_vm.transaction.due_date)
                                    ? _c("div", [
                                        _c("strong", [
                                          _vm._v(
                                            " " +
                                              _vm._s(
                                                _vm.trans("messages.due_date")
                                              ) +
                                              ": "
                                          ),
                                        ]),
                                        _vm._v(" "),
                                        _c("span", [
                                          _vm._v(
                                            "\n                                        " +
                                              _vm._s(
                                                _vm._f("formatDate")(
                                                  _vm.transaction.due_date
                                                )
                                              ) +
                                              "\n                                    "
                                          ),
                                        ]),
                                        _vm._v(" "),
                                        _c("br"),
                                      ])
                                    : _vm._e(),
                                  _vm._v(" "),
                                  _vm.transaction.type == "invoice"
                                    ? _c("div", [
                                        _c("strong", [
                                          _vm._v(
                                            " " +
                                              _vm._s(
                                                _vm.trans(
                                                  "messages.discount_type"
                                                )
                                              ) +
                                              " : "
                                          ),
                                        ]),
                                        _vm._v(
                                          "\n                                    " +
                                            _vm._s(
                                              _vm.trans(
                                                "messages." +
                                                  _vm.transaction.discount_type
                                              )
                                            ) +
                                            " "
                                        ),
                                        _c("br"),
                                      ])
                                    : _vm._e(),
                                ]
                              ),
                              _vm._v(" "),
                              _vm.employee
                                ? _c(
                                    "v-flex",
                                    { attrs: { xs12: "", sm4: "", md4: "" } },
                                    [
                                      _c("strong", [
                                        _vm._v(
                                          " " +
                                            _vm._s(
                                              _vm.trans("messages.expense_for")
                                            ) +
                                            " : "
                                        ),
                                      ]),
                                      _vm._v(
                                        "\n                                " +
                                          _vm._s(_vm.employee.name) +
                                          " "
                                      ),
                                      _c("br"),
                                      _vm._v(" "),
                                      _c("strong", [
                                        _vm._v(
                                          " " +
                                            _vm._s(
                                              _vm.trans("messages.email")
                                            ) +
                                            " : "
                                        ),
                                      ]),
                                      _vm._v(
                                        "\n                                " +
                                          _vm._s(_vm.employee.email) +
                                          " "
                                      ),
                                      _c("br"),
                                      _vm._v(" "),
                                      _vm.employee.mobile
                                        ? _c("div", [
                                            _c("strong", [
                                              _vm._v(
                                                " " +
                                                  _vm._s(
                                                    _vm.trans("messages.mobile")
                                                  ) +
                                                  " : "
                                              ),
                                            ]),
                                            _vm._v(
                                              "\n                                    " +
                                                _vm._s(_vm.employee.mobile) +
                                                " "
                                            ),
                                            _c("br"),
                                          ])
                                        : _vm._e(),
                                    ]
                                  )
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.project
                                ? _c(
                                    "v-flex",
                                    { attrs: { xs12: "", sm4: "", md4: "" } },
                                    [
                                      _c("strong", [
                                        _vm._v(
                                          " " +
                                            _vm._s(
                                              _vm.trans("messages.project")
                                            ) +
                                            " : "
                                        ),
                                      ]),
                                      _vm._v(
                                        "\n                                " +
                                          _vm._s(_vm.project.name) +
                                          " "
                                      ),
                                      _c("br"),
                                      _vm._v(" "),
                                      _c("strong", [
                                        _vm._v(
                                          " " +
                                            _vm._s(
                                              _vm.trans("messages.status")
                                            ) +
                                            " : "
                                        ),
                                      ]),
                                      _vm._v(
                                        "\n                                " +
                                          _vm._s(
                                            _vm.trans(
                                              "messages." + _vm.project.status
                                            )
                                          ) +
                                          " "
                                      ),
                                      _c("br"),
                                      _vm._v(" "),
                                      _c("strong", [
                                        _vm._v(
                                          " " +
                                            _vm._s(
                                              _vm.trans("messages.end_date")
                                            ) +
                                            " : "
                                        ),
                                      ]),
                                      _vm._v(
                                        "\n                                " +
                                          _vm._s(
                                            _vm._f("formatDate")(
                                              _vm.project.end_date
                                            )
                                          ) +
                                          " "
                                      ),
                                      _c("br"),
                                    ]
                                  )
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.customer
                                ? _c(
                                    "v-flex",
                                    { attrs: { xs12: "", sm4: "", md4: "" } },
                                    [
                                      _c("strong", [
                                        _vm._v(
                                          " " +
                                            _vm._s(
                                              _vm.trans("messages.customer")
                                            ) +
                                            " : "
                                        ),
                                      ]),
                                      _vm._v(
                                        "\n                                " +
                                          _vm._s(_vm.customer.company) +
                                          " "
                                      ),
                                      _c("br"),
                                      _vm._v(" "),
                                      _c("strong", [
                                        _vm._v(
                                          " " +
                                            _vm._s(
                                              _vm.trans("messages.tax_number")
                                            ) +
                                            " : "
                                        ),
                                      ]),
                                      _vm._v(
                                        "\n                                " +
                                          _vm._s(_vm.customer.tax_number) +
                                          " "
                                      ),
                                      _c("br"),
                                      _vm._v(" "),
                                      _c("strong", [
                                        _vm._v(
                                          " " +
                                            _vm._s(
                                              _vm.trans("messages.email")
                                            ) +
                                            " : "
                                        ),
                                      ]),
                                      _vm._v(
                                        "\n                                " +
                                          _vm._s(_vm.customer.email) +
                                          " "
                                      ),
                                      _c("br"),
                                      _vm._v(" "),
                                      _c("strong", [
                                        _vm._v(
                                          " " +
                                            _vm._s(
                                              _vm.trans("messages.mobile")
                                            ) +
                                            " : "
                                        ),
                                      ]),
                                      _vm._v(
                                        "\n                                " +
                                          _vm._s(_vm.customer.mobile) +
                                          " "
                                      ),
                                      _c("br"),
                                    ]
                                  )
                                : _vm._e(),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c("v-divider"),
                      _vm._v(" "),
                      _c(
                        "v-container",
                        { attrs: { "grid-list-md": "", "text-xs-center": "" } },
                        [
                          _c(
                            "v-layout",
                            { attrs: { row: "", wrap: "" } },
                            [
                              _c("v-flex", { attrs: { md3: "" } }, [
                                _c("h4", [
                                  _vm._v(_vm._s(_vm.trans("messages.date"))),
                                ]),
                              ]),
                              _vm._v(" "),
                              _c("v-flex", { attrs: { md3: "" } }, [
                                _c("h4", [
                                  _vm._v(_vm._s(_vm.trans("messages.amount"))),
                                ]),
                              ]),
                              _vm._v(" "),
                              _c("v-flex", { attrs: { md6: "" } }, [
                                _c("h4", [
                                  _vm._v(_vm._s(_vm.trans("messages.notes"))),
                                ]),
                              ]),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-layout",
                            { attrs: { row: "", wrap: "" } },
                            [
                              _vm._l(_vm.payments, function (payment) {
                                return [
                                  _c("v-flex", { attrs: { md3: "" } }, [
                                    _vm._v(
                                      "\n                                    " +
                                        _vm._s(
                                          _vm._f("formatDate")(payment.paid_on)
                                        ) +
                                        "\n                                "
                                    ),
                                  ]),
                                  _vm._v(" "),
                                  _c("v-flex", { attrs: { md3: "" } }, [
                                    _vm.transaction.type == "invoice"
                                      ? _c("span", [
                                          _vm._v(
                                            "\n                                        " +
                                              _vm._s(
                                                _vm._f("formatMoney")(
                                                  payment.amount,
                                                  _vm.customer_currency.symbol
                                                )
                                              ) +
                                              "\n                                        "
                                          ),
                                          _c("br"),
                                          _vm._v(" "),
                                          _c("small", [
                                            _vm._v(
                                              "\n                                            ( 1" +
                                                _vm._s(
                                                  _vm.business_currency.symbol
                                                ) +
                                                " =\n                                            " +
                                                _vm._s(
                                                  payment.conversion_rate
                                                ) +
                                                _vm._s(
                                                  _vm.customer_currency.symbol
                                                ) +
                                                ",\n                                            " +
                                                _vm._s(
                                                  _vm._f("formatMoney")(
                                                    payment.final_amount,
                                                    _vm.business_currency.symbol
                                                  )
                                                ) +
                                                ")\n                                        "
                                            ),
                                          ]),
                                        ])
                                      : _vm._e(),
                                    _vm._v(" "),
                                    _vm.transaction.type == "expense"
                                      ? _c("span", [
                                          _vm._v(
                                            "\n                                        " +
                                              _vm._s(
                                                _vm._f("formatMoney")(
                                                  payment.amount,
                                                  _vm.business_currency.symbol
                                                )
                                              ) +
                                              "\n                                        "
                                          ),
                                          _c("br"),
                                        ])
                                      : _vm._e(),
                                  ]),
                                  _vm._v(" "),
                                  _c("v-flex", { attrs: { md6: "" } }, [
                                    _c("span", {
                                      domProps: {
                                        innerHTML: _vm._s(
                                          payment.payment_details
                                        ),
                                      },
                                    }),
                                  ]),
                                ]
                              }),
                            ],
                            2
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "v-card-actions",
                    [
                      _c("v-spacer"),
                      _vm._v(" "),
                      _c(
                        "v-btn",
                        {
                          attrs: { color: "green darken-1", flat: "" },
                          on: {
                            click: function ($event) {
                              _vm.dialog = false
                            },
                          },
                        },
                        [
                          _vm._v(
                            "\n                        " +
                              _vm._s(_vm.trans("messages.close")) +
                              "\n                    "
                          ),
                        ]
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);