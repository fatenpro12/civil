"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_common_reports_Lists_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/report_types/Add.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/report_types/Add.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  props: {
    externalDialog: {
      type: Boolean,
      "default": false
    },
    type: {
      type: Object,
      "default": null
    }
  },
  data: function data() {
    return {
      dialog: false,
      type_name_ar: null,
      type_name_en: null,
      type_list_ar: [],
      type_list_en: [],
      form_name: null,
      loading: false,
      list: 1
    };
  },
  watch: {
    externalDialog: function externalDialog() {
      this.dialog = this.externalDialog;
    }
  },
  methods: {
    create: function create() {
      var self = this;
      self.type_name_ar = null;
      self.type_name_en = null;
      self.type_list_ar = [];
      self.type_list_en = [];
      self.form_name = null;
      self.$validator.reset();
      self.dialog = true;
    },
    close: function close() {
      this.dialog = false;
      this.$emit('close', this.dialog);
      this.list = 1;
      this.type_list_ar = [];
      this.type_list_en = [];
    },
    store: function (_store) {
      function store() {
        return _store.apply(this, arguments);
      }
      store.toString = function () {
        return _store.toString();
      };
      return store;
    }(function () {
      var self = this;
      var data = {
        type_name_ar: self.type_name_ar,
        type_name_en: self.type_name_en,
        type_list_ar: self.type_list_ar,
        type_list_en: self.type_list_en,
        form_name: self.form_name
      };
      self.$validator.validateAll().then(function (result) {
        if (result == true) {
          self.loading = true;
          axios.post('/reportTypes', data).then(function (response) {
            self.loading = false;
            self.dialog = false;
            self.$emit('store', self.dialog);
            self.list = 1;
            self.type_list_ar = [];
            self.type_list_en = [];
            self.$store.commit('showSnackbar', {
              message: response.data.msg,
              color: response.data.success
            });
            if (response.data.success === true) {
              self.$eventBus.$emit('updateCategoryList', response.data.reportTypes);
            }
          })["catch"](function (err) {
            console.log(err.response.status);
            if (err.response.status === 401) {
              store.dispatch('auth/handleResponse', err.response);
            }
          });
        }
      });
    })
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/report_types/Edit.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/report_types/Edit.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  props: {
    report_type: {},
    externalDialog: {
      type: Boolean,
      "default": false
    }
  },
  data: function data() {
    return {
      create_time: '',
      dialog: false,
      loading: false
    };
  },
  computed: {
    list: {
      get: function get() {
        return this.report_type.type_list_ar ? this.report_type.type_list_ar.length : 0;
      },
      set: function set(listNew) {
        return listNew;
      }
    }
  },
  watch: {
    externalDialog: function externalDialog() {
      this.dialog = this.externalDialog;
    }
  },
  created: function created() {
    var self = this;
    self.report = self.$route.params.report;
  },
  methods: {
    close: function close() {
      this.dialog = false;
      this.$emit('close', this.dialog);
      this.list = 1;
      this.type_list_ar = [];
      this.type_list_en = [];
    },
    update: function update() {
      var self = this;
      var data = this.report_type;
      self.$validator.validateAll().then(function (result) {
        if (result == true) {
          self.loading = true;
          axios.put('reportTypes/' + self.report_type.id, data).then(function (response) {
            self.$store.commit('showSnackbar', {
              message: response.data.msg,
              color: response.data.success
            });
            if (response.data.success === true) {
              self.loading = false;
              self.dialog = false;
              self.$forceUpdate();
            }
          })["catch"](function (error) {
            console.log(error);
          });
        }
      });
      //self.reset();
    },
    remove: function remove(index) {
      this.report_type.type_list_en.splice(index - 1, 1);
      this.report_type.type_list_ar.splice(index - 1, 1);
      this.$forceUpdate();
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/report_types/List.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/report_types/List.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _report_types_Edit_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../report_types/Edit.vue */ "./resources/js/common/report_types/Edit.vue");
/* harmony import */ var _report_types_Add_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../report_types/Add.vue */ "./resources/js/common/report_types/Add.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  components: {
    AddReportType: _report_types_Add_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    EditReportType: _report_types_Edit_vue__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  data: function data() {
    var self = this;
    return {
      externalDialog: false,
      externalDialogAdd: false,
      report_type: {},
      total_items: 0,
      loading: true,
      pagination: {
        totalItems: 0
      },
      headers: [{
        text: self.trans('messages.action'),
        value: false,
        align: 'center',
        sortable: false
      }, {
        text: self.trans('data.id'),
        value: 'id',
        align: 'center',
        sortable: true
      }, {
        text: self.trans('data.type_name_ar'),
        value: 'type_name_ar',
        align: 'center',
        sortable: true
      }, {
        text: self.trans('data.type_name_en'),
        value: 'type_name_en',
        align: 'center',
        sortable: true
      }, {
        text: '',
        value: 'data-table-expand'
      }
      /*  {
            text: self.trans('data.type_list_en'),
            value: 'type_list_en',
            align: 'left',
            sortable: true,
        },
        {
            text: self.trans('data.type_list_ar'),
            value: 'type_list_ar',
            align: 'left',
            sortable: true,
        },*/],

      items: [],
      search: '',
      expanded: false
    };
  },
  watch: {
    pagination: {
      handler: function handler() {
        this.getDataFromApi();
      }
    }
  },
  mounted: function mounted() {
    var self = this;
    self.$eventBus.$on('updateCustomerTable', function (data) {
      self.getDataFromApi();
    });
  },
  beforeDestroy: function beforeDestroy() {
    var self = this;
    self.$eventBus.$off('updateCustomerTable');
  },
  methods: {
    getDataFromApi: function getDataFromApi() {
      this.loading = true;
      var _this$pagination = this.pagination,
        sortBy = _this$pagination.sortBy,
        descending = _this$pagination.descending,
        page = _this$pagination.page,
        rowsPerPage = _this$pagination.rowsPerPage;
      var self = this;
      var params = {
        sort_by: sortBy,
        descending: descending,
        page: page,
        rowsPerPage: rowsPerPage
      };
      if (self.search) {
        params['term'] = self.search;
      }
      axios.get('/reportTypes', {
        params: params
      }).then(function (response) {
        self.total_items = response.data.total;
        self.items = response.data;
        self.loading = false;
      })["catch"](function (error) {
        console.log(error);
      });
    },
    create: function create() {
      var self = this;
      var templateType = {
        template: 'customer'
      };
      self.$refs.customerAdd.create(templateType);
    },
    edit: function edit(id) {
      var self = this;
      axios.get('/reportTypes/' + id + '/edit').then(function (response) {
        console.log(response.data);
        self.report_type = response.data;
      })["catch"](function (error) {
        console.log(error);
      });
      this.externalDialog = true;
    },
    deleteCustomer: function deleteCustomer(item) {
      var self = this;
      self.$store.commit('showDialog', {
        type: 'confirm',
        icon: 'warning',
        title: self.trans('messages.are_you_sure'),
        message: self.trans('messages.you_cant_restore_it'),
        okCb: function okCb() {
          axios["delete"]('/reportTypes/' + item.id).then(function (response) {
            self.$store.commit('showSnackbar', {
              message: response.data.msg,
              color: response.data.success
            });
            if (response.data.success === true) {
              self.getDataFromApi();
            }
          })["catch"](function (err) {
            console.log(err.response.status);
            if (err.response.status === 401) {
              store.dispatch('auth/handleResponse', err.response);
            }
          });
        },
        cancelCb: function cancelCb() {
          console.log('CANCEL');
        }
      });
    },
    customerContact: function customerContact(item) {
      var self = this;
      self.$router.push({
        name: 'customers.contacts.list',
        params: {
          id: item.id
        }
      });
    },
    searchCustomer: function searchCustomer() {
      var self = this;
      self.getDataFromApi();
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/reports/List.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/reports/List.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _report_types_Edit_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../report_types/Edit.vue */ "./resources/js/common/report_types/Edit.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  components: {
    EditReportType: _report_types_Edit_vue__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  data: function data() {
    var self = this;
    return {
      externalDialog: false,
      report_type: {},
      total_items: 0,
      loading: true,
      pagination: {
        totalItems: 0
      },
      headers: [{
        text: self.trans('messages.action'),
        value: false,
        align: 'center',
        sortable: false
      }, {
        text: self.trans('data.id'),
        value: 'id',
        align: 'center',
        sortable: true
      }, {
        text: self.trans('data.owner'),
        value: 'project.customer.name',
        align: 'center',
        sortable: true
      }, {
        text: self.trans('data.report_type'),
        value: 'type.name',
        align: 'center',
        sortable: true
      }, {
        text: self.trans('data.status'),
        value: 'status',
        align: 'center',
        sortable: false
      }, {
        text: self.trans('data.enginnering_office_name'),
        value: 'office.name',
        align: 'center',
        sortable: true
      }, {
        text: self.trans('data.contractor'),
        value: 'contractor.name',
        align: 'center',
        sortable: true
      }, {
        text: self.trans('data.project'),
        value: 'project.name',
        align: 'center',
        sortable: true
      }, {
        text: self.trans('data.created_at'),
        value: 'created_at',
        align: 'center',
        sortable: true
      }],
      items: [],
      search: '',
      expanded: false
    };
  },
  watch: {
    pagination: {
      handler: function handler() {
        this.getDataFromApi();
      }
    }
  },
  mounted: function mounted() {
    var self = this;
    self.$eventBus.$on('updateCustomerTable', function (data) {
      self.getDataFromApi();
    });
  },
  beforeDestroy: function beforeDestroy() {
    var self = this;
    self.$eventBus.$off('updateCustomerTable');
  },
  methods: {
    openReport: function openReport(report) {
      if (report.media.length > 0) window.open(report.media[report.media.length - 1].full_url, '_blank'); //.replace('upload','public/upload')
    },
    getDataFromApi: function getDataFromApi() {
      this.loading = true;
      var _this$pagination = this.pagination,
        sortBy = _this$pagination.sortBy,
        descending = _this$pagination.descending,
        page = _this$pagination.page,
        rowsPerPage = _this$pagination.rowsPerPage;
      var self = this;
      var params = {
        //  sort_by: sortBy,
        //  descending: descending,
        page: page,
        rowsPerPage: rowsPerPage
      };
      if (self.search) {
        params['term'] = self.search;
      }
      axios.get('/reports', {
        params: params
      }).then(function (response) {
        self.total_items = response.data.total;
        self.items = response.data.data;
        if (self.$route.params.id) self.items = self.items.filter(function (x) {
          return x.project_id == self.$route.params.id;
        });
        self.loading = false;
      })["catch"](function (error) {
        console.log(error);
      });
    },
    create: function create() {
      var self = this;
      var templateType = {
        template: 'customer'
      };
      self.$refs.customerAdd.create(templateType);
    },
    edit: function edit(id) {
      var self = this;
      axios.get('/reports/' + id + '/edit').then(function (response) {
        console.log(response.data);
        self.report_type = response.data;
      })["catch"](function (error) {
        console.log(error);
      });
      this.externalDialog = true;
    },
    deleteReport: function deleteReport(item) {
      var self = this;
      self.$store.commit('showDialog', {
        type: 'confirm',
        icon: 'warning',
        title: self.trans('messages.are_you_sure'),
        message: self.trans('messages.you_cant_restore_it'),
        okCb: function okCb() {
          axios["delete"]('/reports/' + item.id).then(function (response) {
            self.$store.commit('showSnackbar', {
              message: response.data.msg,
              color: response.data.success
            });
            if (response.data.success === true) {
              self.getDataFromApi();
            }
          })["catch"](function (err) {
            console.log(err.response.status);
            if (err.response.status === 401) {
              store.dispatch('auth/handleResponse', err.response);
            }
          });
        },
        cancelCb: function cancelCb() {
          console.log('CANCEL');
        }
      });
    },
    customerContact: function customerContact(item) {
      var self = this;
      self.$router.push({
        name: 'customers.contacts.list',
        params: {
          id: item.id
        }
      });
    },
    searchCustomer: function searchCustomer() {
      var self = this;
      self.getDataFromApi();
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/reports/Lists.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/reports/Lists.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _report_types_List_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../report_types/List.vue */ "./resources/js/common/report_types/List.vue");
/* harmony import */ var _reports_List_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../reports/List.vue */ "./resources/js/common/reports/List.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  components: {
    Report: _reports_List_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    ReportTypes: _report_types_List_vue__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  data: function data() {
    return {
      tab: null
    };
  }
});

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/report_types/Edit.vue?vue&type=style&index=0&id=77f151c5&scoped=true&lang=css&":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/report_types/Edit.vue?vue&type=style&index=0&id=77f151c5&scoped=true&lang=css& ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "\n.remove-list[data-v-77f151c5]{\r\n    color: rgb(255, 255, 255)!important;\r\n    background-color: #914848;\r\n    max-width: 25px;\r\n    border-radius: 50%;\r\n    min-width: 0;\r\n    margin-top: 25px;\n}\n.card[data-v-77f151c5] {\r\n    position: relative;\r\n    display: flex;\r\n    flex-direction: column;\r\n    min-width: 0;\r\n    word-wrap: break-word;\r\n    background-color: #fff;\r\n    background-clip: border-box;\r\n    border: 1px solid rgba(0, 0, 0, 0.125);\r\n    border-radius: 0.5rem;\n}\n.card > hr[data-v-77f151c5] {\r\n    margin-right: 0;\r\n    margin-left: 0;\n}\n.card > .list-group[data-v-77f151c5] {\r\n    border-top: inherit;\r\n    border-bottom: inherit;\n}\n.card > .list-group[data-v-77f151c5]:first-child {\r\n    border-top-width: 0;\r\n    border-top-left-radius: calc(0.25rem - 1px);\r\n    border-top-right-radius: calc(0.25rem - 1px);\n}\n.card > .list-group[data-v-77f151c5]:last-child {\r\n    border-bottom-width: 0;\r\n    border-bottom-right-radius: calc(0.25rem - 1px);\r\n    border-bottom-left-radius: calc(0.25rem - 1px);\n}\n.card > .card-header + .list-group[data-v-77f151c5],\r\n.card > .list-group + .card-footer[data-v-77f151c5] {\r\n    border-top: 0;\n}\n.card-body[data-v-77f151c5] {\r\n    flex: 1 1 auto;\r\n    padding: 1rem 1rem;\r\n    background-color: rgba(217, 217, 217, 255);\n}\n.card-title[data-v-77f151c5] {\r\n    margin-bottom: 0.5rem;\n}\n.card-subtitle[data-v-77f151c5] {\r\n    margin-top: -0.25rem;\r\n    margin-bottom: 0;\n}\n.card-text[data-v-77f151c5]:last-child {\r\n    margin-bottom: 0;\n}\n.card-link + .card-link[data-v-77f151c5] {\r\n    margin-left: 1rem;\n}\n.card-header[data-v-77f151c5] {\r\n    padding: 0.5rem 1rem;\r\n    margin-bottom: 0;\r\n    background-color: rgba(12, 111, 109, 255);\r\n    border-bottom: 1px solid rgba(0, 0, 0, 0.125);\r\n    color: white;\n}\n.card-header[data-v-77f151c5]:first-child {\r\n    border-radius: calc(0.25rem - 1px) calc(0.25rem - 1px) 0 0;\n}\n.card-footer[data-v-77f151c5] {\r\n    padding: 0.5rem 1rem;\r\n    background-color: rgba(0, 0, 0, 0.03);\r\n    border-top: 1px solid rgba(0, 0, 0, 0.125);\n}\n.card-footer[data-v-77f151c5]:last-child {\r\n    border-radius: 0 0 calc(0.25rem - 1px) calc(0.25rem - 1px);\n}\n.card-header-tabs[data-v-77f151c5] {\r\n    margin-right: -0.5rem;\r\n    margin-bottom: -0.5rem;\r\n    margin-left: -0.5rem;\r\n    border-bottom: 0;\n}\n.card-text[data-v-77f151c5] {\r\n    text-align: -webkit-center;\n}\n.card-header-pills[data-v-77f151c5] {\r\n    margin-right: -0.5rem;\r\n    margin-left: -0.5rem;\n}\n.card-img-overlay[data-v-77f151c5] {\r\n    position: absolute;\r\n    top: 0;\r\n    right: 0;\r\n    bottom: 0;\r\n    left: 0;\r\n    padding: 1rem;\r\n    border-radius: calc(0.25rem - 1px);\n}\n.card-img[data-v-77f151c5],\r\n.card-img-top[data-v-77f151c5],\r\n.card-img-bottom[data-v-77f151c5] {\r\n    width: 100%;\n}\n.card-img[data-v-77f151c5],\r\n.card-img-top[data-v-77f151c5] {\r\n    border-top-left-radius: calc(0.25rem - 1px);\r\n    border-top-right-radius: calc(0.25rem - 1px);\n}\n.card-img[data-v-77f151c5],\r\n.card-img-bottom[data-v-77f151c5] {\r\n    border-bottom-right-radius: calc(0.25rem - 1px);\r\n    border-bottom-left-radius: calc(0.25rem - 1px);\n}\n.card-group > .card[data-v-77f151c5] {\r\n    margin-bottom: 0.75rem;\n}\n@media (min-width: 576px) {\n.card-group[data-v-77f151c5] {\r\n        display: flex;\r\n        flex-flow: row wrap;\n}\n.card-group > .card[data-v-77f151c5] {\r\n        flex: 1 0 0%;\r\n        margin-bottom: 0;\n}\n.card-group > .card + .card[data-v-77f151c5] {\r\n        margin-left: 0;\r\n        border-left: 0;\n}\n.card-group > .card[data-v-77f151c5]:not(:last-child) {\r\n        border-top-right-radius: 0;\r\n        border-bottom-right-radius: 0;\n}\n.card-group > .card:not(:last-child) .card-img-top[data-v-77f151c5],\r\n    .card-group > .card:not(:last-child) .card-header[data-v-77f151c5] {\r\n        border-top-right-radius: 0;\n}\n.card-group > .card:not(:last-child) .card-img-bottom[data-v-77f151c5],\r\n    .card-group > .card:not(:last-child) .card-footer[data-v-77f151c5] {\r\n        border-bottom-right-radius: 0;\n}\n.card-group > .card[data-v-77f151c5]:not(:first-child) {\r\n        border-top-left-radius: 0;\r\n        border-bottom-left-radius: 0;\n}\n.card-group > .card:not(:first-child) .card-img-top[data-v-77f151c5],\r\n    .card-group > .card:not(:first-child) .card-header[data-v-77f151c5] {\r\n        border-top-left-radius: 0;\n}\n.card-group > .card:not(:first-child) .card-img-bottom[data-v-77f151c5],\r\n    .card-group > .card:not(:first-child) .card-footer[data-v-77f151c5] {\r\n        border-bottom-left-radius: 0;\n}\n}\r\n", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/reports/Lists.vue?vue&type=style&index=0&id=751e1eff&scoped=true&lang=css&":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/reports/Lists.vue?vue&type=style&index=0&id=751e1eff&scoped=true&lang=css& ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "\n.report[data-v-751e1eff]{\r\n    display: flex;\r\n    flex-direction: column;\n}\r\n", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/report_types/Edit.vue?vue&type=style&index=0&id=77f151c5&scoped=true&lang=css&":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/report_types/Edit.vue?vue&type=style&index=0&id=77f151c5&scoped=true&lang=css& ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_style_index_0_id_77f151c5_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Edit.vue?vue&type=style&index=0&id=77f151c5&scoped=true&lang=css& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/report_types/Edit.vue?vue&type=style&index=0&id=77f151c5&scoped=true&lang=css&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_style_index_0_id_77f151c5_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_style_index_0_id_77f151c5_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/reports/Lists.vue?vue&type=style&index=0&id=751e1eff&scoped=true&lang=css&":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/reports/Lists.vue?vue&type=style&index=0&id=751e1eff&scoped=true&lang=css& ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Lists_vue_vue_type_style_index_0_id_751e1eff_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Lists.vue?vue&type=style&index=0&id=751e1eff&scoped=true&lang=css& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/reports/Lists.vue?vue&type=style&index=0&id=751e1eff&scoped=true&lang=css&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Lists_vue_vue_type_style_index_0_id_751e1eff_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Lists_vue_vue_type_style_index_0_id_751e1eff_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./resources/js/common/report_types/Add.vue":
/*!**************************************************!*\
  !*** ./resources/js/common/report_types/Add.vue ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Add_vue_vue_type_template_id_71f0dc36___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Add.vue?vue&type=template&id=71f0dc36& */ "./resources/js/common/report_types/Add.vue?vue&type=template&id=71f0dc36&");
/* harmony import */ var _Add_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Add.vue?vue&type=script&lang=js& */ "./resources/js/common/report_types/Add.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Add_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Add_vue_vue_type_template_id_71f0dc36___WEBPACK_IMPORTED_MODULE_0__.render,
  _Add_vue_vue_type_template_id_71f0dc36___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/common/report_types/Add.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/common/report_types/Edit.vue":
/*!***************************************************!*\
  !*** ./resources/js/common/report_types/Edit.vue ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Edit_vue_vue_type_template_id_77f151c5_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Edit.vue?vue&type=template&id=77f151c5&scoped=true& */ "./resources/js/common/report_types/Edit.vue?vue&type=template&id=77f151c5&scoped=true&");
/* harmony import */ var _Edit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Edit.vue?vue&type=script&lang=js& */ "./resources/js/common/report_types/Edit.vue?vue&type=script&lang=js&");
/* harmony import */ var _Edit_vue_vue_type_style_index_0_id_77f151c5_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Edit.vue?vue&type=style&index=0&id=77f151c5&scoped=true&lang=css& */ "./resources/js/common/report_types/Edit.vue?vue&type=style&index=0&id=77f151c5&scoped=true&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Edit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Edit_vue_vue_type_template_id_77f151c5_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render,
  _Edit_vue_vue_type_template_id_77f151c5_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  "77f151c5",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/common/report_types/Edit.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/common/report_types/List.vue":
/*!***************************************************!*\
  !*** ./resources/js/common/report_types/List.vue ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _List_vue_vue_type_template_id_68a92a59___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./List.vue?vue&type=template&id=68a92a59& */ "./resources/js/common/report_types/List.vue?vue&type=template&id=68a92a59&");
/* harmony import */ var _List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./List.vue?vue&type=script&lang=js& */ "./resources/js/common/report_types/List.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _List_vue_vue_type_template_id_68a92a59___WEBPACK_IMPORTED_MODULE_0__.render,
  _List_vue_vue_type_template_id_68a92a59___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/common/report_types/List.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/common/reports/List.vue":
/*!**********************************************!*\
  !*** ./resources/js/common/reports/List.vue ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _List_vue_vue_type_template_id_7ccf52b8_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./List.vue?vue&type=template&id=7ccf52b8&scoped=true& */ "./resources/js/common/reports/List.vue?vue&type=template&id=7ccf52b8&scoped=true&");
/* harmony import */ var _List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./List.vue?vue&type=script&lang=js& */ "./resources/js/common/reports/List.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _List_vue_vue_type_template_id_7ccf52b8_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render,
  _List_vue_vue_type_template_id_7ccf52b8_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  "7ccf52b8",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/common/reports/List.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/common/reports/Lists.vue":
/*!***********************************************!*\
  !*** ./resources/js/common/reports/Lists.vue ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Lists_vue_vue_type_template_id_751e1eff_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Lists.vue?vue&type=template&id=751e1eff&scoped=true& */ "./resources/js/common/reports/Lists.vue?vue&type=template&id=751e1eff&scoped=true&");
/* harmony import */ var _Lists_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Lists.vue?vue&type=script&lang=js& */ "./resources/js/common/reports/Lists.vue?vue&type=script&lang=js&");
/* harmony import */ var _Lists_vue_vue_type_style_index_0_id_751e1eff_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Lists.vue?vue&type=style&index=0&id=751e1eff&scoped=true&lang=css& */ "./resources/js/common/reports/Lists.vue?vue&type=style&index=0&id=751e1eff&scoped=true&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Lists_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Lists_vue_vue_type_template_id_751e1eff_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render,
  _Lists_vue_vue_type_template_id_751e1eff_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  "751e1eff",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/common/reports/Lists.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/common/report_types/Add.vue?vue&type=script&lang=js&":
/*!***************************************************************************!*\
  !*** ./resources/js/common/report_types/Add.vue?vue&type=script&lang=js& ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Add_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Add.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/report_types/Add.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Add_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/common/report_types/Edit.vue?vue&type=script&lang=js&":
/*!****************************************************************************!*\
  !*** ./resources/js/common/report_types/Edit.vue?vue&type=script&lang=js& ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Edit.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/report_types/Edit.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/common/report_types/List.vue?vue&type=script&lang=js&":
/*!****************************************************************************!*\
  !*** ./resources/js/common/report_types/List.vue?vue&type=script&lang=js& ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./List.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/report_types/List.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/common/reports/List.vue?vue&type=script&lang=js&":
/*!***********************************************************************!*\
  !*** ./resources/js/common/reports/List.vue?vue&type=script&lang=js& ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./List.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/reports/List.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/common/reports/Lists.vue?vue&type=script&lang=js&":
/*!************************************************************************!*\
  !*** ./resources/js/common/reports/Lists.vue?vue&type=script&lang=js& ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Lists_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Lists.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/reports/Lists.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Lists_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/common/report_types/Edit.vue?vue&type=style&index=0&id=77f151c5&scoped=true&lang=css&":
/*!************************************************************************************************************!*\
  !*** ./resources/js/common/report_types/Edit.vue?vue&type=style&index=0&id=77f151c5&scoped=true&lang=css& ***!
  \************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_style_index_0_id_77f151c5_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Edit.vue?vue&type=style&index=0&id=77f151c5&scoped=true&lang=css& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/report_types/Edit.vue?vue&type=style&index=0&id=77f151c5&scoped=true&lang=css&");


/***/ }),

/***/ "./resources/js/common/reports/Lists.vue?vue&type=style&index=0&id=751e1eff&scoped=true&lang=css&":
/*!********************************************************************************************************!*\
  !*** ./resources/js/common/reports/Lists.vue?vue&type=style&index=0&id=751e1eff&scoped=true&lang=css& ***!
  \********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Lists_vue_vue_type_style_index_0_id_751e1eff_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Lists.vue?vue&type=style&index=0&id=751e1eff&scoped=true&lang=css& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/reports/Lists.vue?vue&type=style&index=0&id=751e1eff&scoped=true&lang=css&");


/***/ }),

/***/ "./resources/js/common/report_types/Add.vue?vue&type=template&id=71f0dc36&":
/*!*********************************************************************************!*\
  !*** ./resources/js/common/report_types/Add.vue?vue&type=template&id=71f0dc36& ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Add_vue_vue_type_template_id_71f0dc36___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Add_vue_vue_type_template_id_71f0dc36___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Add_vue_vue_type_template_id_71f0dc36___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Add.vue?vue&type=template&id=71f0dc36& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/report_types/Add.vue?vue&type=template&id=71f0dc36&");


/***/ }),

/***/ "./resources/js/common/report_types/Edit.vue?vue&type=template&id=77f151c5&scoped=true&":
/*!**********************************************************************************************!*\
  !*** ./resources/js/common/report_types/Edit.vue?vue&type=template&id=77f151c5&scoped=true& ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_template_id_77f151c5_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_template_id_77f151c5_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_template_id_77f151c5_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Edit.vue?vue&type=template&id=77f151c5&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/report_types/Edit.vue?vue&type=template&id=77f151c5&scoped=true&");


/***/ }),

/***/ "./resources/js/common/report_types/List.vue?vue&type=template&id=68a92a59&":
/*!**********************************************************************************!*\
  !*** ./resources/js/common/report_types/List.vue?vue&type=template&id=68a92a59& ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_68a92a59___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_68a92a59___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_68a92a59___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./List.vue?vue&type=template&id=68a92a59& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/report_types/List.vue?vue&type=template&id=68a92a59&");


/***/ }),

/***/ "./resources/js/common/reports/List.vue?vue&type=template&id=7ccf52b8&scoped=true&":
/*!*****************************************************************************************!*\
  !*** ./resources/js/common/reports/List.vue?vue&type=template&id=7ccf52b8&scoped=true& ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_7ccf52b8_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_7ccf52b8_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_7ccf52b8_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./List.vue?vue&type=template&id=7ccf52b8&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/reports/List.vue?vue&type=template&id=7ccf52b8&scoped=true&");


/***/ }),

/***/ "./resources/js/common/reports/Lists.vue?vue&type=template&id=751e1eff&scoped=true&":
/*!******************************************************************************************!*\
  !*** ./resources/js/common/reports/Lists.vue?vue&type=template&id=751e1eff&scoped=true& ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Lists_vue_vue_type_template_id_751e1eff_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Lists_vue_vue_type_template_id_751e1eff_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Lists_vue_vue_type_template_id_751e1eff_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Lists.vue?vue&type=template&id=751e1eff&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/reports/Lists.vue?vue&type=template&id=751e1eff&scoped=true&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/report_types/Add.vue?vue&type=template&id=71f0dc36&":
/*!************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/report_types/Add.vue?vue&type=template&id=71f0dc36& ***!
  \************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "v-layout",
    { attrs: { row: "", "justify-center": "" } },
    [
      _c(
        "v-dialog",
        {
          attrs: { width: "700", persistent: "" },
          model: {
            value: _vm.dialog,
            callback: function ($$v) {
              _vm.dialog = $$v
            },
            expression: "dialog",
          },
        },
        [
          _c(
            "v-card",
            [
              _c(
                "v-card-title",
                [
                  _c("v-icon", { attrs: { medium: "" } }, [_vm._v("category")]),
                  _vm._v(" "),
                  _c("span", { staticClass: "headline" }, [
                    _vm._v(
                      "\n                    " +
                        _vm._s(_vm.trans("data.create_report_type")) +
                        "\n                "
                    ),
                  ]),
                  _vm._v(" "),
                  _c("v-spacer"),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    { attrs: { flat: "", icon: "" }, on: { click: _vm.close } },
                    [_c("v-icon", [_vm._v("clear")])],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("v-divider"),
              _vm._v(" "),
              _c(
                "v-card-text",
                [
                  _c(
                    "v-container",
                    { attrs: { "grid-list-md": "" } },
                    [
                      _c(
                        "v-layout",
                        { attrs: { row: "", wrap: "" } },
                        [
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm12: "", md12: "" } },
                            [
                              _c("v-text-field", {
                                directives: [
                                  {
                                    name: "validate",
                                    rawName: "v-validate",
                                    value: "required",
                                    expression: "'required'",
                                  },
                                ],
                                attrs: {
                                  label: _vm.trans("data.type_name_ar"),
                                  "data-vv-name": "type_name_ar",
                                  "data-vv-as": _vm.trans("data.type_name_ar"),
                                  "error-messages":
                                    _vm.errors.collect("type_name_ar"),
                                  required: "",
                                },
                                model: {
                                  value: _vm.type_name_ar,
                                  callback: function ($$v) {
                                    _vm.type_name_ar = $$v
                                  },
                                  expression: "type_name_ar",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm12: "", md12: "" } },
                            [
                              _c("v-text-field", {
                                directives: [
                                  {
                                    name: "validate",
                                    rawName: "v-validate",
                                    value: "required",
                                    expression: "'required'",
                                  },
                                ],
                                attrs: {
                                  label: _vm.trans("data.type_name_en"),
                                  "data-vv-name": "type_name_en",
                                  "data-vv-as": _vm.trans("data.type_name_en"),
                                  "error-messages":
                                    _vm.errors.collect("type_name_en"),
                                  required: "",
                                },
                                model: {
                                  value: _vm.type_name_en,
                                  callback: function ($$v) {
                                    _vm.type_name_en = $$v
                                  },
                                  expression: "type_name_en",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _vm._l(_vm.list, function (i) {
                            return _c(
                              "v-layout",
                              { key: i, attrs: { row: "", wrap: "" } },
                              [
                                _c(
                                  "v-flex",
                                  { attrs: { xs6: "", sm6: "", md6: "" } },
                                  [
                                    _c("v-text-field", {
                                      directives: [
                                        {
                                          name: "validate",
                                          rawName: "v-validate",
                                          value: "required",
                                          expression: "'required'",
                                        },
                                      ],
                                      attrs: {
                                        label: _vm.trans("data.type_list_ar"),
                                        "data-vv-name": "type_list_ar",
                                        "data-vv-as":
                                          _vm.trans("data.type_list_ar"),
                                        "error-messages":
                                          _vm.errors.collect("type_list_ar"),
                                        required: "",
                                      },
                                      model: {
                                        value: _vm.type_list_ar[i - 1],
                                        callback: function ($$v) {
                                          _vm.$set(_vm.type_list_ar, i - 1, $$v)
                                        },
                                        expression: "type_list_ar[i-1]",
                                      },
                                    }),
                                  ],
                                  1
                                ),
                                _vm._v(" "),
                                _c(
                                  "v-flex",
                                  { attrs: { xs6: "", sm6: "", md6: "" } },
                                  [
                                    _c("v-text-field", {
                                      directives: [
                                        {
                                          name: "validate",
                                          rawName: "v-validate",
                                          value: "required",
                                          expression: "'required'",
                                        },
                                      ],
                                      attrs: {
                                        label: _vm.trans("data.type_list_en"),
                                        "data-vv-name": "type_list_en",
                                        "data-vv-as":
                                          _vm.trans("data.type_list_en"),
                                        "error-messages":
                                          _vm.errors.collect("type_list_en"),
                                        required: "",
                                      },
                                      model: {
                                        value: _vm.type_list_en[i - 1],
                                        callback: function ($$v) {
                                          _vm.$set(_vm.type_list_en, i - 1, $$v)
                                        },
                                        expression: "type_list_en[i-1]",
                                      },
                                    }),
                                  ],
                                  1
                                ),
                              ],
                              1
                            )
                          }),
                        ],
                        2
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("v-divider"),
              _vm._v(" "),
              _c(
                "v-card-actions",
                [
                  _c("v-spacer"),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      staticStyle: { color: "#06706d" },
                      attrs: { color: " darken-1", flat: "" },
                      on: { click: _vm.close },
                    },
                    [
                      _vm._v(
                        "\n                    " +
                          _vm._s(_vm.trans("messages.close")) +
                          "\n                "
                      ),
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      staticStyle: {
                        color: "#fff",
                        "background-color": "cyan",
                      },
                      attrs: { color: "secondary", flat: "" },
                      on: {
                        click: function ($event) {
                          _vm.list++
                        },
                      },
                    },
                    [
                      _vm._v(
                        "\n                    " +
                          _vm._s(_vm.trans("messages.list_add")) +
                          "+\n                "
                      ),
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      staticStyle: {
                        color: "#fff",
                        "background-color": "darkred",
                      },
                      attrs: { flat: "" },
                      on: {
                        click: function ($event) {
                          _vm.list > 0 ? _vm.list-- : (_vm.list = 0)
                        },
                      },
                    },
                    [
                      _vm._v(
                        "\n                    " +
                          _vm._s(_vm.trans("messages.list_remove")) +
                          "-\n                "
                      ),
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      staticStyle: {
                        "background-color": "#06706d",
                        color: "white",
                      },
                      attrs: { loading: _vm.loading, disabled: _vm.loading },
                      on: { click: _vm.store },
                    },
                    [
                      _vm._v(
                        "\n                    " +
                          _vm._s(_vm.trans("messages.save")) +
                          "\n                "
                      ),
                    ]
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/report_types/Edit.vue?vue&type=template&id=77f151c5&scoped=true&":
/*!*************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/report_types/Edit.vue?vue&type=template&id=77f151c5&scoped=true& ***!
  \*************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "v-layout",
    { attrs: { row: "", "justify-center": "" } },
    [
      _c(
        "v-dialog",
        {
          attrs: { width: "700", persistent: "" },
          model: {
            value: _vm.dialog,
            callback: function ($$v) {
              _vm.dialog = $$v
            },
            expression: "dialog",
          },
        },
        [
          _c(
            "v-card",
            [
              _c(
                "v-card-title",
                [
                  _c("v-icon", { attrs: { medium: "" } }, [_vm._v("category")]),
                  _vm._v(" "),
                  _c("span", { staticClass: "headline" }, [
                    _vm._v(
                      "\n                      " +
                        _vm._s(_vm.trans("data.edit_report_type")) +
                        "\n                  "
                    ),
                  ]),
                  _vm._v(" "),
                  _c("v-spacer"),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    { attrs: { flat: "", icon: "" }, on: { click: _vm.close } },
                    [_c("v-icon", [_vm._v("clear")])],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("v-divider"),
              _vm._v(" "),
              _c(
                "v-card-text",
                [
                  _c(
                    "v-container",
                    { attrs: { "grid-list-md": "" } },
                    [
                      _c(
                        "v-layout",
                        { attrs: { row: "", wrap: "" } },
                        [
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm12: "", md12: "" } },
                            [
                              _c("v-text-field", {
                                directives: [
                                  {
                                    name: "validate",
                                    rawName: "v-validate",
                                    value: "required",
                                    expression: "'required'",
                                  },
                                ],
                                attrs: {
                                  label: _vm.trans("data.type_name_ar"),
                                  "data-vv-name": "type_name_ar",
                                  "data-vv-as": _vm.trans("data.type_name_ar"),
                                  "error-messages":
                                    _vm.errors.collect("type_name_ar"),
                                  required: "",
                                },
                                model: {
                                  value: _vm.report_type.type_name_ar,
                                  callback: function ($$v) {
                                    _vm.$set(
                                      _vm.report_type,
                                      "type_name_ar",
                                      $$v
                                    )
                                  },
                                  expression: "report_type.type_name_ar",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm12: "", md12: "" } },
                            [
                              _c("v-text-field", {
                                directives: [
                                  {
                                    name: "validate",
                                    rawName: "v-validate",
                                    value: "required",
                                    expression: "'required'",
                                  },
                                ],
                                attrs: {
                                  label: _vm.trans("data.type_name_en"),
                                  "data-vv-name": "type_name_en",
                                  "data-vv-as": _vm.trans("data.type_name_en"),
                                  "error-messages":
                                    _vm.errors.collect("type_name_en"),
                                  required: "",
                                },
                                model: {
                                  value: _vm.report_type.type_name_en,
                                  callback: function ($$v) {
                                    _vm.$set(
                                      _vm.report_type,
                                      "type_name_en",
                                      $$v
                                    )
                                  },
                                  expression: "report_type.type_name_en",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _vm._l(_vm.list, function (i) {
                            return _c(
                              "v-layout",
                              { key: i, attrs: { row: "", wrap: "" } },
                              [
                                _c(
                                  "v-flex",
                                  { attrs: { xs5: "", sm5: "", md5: "" } },
                                  [
                                    _c("v-text-field", {
                                      directives: [
                                        {
                                          name: "validate",
                                          rawName: "v-validate",
                                          value: "required",
                                          expression: "'required'",
                                        },
                                      ],
                                      attrs: {
                                        label: _vm.trans("data.type_list_ar"),
                                        "data-vv-name": "type_list_ar",
                                        "data-vv-as":
                                          _vm.trans("data.type_list_ar"),
                                        "error-messages":
                                          _vm.errors.collect("type_list_ar"),
                                        required: "",
                                      },
                                      model: {
                                        value:
                                          _vm.report_type.type_list_ar[i - 1],
                                        callback: function ($$v) {
                                          _vm.$set(
                                            _vm.report_type.type_list_ar,
                                            i - 1,
                                            $$v
                                          )
                                        },
                                        expression:
                                          "report_type.type_list_ar[i-1]",
                                      },
                                    }),
                                  ],
                                  1
                                ),
                                _vm._v(" "),
                                _c(
                                  "v-flex",
                                  { attrs: { xs6: "", sm6: "", md6: "" } },
                                  [
                                    _c("v-text-field", {
                                      directives: [
                                        {
                                          name: "validate",
                                          rawName: "v-validate",
                                          value: "required",
                                          expression: "'required'",
                                        },
                                      ],
                                      attrs: {
                                        label: _vm.trans("data.type_list_en"),
                                        "data-vv-name": "type_list_en",
                                        "data-vv-as":
                                          _vm.trans("data.type_list_en"),
                                        "error-messages":
                                          _vm.errors.collect("type_list_en"),
                                        required: "",
                                      },
                                      model: {
                                        value:
                                          _vm.report_type.type_list_en[i - 1],
                                        callback: function ($$v) {
                                          _vm.$set(
                                            _vm.report_type.type_list_en,
                                            i - 1,
                                            $$v
                                          )
                                        },
                                        expression:
                                          "report_type.type_list_en[i-1]",
                                      },
                                    }),
                                  ],
                                  1
                                ),
                                _vm._v(" "),
                                _c(
                                  "v-flex",
                                  { attrs: { xs1: "", sm1: "", md1: "" } },
                                  [
                                    _c(
                                      "v-btn",
                                      {
                                        staticClass: "remove-list",
                                        attrs: { flat: "" },
                                        on: {
                                          click: function ($event) {
                                            return _vm.remove(i)
                                          },
                                        },
                                      },
                                      [
                                        _vm._v(
                                          "\n                      " +
                                            _vm._s(
                                              _vm.trans("messages.list_remove")
                                            ) +
                                            "-\n                  "
                                        ),
                                      ]
                                    ),
                                  ],
                                  1
                                ),
                              ],
                              1
                            )
                          }),
                        ],
                        2
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("v-divider"),
              _vm._v(" "),
              _c(
                "v-card-actions",
                [
                  _c("v-spacer"),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      staticStyle: { color: "#06706d" },
                      attrs: { color: " darken-1", flat: "" },
                      on: { click: _vm.close },
                    },
                    [
                      _vm._v(
                        "\n                      " +
                          _vm._s(_vm.trans("messages.close")) +
                          "\n                  "
                      ),
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      staticStyle: {
                        color: "#fff",
                        "background-color": "cyan",
                      },
                      attrs: { color: "secondary", flat: "" },
                      on: {
                        click: function ($event) {
                          _vm.list++
                        },
                      },
                    },
                    [
                      _vm._v(
                        "\n                      " +
                          _vm._s(_vm.trans("messages.list_add")) +
                          "+\n                  "
                      ),
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      staticStyle: {
                        "background-color": "#06706d",
                        color: "white",
                      },
                      attrs: { loading: _vm.loading, disabled: _vm.loading },
                      on: { click: _vm.update },
                    },
                    [
                      _vm._v(
                        "\n                      " +
                          _vm._s(_vm.trans("messages.save")) +
                          "\n                  "
                      ),
                    ]
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/report_types/List.vue?vue&type=template&id=68a92a59&":
/*!*************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/report_types/List.vue?vue&type=template&id=68a92a59& ***!
  \*************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "v-card-title",
        {
          staticStyle: {
            width: "100%",
            display: "flex",
            "justify-content": "space-between",
          },
        },
        [
          _c("div", { staticClass: "headline" }, [
            _vm._v(
              "\n                      " +
                _vm._s(_vm.trans("data.all_report_types")) +
                "\n                  "
            ),
          ]),
          _vm._v(" "),
          _vm.getCurrentUser().user_type_log === "ENGINEERING_OFFICE_MANAGER" ||
          _vm.getCurrentUser().user_type_log === "SITE_MANAGENMENT"
            ? _c(
                "v-btn",
                {
                  staticStyle: { color: "#06706d" },
                  on: {
                    click: function ($event) {
                      _vm.externalDialogAdd = true
                    },
                  },
                },
                [
                  _vm._v(
                    "\n              " +
                      _vm._s(_vm.trans("data.reportTypeAdd")) +
                      "\n          "
                  ),
                ]
              )
            : _vm._e(),
        ],
        1
      ),
      _vm._v(" "),
      _c("v-divider"),
      _vm._v(" "),
      _c("v-data-table", {
        staticClass: "elevation-3",
        attrs: {
          headers: _vm.headers,
          pagination: _vm.pagination,
          "total-items": _vm.total_items,
          loading: _vm.loading,
          items: _vm.items,
          expanded: _vm.expanded,
          "show-expand": "",
        },
        on: {
          "update:pagination": function ($event) {
            _vm.pagination = $event
          },
          "update:expanded": function ($event) {
            _vm.expanded = $event
          },
        },
        scopedSlots: _vm._u([
          {
            key: "items",
            fn: function (props) {
              return [
                _c(
                  "td",
                  { attrs: { align: "center" } },
                  [
                    _vm.$can("report.edit") || _vm.$can("report.delete")
                      ? _c(
                          "v-menu",
                          [
                            _c(
                              "v-btn",
                              {
                                attrs: { slot: "activator", icon: "" },
                                slot: "activator",
                              },
                              [_c("v-icon", [_vm._v("more_vert")])],
                              1
                            ),
                            _vm._v(" "),
                            _c(
                              "v-list",
                              [
                                _vm.$can("report.edit")
                                  ? _c(
                                      "v-list-tile",
                                      {
                                        on: {
                                          click: function ($event) {
                                            return _vm.edit(props.item.id)
                                          },
                                        },
                                      },
                                      [
                                        _c(
                                          "v-list-tile-title",
                                          [
                                            _c(
                                              "v-icon",
                                              {
                                                staticClass: "mr-2",
                                                attrs: { small: "" },
                                              },
                                              [_vm._v(" edit ")]
                                            ),
                                            _vm._v(
                                              "\n                                      " +
                                                _vm._s(
                                                  _vm.trans("messages.edit")
                                                ) +
                                                "\n                                  "
                                            ),
                                          ],
                                          1
                                        ),
                                      ],
                                      1
                                    )
                                  : _vm._e(),
                                _vm._v(" "),
                                _vm.$can("report.delete")
                                  ? _c(
                                      "v-list-tile",
                                      {
                                        on: {
                                          click: function ($event) {
                                            return _vm.deleteCustomer(
                                              props.item
                                            )
                                          },
                                        },
                                      },
                                      [
                                        _c(
                                          "v-list-tile-title",
                                          [
                                            _c(
                                              "v-icon",
                                              {
                                                staticClass: "mr-2",
                                                attrs: { small: "" },
                                              },
                                              [_vm._v(" delete_forever ")]
                                            ),
                                            _vm._v(
                                              "\n                                      " +
                                                _vm._s(
                                                  _vm.trans("messages.delete")
                                                ) +
                                                "\n                                  "
                                            ),
                                          ],
                                          1
                                        ),
                                      ],
                                      1
                                    )
                                  : _vm._e(),
                              ],
                              1
                            ),
                          ],
                          1
                        )
                      : _vm._e(),
                  ],
                  1
                ),
                _vm._v(" "),
                _c("td", { attrs: { align: "center" } }, [
                  _vm._v(_vm._s(props.item.id)),
                ]),
                _vm._v(" "),
                _c("td", { attrs: { align: "center" } }, [
                  _vm._v(_vm._s(props.item.type_name_ar)),
                ]),
                _vm._v(" "),
                _c("td", { attrs: { align: "center" } }, [
                  _vm._v(_vm._s(props.item.type_name_en)),
                ]),
                _vm._v(" "),
                _c(
                  "td",
                  {
                    attrs: { align: "center" },
                    on: {
                      click: function ($event) {
                        props.expanded = !props.expanded
                      },
                    },
                  },
                  [_c("v-icon", [_vm._v("arrow_drop_down")])],
                  1
                ),
              ]
            },
          },
          {
            key: "expand",
            fn: function (props) {
              return [
                _c(
                  "td",
                  { attrs: { colspan: _vm.headers.length } },
                  _vm._l(props.item.type_list_ar, function (data, index) {
                    return _c("div", { key: data }, [
                      _vm._v(
                        "\n     " + _vm._s(index + 1 + "-" + data) + "\n     "
                      ),
                    ])
                  }),
                  0
                ),
                _vm._v(" "),
                _c(
                  "td",
                  { attrs: { colspan: _vm.headers.length } },
                  _vm._l(props.item.type_list_en, function (data) {
                    return _c("div", { key: data }, [
                      _vm._v("\n     " + _vm._s(data) + "\n     "),
                    ])
                  }),
                  0
                ),
              ]
            },
          },
        ]),
      }),
      _vm._v(" "),
      _c("AddReportType", {
        attrs: { externalDialog: _vm.externalDialogAdd },
        on: {
          close: function ($event) {
            _vm.externalDialog = _vm.event
          },
          store: function ($event) {
            _vm.externalDialog = _vm.event
          },
        },
      }),
      _vm._v(" "),
      _c("EditReportType", {
        attrs: {
          report_type: _vm.report_type,
          externalDialog: _vm.externalDialog,
        },
        on: {
          close: function ($event) {
            _vm.externalDialog = _vm.event
          },
          store: function ($event) {
            _vm.externalDialog = _vm.event
          },
        },
      }),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/reports/List.vue?vue&type=template&id=7ccf52b8&scoped=true&":
/*!********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/reports/List.vue?vue&type=template&id=7ccf52b8&scoped=true& ***!
  \********************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "v-card-title",
        [
          _c("div", [
            _c("div", { staticClass: "headline" }, [
              _vm._v(
                "\n                      " +
                  _vm._s(_vm.trans("data.reports")) +
                  "\n                  "
              ),
            ]),
          ]),
          _vm._v(" "),
          _vm.$can("report.create")
            ? _c(
                "v-btn",
                {
                  staticStyle: { color: "#06706d" },
                  attrs: { disabled: !_vm.checkActive() },
                  on: {
                    click: function ($event) {
                      return _vm.$router.push({
                        name: "add_report",
                      })
                    },
                  },
                },
                [
                  _vm._v(
                    "\n              " +
                      _vm._s(_vm.trans("data.create_a_report")) +
                      "\n          "
                  ),
                ]
              )
            : _vm._e(),
        ],
        1
      ),
      _vm._v(" "),
      _c("v-divider"),
      _vm._v(" "),
      _c("v-data-table", {
        staticClass: "elevation-3",
        attrs: {
          headers: _vm.headers,
          pagination: _vm.pagination,
          "total-items": _vm.total_items,
          loading: _vm.loading,
          items: _vm.items,
        },
        on: {
          "update:pagination": function ($event) {
            _vm.pagination = $event
          },
        },
        scopedSlots: _vm._u([
          {
            key: "items",
            fn: function (props) {
              return [
                _c(
                  "td",
                  { attrs: { align: "center" } },
                  [
                    _c(
                      "v-menu",
                      [
                        _c(
                          "v-btn",
                          {
                            attrs: { slot: "activator", icon: "" },
                            slot: "activator",
                          },
                          [_c("v-icon", [_vm._v("more_vert")])],
                          1
                        ),
                        _vm._v(" "),
                        _c(
                          "v-list",
                          [
                            _vm.$can("report.view")
                              ? _c(
                                  "v-list-tile",
                                  {
                                    on: {
                                      click: function ($event) {
                                        return _vm.$router.push({
                                          name: "edit_report",
                                          params: {
                                            id: props.item.id, //media?props.item.media[0].full_url?props.item.media[0].full_url:props.item.media[0].original_url:props.item.id,
                                            item: props.item,
                                          },
                                        })
                                      },
                                    },
                                  },
                                  [
                                    _c(
                                      "v-list-tile-title",
                                      [
                                        _c(
                                          "v-icon",
                                          {
                                            staticClass: "mr-2",
                                            attrs: { small: "" },
                                          },
                                          [_vm._v(" visibility ")]
                                        ),
                                        _vm._v(
                                          "\n                                      " +
                                            _vm._s(
                                              _vm.trans("data.report_review")
                                            ) +
                                            "\n                                  "
                                        ),
                                      ],
                                      1
                                    ),
                                  ],
                                  1
                                )
                              : _vm._e(),
                            _vm._v(" "),
                            _vm.$can("report.delete")
                              ? _c(
                                  "v-list-tile",
                                  {
                                    on: {
                                      click: function ($event) {
                                        return _vm.deleteReport(props.item)
                                      },
                                    },
                                  },
                                  [
                                    _c(
                                      "v-list-tile-title",
                                      [
                                        _c(
                                          "v-icon",
                                          {
                                            staticClass: "mr-2",
                                            attrs: { small: "" },
                                          },
                                          [_vm._v(" delete_forever ")]
                                        ),
                                        _vm._v(
                                          "\n                                      " +
                                            _vm._s(
                                              _vm.trans("messages.delete")
                                            ) +
                                            "\n                                  "
                                        ),
                                      ],
                                      1
                                    ),
                                  ],
                                  1
                                )
                              : _vm._e(),
                          ],
                          1
                        ),
                      ],
                      1
                    ),
                  ],
                  1
                ),
                _vm._v(" "),
                _c("td", { attrs: { align: "center" } }, [
                  _vm._v(_vm._s(props.item.id)),
                ]),
                _vm._v(" "),
                _c(
                  "td",
                  { attrs: { align: "center" } },
                  _vm._l(props.item.project.owners, function (owner) {
                    return _c("span", { key: owner.id }, [
                      _vm._v(_vm._s(owner.name + " ")),
                    ])
                  }),
                  0
                ),
                _vm._v(" "),
                _c("td", { attrs: { align: "center" } }, [
                  _vm._v(_vm._s(props.item.type ? props.item.type.name : null)),
                ]),
                _vm._v(" "),
                _c("td", { attrs: { align: "center" } }, [
                  props.item.report_status === "Acceptable"
                    ? _c("span", [_vm._v(_vm._s(_vm.trans("data.Acceptable")))])
                    : _vm._e(),
                  _vm._v(" "),
                  props.item.report_status === "withComments"
                    ? _c("span", [
                        _vm._v(_vm._s(_vm.trans("data.Accepted comments"))),
                      ])
                    : _vm._e(),
                  _vm._v(" "),
                  props.item.report_status === "unacceptable"
                    ? _c("span", [
                        _vm._v(_vm._s(_vm.trans("data.unacceptable"))),
                      ])
                    : _vm._e(),
                ]),
                _vm._v(" "),
                _c("td", { attrs: { align: "center" } }, [
                  _vm._v(
                    _vm._s(
                      props.item.office.roles.find(function (val) {
                        return val.id === 7
                      })
                        ? props.item.office.parent.name
                        : props.item.office.name
                    )
                  ),
                ]),
                _vm._v(" "),
                _c(
                  "td",
                  { attrs: { align: "center" } },
                  _vm._l(
                    props.item.project.members.filter(function (val) {
                      return val.user_type_log === "CONTRACTING_COMPANY"
                    }),
                    function (contractor) {
                      return _c("span", { key: contractor.id }, [
                        _vm._v(
                          "\n                      " +
                            _vm._s(contractor.name) +
                            "\n                      "
                        ),
                      ])
                    }
                  ),
                  0
                ),
                _vm._v(" "),
                _c("td", { attrs: { align: "center" } }, [
                  _vm._v(_vm._s(props.item.project.name)),
                ]),
                _vm._v(" "),
                _c("td", { attrs: { align: "center" } }, [
                  _vm._v(_vm._s(_vm._f("formatDate")(props.item.created_at))),
                ]),
              ]
            },
          },
        ]),
      }),
      _vm._v(" "),
      _c("EditReportType", {
        attrs: {
          report_type: _vm.report_type,
          externalDialog: _vm.externalDialog,
        },
        on: {
          close: function ($event) {
            _vm.externalDialog = _vm.event
          },
          store: function ($event) {
            _vm.externalDialog = _vm.event
          },
        },
      }),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/reports/Lists.vue?vue&type=template&id=751e1eff&scoped=true&":
/*!*********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/reports/Lists.vue?vue&type=template&id=751e1eff&scoped=true& ***!
  \*********************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { class: _vm.$vuetify.breakpoint.xsOnly ? "pt-2" : "" },
    [
      _c(
        "v-tabs",
        {
          class: _vm.$vuetify.breakpoint.xsOnly ? "" : "mx-5",
          attrs: {
            "background-color": "transparent",
            color: "basil",
            grow: "",
          },
          model: {
            value: _vm.tab,
            callback: function ($$v) {
              _vm.tab = $$v
            },
            expression: "tab",
          },
        },
        [
          _c("v-tab", [
            _c("h3", [_vm._v(" " + _vm._s(_vm.trans("data.reports")))]),
          ]),
          _vm._v(" "),
          _c("v-tab", [
            _c("h3", [
              _vm._v(" " + _vm._s(_vm.trans("data.all_report_types"))),
            ]),
          ]),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "v-tabs-items",
        {
          model: {
            value: _vm.tab,
            callback: function ($$v) {
              _vm.tab = $$v
            },
            expression: "tab",
          },
        },
        [
          _c("v-tab-item", [
            _c(
              "div",
              {
                staticClass: "mx-auto elevation-2 pt-1 pb-3 my-2 report",
                class: _vm.$vuetify.breakpoint.xsOnly ? "" : "px-5",
                staticStyle: { "min-width": "70%", flex: "4" },
                attrs: { flat: "" },
              },
              [
                _c("Report"),
                _vm._v(" "),
                _c(
                  "div",
                  { staticClass: "mx-auto" },
                  [
                    _c(
                      "v-btn",
                      {
                        staticStyle: {
                          "background-color": "#06706d",
                          color: "white",
                        },
                        on: {
                          click: function ($event) {
                            return _vm.$router.go(-1)
                          },
                        },
                      },
                      [
                        _vm._v(
                          "\n                      " +
                            _vm._s(_vm.trans("messages.back")) +
                            "\n                  "
                        ),
                      ]
                    ),
                  ],
                  1
                ),
              ],
              1
            ),
          ]),
          _vm._v(" "),
          _c("v-tab-item", [
            _c(
              "div",
              {
                staticClass: "elevation-2 pt-1 pb-3 my-2",
                class: _vm.$vuetify.breakpoint.xsOnly ? "" : "px-5",
                staticStyle: { "mx-auto min-width": "70%", flex: "4" },
                attrs: { flat: "" },
              },
              [
                _c("ReportTypes"),
                _vm._v(" "),
                _c(
                  "div",
                  { staticClass: "flex justify-center" },
                  [
                    _c(
                      "v-btn",
                      {
                        staticStyle: {
                          "background-color": "#06706d",
                          color: "white",
                        },
                        on: {
                          click: function ($event) {
                            return _vm.$router.go(-1)
                          },
                        },
                      },
                      [
                        _vm._v(
                          "\n                      " +
                            _vm._s(_vm.trans("messages.back")) +
                            "\n                  "
                        ),
                      ]
                    ),
                  ],
                  1
                ),
              ],
              1
            ),
          ]),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);