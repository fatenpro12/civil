"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_common_projects_components_List_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/components/List.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/components/List.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components_Avatar__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../components/Avatar */ "./resources/js/common/projects/components/Avatar.vue");
/* harmony import */ var _tasks_Add__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../tasks/Add */ "./resources/js/common/projects/tasks/Add.vue");
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../store */ "./resources/js/store/index.js");
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  components: {
    avatar: _components_Avatar__WEBPACK_IMPORTED_MODULE_0__["default"],
    TaskFormAdd: _tasks_Add__WEBPACK_IMPORTED_MODULE_1__["default"]
  },
  data: function data() {
    var _ref;
    var self = this;
    return _ref = {
      total_items: 0,
      isshow: false,
      progress: 80,
      items: [],
      backGround: '',
      status: '',
      pagination: {
        totalItems: 0
      },
      headers: [{
        text: self.trans('messages.action'),
        value: false,
        align: 'center',
        sortable: false
      }, {
        text: self.trans('data.id'),
        value: 'id',
        align: 'center',
        sortable: true
      }, {
        text: self.trans('messages.name'),
        value: 'name',
        align: 'center',
        sortable: true
      },
      // {
      //     text: self.trans('messages.company'),
      //     value: 'company',
      //     align: 'left',
      //     sortable: true,
      // },
      {
        text: self.trans('messages.status'),
        value: 'status',
        align: 'center',
        sortable: true
      }, {
        text: self.trans('messages.favorited'),
        value: 'favorited',
        align: 'center',
        sortable: false
      }, {
        text: self.trans('data.owners'),
        value: 'owners',
        align: 'center',
        sortable: true
      }, {
        text: self.trans('messages.members'),
        value: 'members',
        align: 'center',
        sortable: true
      }, {
        text: self.trans('messages.project_progress'),
        value: 'project_progress',
        align: 'center',
        sortable: false
      }],
      projectData: [],
      statuses: [],
      url: null,
      users: [{
        id: 0,
        name: self.trans('messages.all')
      }],
      customers: [{
        id: 0,
        company: self.trans('messages.all')
      }]
    }, _defineProperty(_ref, "status", [{
      key: '',
      value: self.trans('messages.all')
    }]), _defineProperty(_ref, "categories", [{
      id: 0,
      name: self.trans('messages.all')
    }]), _defineProperty(_ref, "filters", []), _defineProperty(_ref, "tabs", 'tab-1'), _defineProperty(_ref, "statistics", []), _defineProperty(_ref, "loading", false), _ref;
  },
  created: function created() {
    var _this = this;
    var self = this;
    self.url = '/projects';
    self.getDataFromApi();
    self.getFilterData();
    self.$eventBus.$on('updateProjectTable', function (data) {
      self.url = '/projects';
      self.projectData = [];
      _this.getDataFromApi();
    });
  },
  beforeDestroy: function beforeDestroy() {
    var self = this;
    self.$eventBus.$off('updateProjectTable');
  },
  methods: {
    acceptProject: function acceptProject(id) {
      var _this2 = this;
      axios.post('accept-project', {
        project_id: id
      }).then(function (response) {
        _this2.$store.commit('showSnackbar', {
          message: response.data.msg,
          color: response.data.success
        });
        _this2.backGround = '368e0b';
        _this2.status = 'accepted';
        _this2.getDataFromApi();
        _this2.$forceUpdate();
      });
    },
    rejectProject: function rejectProject(id) {
      var _this3 = this;
      axios.post('reject-project', {
        project_id: id
      }).then(function (response) {
        _this3.$store.commit('showSnackbar', {
          message: response.data.msg,
          color: response.data.success
        });
        _this3.backGround = '8d0303';
        _this3.status = 'rejected';
        _this3.getDataFromApi();
        _this3.$forceUpdate();
      });
    },
    /*create() {
        const self = this;
        self.$refs.projectAdd.create();
    },*/
    getDataFromApi: function getDataFromApi() {
      var self = this;
      self.loading = true;
      var params = {};
      if (self.filters.status) {
        params['status'] = self.filters.status;
      }
      if (self.filters.category_id) {
        params['category_id'] = self.filters.category_id;
      }
      if (self.filters.customer_id) {
        params['customer_id'] = self.filters.customer_id;
      }
      if (self.filters.user_id) {
        params['user_id'] = self.filters.user_id;
      }
      axios.get(self.url, {
        params: params
      }).then(function (response) {
        self.loading = false;
        self.projectData = response.data.projects; //_.concat(self.projectData, response.data.projects.data);
        self.statuses = response.data.status;
        //    self.url = _.get(response, 'data.projects.next_page_url', null);
        self.getStatistics();
      })["catch"](function (err) {
        console.log(err.response.status);
        if (err.response.status === 401) {
          _store__WEBPACK_IMPORTED_MODULE_2__["default"].dispatch('auth/handleResponse', err.response);
        }
      });
      ;
    },
    edit: function edit(id) {
      var self = this;
      self.$router.push({
        name: 'edit-project',
        params: {
          id: id
        }
      });

      // self.$refs.projectEdit.edit(id);
    },
    view: function view(id) {
      var self = this;
      self.$router.push({
        name: 'view_project',
        params: {
          id: id
        }
      });

      // self.$refs.projectEdit.edit(id);
    },
    deleteProject: function deleteProject(id) {
      var self = this;
      self.$store.commit('showDialog', {
        type: 'confirm',
        icon: 'warning',
        title: self.trans('messages.are_you_sure'),
        message: self.trans('messages.you_cant_restore_it'),
        okCb: function okCb() {
          axios["delete"]('/projects/' + id).then(function (response) {
            self.$store.commit('showSnackbar', {
              message: response.data.msg,
              color: response.data.success
            });
            if (response.data.success === true) {
              self.url = '/projects';
              self.projectData = [];
              self.getDataFromApi();
            }
          })["catch"](function (error) {
            console.log(error);
          });
        },
        cancelCb: function cancelCb() {
          console.log('CANCEL');
        }
      });
    },
    markAsFavorite: function markAsFavorite(project) {
      var self = this;
      axios.get('/projects/mark-favorite', {
        params: {
          id: project.id,
          favorite: project.is_favorited
        }
      }).then(function (response) {
        self.$store.commit('showSnackbar', {
          message: response.data.msg,
          color: response.data.success
        });
        project.is_favorited = response.data.favorite;
      })["catch"](function (err) {
        console.log(err.response.status);
        if (err.response.status === 401) {
          _store__WEBPACK_IMPORTED_MODULE_2__["default"].dispatch('auth/handleResponse', err.response);
        }
      });
      ;
    },
    updateStatus: function updateStatus(status, project) {
      var self = this;
      axios.get('/projects/update-status', {
        params: {
          id: project.id,
          status: status
        }
      }).then(function (response) {
        self.$store.commit('showSnackbar', {
          message: response.data.msg,
          color: response.data.success
        });
        if (response.data.success === true) {
          project.status = status;
          self.getStatistics();
        }
      })["catch"](function (err) {
        console.log(err.response.status);
        if (err.response.status === 401) {
          _store__WEBPACK_IMPORTED_MODULE_2__["default"].dispatch('auth/handleResponse', err.response);
        }
      });
      ;
    },
    toggleFavorite: function toggleFavorite(project) {
      if (project.is_favorited) {
        return 'yellow darken-2';
      } else {
        return 'grey lighten-1';
      }
    },
    getFilterData: function getFilterData() {
      var self = this;
      if (self.$can('superadmin')) {
        axios.get('/projects/create').then(function (response) {
          self.users = _.concat(self.users, response.data.users);
          self.customers = _.concat(self.customers, response.data.customers);
          self.status = _.concat(self.status, response.data.status);
          self.categories = _.concat(self.categories, response.data.categories);
        })["catch"](function (error) {
          console.log(error);
        });
      }
    },
    getEnginneringTypes: function getEnginneringTypes() {
      var self = this;
      axios.get('/get-enginnering-types').then(function (response) {
        self.enginnering_types = response.data;
        //alert(JSON.stringify(self.employee_data))
        //alert(JSON.stringify(response.data.find(x=>x.key==self.employee_data.enginnering_type)))
        self.enginnering_type = response.data.find(function (x) {
          return x.key == employee_data.enginnering_type;
        }) != undefined ? response.data.find(function (x) {
          return x.key == employee_data.enginnering_type;
        }).value : '';
      })["catch"](function (err) {
        console.log(err.response.status);
        if (err.response.status === 401) {
          _store__WEBPACK_IMPORTED_MODULE_2__["default"].dispatch('auth/handleResponse', err.response);
        }
      });
      ;
    },
    filterChanged: function filterChanged() {
      var self = this;
      self.url = '/projects';
      self.projectData = [];
      self.getDataFromApi();
    },
    getStatistics: function getStatistics() {
      var self = this;
      if (self.$can('superadmin')) {
        axios.get('/projects-statistics').then(function (response) {
          self.statistics = response.data;
        })["catch"](function (error) {
          console.log(error);
        });
      }
    }
  }
});

/***/ }),

/***/ "./resources/js/common/projects/components/List.vue":
/*!**********************************************************!*\
  !*** ./resources/js/common/projects/components/List.vue ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _List_vue_vue_type_template_id_7a05c5d0___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./List.vue?vue&type=template&id=7a05c5d0& */ "./resources/js/common/projects/components/List.vue?vue&type=template&id=7a05c5d0&");
/* harmony import */ var _List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./List.vue?vue&type=script&lang=js& */ "./resources/js/common/projects/components/List.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _List_vue_vue_type_template_id_7a05c5d0___WEBPACK_IMPORTED_MODULE_0__.render,
  _List_vue_vue_type_template_id_7a05c5d0___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/common/projects/components/List.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/common/projects/components/List.vue?vue&type=script&lang=js&":
/*!***********************************************************************************!*\
  !*** ./resources/js/common/projects/components/List.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./List.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/components/List.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/common/projects/components/List.vue?vue&type=template&id=7a05c5d0&":
/*!*****************************************************************************************!*\
  !*** ./resources/js/common/projects/components/List.vue?vue&type=template&id=7a05c5d0& ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_7a05c5d0___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_7a05c5d0___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_7a05c5d0___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./List.vue?vue&type=template&id=7a05c5d0& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/components/List.vue?vue&type=template&id=7a05c5d0&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/components/List.vue?vue&type=template&id=7a05c5d0&":
/*!********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/components/List.vue?vue&type=template&id=7a05c5d0& ***!
  \********************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "v-container",
        { attrs: { "grid-list-md": "" } },
        [
          _c(
            "v-layout",
            { attrs: { row: "", "pt-3": "" } },
            [
              _c(
                "v-flex",
                { attrs: { xs12: "", sm12: "" } },
                [
                  _c(
                    "v-card",
                    { staticClass: "elevation-3 w-full" },
                    [
                      _c(
                        "v-card-title",
                        { attrs: { "primary-title": "", xs8: "", sm8: "" } },
                        [
                          _c("div", [
                            _c("div", { staticClass: "headline" }, [
                              _vm._v(
                                "\n                                    " +
                                  _vm._s(_vm.trans("data.current_projects")) +
                                  "\n                                "
                              ),
                            ]),
                          ]),
                          _vm._v(" "),
                          _c("v-spacer"),
                          _vm._v(" "),
                          _vm.projectData.length == 0 || _vm.isshow
                            ? _c(
                                "v-btn",
                                {
                                  staticClass: "lighten-1",
                                  staticStyle: {
                                    "background-color": "#06706d",
                                    color: "white",
                                  },
                                  on: {
                                    click: function ($event) {
                                      return _vm.$router.push({
                                        name: "add-project",
                                      })
                                    },
                                  },
                                },
                                [
                                  _vm._v(
                                    "\n                                " +
                                      _vm._s(_vm.trans("data.add_project")) +
                                      "\n                                "
                                  ),
                                  _c(
                                    "v-icon",
                                    { attrs: { right: "", dark: "" } },
                                    [_vm._v("add")]
                                  ),
                                ],
                                1
                              )
                            : _vm._e(),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c("v-divider"),
                      _vm._v(" "),
                      _c(
                        "v-card-text",
                        [
                          _c(
                            "v-container",
                            { attrs: { "grid-list-md": "" } },
                            [
                              _c(
                                "v-layout",
                                { attrs: { wrap: "" } },
                                [
                                  _c(
                                    "v-flex",
                                    { attrs: { xs12: "", sm12: "", md12: "" } },
                                    [
                                      _c("v-data-table", {
                                        staticClass: "elevation-3 w-full",
                                        attrs: {
                                          headers: _vm.headers,
                                          pagination: _vm.pagination,
                                          "total-items": _vm.total_items,
                                          loading: _vm.loading,
                                          items: _vm.projectData,
                                        },
                                        on: {
                                          "update:pagination": function (
                                            $event
                                          ) {
                                            _vm.pagination = $event
                                          },
                                        },
                                        scopedSlots: _vm._u([
                                          {
                                            key: "items",
                                            fn: function (props) {
                                              return [
                                                _c("td", [
                                                  _c(
                                                    "div",
                                                    {
                                                      attrs: {
                                                        align: "center",
                                                      },
                                                    },
                                                    [
                                                      _c(
                                                        "v-menu",
                                                        [
                                                          _c(
                                                            "v-btn",
                                                            {
                                                              attrs: {
                                                                slot: "activator",
                                                                icon: "",
                                                              },
                                                              slot: "activator",
                                                            },
                                                            [
                                                              _c("v-icon", [
                                                                _vm._v(
                                                                  "more_vert"
                                                                ),
                                                              ]),
                                                            ],
                                                            1
                                                          ),
                                                          _vm._v(" "),
                                                          _c(
                                                            "v-list",
                                                            [
                                                              _vm.getCurrentUser()
                                                                .user_type_log ===
                                                                "ESTATE_OWNER" &&
                                                              props.item.owners.find(
                                                                function (x) {
                                                                  return (
                                                                    x.id ==
                                                                    _vm.getCurrentUser()
                                                                      .id
                                                                  )
                                                                }
                                                              ) &&
                                                              props.item.owners.find(
                                                                function (x) {
                                                                  return (
                                                                    x.id ==
                                                                    _vm.getCurrentUser()
                                                                      .id
                                                                  )
                                                                }
                                                              ).pivot.status !=
                                                                "accepted"
                                                                ? _c(
                                                                    "v-list-tile",
                                                                    {
                                                                      attrs: {
                                                                        disabled:
                                                                          !_vm.checkActive(),
                                                                      },
                                                                      on: {
                                                                        click:
                                                                          function (
                                                                            $event
                                                                          ) {
                                                                            return _vm.acceptProject(
                                                                              props
                                                                                .item
                                                                                .id
                                                                            )
                                                                          },
                                                                      },
                                                                    },
                                                                    [
                                                                      _c(
                                                                        "v-list-tile-title",
                                                                        [
                                                                          _vm._v(
                                                                            "\n                                                                        " +
                                                                              _vm._s(
                                                                                _vm.trans(
                                                                                  "messages.accept_project"
                                                                                )
                                                                              ) +
                                                                              "\n                                                                    "
                                                                          ),
                                                                        ]
                                                                      ),
                                                                    ],
                                                                    1
                                                                  )
                                                                : _vm._e(),
                                                              _vm._v(" "),
                                                              _vm.getCurrentUser()
                                                                .user_type_log ===
                                                                "ESTATE_OWNER" &&
                                                              props.item.owners.find(
                                                                function (x) {
                                                                  return (
                                                                    x.id ==
                                                                    _vm.getCurrentUser()
                                                                      .id
                                                                  )
                                                                }
                                                              ) &&
                                                              props.item.owners.find(
                                                                function (x) {
                                                                  return (
                                                                    x.id ==
                                                                    _vm.getCurrentUser()
                                                                      .id
                                                                  )
                                                                }
                                                              ).pivot.status !=
                                                                "rejected"
                                                                ? _c(
                                                                    "v-list-tile",
                                                                    {
                                                                      attrs: {
                                                                        disabled:
                                                                          !_vm.checkActive(),
                                                                      },
                                                                      on: {
                                                                        click:
                                                                          function (
                                                                            $event
                                                                          ) {
                                                                            return _vm.rejectProject(
                                                                              props
                                                                                .item
                                                                                .id
                                                                            )
                                                                          },
                                                                      },
                                                                    },
                                                                    [
                                                                      _c(
                                                                        "v-list-tile-title",
                                                                        [
                                                                          _vm._v(
                                                                            "\n                                                                        " +
                                                                              _vm._s(
                                                                                _vm.trans(
                                                                                  "messages.reject_project"
                                                                                )
                                                                              ) +
                                                                              "\n                                                                    "
                                                                          ),
                                                                        ]
                                                                      ),
                                                                    ],
                                                                    1
                                                                  )
                                                                : _vm._e(),
                                                              _vm._v(" "),
                                                              _c(
                                                                "v-list-tile",
                                                                {
                                                                  attrs: {
                                                                    disabled:
                                                                      !_vm.checkActive(),
                                                                  },
                                                                  on: {
                                                                    click:
                                                                      function (
                                                                        $event
                                                                      ) {
                                                                        return _vm.$router.push(
                                                                          {
                                                                            name: "view_project",
                                                                            // name: 'create_visit_request_list',
                                                                            params:
                                                                              {
                                                                                id: props
                                                                                  .item
                                                                                  .id,
                                                                                currentCard:
                                                                                  "taskLists",
                                                                              },
                                                                          }
                                                                        )
                                                                      },
                                                                  },
                                                                },
                                                                [
                                                                  _c(
                                                                    "v-list-tile-title",
                                                                    [
                                                                      _vm._v(
                                                                        "\n                                                                        " +
                                                                          _vm._s(
                                                                            _vm.trans(
                                                                              "data.add_task"
                                                                            )
                                                                          ) +
                                                                          "\n                                                                    "
                                                                      ),
                                                                    ]
                                                                  ),
                                                                ],
                                                                1
                                                              ),
                                                              _vm._v(" "),
                                                              _vm.$can(
                                                                "tickets.create"
                                                              )
                                                                ? _c(
                                                                    "v-list-tile",
                                                                    {
                                                                      attrs: {
                                                                        disabled:
                                                                          !_vm.checkActive(),
                                                                      },
                                                                      on: {
                                                                        click:
                                                                          function (
                                                                            $event
                                                                          ) {
                                                                            return _vm.$router.push(
                                                                              {
                                                                                name: "view_project",
                                                                                // name: 'create_visit_request_list',
                                                                                params:
                                                                                  {
                                                                                    id: props
                                                                                      .item
                                                                                      .id,
                                                                                    currentCard:
                                                                                      "visitRequests",
                                                                                    customer_id:
                                                                                      props
                                                                                        .item
                                                                                        .customer_id,
                                                                                    request_type:
                                                                                      "visit_request",
                                                                                  },
                                                                              }
                                                                            )
                                                                          },
                                                                      },
                                                                    },
                                                                    [
                                                                      _c(
                                                                        "v-list-tile-title",
                                                                        [
                                                                          _vm._v(
                                                                            "\n                                                                        " +
                                                                              _vm._s(
                                                                                _vm.trans(
                                                                                  "data.create_a_visit_request"
                                                                                )
                                                                              ) +
                                                                              "\n                                                                    "
                                                                          ),
                                                                        ]
                                                                      ),
                                                                    ],
                                                                    1
                                                                  )
                                                                : _vm._e(),
                                                              _vm._v(" "),
                                                              _vm.$can(
                                                                "project.delete"
                                                              )
                                                                ? _c(
                                                                    "v-list-tile",
                                                                    {
                                                                      attrs: {
                                                                        disabled:
                                                                          !_vm.checkActive(),
                                                                      },
                                                                      on: {
                                                                        click:
                                                                          function (
                                                                            $event
                                                                          ) {
                                                                            return _vm.deleteProject(
                                                                              props
                                                                                .item
                                                                                .id
                                                                            )
                                                                          },
                                                                      },
                                                                    },
                                                                    [
                                                                      _c(
                                                                        "v-list-tile-title",
                                                                        [
                                                                          _vm._v(
                                                                            "\n                                                                        " +
                                                                              _vm._s(
                                                                                _vm.trans(
                                                                                  "messages.delete"
                                                                                )
                                                                              ) +
                                                                              "\n                                                                    "
                                                                          ),
                                                                        ]
                                                                      ),
                                                                    ],
                                                                    1
                                                                  )
                                                                : _vm._e(),
                                                              _vm._v(" "),
                                                              _vm.$can(
                                                                "project.edit"
                                                              )
                                                                ? _c(
                                                                    "v-list-tile",
                                                                    {
                                                                      attrs: {
                                                                        disabled:
                                                                          !_vm.checkActive(),
                                                                      },
                                                                      on: {
                                                                        click:
                                                                          function (
                                                                            $event
                                                                          ) {
                                                                            return _vm.edit(
                                                                              props
                                                                                .item
                                                                                .id
                                                                            )
                                                                          },
                                                                      },
                                                                    },
                                                                    [
                                                                      _c(
                                                                        "v-list-tile-title",
                                                                        [
                                                                          _vm._v(
                                                                            "\n                                                                        " +
                                                                              _vm._s(
                                                                                _vm.trans(
                                                                                  "messages.edit"
                                                                                )
                                                                              ) +
                                                                              "\n                                                                    "
                                                                          ),
                                                                        ]
                                                                      ),
                                                                    ],
                                                                    1
                                                                  )
                                                                : _vm._e(),
                                                              _vm._v(" "),
                                                              _vm.$can(
                                                                "project.list"
                                                              )
                                                                ? _c(
                                                                    "v-list-tile",
                                                                    {
                                                                      on: {
                                                                        click:
                                                                          function (
                                                                            $event
                                                                          ) {
                                                                            return _vm.view(
                                                                              props
                                                                                .item
                                                                                .id
                                                                            )
                                                                          },
                                                                      },
                                                                    },
                                                                    [
                                                                      _c(
                                                                        "v-list-tile-title",
                                                                        [
                                                                          _vm._v(
                                                                            "\n                                                                        " +
                                                                              _vm._s(
                                                                                _vm.trans(
                                                                                  "data.view"
                                                                                )
                                                                              ) +
                                                                              "\n                                                                    "
                                                                          ),
                                                                        ]
                                                                      ),
                                                                    ],
                                                                    1
                                                                  )
                                                                : _vm._e(),
                                                              _vm._v(" "),
                                                              _vm.$can(
                                                                "report.create"
                                                              )
                                                                ? _c(
                                                                    "v-list-tile",
                                                                    {
                                                                      attrs: {
                                                                        disabled:
                                                                          !_vm.checkActive(),
                                                                      },
                                                                      on: {
                                                                        click:
                                                                          function (
                                                                            $event
                                                                          ) {
                                                                            return _vm.$router.push(
                                                                              {
                                                                                name: "add_report",
                                                                                params:
                                                                                  {
                                                                                    id: props
                                                                                      .item
                                                                                      .id,
                                                                                  },
                                                                              }
                                                                            )
                                                                          },
                                                                      },
                                                                    },
                                                                    [
                                                                      _c(
                                                                        "v-list-tile-title",
                                                                        [
                                                                          _vm._v(
                                                                            "\n                                                                        " +
                                                                              _vm._s(
                                                                                _vm.trans(
                                                                                  "data.create_a_report"
                                                                                )
                                                                              ) +
                                                                              "\n                                                                    "
                                                                          ),
                                                                        ]
                                                                      ),
                                                                    ],
                                                                    1
                                                                  )
                                                                : _vm._e(),
                                                              _vm._v(" "),
                                                              _vm.$can(
                                                                "report.view"
                                                              )
                                                                ? _c(
                                                                    "v-list-tile",
                                                                    {
                                                                      attrs: {
                                                                        disabled:
                                                                          !_vm.checkActive(),
                                                                      },
                                                                      on: {
                                                                        click:
                                                                          function (
                                                                            $event
                                                                          ) {
                                                                            return _vm.$router.push(
                                                                              {
                                                                                name: "reports_list",
                                                                                params:
                                                                                  {
                                                                                    id: props
                                                                                      .item
                                                                                      .id,
                                                                                  },
                                                                              }
                                                                            )
                                                                          },
                                                                      },
                                                                    },
                                                                    [
                                                                      _c(
                                                                        "v-list-tile-title",
                                                                        [
                                                                          _vm._v(
                                                                            "\n                                                                        " +
                                                                              _vm._s(
                                                                                _vm.trans(
                                                                                  "data.reports_review"
                                                                                )
                                                                              ) +
                                                                              "\n                                                                    "
                                                                          ),
                                                                        ]
                                                                      ),
                                                                    ],
                                                                    1
                                                                  )
                                                                : _vm._e(),
                                                              _vm._v(" "),
                                                              _c(
                                                                "v-list-tile",
                                                                {
                                                                  attrs: {
                                                                    disabled:
                                                                      !_vm.checkActive(),
                                                                  },
                                                                  on: {
                                                                    click:
                                                                      function (
                                                                        $event
                                                                      ) {
                                                                        return _vm.$router.push(
                                                                          {
                                                                            name: "project.schedule",
                                                                            params:
                                                                              {
                                                                                project_id:
                                                                                  props
                                                                                    .item
                                                                                    .id,
                                                                              },
                                                                          }
                                                                        )
                                                                      },
                                                                  },
                                                                },
                                                                [
                                                                  _c(
                                                                    "v-list-tile-title",
                                                                    [
                                                                      _vm._v(
                                                                        "\n                                                                        " +
                                                                          _vm._s(
                                                                            _vm.trans(
                                                                              "data.schedule"
                                                                            )
                                                                          ) +
                                                                          "\n                                                                    "
                                                                      ),
                                                                    ]
                                                                  ),
                                                                ],
                                                                1
                                                              ),
                                                              _vm._v(" "),
                                                              _c(
                                                                "v-list-tile",
                                                                {
                                                                  attrs: {
                                                                    disabled:
                                                                      !_vm.checkActive(),
                                                                  },
                                                                  on: {
                                                                    click:
                                                                      function (
                                                                        $event
                                                                      ) {
                                                                        return _vm.$router.push(
                                                                          {
                                                                            name: "view_project",
                                                                            // name: 'project.attachments',
                                                                            params:
                                                                              {
                                                                                id: props
                                                                                  .item
                                                                                  .id,
                                                                                currentCard:
                                                                                  "document",
                                                                                media:
                                                                                  props.item,
                                                                              },
                                                                          }
                                                                        )
                                                                      },
                                                                  },
                                                                },
                                                                [
                                                                  _c(
                                                                    "v-list-tile-title",
                                                                    [
                                                                      _vm._v(
                                                                        "\n                                                                        " +
                                                                          _vm._s(
                                                                            _vm.trans(
                                                                              "data.attachments"
                                                                            )
                                                                          ) +
                                                                          "\n                                                                    "
                                                                      ),
                                                                    ]
                                                                  ),
                                                                ],
                                                                1
                                                              ),
                                                              _vm._v(" "),
                                                              _c(
                                                                "v-list-tile",
                                                                {
                                                                  attrs: {
                                                                    disabled:
                                                                      !_vm.checkActive(),
                                                                  },
                                                                  on: {
                                                                    click:
                                                                      function (
                                                                        $event
                                                                      ) {
                                                                        return _vm.$router.push(
                                                                          {
                                                                            name: "view_project",
                                                                            // name: 'create_visit_request_list',
                                                                            params:
                                                                              {
                                                                                id: props
                                                                                  .item
                                                                                  .id,
                                                                                currentCard:
                                                                                  "visitInvoices",
                                                                              },
                                                                          }
                                                                        )
                                                                      },
                                                                  },
                                                                },
                                                                [
                                                                  _c(
                                                                    "v-list-tile-title",
                                                                    [
                                                                      _vm._v(
                                                                        "\n                                                                        " +
                                                                          _vm._s(
                                                                            _vm.trans(
                                                                              "messages.invoices"
                                                                            )
                                                                          ) +
                                                                          "\n                                                                    "
                                                                      ),
                                                                    ]
                                                                  ),
                                                                ],
                                                                1
                                                              ),
                                                            ],
                                                            1
                                                          ),
                                                        ],
                                                        1
                                                      ),
                                                    ],
                                                    1
                                                  ),
                                                ]),
                                                _vm._v(" "),
                                                _c("td", [
                                                  _c(
                                                    "div",
                                                    {
                                                      attrs: {
                                                        align: "center",
                                                      },
                                                    },
                                                    [
                                                      _vm._v(
                                                        "\n                                                        " +
                                                          _vm._s(
                                                            props.item.id
                                                          ) +
                                                          "\n                                                    "
                                                      ),
                                                    ]
                                                  ),
                                                ]),
                                                _vm._v(" "),
                                                _c("td", [
                                                  _c(
                                                    "div",
                                                    {
                                                      attrs: {
                                                        align: "center",
                                                      },
                                                    },
                                                    [
                                                      _vm._v(
                                                        "\n                                                        " +
                                                          _vm._s(
                                                            props.item.name
                                                          ) +
                                                          "\n                                                    "
                                                      ),
                                                    ]
                                                  ),
                                                ]),
                                                _vm._v(" "),
                                                _c("td", [
                                                  _c(
                                                    "div",
                                                    {
                                                      attrs: {
                                                        align: "center",
                                                      },
                                                    },
                                                    [
                                                      _c(
                                                        "v-chip",
                                                        {
                                                          staticClass: "ma-2",
                                                          attrs: {
                                                            color: _vm.getColor(
                                                              props.item.status
                                                            ),
                                                            "text-color":
                                                              "white",
                                                          },
                                                        },
                                                        [
                                                          _vm._v(
                                                            "\n                                                            " +
                                                              _vm._s(
                                                                _vm.trans(
                                                                  "messages." +
                                                                    props.item
                                                                      .status
                                                                )
                                                              ) +
                                                              "\n                                                        "
                                                          ),
                                                        ]
                                                      ),
                                                    ],
                                                    1
                                                  ),
                                                ]),
                                                _vm._v(" "),
                                                _c("td", [
                                                  _c(
                                                    "div",
                                                    {
                                                      attrs: {
                                                        align: "center",
                                                      },
                                                    },
                                                    [
                                                      _c(
                                                        "v-btn",
                                                        {
                                                          attrs: { icon: "" },
                                                          on: {
                                                            click: function (
                                                              $event
                                                            ) {
                                                              return _vm.markAsFavorite(
                                                                props.item
                                                              )
                                                            },
                                                          },
                                                        },
                                                        [
                                                          _c(
                                                            "v-icon",
                                                            {
                                                              attrs: {
                                                                color:
                                                                  _vm.toggleFavorite(
                                                                    props.item
                                                                  ),
                                                              },
                                                            },
                                                            [
                                                              _vm._v(
                                                                "\n                                                                star\n                                                            "
                                                              ),
                                                            ]
                                                          ),
                                                        ],
                                                        1
                                                      ),
                                                    ],
                                                    1
                                                  ),
                                                ]),
                                                _vm._v(" "),
                                                _c("td", [
                                                  _c(
                                                    "div",
                                                    {
                                                      attrs: {
                                                        align: "center",
                                                      },
                                                    },
                                                    [
                                                      _c("avatar", {
                                                        staticClass: "mr-2",
                                                        attrs: {
                                                          members:
                                                            props.item.owners,
                                                          backGround:
                                                            _vm.backGround,
                                                          status: _vm.status,
                                                        },
                                                      }),
                                                    ],
                                                    1
                                                  ),
                                                ]),
                                                _vm._v(" "),
                                                _c("td", [
                                                  _c(
                                                    "div",
                                                    {
                                                      attrs: {
                                                        align: "center",
                                                      },
                                                    },
                                                    [
                                                      _c("avatar", {
                                                        staticClass: "mr-2",
                                                        attrs: {
                                                          members:
                                                            props.item.members,
                                                        },
                                                      }),
                                                    ],
                                                    1
                                                  ),
                                                ]),
                                                _vm._v(" "),
                                                _c(
                                                  "td",
                                                  [
                                                    _c("v-progress-linear", {
                                                      attrs: {
                                                        striped: "",
                                                        value: _vm.getprogress(
                                                          props.item.status
                                                        ),
                                                      },
                                                    }),
                                                  ],
                                                  1
                                                ),
                                              ]
                                            },
                                          },
                                        ]),
                                      }),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c("br"),
          _vm._v(" "),
          _c(
            "div",
            { attrs: { align: "center" } },
            [
              _c(
                "v-btn",
                {
                  staticStyle: {
                    "background-color": "#06706d",
                    color: "white",
                  },
                  on: {
                    click: function ($event) {
                      return _vm.$router.go(-1)
                    },
                  },
                },
                [
                  _vm._v(
                    "\n                    " +
                      _vm._s(_vm.trans("messages.back")) +
                      "\n                "
                  ),
                ]
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c("br"),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);