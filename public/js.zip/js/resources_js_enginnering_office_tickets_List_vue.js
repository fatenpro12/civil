"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_enginnering_office_tickets_List_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/AcceptEnginneringOfficeModal.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/AcceptEnginneringOfficeModal.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../store */ "./resources/js/store/index.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'permission',
  data: function data() {
    return {
      users: [],
      enginners: [],
      arr: [],
      dialog: false,
      dead_line_date: null,
      loading: false,
      status: '',
      office_id: null,
      id: '',
      request_id: '',
      inputs: [],
      is_show: false,
      enginnering_types: [],
      valid: true,
      project: null
    };
  },
  mounted: function mounted() {
    var self = this;
    self.getEnginneringTypes();
    self.setCurrentUser();
    console.log(self.inputs, self.enginnering_types);
  },
  computed: {
    computedDateFormattedMomentjs: function computedDateFormattedMomentjs() {
      var self = this;
      return null; //self.dead_line_date
      // ? moment(self.location.instrument_date).format('dddd, MMMM Do YYYY')
      // : '';
    },
    computedDateFormattedDatefns: function computedDateFormattedDatefns() {
      var self = this;
      return self.dead_line_date;
      // ? format(parseISO(self.location.instrument_date), 'EEEE, MMMM do yyyy')
      //  : '';
    }
  },

  methods: {
    close: function close() {
      var self = this;
      self.dialog = false;
      self.loading = false;
      self.reset();
      self.resetValidation();
      self.inputs = [];
      self.arr = [];
      self.is_show = false;
    },
    reset: function reset() {
      this.$refs.form.reset();
    },
    resetValidation: function resetValidation() {
      this.$refs.form.resetValidation();
    },
    add: function add(k) {
      var _this = this;
      var myArrayFiltered = this.enginnering_types.filter(function (array) {
        return _this.arr.every(function (filter) {
          return !(filter === array.key);
        });
      });
      if (this.inputs[k].enginner_id != '') {
        this.inputs.push({
          enginner_id: '',
          isDefault: '',
          users: [],
          enginnering_types: myArrayFiltered
        });
      } else {
        alert('please fill field');
      }
    },
    remove: function remove(index) {
      this.arr.splice(index, 1);
      this.inputs.splice(index, 1);
    },
    updatevalues1: function updatevalues1(value, key) {
      var self = this;
      self.arr.push(value);
      axios.post('/enginner_office/get-office-empoloyees-specialty', {
        office_id: self.office_id,
        specialty_id: value
      }).then(function (response) {
        self.inputs[key].users = response.data;
        console.log(self.inputs);
      })["catch"](function (err) {
        console.log(err.response.status);
        if (err.response.status === 401) {
          _store__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch('auth/handleResponse', err.response);
        }
      });
      ;

      // self.current_customer = value;
    },
    setCurrentUser: function setCurrentUser() {
      var self = this;
      axios.get('/get-current-user').then(function (response) {
        if (!response.data.error_code) {
          var user = response.data.data.original;
          self.enginner = user.id;
        } else {
          self.$store.commit('hideLoader');
          self.$store.commit('showSnackbar', {
            message: response.data.error_description,
            color: 'red'
          });
        }

        //  self.resetvalues(1);
      });
    },
    fillData: function fillData(data) {
      var self = this;
      self.dialog = true;
      self.status = data.status;
      self.office_id = data.office_id;
      self.request_id = data.id;
      axios.post('/enginner_office/get-office-empoloyees-request', {
        office_id: self.office_id,
        request_id: self.request_id
      }).then(function (response) {
        if (response.data.length > 0) {
          var tmp = response.data;
          for (var i = 0; i < tmp.length; i++) {
            self.inputs.push({
              // type: tmp[i] != undefined ? tmp[i].name : ' ',
              specialty_id: tmp[i] != undefined ? tmp[i].id : '',
              enginner_id: '',
              enginnering_types: self.enginnering_types,
              isDefault: '',
              users: tmp[i] != undefined ? tmp[i].employees : []
            });
          }
          console.log(self.inputs);
        } else {
          self.is_show = true;
          self.inputs.push({
            type: ' ',
            specialty_id: null,
            enginner_id: '',
            isDefault: '',
            enginnering_types: self.enginnering_types,
            users: []
          });
        }
      })["catch"](function (err) {
        console.log(err.response.status);
        if (err.response.status === 401) {
          _store__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch('auth/handleResponse', err.response);
        }
      });
      ;
    },
    getEmployeeSpecialty: function getEmployeeSpecialty(specialty_id) {
      var self = this;
      axios.post('/enginner_office/get-office-empoloyees-specialty', {
        office_id: self.office_id,
        specialty_id: specialty_id
      }).then(function (response) {
        return response.data;
      })["catch"](function (err) {
        console.log(err.response.status);
        if (err.response.status === 401) {
          _store__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch('auth/handleResponse', err.response);
        }
      });
      ;
    },
    //
    save: function save() {
      var self = this;
      var data = {
        id: self.request_id,
        default_enginners: self.inputs,
        dead_line_date: self.dead_line_date,
        enginners: self.enginners
      };
      if (this.$refs.form.validate()) {
        self.loading = true;
        axios.post('/enginner_office/accept-project', data).then(function (response) {
          if (!response.data.error_code) {
            self.loading = false;
            self.dialog = false;
            self.reset();
            self.resetValidation();
            self.inputs.splice(1);
            self.$emit('next');
            self.$store.commit('hideLoader');
            self.$store.commit('showSnackbar', {
              message: response.data.data,
              color: 'green'
            });
            self.inputs = [];
          } else {
            self.$store.commit('hideLoader');
            self.$store.commit('showSnackbar', {
              message: response.data.error_description,
              color: 'red'
            });
          }
        });
      }
    },
    getEnginneringTypes: function getEnginneringTypes() {
      var self = this;
      axios.get('/get-enginnering-types').then(function (response) {
        self.enginnering_types = response.data;
      })["catch"](function (err) {
        console.log(err.response.status);
        if (err.response.status === 401) {
          _store__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch('auth/handleResponse', err.response);
        }
      });
      ;
    },
    getDefaultMembers: function getDefaultMembers(id) {
      var self = this;
      axios.get('get-default-members/' + id).then(function (response) {
        // if (response.data.length > 0) {
        //     self.enginners = response.data;
        //     self.inputs = [
        //         {
        //             enginner_id: '',
        //             isDefault: '',
        //         },
        //     ];
        // }
      })["catch"](function (error) {
        self.type = '-';
      });
      return self.type;
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/AcceptingEnginnerModal.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/AcceptingEnginnerModal.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../store */ "./resources/js/store/index.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'permission',
  data: function data() {
    return {
      users: [],
      enginners: [],
      arr: [],
      dialog: false,
      dead_line_date: null,
      loading: false,
      status: '',
      office_id: null,
      id: '',
      valid: true
    };
  },
  mounted: function mounted() {
    var self = this;
    self.setCurrentUser();
  },
  computed: {
    computedDateFormattedMomentjs: function computedDateFormattedMomentjs() {
      var self = this;
      return null; //self.dead_line_date
      // ? moment(self.location.instrument_date).format('dddd, MMMM Do YYYY')
      // : '';
    },
    computedDateFormattedDatefns: function computedDateFormattedDatefns() {
      var self = this;
      return self.dead_line_date;
      // ? format(parseISO(self.location.instrument_date), 'EEEE, MMMM do yyyy')
      //  : '';
    }
  },

  methods: {
    close: function close() {
      var self = this;
      self.dialog = false;
      self.loading = false;
      self.reset();
      self.resetValidation();
      self.inputs.splice(1);
      self.arr = [];
    },
    reset: function reset() {
      this.$refs.form.reset();
    },
    resetValidation: function resetValidation() {
      this.$refs.form.resetValidation();
    },
    setCurrentUser: function setCurrentUser() {
      var self = this;
      axios.get('/get-current-user').then(function (response) {
        if (!response.data.error_code) {
          var user = response.data.data.original;
          self.enginner = user.id;
        } else {
          self.$store.commit('hideLoader');
          self.$store.commit('showSnackbar', {
            message: response.data.error_description,
            color: 'red'
          });
        }
      });
    },
    create: function create(data) {
      var self = this;
      self.dialog = true;
      self.id = data.id;
    },
    fillData: function fillData(data) {
      var self = this;
      self.id = data.id;
    },
    save: function save() {
      var self = this;
      var data = {
        request_id: self.id,
        dead_line_date: self.dead_line_date
      };
      if (this.$refs.form.validate()) {
        self.loading = true;
        axios.post('/enginner_office/accept-request-by-enginner', data).then(function (response) {
          if (!response.data.error_code) {
            self.loading = false;
            self.dialog = false;
            self.reset();
            self.resetValidation();
            self.$emit('next');
            self.$store.commit('hideLoader');
            self.$store.commit('showSnackbar', {
              message: response.data.data,
              color: 'green'
            });
          } else {
            self.$store.commit('hideLoader');
            self.$store.commit('showSnackbar', {
              message: response.data.error_description,
              color: 'red'
            });
            self.loading = false;
          }
        });
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/List.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/List.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _view_visit_request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./view_visit_request */ "./resources/js/common/visit-request/view_visit_request.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  components: {
    ViewVisitRequest: _view_visit_request__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  props: {
    url: {
      type: String
    },
    params: {
      type: Object,
      "default": null
    }
  },
  data: function data() {
    var self = this;
    return {
      expand: true,
      currentUser: '',
      projects: [],
      total_items: 0,
      loading: false,
      pagination: {
        totalItems: 0
      },
      projectRequests: [],
      request_types: [],
      headers: [{
        text: self.trans('messages.action'),
        value: false,
        align: 'center',
        sortable: false
      }, {
        text: self.trans('data.id'),
        value: false,
        align: 'center',
        sortable: true
      }, {
        text: self.trans('messages.status'),
        value: 'status',
        align: 'center',
        sortable: true
      }, {
        text: self.trans('messages.customer'),
        value: 'customer',
        align: 'center',
        sortable: true
      }, {
        text: self.trans('data.project_name'),
        value: 'project_name',
        align: 'center',
        sortable: true
      }, {
        text: self.trans('data.enginnering_type'),
        value: 'enginnering_type',
        align: 'center',
        sortable: true
      }, {
        text: self.trans('messages.created_at'),
        value: 'created_at',
        align: 'center',
        sortable: true
      }],
      items: [],
      type: '',
      project_name: ''
    };
  },
  watch: {
    pagination: {
      handler: function handler() {
        this.getAllProjectRequest();
      }
    }
  },
  mounted: function mounted() {
    var self = this;
    self.$eventBus.$on('updateTicketsTable', function (data) {
      self.projectRequest = [];
      self.projects = [];
      self.getAllProjectRequest();
    });
  },
  beforeDestroy: function beforeDestroy() {
    var self = this;
    self.$eventBus.$off('updateTicketsTable');
  },
  methods: {
    viewReport: function viewReport(item) {
      this.$router.push({
        name: 'edit_report',
        params: {
          id: item.id
          //  id: item.report.media[item.report.media.length-1].full_url?item.report.media[item.report.media.length-1].full_url:item.report.media[item.report.media.length-1].original_url
        }
      });
    },
    editRequest: function editRequest(request) {
      this.$router.push({
        name: 'edit_visit_request_estate_list',
        params: {
          id: request.id
        }
      });
    },
    sendRequest: function sendRequest(request) {
      var self = this;
      self.$store.commit('showDialog', {
        type: 'confirm',
        icon: 'warning',
        title: self.trans('messages.are_you_sure'),
        okCb: function okCb() {
          axios.post('confirm-send', {
            request_id: request.id
          }).then(function (response) {
            self.projectRequest = [];
            self.projects = [];
            self.$store.commit('showSnackbar', {
              message: response.data.data,
              color: 'green'
            });
            self.getAllProjectRequest();
          })["catch"](function (error) {
            console.log(error);
          });
        },
        cancelCb: function cancelCb() {
          console.log('CANCEL');
        }
      });
    },
    removeProject: function removeProject(id) {
      var self = this;
      self.$store.commit('showDialog', {
        type: 'confirm',
        icon: 'warning',
        title: self.trans('messages.are_you_sure'),
        message: self.trans('messages.you_cant_restore_it'),
        okCb: function okCb() {
          axios["delete"]('request/' + id).then(function (response) {
            self.$store.commit('showSnackbar', {
              message: response.data.msg,
              color: response.data.success
            });
            self.projectRequest = [];
            self.projects = [];
            self.getAllProjectRequest();
          })["catch"](function (error) {
            console.log(error);
          });
        },
        cancelCb: function cancelCb() {
          console.log('CANCEL');
        }
      });
    },
    viewRequest: function viewRequest(request) {
      this.$refs.viewVisitRequest.create(request.id);
    },
    getVisitRequestType: function getVisitRequestType(id) {
      var self = this;
      axios.get('/visit-request-type/' + id).then(function (response) {
        self.type = response.data.data;
      })["catch"](function (error) {
        self.type = '-';
      });
      return self.type;
    },
    getAllProjectRequest: function getAllProjectRequest() {
      var self = this;
      self.loading = true;
      axios.get(self.url, {
        params: self.params
      }).then(function (response) {
        self.total_items = response.data.length;
        self.projectRequests = response.data.data;
        self.projects = response.data;
        self.loading = false;
      })["catch"](function (err) {
        console.log(err.response.status);
        if (err.response.status === 401) {
          store.dispatch('auth/handleResponse', err.response);
        }
      });
      ;
    },
    viewProject: function viewProject(id) {
      var self = this;
      self.$router.push({
        name: 'view_project',
        params: {
          id: id
        }
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/view_visit_request.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/view_visit_request.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../store */ "./resources/js/store/index.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  data: function data() {
    return {
      propRequestId: null,
      dialog: false,
      project_name: '',
      loading: false,
      request_type: '',
      customer: '',
      dead_line_date: null,
      note: '',
      //
      enginnering_type: '',
      request_enginners: [],
      offices: []
    };
  },
  methods: {
    getEnginners: function getEnginners() {
      var self = this;
      axios.get('get-requests-enginners/' + self.propRequestId).then(function (response) {
        self.request_enginners = response.data;
      });
    },
    create: function create(data) {
      this.dialog = true;
      this.propRequestId = data;
      var self = this;
      self.getEnginners();
      this.loadRequest(function () {});
    },
    loadRequest: function loadRequest() {
      var self = this;
      axios.get('request/' + self.propRequestId).then(function (response) {
        console.log(response.data.msg);
        if (response.data.success) {
          var tem = response.data.msg;
          self.enginnering_type = tem.request.specialties ? tem.request.specialties.map(function (x) {
            return x.name;
          }).join(',') : '';
          self.request_type = tem.request.request_type;
          self.project_name = tem.request.projectName;
          self.customer = tem.request.customer;
          self.offices = tem.request.offices;
          self.note = tem.request.note;
          self.dead_line_date = tem.request.dead_line_date;
        } else {
          self.$store.commit('showSnackbar', {
            message: response.data.msg,
            color: response.data.success
          });
        }
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/enginnering_office/tickets/List.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/enginnering_office/tickets/List.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _common_visit_request_AcceptEnginneringOfficeModal_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../common/visit-request/AcceptEnginneringOfficeModal.vue */ "./resources/js/common/visit-request/AcceptEnginneringOfficeModal.vue");
/* harmony import */ var _common_visit_request_AcceptingEnginnerModal_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../common/visit-request/AcceptingEnginnerModal.vue */ "./resources/js/common/visit-request/AcceptingEnginnerModal.vue");
/* harmony import */ var _common_visit_request_List__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../common/visit-request/List */ "./resources/js/common/visit-request/List.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  components: {
    AcceptEnginneringOfficeModal: _common_visit_request_AcceptEnginneringOfficeModal_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    AcceptingEnginnerModal: _common_visit_request_AcceptingEnginnerModal_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    VisitRequest: _common_visit_request_List__WEBPACK_IMPORTED_MODULE_2__["default"]
  },
  props: {
    id: {
      required: false
    }
  },
  data: function data() {
    var self = this;
    return {
      currentUser: '',
      projects: [],
      loading: false
    };
  },
  mounted: function mounted() {
    this.currentUser = this.getCurrentUser();
  },
  methods: {
    rejectProject: function rejectProject(request_id) {
      var self = this;
      self.$store.commit('showDialog', {
        type: 'confirm',
        icon: 'warning',
        title: self.trans('messages.are_you_sure'),
        message: self.trans('messages.you_cant_restore_it'),
        okCb: function okCb() {
          axios.post('/enginner_office/request-cancel', {
            request_id: request_id
          }).then(function (response) {
            if (!response.data.error_code) {
              self.$store.commit('showSnackbar', {
                message: response.data.data,
                color: 'green'
              });
              self.projectRequest = [];
              self.projects = [];
              self.$refs.visitRequest.getAllProjectRequest();
            }
          })["catch"](function (error) {
            console.log(error);
          });
        },
        cancelCb: function cancelCb() {
          console.log('CANCEL');
        }
      });
    },
    acceptRequestByEnginner: function acceptRequestByEnginner(item) {
      var self = this;
      self.$store.commit('showDialog', {
        type: 'confirm',
        icon: 'warning',
        title: self.trans('messages.are_you_sure'),
        message: self.trans('messages.are_you_sure'),
        okCb: function okCb() {
          self.$refs.acceptenginner.create(item);
        },
        cancelCb: function cancelCb() {
          console.log('CANCEL');
        }
      });
    },
    acceptProject: function acceptProject(item) {
      var self = this;
      self.$store.commit('showDialog', {
        type: 'confirm',
        icon: 'warning',
        title: self.trans('messages.are_you_sure'),
        message: self.trans('messages.are_you_sure'),
        okCb: function okCb() {
          var data = {
            status: item.status,
            id: item.id,
            project: item.project,
            office_id: item.offices[0].id
          };
          self.$refs.acceptenginneringoffice.fillData(data);
        },
        cancelCb: function cancelCb() {
          console.log('CANCEL');
        }
      });
    },
    createReport: function createReport(item) {
      var self = this;
      if (!item.report) self.$router.push({
        name: 'add_report',
        params: {
          id: item.projectId,
          visit_request_id: item.id
        }
      });else self.$router.push({
        name: 'edit_report',
        params: {
          id: item.report
        }
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/AcceptEnginneringOfficeModal.vue?vue&type=style&index=0&id=2246b9e7&scoped=true&lang=css&":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/AcceptEnginneringOfficeModal.vue?vue&type=style&index=0&id=2246b9e7&scoped=true&lang=css& ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "\n.style_rtl[data-v-2246b9e7] {\r\n    padding-left: 5px;\n}\n.style_ltr[data-v-2246b9e7] {\r\n    padding-right: 5px;\n}\r\n", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/AcceptingEnginnerModal.vue?vue&type=style&index=0&id=758dc7da&scoped=true&lang=css&":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/AcceptingEnginnerModal.vue?vue&type=style&index=0&id=758dc7da&scoped=true&lang=css& ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "\n.style_rtl[data-v-758dc7da] {\r\n    padding-left: 5px;\n}\n.style_ltr[data-v-758dc7da] {\r\n    padding-right: 5px;\n}\r\n", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/AcceptEnginneringOfficeModal.vue?vue&type=style&index=0&id=2246b9e7&scoped=true&lang=css&":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/AcceptEnginneringOfficeModal.vue?vue&type=style&index=0&id=2246b9e7&scoped=true&lang=css& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_AcceptEnginneringOfficeModal_vue_vue_type_style_index_0_id_2246b9e7_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AcceptEnginneringOfficeModal.vue?vue&type=style&index=0&id=2246b9e7&scoped=true&lang=css& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/AcceptEnginneringOfficeModal.vue?vue&type=style&index=0&id=2246b9e7&scoped=true&lang=css&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_AcceptEnginneringOfficeModal_vue_vue_type_style_index_0_id_2246b9e7_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_AcceptEnginneringOfficeModal_vue_vue_type_style_index_0_id_2246b9e7_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/AcceptingEnginnerModal.vue?vue&type=style&index=0&id=758dc7da&scoped=true&lang=css&":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/AcceptingEnginnerModal.vue?vue&type=style&index=0&id=758dc7da&scoped=true&lang=css& ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_AcceptingEnginnerModal_vue_vue_type_style_index_0_id_758dc7da_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AcceptingEnginnerModal.vue?vue&type=style&index=0&id=758dc7da&scoped=true&lang=css& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/AcceptingEnginnerModal.vue?vue&type=style&index=0&id=758dc7da&scoped=true&lang=css&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_AcceptingEnginnerModal_vue_vue_type_style_index_0_id_758dc7da_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_AcceptingEnginnerModal_vue_vue_type_style_index_0_id_758dc7da_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./resources/js/common/visit-request/AcceptEnginneringOfficeModal.vue":
/*!****************************************************************************!*\
  !*** ./resources/js/common/visit-request/AcceptEnginneringOfficeModal.vue ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _AcceptEnginneringOfficeModal_vue_vue_type_template_id_2246b9e7_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./AcceptEnginneringOfficeModal.vue?vue&type=template&id=2246b9e7&scoped=true& */ "./resources/js/common/visit-request/AcceptEnginneringOfficeModal.vue?vue&type=template&id=2246b9e7&scoped=true&");
/* harmony import */ var _AcceptEnginneringOfficeModal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./AcceptEnginneringOfficeModal.vue?vue&type=script&lang=js& */ "./resources/js/common/visit-request/AcceptEnginneringOfficeModal.vue?vue&type=script&lang=js&");
/* harmony import */ var _AcceptEnginneringOfficeModal_vue_vue_type_style_index_0_id_2246b9e7_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./AcceptEnginneringOfficeModal.vue?vue&type=style&index=0&id=2246b9e7&scoped=true&lang=css& */ "./resources/js/common/visit-request/AcceptEnginneringOfficeModal.vue?vue&type=style&index=0&id=2246b9e7&scoped=true&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _AcceptEnginneringOfficeModal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _AcceptEnginneringOfficeModal_vue_vue_type_template_id_2246b9e7_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render,
  _AcceptEnginneringOfficeModal_vue_vue_type_template_id_2246b9e7_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  "2246b9e7",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/common/visit-request/AcceptEnginneringOfficeModal.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/common/visit-request/AcceptingEnginnerModal.vue":
/*!**********************************************************************!*\
  !*** ./resources/js/common/visit-request/AcceptingEnginnerModal.vue ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _AcceptingEnginnerModal_vue_vue_type_template_id_758dc7da_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./AcceptingEnginnerModal.vue?vue&type=template&id=758dc7da&scoped=true& */ "./resources/js/common/visit-request/AcceptingEnginnerModal.vue?vue&type=template&id=758dc7da&scoped=true&");
/* harmony import */ var _AcceptingEnginnerModal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./AcceptingEnginnerModal.vue?vue&type=script&lang=js& */ "./resources/js/common/visit-request/AcceptingEnginnerModal.vue?vue&type=script&lang=js&");
/* harmony import */ var _AcceptingEnginnerModal_vue_vue_type_style_index_0_id_758dc7da_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./AcceptingEnginnerModal.vue?vue&type=style&index=0&id=758dc7da&scoped=true&lang=css& */ "./resources/js/common/visit-request/AcceptingEnginnerModal.vue?vue&type=style&index=0&id=758dc7da&scoped=true&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _AcceptingEnginnerModal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _AcceptingEnginnerModal_vue_vue_type_template_id_758dc7da_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render,
  _AcceptingEnginnerModal_vue_vue_type_template_id_758dc7da_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  "758dc7da",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/common/visit-request/AcceptingEnginnerModal.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/common/visit-request/List.vue":
/*!****************************************************!*\
  !*** ./resources/js/common/visit-request/List.vue ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _List_vue_vue_type_template_id_540dc196___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./List.vue?vue&type=template&id=540dc196& */ "./resources/js/common/visit-request/List.vue?vue&type=template&id=540dc196&");
/* harmony import */ var _List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./List.vue?vue&type=script&lang=js& */ "./resources/js/common/visit-request/List.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _List_vue_vue_type_template_id_540dc196___WEBPACK_IMPORTED_MODULE_0__.render,
  _List_vue_vue_type_template_id_540dc196___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/common/visit-request/List.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/common/visit-request/view_visit_request.vue":
/*!******************************************************************!*\
  !*** ./resources/js/common/visit-request/view_visit_request.vue ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _view_visit_request_vue_vue_type_template_id_68e2c6d9___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./view_visit_request.vue?vue&type=template&id=68e2c6d9& */ "./resources/js/common/visit-request/view_visit_request.vue?vue&type=template&id=68e2c6d9&");
/* harmony import */ var _view_visit_request_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./view_visit_request.vue?vue&type=script&lang=js& */ "./resources/js/common/visit-request/view_visit_request.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _view_visit_request_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _view_visit_request_vue_vue_type_template_id_68e2c6d9___WEBPACK_IMPORTED_MODULE_0__.render,
  _view_visit_request_vue_vue_type_template_id_68e2c6d9___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/common/visit-request/view_visit_request.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/enginnering_office/tickets/List.vue":
/*!**********************************************************!*\
  !*** ./resources/js/enginnering_office/tickets/List.vue ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _List_vue_vue_type_template_id_1086e236___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./List.vue?vue&type=template&id=1086e236& */ "./resources/js/enginnering_office/tickets/List.vue?vue&type=template&id=1086e236&");
/* harmony import */ var _List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./List.vue?vue&type=script&lang=js& */ "./resources/js/enginnering_office/tickets/List.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _List_vue_vue_type_template_id_1086e236___WEBPACK_IMPORTED_MODULE_0__.render,
  _List_vue_vue_type_template_id_1086e236___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/enginnering_office/tickets/List.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/common/visit-request/AcceptEnginneringOfficeModal.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************!*\
  !*** ./resources/js/common/visit-request/AcceptEnginneringOfficeModal.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AcceptEnginneringOfficeModal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AcceptEnginneringOfficeModal.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/AcceptEnginneringOfficeModal.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AcceptEnginneringOfficeModal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/common/visit-request/AcceptingEnginnerModal.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************!*\
  !*** ./resources/js/common/visit-request/AcceptingEnginnerModal.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AcceptingEnginnerModal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AcceptingEnginnerModal.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/AcceptingEnginnerModal.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AcceptingEnginnerModal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/common/visit-request/List.vue?vue&type=script&lang=js&":
/*!*****************************************************************************!*\
  !*** ./resources/js/common/visit-request/List.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./List.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/List.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/common/visit-request/view_visit_request.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************!*\
  !*** ./resources/js/common/visit-request/view_visit_request.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_view_visit_request_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./view_visit_request.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/view_visit_request.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_view_visit_request_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/enginnering_office/tickets/List.vue?vue&type=script&lang=js&":
/*!***********************************************************************************!*\
  !*** ./resources/js/enginnering_office/tickets/List.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./List.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/enginnering_office/tickets/List.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/common/visit-request/AcceptEnginneringOfficeModal.vue?vue&type=style&index=0&id=2246b9e7&scoped=true&lang=css&":
/*!*************************************************************************************************************************************!*\
  !*** ./resources/js/common/visit-request/AcceptEnginneringOfficeModal.vue?vue&type=style&index=0&id=2246b9e7&scoped=true&lang=css& ***!
  \*************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_AcceptEnginneringOfficeModal_vue_vue_type_style_index_0_id_2246b9e7_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AcceptEnginneringOfficeModal.vue?vue&type=style&index=0&id=2246b9e7&scoped=true&lang=css& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/AcceptEnginneringOfficeModal.vue?vue&type=style&index=0&id=2246b9e7&scoped=true&lang=css&");


/***/ }),

/***/ "./resources/js/common/visit-request/AcceptingEnginnerModal.vue?vue&type=style&index=0&id=758dc7da&scoped=true&lang=css&":
/*!*******************************************************************************************************************************!*\
  !*** ./resources/js/common/visit-request/AcceptingEnginnerModal.vue?vue&type=style&index=0&id=758dc7da&scoped=true&lang=css& ***!
  \*******************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_AcceptingEnginnerModal_vue_vue_type_style_index_0_id_758dc7da_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AcceptingEnginnerModal.vue?vue&type=style&index=0&id=758dc7da&scoped=true&lang=css& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/AcceptingEnginnerModal.vue?vue&type=style&index=0&id=758dc7da&scoped=true&lang=css&");


/***/ }),

/***/ "./resources/js/common/visit-request/AcceptEnginneringOfficeModal.vue?vue&type=template&id=2246b9e7&scoped=true&":
/*!***********************************************************************************************************************!*\
  !*** ./resources/js/common/visit-request/AcceptEnginneringOfficeModal.vue?vue&type=template&id=2246b9e7&scoped=true& ***!
  \***********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_AcceptEnginneringOfficeModal_vue_vue_type_template_id_2246b9e7_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_AcceptEnginneringOfficeModal_vue_vue_type_template_id_2246b9e7_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_AcceptEnginneringOfficeModal_vue_vue_type_template_id_2246b9e7_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AcceptEnginneringOfficeModal.vue?vue&type=template&id=2246b9e7&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/AcceptEnginneringOfficeModal.vue?vue&type=template&id=2246b9e7&scoped=true&");


/***/ }),

/***/ "./resources/js/common/visit-request/AcceptingEnginnerModal.vue?vue&type=template&id=758dc7da&scoped=true&":
/*!*****************************************************************************************************************!*\
  !*** ./resources/js/common/visit-request/AcceptingEnginnerModal.vue?vue&type=template&id=758dc7da&scoped=true& ***!
  \*****************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_AcceptingEnginnerModal_vue_vue_type_template_id_758dc7da_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_AcceptingEnginnerModal_vue_vue_type_template_id_758dc7da_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_AcceptingEnginnerModal_vue_vue_type_template_id_758dc7da_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AcceptingEnginnerModal.vue?vue&type=template&id=758dc7da&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/AcceptingEnginnerModal.vue?vue&type=template&id=758dc7da&scoped=true&");


/***/ }),

/***/ "./resources/js/common/visit-request/List.vue?vue&type=template&id=540dc196&":
/*!***********************************************************************************!*\
  !*** ./resources/js/common/visit-request/List.vue?vue&type=template&id=540dc196& ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_540dc196___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_540dc196___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_540dc196___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./List.vue?vue&type=template&id=540dc196& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/List.vue?vue&type=template&id=540dc196&");


/***/ }),

/***/ "./resources/js/common/visit-request/view_visit_request.vue?vue&type=template&id=68e2c6d9&":
/*!*************************************************************************************************!*\
  !*** ./resources/js/common/visit-request/view_visit_request.vue?vue&type=template&id=68e2c6d9& ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_view_visit_request_vue_vue_type_template_id_68e2c6d9___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_view_visit_request_vue_vue_type_template_id_68e2c6d9___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_view_visit_request_vue_vue_type_template_id_68e2c6d9___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./view_visit_request.vue?vue&type=template&id=68e2c6d9& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/view_visit_request.vue?vue&type=template&id=68e2c6d9&");


/***/ }),

/***/ "./resources/js/enginnering_office/tickets/List.vue?vue&type=template&id=1086e236&":
/*!*****************************************************************************************!*\
  !*** ./resources/js/enginnering_office/tickets/List.vue?vue&type=template&id=1086e236& ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_1086e236___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_1086e236___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_1086e236___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./List.vue?vue&type=template&id=1086e236& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/enginnering_office/tickets/List.vue?vue&type=template&id=1086e236&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/AcceptEnginneringOfficeModal.vue?vue&type=template&id=2246b9e7&scoped=true&":
/*!**************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/AcceptEnginneringOfficeModal.vue?vue&type=template&id=2246b9e7&scoped=true& ***!
  \**************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { attrs: { justify: "center" } },
    [
      _c(
        "v-dialog",
        {
          attrs: { persistent: "", "max-width": "750px" },
          model: {
            value: _vm.dialog,
            callback: function ($$v) {
              _vm.dialog = $$v
            },
            expression: "dialog",
          },
        },
        [
          _c(
            "v-card",
            [
              _c(
                "v-card-text",
                [
                  _c(
                    "v-form",
                    {
                      ref: "form",
                      attrs: { "lazy-validation": "" },
                      model: {
                        value: _vm.valid,
                        callback: function ($$v) {
                          _vm.valid = $$v
                        },
                        expression: "valid",
                      },
                    },
                    [
                      _c(
                        "v-container",
                        [
                          _c(
                            "div",
                            { staticStyle: {}, attrs: { cols: "12", sm: "6" } },
                            [
                              _c("v-datetime-picker", {
                                attrs: {
                                  label: _vm.trans("data.visit_datetime"),
                                  datetime: _vm.dead_line_date,
                                  okText: _vm.trans("data.ok"),
                                  clearText: _vm.trans("data.clear"),
                                  timeFormat: "HH:mm",
                                },
                                model: {
                                  value: _vm.dead_line_date,
                                  callback: function ($$v) {
                                    _vm.dead_line_date = $$v
                                  },
                                  expression: "dead_line_date",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _vm.enginners.length > 0
                            ? _c(
                                "v-layout",
                                { attrs: { row: "" } },
                                [
                                  _c(
                                    "v-flex",
                                    { attrs: { xs12: "", md12: "" } },
                                    [
                                      _c("v-autocomplete", {
                                        attrs: {
                                          "item-text": "name",
                                          "item-value": "id",
                                          items: _vm.users,
                                          multiple: "",
                                          rules: [
                                            function (v) {
                                              return (
                                                !!v ||
                                                _vm.trans("messages.required", {
                                                  name: _vm.trans(
                                                    "data.enginner"
                                                  ),
                                                })
                                              )
                                            },
                                          ],
                                          label: _vm.trans("data.enginner"),
                                          "error-messages":
                                            _vm.errors.collect("enginner"),
                                          required: "",
                                        },
                                        model: {
                                          value: _vm.enginners,
                                          callback: function ($$v) {
                                            _vm.enginners = $$v
                                          },
                                          expression: "enginners",
                                        },
                                      }),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              )
                            : _vm._e(),
                          _vm._v(" "),
                          _vm.enginners.length <= 0
                            ? _c(
                                "div",
                                _vm._l(_vm.inputs, function (input, k) {
                                  return _c(
                                    "v-layout",
                                    { key: k, attrs: { row: "" } },
                                    [
                                      _c(
                                        "v-flex",
                                        { attrs: { xs12: "", md4: "" } },
                                        [
                                          _c("v-text-field", {
                                            attrs: {
                                              label: _vm.trans(
                                                "data.enginnering_type"
                                              ),
                                              "data-vv-name":
                                                "enginnering_type",
                                              "data-vv-as": _vm.trans(
                                                "data.enginnering_type"
                                              ),
                                              "error-messages":
                                                _vm.errors.collect(
                                                  "enginnering_type"
                                                ),
                                              required: "",
                                            },
                                            model: {
                                              value:
                                                input.enginnering_types.find(
                                                  function (x) {
                                                    return (
                                                      x.key ===
                                                      input.specialty_id
                                                    )
                                                  }
                                                ).value,
                                              callback: function ($$v) {
                                                _vm.$set(
                                                  input.enginnering_types.find(
                                                    function (x) {
                                                      return (
                                                        x.key ===
                                                        input.specialty_id
                                                      )
                                                    }
                                                  ),
                                                  "value",
                                                  $$v
                                                )
                                              },
                                              expression:
                                                "input.enginnering_types.find(x => x.key === input.specialty_id).value",
                                            },
                                          }),
                                        ],
                                        1
                                      ),
                                      _vm._v(" "),
                                      _c(
                                        "v-flex",
                                        { attrs: { xs12: "", md3: "" } },
                                        [
                                          _c("v-autocomplete", {
                                            attrs: {
                                              "item-text": "name",
                                              "item-value": "id",
                                              items: input.users,
                                              rules: [
                                                function (v) {
                                                  return (
                                                    !!v ||
                                                    _vm.trans(
                                                      "messages.required",
                                                      {
                                                        name: _vm.trans(
                                                          "data.enginner"
                                                        ),
                                                      }
                                                    )
                                                  )
                                                },
                                              ],
                                              label: _vm.trans("data.enginner"),
                                              "error-messages":
                                                _vm.errors.collect("enginner"),
                                              required: "",
                                            },
                                            model: {
                                              value: input.enginner_id,
                                              callback: function ($$v) {
                                                _vm.$set(
                                                  input,
                                                  "enginner_id",
                                                  $$v
                                                )
                                              },
                                              expression: "input.enginner_id",
                                            },
                                          }),
                                        ],
                                        1
                                      ),
                                      _vm._v(" "),
                                      _c(
                                        "v-flex",
                                        { attrs: { xs12: "", md2: "" } },
                                        [
                                          _c("v-checkbox", {
                                            attrs: {
                                              label:
                                                _vm.trans("data.is_default"),
                                            },
                                            model: {
                                              value: input.isDefault,
                                              callback: function ($$v) {
                                                _vm.$set(
                                                  input,
                                                  "isDefault",
                                                  $$v
                                                )
                                              },
                                              expression: "input.isDefault",
                                            },
                                          }),
                                        ],
                                        1
                                      ),
                                      _vm._v(" "),
                                      _vm.is_show
                                        ? _c(
                                            "v-flex",
                                            { attrs: { xs12: "", md3: "" } },
                                            [
                                              _c(
                                                "v-btn",
                                                {
                                                  directives: [
                                                    {
                                                      name: "show",
                                                      rawName: "v-show",
                                                      value:
                                                        k ==
                                                          _vm.inputs.length -
                                                            1 && !_vm.isEdit,
                                                      expression:
                                                        "k == inputs.length - 1 && !isEdit",
                                                    },
                                                  ],
                                                  staticStyle: {
                                                    "background-color":
                                                      "#06706d",
                                                    color: "white",
                                                  },
                                                  attrs: { small: "", fab: "" },
                                                  on: {
                                                    click: function ($event) {
                                                      return _vm.add(k)
                                                    },
                                                  },
                                                },
                                                [
                                                  _c(
                                                    "v-icon",
                                                    { attrs: { dark: "" } },
                                                    [_vm._v(" add ")]
                                                  ),
                                                ],
                                                1
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "v-btn",
                                                {
                                                  directives: [
                                                    {
                                                      name: "show",
                                                      rawName: "v-show",
                                                      value:
                                                        k ||
                                                        (!k &&
                                                          _vm.inputs.length >
                                                            1 &&
                                                          !_vm.isEdit),
                                                      expression:
                                                        "k || (!k && inputs.length > 1 && !isEdit)",
                                                    },
                                                  ],
                                                  attrs: {
                                                    small: "",
                                                    fab: "",
                                                    color: "red",
                                                    dark: "",
                                                  },
                                                  on: {
                                                    click: function ($event) {
                                                      return _vm.remove(k)
                                                    },
                                                  },
                                                },
                                                [
                                                  _c("i", {
                                                    staticClass:
                                                      "fas fa-minus-circle",
                                                  }),
                                                ]
                                              ),
                                            ],
                                            1
                                          )
                                        : _vm._e(),
                                    ],
                                    1
                                  )
                                }),
                                1
                              )
                            : _vm._e(),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "v-card-actions",
                [
                  _c("v-spacer"),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      staticStyle: { color: "#06706d" },
                      attrs: { text: "" },
                      on: {
                        click: function ($event) {
                          return _vm.close()
                        },
                      },
                    },
                    [
                      _vm._v(
                        "\n                        " +
                          _vm._s(_vm.trans("data.cancel")) +
                          "\n                    "
                      ),
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      attrs: { dark: "", color: "teal" },
                      on: {
                        click: function ($event) {
                          return _vm.viewProject(_vm.project)
                        },
                      },
                    },
                    [
                      _vm._v(
                        "\n                        " +
                          _vm._s(_vm.trans("data.project_info")) +
                          "\n                    "
                      ),
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      staticStyle: {
                        "background-color": "#06706d",
                        color: "white",
                      },
                      attrs: {
                        color: "darken-1",
                        loading: _vm.loading,
                        disabled: _vm.loading || !_vm.checkActive(),
                        text: "",
                      },
                      on: {
                        click: function ($event) {
                          return _vm.save()
                        },
                      },
                    },
                    [
                      _vm._v(
                        "\n                        " +
                          _vm._s(_vm.trans("data.save")) +
                          "\n                    "
                      ),
                    ]
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/AcceptingEnginnerModal.vue?vue&type=template&id=758dc7da&scoped=true&":
/*!********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/AcceptingEnginnerModal.vue?vue&type=template&id=758dc7da&scoped=true& ***!
  \********************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { attrs: { justify: "center" } },
    [
      _c(
        "v-dialog",
        {
          attrs: { persistent: "", "max-width": "550px" },
          model: {
            value: _vm.dialog,
            callback: function ($$v) {
              _vm.dialog = $$v
            },
            expression: "dialog",
          },
        },
        [
          _c(
            "v-card",
            [
              _c("v-card-title", [
                _vm._v(_vm._s(_vm.trans("data.enginnering_office"))),
              ]),
              _vm._v(" "),
              _c(
                "v-card-text",
                [
                  _c(
                    "v-form",
                    {
                      ref: "form",
                      attrs: { "lazy-validation": "" },
                      model: {
                        value: _vm.valid,
                        callback: function ($$v) {
                          _vm.valid = $$v
                        },
                        expression: "valid",
                      },
                    },
                    [
                      _c("v-container", [
                        _c(
                          "div",
                          { staticStyle: {}, attrs: { cols: "12", sm: "6" } },
                          [
                            _c("v-datetime-picker", {
                              attrs: {
                                label: _vm.trans("data.visit_datetime"),
                                datetime: _vm.dead_line_date,
                                okText: _vm.trans("data.ok"),
                                clearText: _vm.trans("data.clear"),
                                timeFormat: "HH:mm",
                                rules: [
                                  function (v) {
                                    return (
                                      v.length == 0 ||
                                      _vm.trans("messages.required", {
                                        name: _vm.trans("data.visit_datetime"),
                                      })
                                    )
                                  },
                                ],
                                required: "",
                              },
                              model: {
                                value: _vm.dead_line_date,
                                callback: function ($$v) {
                                  _vm.dead_line_date = $$v
                                },
                                expression: "dead_line_date",
                              },
                            }),
                          ],
                          1
                        ),
                      ]),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "v-card-actions",
                [
                  _c("v-spacer"),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      staticStyle: { color: "#06706d" },
                      attrs: { text: "" },
                      on: {
                        click: function ($event) {
                          return _vm.close()
                        },
                      },
                    },
                    [
                      _vm._v(
                        "\n                        " +
                          _vm._s(_vm.trans("data.cancel")) +
                          "\n                    "
                      ),
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      staticStyle: {
                        "background-color": "#06706d",
                        color: "white",
                      },
                      attrs: {
                        color: "darken-1",
                        loading: _vm.loading,
                        disabled: _vm.loading || !_vm.checkActive(),
                        text: "",
                      },
                      on: {
                        click: function ($event) {
                          return _vm.save()
                        },
                      },
                    },
                    [
                      _vm._v(
                        "\n                        " +
                          _vm._s(_vm.trans("data.save")) +
                          "\n                    "
                      ),
                    ]
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/List.vue?vue&type=template&id=540dc196&":
/*!**************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/List.vue?vue&type=template&id=540dc196& ***!
  \**************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "v-container",
    {
      class: _vm.$vuetify.breakpoint.xsOnly ? "pt-4" : "",
      attrs: { "grid-list-md": "" },
    },
    [
      _c("ViewVisitRequest", { ref: "viewVisitRequest" }),
      _vm._v(" "),
      _c(
        "v-card",
        { staticClass: "mt-3" },
        [
          _c(
            "v-card-title",
            { attrs: { "primary-title": "", xs8: "", sm8: "" } },
            [
              _c("div", [
                _c("div", { staticClass: "headline" }, [
                  _vm._v(
                    "\n                    " +
                      _vm._s(_vm.trans("data.visit_requests")) +
                      "\n                "
                  ),
                ]),
              ]),
              _vm._v(" "),
              _c("v-spacer"),
              _vm._v(" "),
              _c(
                "v-btn",
                {
                  staticClass: "lighten-1",
                  staticStyle: {
                    "background-color": "#06706d",
                    color: "white",
                  },
                  attrs: { disabled: !_vm.checkActive() },
                  on: {
                    click: function ($event) {
                      return _vm.$router.push({
                        name: "create_visit_estate_request_list",
                        params: { request_type: "visit_request" },
                      })
                    },
                  },
                },
                [
                  _vm._v(
                    "\n                " +
                      _vm._s(_vm.trans("messages.add")) +
                      "\n                "
                  ),
                  _c("v-icon", { attrs: { right: "", dark: "" } }, [
                    _vm._v("add"),
                  ]),
                ],
                1
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c("v-divider"),
          _vm._v(" "),
          _c("v-data-table", {
            staticClass: "elevation-3",
            attrs: {
              headers: _vm.headers,
              pagination: _vm.pagination,
              "total-items": _vm.total_items,
              loading: _vm.loading,
              items: _vm.projects,
              expand: _vm.expand,
            },
            on: {
              "update:pagination": function ($event) {
                _vm.pagination = $event
              },
            },
            scopedSlots: _vm._u(
              [
                {
                  key: "items",
                  fn: function (props) {
                    return [
                      _c("tr", [
                        _c("td", [
                          _c(
                            "div",
                            {
                              staticStyle: {
                                display: "inline-flex",
                                "padding-left": "30%",
                              },
                              attrs: { align: "center" },
                            },
                            [
                              _vm._t("expandIcon", null, { props: props }),
                              _vm._v(" "),
                              _c(
                                "v-btn",
                                {
                                  attrs: {
                                    small: "",
                                    fab: "",
                                    dark: "",
                                    color: "success",
                                  },
                                  on: {
                                    click: function ($event) {
                                      return _vm.viewRequest(props.item)
                                    },
                                  },
                                },
                                [
                                  _c("v-icon", { attrs: { color: "white" } }, [
                                    _vm._v("info"),
                                  ]),
                                ],
                                1
                              ),
                              _vm._v(" "),
                              _vm._t("actions", null, { props: props }),
                              _vm._v(" "),
                              props.item.status == "new"
                                ? _c(
                                    "v-btn",
                                    {
                                      attrs: {
                                        disabled: !_vm.checkActive(),
                                        small: "",
                                        fab: "",
                                        color: "success",
                                      },
                                      on: {
                                        click: function ($event) {
                                          return _vm.editRequest(props.item)
                                        },
                                      },
                                    },
                                    [
                                      _c(
                                        "v-icon",
                                        { attrs: { color: "white" } },
                                        [_vm._v("edit")]
                                      ),
                                    ],
                                    1
                                  )
                                : _vm._e(),
                              _vm._v(" "),
                              _c(
                                "div",
                                [
                                  props.item.sent == 0 &&
                                  props.item.status == "new"
                                    ? _c(
                                        "v-btn",
                                        {
                                          attrs: {
                                            color: "primary",
                                            small: "",
                                            fab: "",
                                            disabled: !_vm.checkActive(),
                                          },
                                          on: {
                                            click: function ($event) {
                                              return _vm.sendRequest(props.item)
                                            },
                                          },
                                        },
                                        [
                                          _c(
                                            "v-icon",
                                            { attrs: { color: "white" } },
                                            [_vm._v("mail")]
                                          ),
                                        ],
                                        1
                                      )
                                    : _vm._e(),
                                ],
                                1
                              ),
                              _vm._v(" "),
                              props.item.status == "new" ||
                              props.item.status == "rejected"
                                ? _c(
                                    "v-btn",
                                    {
                                      attrs: {
                                        color: "error",
                                        disabled: !_vm.checkActive(),
                                        small: "",
                                        fab: "",
                                      },
                                      on: {
                                        click: function ($event) {
                                          return _vm.removeProject(
                                            props.item.id
                                          )
                                        },
                                      },
                                    },
                                    [
                                      _c(
                                        "v-icon",
                                        { attrs: { color: "white" } },
                                        [_vm._v("delete")]
                                      ),
                                    ],
                                    1
                                  )
                                : _vm._e(),
                            ],
                            2
                          ),
                        ]),
                        _vm._v(" "),
                        _c("td", [
                          _c("div", { attrs: { align: "center" } }, [
                            _vm._v(
                              "\n                        " +
                                _vm._s(props.item.id) +
                                "\n                    "
                            ),
                          ]),
                        ]),
                        _vm._v(" "),
                        _c("td", [
                          _c(
                            "div",
                            { attrs: { align: "center" } },
                            [
                              props.item.status != ""
                                ? _c(
                                    "v-chip",
                                    {
                                      staticClass: "ma-2",
                                      attrs: {
                                        disabled: !_vm.checkActive(),
                                        color: _vm.getColor(props.item.status),
                                        "text-color": "white",
                                      },
                                    },
                                    [
                                      _vm._v(
                                        "\n                            " +
                                          _vm._s(
                                            props.item.office_id ==
                                              _vm.currentUser
                                              ? props.item.office_status
                                              : props.item.status
                                          ) +
                                          "\n                        "
                                      ),
                                    ]
                                  )
                                : _vm._e(),
                            ],
                            1
                          ),
                        ]),
                        _vm._v(" "),
                        _c("td", [
                          _c("div", { attrs: { align: "center" } }, [
                            _vm._v(
                              "\n                        " +
                                _vm._s(props.item.customer) +
                                "\n                    "
                            ),
                          ]),
                        ]),
                        _vm._v(" "),
                        _c("td", [
                          _c(
                            "div",
                            { attrs: { align: "center" } },
                            [
                              _c(
                                "v-btn",
                                {
                                  attrs: {
                                    small: "",
                                    fab: "",
                                    dark: "",
                                    color: "teal",
                                  },
                                  on: {
                                    click: function ($event) {
                                      return _vm.viewProject(
                                        props.item.projectId
                                      )
                                    },
                                  },
                                },
                                [
                                  _vm._v(
                                    "\n                            " +
                                      _vm._s(props.item.projectName) +
                                      "\n                            "
                                  ),
                                ]
                              ),
                            ],
                            1
                          ),
                        ]),
                        _vm._v(" "),
                        _c("td", [
                          _c("div", { attrs: { align: "center" } }, [
                            _vm._v(
                              "\n                        " +
                                _vm._s(
                                  props.item.specialties != null
                                    ? props.item.specialties
                                        .map(function (x) {
                                          return x.name
                                        })
                                        .join(",")
                                    : ""
                                ) +
                                "\n                    "
                            ),
                          ]),
                        ]),
                        _vm._v(" "),
                        _c("td", [
                          _c("div", { attrs: { align: "center" } }, [
                            _vm._v(
                              "\n                        " +
                                _vm._s(
                                  props.item.created_at
                                    ? _vm.createdDate(props.item.created_at)
                                    : "-"
                                ) +
                                "\n                    "
                            ),
                          ]),
                        ]),
                      ]),
                    ]
                  },
                },
                {
                  key: "expand",
                  fn: function (props) {
                    return [_vm._t("offices", null, { props: props })]
                  },
                },
              ],
              null,
              true
            ),
          }),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "div",
        { attrs: { align: "center" } },
        [
          _c(
            "v-btn",
            {
              staticStyle: { "background-color": "#06706d", color: "white" },
              on: {
                click: function ($event) {
                  return _vm.$router.go(-1)
                },
              },
            },
            [
              _vm._v(
                "\n            " +
                  _vm._s(_vm.trans("messages.back")) +
                  "\n        "
              ),
            ]
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/view_visit_request.vue?vue&type=template&id=68e2c6d9&":
/*!****************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/view_visit_request.vue?vue&type=template&id=68e2c6d9& ***!
  \****************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "v-layout",
    { attrs: { row: "", "justify-center": "" } },
    [
      _c(
        "v-dialog",
        {
          attrs: { persistent: "", "max-width": "600px" },
          model: {
            value: _vm.dialog,
            callback: function ($$v) {
              _vm.dialog = $$v
            },
            expression: "dialog",
          },
        },
        [
          _c(
            "div",
            {
              staticClass:
                "overflow-hidden bg-white shadow sm:rounded-lg mx-auto",
              class: _vm.$vuetify.breakpoint.xsOnly ? "w-full mt-5" : "",
            },
            [
              _c(
                "div",
                { staticClass: "px-4 py-3 sm:px-6 flex" },
                [
                  _c(
                    "h3",
                    {
                      staticClass:
                        "text-lg mt-2 font-medium leading-6 text-gray-900",
                    },
                    [_vm._v(_vm._s(_vm.trans("data.visit_request_detaile")))]
                  ),
                  _vm._v(" "),
                  _c("v-spacer"),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      attrs: { flat: "", icon: "" },
                      on: {
                        click: function ($event) {
                          _vm.dialog = false
                        },
                      },
                    },
                    [_c("v-icon", [_vm._v("clear")])],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("div", { staticClass: "border-t border-gray-200" }, [
                _c("dl", [
                  _c(
                    "div",
                    {
                      staticClass:
                        "bg-gray-50 px-4 py-3 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6",
                      class: _vm.$vuetify.breakpoint.xsOnly
                        ? "flex justify-around"
                        : "",
                    },
                    [
                      _c(
                        "dt",
                        { staticClass: "text-md font-medium text-gray-500" },
                        [_vm._v(_vm._s(_vm.trans("data.project_name")))]
                      ),
                      _vm._v(" "),
                      _c(
                        "dd",
                        {
                          staticClass:
                            "mt-1 text-md text-gray-900 sm:col-span-2 sm:mt-0",
                        },
                        [_vm._v(_vm._s(_vm.project_name))]
                      ),
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      staticClass:
                        "bg-white px-4 py-3 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6",
                      class: _vm.$vuetify.breakpoint.xsOnly
                        ? "flex justify-around"
                        : "",
                    },
                    [
                      _c(
                        "dt",
                        { staticClass: "text-md font-medium text-gray-500" },
                        [_vm._v(_vm._s(_vm.trans("messages.customer")))]
                      ),
                      _vm._v(" "),
                      _c(
                        "dd",
                        {
                          staticClass:
                            "mt-1 text-md text-gray-900 sm:col-span-2 sm:mt-0",
                        },
                        [_vm._v(_vm._s(_vm.customer))]
                      ),
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      staticClass:
                        "bg-gray-50 px-4 py-3 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6",
                      class: _vm.$vuetify.breakpoint.xsOnly
                        ? "flex justify-around"
                        : "",
                    },
                    [
                      _c(
                        "dt",
                        { staticClass: "text-md font-medium text-gray-500" },
                        [_vm._v(_vm._s(_vm.trans("data.visit_datetime")))]
                      ),
                      _vm._v(" "),
                      _c(
                        "dd",
                        {
                          staticClass:
                            "mt-1 text-md text-gray-900 sm:col-span-2 sm:mt-0",
                        },
                        [_vm._v(_vm._s(_vm.dead_line_date))]
                      ),
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      staticClass:
                        "bg-white px-4 py-3 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6",
                      class: _vm.$vuetify.breakpoint.xsOnly
                        ? "flex justify-around"
                        : "",
                    },
                    [
                      _c(
                        "dt",
                        { staticClass: "text-md font-medium text-gray-500" },
                        [_vm._v(_vm._s(_vm.trans("data.enginnering_type")))]
                      ),
                      _vm._v(" "),
                      _c(
                        "dd",
                        {
                          staticClass:
                            "mt-1 text-md text-gray-900 sm:col-span-2 sm:mt-0",
                        },
                        [_vm._v(_vm._s(_vm.enginnering_type))]
                      ),
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      staticClass:
                        "bg-gray-50 px-4 py-3 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6",
                      class: _vm.$vuetify.breakpoint.xsOnly
                        ? "flex justify-around"
                        : "",
                    },
                    [
                      _c(
                        "dt",
                        { staticClass: "text-md font-medium text-gray-500" },
                        [_vm._v(_vm._s(_vm.trans("data.note")))]
                      ),
                      _vm._v(" "),
                      _c(
                        "dd",
                        {
                          staticClass:
                            "mt-1 text-md text-gray-900 sm:col-span-2 sm:mt-0",
                        },
                        [_vm._v(_vm._s(_vm.note))]
                      ),
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      staticClass:
                        "bg-white px-4 py-3 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6",
                      class: _vm.$vuetify.breakpoint.xsOnly
                        ? "flex justify-around"
                        : "",
                    },
                    [
                      _c(
                        "dt",
                        { staticClass: "text-md font-medium text-gray-500" },
                        [
                          _vm._v(
                            _vm._s(_vm.trans("data.enginnering_office_name"))
                          ),
                        ]
                      ),
                      _vm._v(" "),
                      _c(
                        "dd",
                        {
                          staticClass:
                            "mt-1 text-md text-gray-900 sm:col-span-2 sm:mt-0",
                        },
                        [
                          _vm._v(
                            _vm._s(_vm.offices[0] ? _vm.offices[0].name : "")
                          ),
                        ]
                      ),
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      staticClass:
                        "bg-gray-50 px-4 py-3 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6",
                    },
                    [
                      _c(
                        "dt",
                        { staticClass: "text-md font-medium text-gray-500" },
                        [
                          _vm._v(
                            _vm._s(_vm.trans("data.employee_and_Dead_lines"))
                          ),
                        ]
                      ),
                      _vm._v(" "),
                      _c(
                        "dd",
                        {
                          staticClass:
                            "mt-1 text-md text-gray-900 sm:col-span-2 sm:mt-0",
                        },
                        [
                          _c(
                            "ul",
                            {
                              staticClass:
                                "divide-y divide-gray-200 rounded-md border border-gray-200",
                              attrs: { role: "list" },
                            },
                            _vm._l(_vm.request_enginners, function (enginner) {
                              return _c(
                                "li",
                                {
                                  key: enginner.id,
                                  staticClass:
                                    "flex items-center justify-between py-3 px-2 text-md",
                                },
                                [
                                  _c(
                                    "span",
                                    {
                                      staticClass:
                                        "ml-2 w-0 flex-1 min-w-fit truncate",
                                    },
                                    [_vm._v(_vm._s(enginner.employee.name))]
                                  ),
                                  _vm._v(" "),
                                  _c(
                                    "span",
                                    {
                                      staticClass:
                                        "ml-2 w-0 flex-1 min-w-fit truncate",
                                    },
                                    [
                                      _vm._v(
                                        _vm._s(
                                          enginner.dead_line_date != null
                                            ? enginner.dead_line_date
                                            : "لم يحدد بعد"
                                        )
                                      ),
                                    ]
                                  ),
                                ]
                              )
                            }),
                            0
                          ),
                        ]
                      ),
                    ]
                  ),
                ]),
                _vm._v(" "),
                _c(
                  "div",
                  { staticClass: "mx-auto my-2 flex justify-center" },
                  [
                    _c(
                      "v-btn",
                      {
                        staticStyle: { color: "#06706d" },
                        on: {
                          click: function ($event) {
                            _vm.dialog = false
                          },
                        },
                      },
                      [
                        _vm._v(
                          "\r\n                        " +
                            _vm._s(_vm.trans("data.close")) +
                            "\r\n                    "
                        ),
                      ]
                    ),
                  ],
                  1
                ),
              ]),
            ]
          ),
        ]
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/enginnering_office/tickets/List.vue?vue&type=template&id=1086e236&":
/*!********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/enginnering_office/tickets/List.vue?vue&type=template&id=1086e236& ***!
  \********************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c("AcceptEnginneringOfficeModal", {
        ref: "acceptenginneringoffice",
        on: {
          next: function ($event) {
            return _vm.$refs.visitRequest.getAllProjectRequest($event)
          },
        },
      }),
      _vm._v(" "),
      _c("AcceptingEnginnerModal", {
        ref: "acceptenginner",
        on: {
          next: function ($event) {
            return _vm.$refs.visitRequest.getAllProjectRequest($event)
          },
        },
      }),
      _vm._v(" "),
      _c("VisitRequest", {
        ref: "visitRequest",
        attrs: {
          url: "enginner_office/get-office-requests",
          params: { projectId: _vm.id },
        },
        scopedSlots: _vm._u([
          {
            key: "actions",
            fn: function (ref) {
              var props = ref.props
              return [
                _c(
                  "div",
                  [
                    props.item.status == "sent" &&
                    props.item.offices.length > 0 &&
                    props.item.offices[0].id == _vm.currentUser.id
                      ? _c(
                          "v-btn",
                          {
                            attrs: {
                              color: "primary",
                              small: "",
                              fab: "",
                              disabled: !_vm.checkActive(),
                            },
                            on: {
                              click: function ($event) {
                                return _vm.acceptProject(props.item)
                              },
                            },
                          },
                          [
                            _c("v-icon", { attrs: { color: "white" } }, [
                              _vm._v("check"),
                            ]),
                          ],
                          1
                        )
                      : _vm._e(),
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "div",
                  [
                    (
                      props.item.request_enginners != undefined
                        ? props.item.request_enginners.filter(function (x) {
                            return (
                              x.user_id == _vm.currentUser.id &&
                              x.is_cheaked == 0
                            )
                          }).length > 0
                        : false
                    )
                      ? _c(
                          "v-btn",
                          {
                            attrs: {
                              color: "primary",
                              small: "",
                              fab: "",
                              disabled: !_vm.checkActive(),
                            },
                            on: {
                              click: function ($event) {
                                return _vm.acceptRequestByEnginner(props.item)
                              },
                            },
                          },
                          [
                            _c("v-icon", { attrs: { color: "white" } }, [
                              _vm._v("check"),
                            ]),
                          ],
                          1
                        )
                      : _vm._e(),
                  ],
                  1
                ),
                _vm._v(" "),
                props.item.status == "sent" &&
                props.item.offices.length > 0 &&
                props.item.offices[0].id == _vm.currentUser.id
                  ? _c(
                      "v-btn",
                      {
                        attrs: {
                          color: "error",
                          small: "",
                          fab: "",
                          disabled: !_vm.checkActive(),
                        },
                        on: {
                          click: function ($event) {
                            return _vm.rejectProject(props.item.id)
                          },
                        },
                      },
                      [
                        _c("v-icon", { attrs: { color: "white" } }, [
                          _vm._v("cancel"),
                        ]),
                      ],
                      1
                    )
                  : _vm._e(),
                _vm._v(" "),
                (
                  props.item.request_enginners != undefined
                    ? props.item.request_enginners.filter(function (x) {
                        return (
                          x.user_id == _vm.currentUser.id && x.is_cheaked == 1
                        )
                      }).length > 0
                    : false
                )
                  ? _c(
                      "v-btn",
                      {
                        attrs: {
                          color: "primary",
                          small: "",
                          fab: "",
                          disabled: !_vm.checkActive(),
                        },
                        on: {
                          click: function ($event) {
                            return _vm.createReport(props.item)
                          },
                        },
                      },
                      [
                        _c("v-icon", { attrs: { color: "white" } }, [
                          _vm._v(" list "),
                        ]),
                      ],
                      1
                    )
                  : _vm._e(),
              ]
            },
          },
        ]),
      }),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);