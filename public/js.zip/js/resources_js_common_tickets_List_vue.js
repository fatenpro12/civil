"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_common_tickets_List_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/status/StatusLabel.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/status/StatusLabel.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  props: ['status'],
  methods: {
    color: function color(status) {
      if (status === 'approved' || status === 'paid' || status === 'closed') {
        return 'green lighten-1';
      } else if (status === 'cancelled' || status === 'due' || status === 'new' || status === 'urgent') {
        return 'red accent-2';
      } else if (status === 'pending' || status === 'partial') {
        return 'cyan lighten-2';
      } else if (status === 'open') {
        return 'pink lighten-1';
      } else if (status === 'low') {
        return 'yellow darken-4';
      } else if (status === 'medium') {
        return 'deep-orange lighten-2';
      } else if (status === 'high') {
        return 'red accent-1';
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/tickets/AcceptEnginneringOfficeModal.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/tickets/AcceptEnginneringOfficeModal.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../store */ "./resources/js/store/index.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'permission',
  data: function data() {
    return {
      valid: true,
      users: [],
      enginners: [],
      dialog: false,
      dead_line_date: null,
      loading: false,
      status: '',
      office_id: null,
      isEdit: false,
      id: '',
      inputs: [{
        enginner_id: '',
        isDefault: ''
      }]
    };
  },
  mounted: function mounted() {
    var self = this;
    self.loadUsers();
    self.setCurrentUser();
  },
  computed: {
    computedDateFormattedMomentjs: function computedDateFormattedMomentjs() {
      var self = this;
      return null; //self.dead_line_date
      // ? moment(self.location.instrument_date).format('dddd, MMMM Do YYYY')
      // : '';
    },
    computedDateFormattedDatefns: function computedDateFormattedDatefns() {
      var self = this;
      return self.dead_line_date;
      // ? format(parseISO(self.location.instrument_date), 'EEEE, MMMM do yyyy')
      //  : '';
    }
  },

  methods: {
    close: function close() {
      var self = this;
      self.dialog = false;
      self.loading = false;
      self.reset();
      self.resetValidation();
      self.inputs.splice(1);
    },
    reset: function reset() {
      this.$refs.form.reset();
    },
    resetValidation: function resetValidation() {
      this.$refs.form.resetValidation();
    },
    add: function add() {
      this.inputs.push({
        enginner_id: '',
        isDefault: ''
      });
      console.log(this.inputs);
    },
    remove: function remove(index) {
      this.inputs.splice(index, 1);
    },
    updatevalues: function updatevalues(value, key) {
      var self = this;
      // self.current_customer = value;
    },
    //detects location from browser
    loadUsers: function loadUsers() {
      var self = this;
    },
    setCurrentUser: function setCurrentUser() {
      var self = this;
      axios.get('/get-current-user').then(function (response) {
        if (!response.data.error_code) {
          var user = response.data.data.original;
          self.enginner = user.id;
        } else {
          self.$store.commit('hideLoader');
          self.$store.commit('showSnackbar', {
            message: response.data.error_description,
            color: 'red'
          });
        }

        //  self.resetvalues(1);
      });
    },
    create: function create(id) {
      var self = this;
      self.getDefaultMembers(id);
      //  alert(id)
      self.dialog = true;
    },
    fillData: function fillData(data) {
      var self = this;
      self.status = data.status;
      self.office_id = data.office_id;
      self.id = data.id;
      axios.get('get-office-empoloyees/' + self.office_id).then(function (response) {
        //self.gender_types = response.data.gender_types;
        self.users = response.data;
      })["catch"](function (err) {
        console.log(err.response.status);
        if (err.response.status === 401) {
          _store__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch('auth/handleResponse', err.response);
        }
      });
      ;
    },
    save: function save() {
      var self = this;
      var data = {
        id: self.id,
        default_enginners: self.inputs,
        dead_line_date: self.dead_line_date,
        enginners: self.enginners
      };
      if (this.$refs.form.validate()) {
        self.loading = true;
        axios.post('/accept-project', data).then(function (response) {
          if (!response.data.error_code) {
            self.loading = false;
            self.dialog = false;
            self.reset();
            self.resetValidation();
            self.inputs.splice(1);
            self.$emit('next');
            self.$store.commit('hideLoader');
            self.$store.commit('showSnackbar', {
              message: response.data.data,
              color: 'green'
            });
          } else {
            self.$store.commit('hideLoader');
            self.$store.commit('showSnackbar', {
              message: response.data.error_description,
              color: 'red'
            });
          }
        });
      }
    },
    getDefaultMembers: function getDefaultMembers(id) {
      var self = this;
      axios.get('get-default-members/' + id).then(function (response) {
        // if (response.data.length > 0) {
        //     self.enginners = response.data;
        //     self.inputs = [
        //         {
        //             enginner_id: '',
        //             isDefault: '',
        //         },
        //     ];
        // }
      })["catch"](function (error) {
        self.type = '-';
      });
      return self.type;
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/tickets/Edit.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/tickets/Edit.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _common_projects_category_Add__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../common/projects/category/Add */ "./resources/js/common/projects/category/Add.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  components: {
    CategoryAdd: _common_projects_category_Add__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  data: function data() {
    return {
      dialog: false,
      loading: false,
      form_fields: [],
      statuses: [],
      employees: [],
      ticket_types: [],
      customers: [],
      priorities: [],
      ticket_id: null
    };
  },
  created: function created() {
    var self = this;
    self.$eventBus.$on('updateCategoryList', function (data) {
      self.ticket_types.push(data);
      self.form_fields.category_id = data.id;
    });
  },
  beforeDestroy: function beforeDestroy() {
    var self = this;
    self.$eventBus.$off('updateCategoryList');
  },
  methods: {
    edit: function edit(ticket_id) {
      var self = this;
      self.ticket_id = ticket_id;
      axios.get('/tickets/' + ticket_id + '/edit').then(function (response) {
        self.form_fields = response.data.ticket;
        self.statuses = response.data.statuses;
        self.ticket_types = response.data.ticket_types;
        self.priorities = response.data.priority;
        self.employees = response.data.employees;
        self.customers = response.data.customers;
        self.dialog = true;
      })["catch"](function (error) {
        console.log(error);
      });
    },
    createCategory: function createCategory() {
      var data = {
        type: 'tickets'
      };
      this.$refs.categoryAdd.create(data);
    },
    store: function (_store) {
      function store() {
        return _store.apply(this, arguments);
      }
      store.toString = function () {
        return _store.toString();
      };
      return store;
    }(function () {
      var self = this;
      var data = _.pick(self.form_fields, ['title', 'category_id', 'priority', 'description', 'status', 'assigned_to', 'customer_id']);
      self.$validator.validateAll().then(function (result) {
        if (result == true) {
          self.loading = true;
          axios.put('/tickets/' + self.ticket_id, data).then(function (response) {
            self.loading = false;
            self.$store.commit('showSnackbar', {
              message: response.data.msg,
              color: response.data.success
            });
            if (response.data.success === true) {
              self.dialog = false;
              self.$eventBus.$emit('updateTicketsTable');
            }
          })["catch"](function (err) {
            console.log(err.response.status);
            if (err.response.status === 401) {
              store.dispatch('auth/handleResponse', err.response);
            }
          });
        }
      });
    })
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/tickets/List.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/tickets/List.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Edit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Edit */ "./resources/js/common/tickets/Edit.vue");
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../store */ "./resources/js/store/index.js");
/* harmony import */ var _admin_status_StatusLabel__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../admin/status/StatusLabel */ "./resources/js/admin/status/StatusLabel.vue");
/* harmony import */ var _AcceptEnginneringOfficeModal_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./AcceptEnginneringOfficeModal.vue */ "./resources/js/common/tickets/AcceptEnginneringOfficeModal.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  components: {
    TicketEdit: _Edit__WEBPACK_IMPORTED_MODULE_0__["default"],
    StatusLabel: _admin_status_StatusLabel__WEBPACK_IMPORTED_MODULE_2__["default"],
    AcceptEnginneringOfficeModal: _AcceptEnginneringOfficeModal_vue__WEBPACK_IMPORTED_MODULE_3__["default"]
  },
  props: {
    id: {
      required: false
    },
    backBtn: true
  },
  data: function data() {
    var self = this;
    return {
      currentUser: '',
      projects: [],
      total_items: 0,
      loading: false,
      pagination: {
        totalItems: 0
      },
      projectRequests: [],
      request_types: [],
      headers: [{
        text: self.trans('messages.action'),
        value: false,
        align: 'center',
        sortable: false
      }, {
        text: self.trans('data.id'),
        value: false,
        align: 'center',
        sortable: false
      }, {
        text: self.trans('messages.status'),
        value: 'status',
        align: 'center',
        sortable: true
      }, {
        text: self.trans('messages.customer'),
        value: 'customer',
        align: 'center',
        sortable: true
      },
      // {
      //     text: self.trans('data.request_type'),
      //     value: 'request_type',
      //     align: 'center',
      //     sortable: true,
      // },
      {
        text: self.trans('data.project_name'),
        value: 'project_name',
        align: 'center',
        sortable: true
      }, {
        text: self.trans('messages.created_at'),
        value: 'created_at',
        align: 'center',
        sortable: true
      }],
      customername: '',
      items: [],
      employees: [],
      ticket_types: [],
      statuses: [],
      filters: [],
      customers: [],
      priorities: [],
      tabs: 'tab-1',
      ticket_stats: [],
      type: '',
      project_name: ''
    };
  },
  watch: {
    pagination: {
      handler: function handler() {
        // this.getTicketFromApi();
        //  this.getAllProjectRequest();
      }
    }
  },
  mounted: function mounted() {
    var self = this;
    self.getCurrentUser();
    self.$eventBus.$on('updateTicketsTable', function (data) {
      self.projectRequest = [];
      self.projects = [];
      self.getAllProjectRequest();
    });
  },
  beforeDestroy: function beforeDestroy() {
    var self = this;
    self.$eventBus.$off('updateTicketsTable');
  },
  created: function created() {
    var self = this;
    self.projectRequests = [];
    self.projects = [];
    self.getRequestTypes();
    this.getAllProjectRequest();
  },
  methods: {
    getRequestTypes: function getRequestTypes() {
      var self = this;
      axios.get('/get-request-types').then(function (response) {
        self.request_types = response.data;
      })["catch"](function (err) {
        console.log(err.response.status);
        if (err.response.status === 401) {
          _store__WEBPACK_IMPORTED_MODULE_1__["default"].dispatch('auth/handleResponse', err.response);
        }
      });
      ;
    },
    sendRequest: function sendRequest(request) {
      var self = this;
      self.$store.commit('showDialog', {
        type: 'confirm',
        icon: 'warning',
        title: self.trans('messages.are_you_sure'),
        okCb: function okCb() {
          axios.post('confirm-send', {
            request_id: request.id
          }).then(function (response) {
            self.projectRequest = [];
            self.projects = [];
            self.$store.commit('showSnackbar', {
              message: response.data.data,
              color: 'green'
            });
            self.getAllProjectRequest();
          })["catch"](function (error) {
            console.log(error);
          });
        },
        cancelCb: function cancelCb() {
          console.log('CANCEL');
        }
      });
    },
    editRequest: function editRequest(request) {
      this.$router.push({
        name: 'edit_visit_request_list',
        params: {
          id: request.id
        }
      });
    },
    viewRequest: function viewRequest(request) {
      this.$router.push({
        name: 'view_visit_request_list',
        params: {
          id: request.id
        }
      });
    },
    getType: function getType(visit) {
      var self = this;
      return self.request_types.find(function (o) {
        return o.key == visit;
      }).value;
    },
    getProject: function getProject(project_id) {
      var self = this;
      axios.get('/get-project/' + project_id).then(function (response) {
        self.project_name = response.data.name;
        console.log(self.project_name);
      })["catch"](function (error) {
        // self.project_name= '-';
      });
      return self.project_name;
    },
    getVisitRequestType: function getVisitRequestType(id) {
      var self = this;
      axios.get('/visit-request-type/' + id).then(function (response) {
        self.type = response.data.data;
      })["catch"](function (error) {
        self.type = '-';
      });
      return self.type;
    },
    createdDate: function createdDate(date) {
      var current_datetime = new Date(date);
      return current_datetime.toLocaleDateString('en-US');
    },
    rejectProject: function rejectProject(request_id) {
      var self = this;
      self.$store.commit('showDialog', {
        type: 'confirm',
        icon: 'warning',
        title: self.trans('messages.are_you_sure'),
        message: self.trans('messages.you_cant_restore_it'),
        okCb: function okCb() {
          axios.post('request-cancel', {
            request_id: request_id
          }).then(function (response) {
            if (!response.data.error_code) {
              self.$store.commit('showSnackbar', {
                message: response.data.data,
                color: 'green'
              });
              self.projectRequest = [];
              self.projects = [];
              self.getAllProjectRequest();
            }
          })["catch"](function (error) {
            console.log(error);
          });
        },
        cancelCb: function cancelCb() {
          console.log('CANCEL');
        }
      });
    },
    acceptProject: function acceptProject(item) {
      var self = this;
      self.$store.commit('showDialog', {
        type: 'confirm',
        icon: 'warning',
        title: self.trans('messages.are_you_sure'),
        message: self.trans('messages.are_you_sure'),
        okCb: function okCb() {
          self.$refs.acceptenginneringoffice.create(item.project_id);
          var data = {
            status: item.status,
            id: item.id,
            office_id: item.office_id
          };
          self.$refs.acceptenginneringoffice.fillData(data);
        },
        cancelCb: function cancelCb() {
          console.log('CANCEL');
        }
      });
    },
    removeProject: function removeProject(id) {
      var self = this;
      self.$store.commit('showDialog', {
        type: 'confirm',
        icon: 'warning',
        title: self.trans('messages.are_you_sure'),
        message: self.trans('messages.you_cant_restore_it'),
        okCb: function okCb() {
          axios["delete"]('request/' + id).then(function (response) {
            self.$store.commit('showSnackbar', {
              message: response.data.msg,
              color: response.data.success
            });
            self.projectRequest = [];
            self.projects = [];
            self.getAllProjectRequest();
          })["catch"](function (error) {
            console.log(error);
          });
        },
        cancelCb: function cancelCb() {
          console.log('CANCEL');
        }
      });
    },
    getCustomer: function getCustomer(id) {
      var self = this;
      axios.get('/get-Customer-name/' + id).then(function (response) {
        self.customername = response.data.data;
      })["catch"](function (error) {
        self.customername = '-';
      });
      return self.customername;
    },
    getAllProjectRequest: function getAllProjectRequest() {
      var self = this;
      self.loading = true;
      var params = {};
      params['projectId'] = self.id;
      //  {'projectId':self.id}
      axios.get('get-requests', {
        params: params
      }).then(function (response) {
        self.total_items = response.data.length;
        //   self.projectRequests = response.data.data;
        self.projects = response.data;
        self.loading = false;
      })["catch"](function (err) {
        console.log(err.response.status);
        if (err.response.status === 401) {
          _store__WEBPACK_IMPORTED_MODULE_1__["default"].dispatch('auth/handleResponse', err.response);
        }
      });
      ;
    },
    removeVisitRequest: function removeVisitRequest(id) {},
    getTicketFromApi: function getTicketFromApi() {
      var self = this;
      self.loading = true;
      var _self$pagination = self.pagination,
        sortBy = _self$pagination.sortBy,
        descending = _self$pagination.descending,
        page = _self$pagination.page,
        rowsPerPage = _self$pagination.rowsPerPage;
      var params = {
        sort_by: sortBy,
        descending: descending,
        page: page,
        rowsPerPage: rowsPerPage
      };
      if (self.filters.assigned_to) {
        params['assigned_to'] = self.filters.assigned_to;
      }
      if (self.filters.category_id) {
        params['category_id'] = self.filters.category_id;
      }
      if (self.filters.priority) {
        params['priority'] = self.filters.priority;
      }
      if (self.filters.status) {
        params['status'] = self.filters.status;
      }
      if (self.filters.customer_id) {
        params['customer_id'] = self.filters.customer_id;
      }
      axios.get('/tickets', {
        params: params
      }).then(function (response) {
        self.total_items = response.data.total;
        self.items = response.data.data;
        self.loading = false;
      })["catch"](function (err) {
        console.log(err.response.status);
        if (err.response.status === 401) {
          _store__WEBPACK_IMPORTED_MODULE_1__["default"].dispatch('auth/handleResponse', err.response);
        }
      });
      ;
    },
    edit: function edit(ticket_id) {
      this.$refs.ticketEdit.edit(ticket_id);
    },
    deleteTicket: function deleteTicket(ticket) {
      var self = this;
      self.$store.commit('showDialog', {
        type: 'confirm',
        icon: 'warning',
        title: self.trans('messages.are_you_sure'),
        message: self.trans('messages.you_cant_restore_it'),
        okCb: function okCb() {
          axios["delete"]('/tickets/' + ticket.id).then(function (response) {
            self.$store.commit('showSnackbar', {
              message: response.data.msg,
              color: response.data.success
            });
            if (response.data.success === true) {
              //   self.getTicketFromApi();
              // self.getStatistics();
              //self.getFilters();
            }
          })["catch"](function (error) {
            console.log(error);
          });
        },
        cancelCb: function cancelCb() {
          console.log('CANCEL');
        }
      });
    },
    getCurrentUser: function getCurrentUser() {
      var self = this;
      axios.get('/get-current-user', {}).then(function (response) {
        if (!response.data.error_code) {
          self.currentUser = response.data.data.original.id;
        } else {
          self.$store.commit('hideLoader');
          self.$store.commit('showSnackbar', {
            message: response.data.error_description,
            color: 'red'
          });
        }
      });
    },
    viewProject: function viewProject(id) {
      var self = this;
      self.$router.push({
        name: 'view_project',
        params: {
          id: id
        }
      });
    }
    /*    getFilters() {
        const self = this;
        axios
            .get('/tickets/get-filters')
            .then(function(response) {
                self.employees = response.data.employees;
                self.ticket_types = response.data.ticket_types;
                self.statuses = response.data.statuses;
                self.customers = response.data.customers;
                self.priorities = response.data.priorities;
            })
            .catch(function(error) {
                console.log(error);
            });
    },*/
    /*      getStatistics() {
        const self = this;
        axios
            .get('/tickets-statistics')
            .then(function(response) {
                self.ticket_stats = response.data;
            })
            .catch(function(error) {
                console.log(error);
            });
    },*/
  }
});

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/tickets/AcceptEnginneringOfficeModal.vue?vue&type=style&index=0&id=147f24cd&scoped=true&lang=css&":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/tickets/AcceptEnginneringOfficeModal.vue?vue&type=style&index=0&id=147f24cd&scoped=true&lang=css& ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "\n.style_rtl[data-v-147f24cd] {\r\n    padding-left: 5px;\n}\n.style_ltr[data-v-147f24cd] {\r\n    padding-right: 5px;\n}\r\n", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/tickets/AcceptEnginneringOfficeModal.vue?vue&type=style&index=0&id=147f24cd&scoped=true&lang=css&":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/tickets/AcceptEnginneringOfficeModal.vue?vue&type=style&index=0&id=147f24cd&scoped=true&lang=css& ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_AcceptEnginneringOfficeModal_vue_vue_type_style_index_0_id_147f24cd_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AcceptEnginneringOfficeModal.vue?vue&type=style&index=0&id=147f24cd&scoped=true&lang=css& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/tickets/AcceptEnginneringOfficeModal.vue?vue&type=style&index=0&id=147f24cd&scoped=true&lang=css&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_AcceptEnginneringOfficeModal_vue_vue_type_style_index_0_id_147f24cd_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_AcceptEnginneringOfficeModal_vue_vue_type_style_index_0_id_147f24cd_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./resources/js/admin/status/StatusLabel.vue":
/*!***************************************************!*\
  !*** ./resources/js/admin/status/StatusLabel.vue ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _StatusLabel_vue_vue_type_template_id_2169abba___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./StatusLabel.vue?vue&type=template&id=2169abba& */ "./resources/js/admin/status/StatusLabel.vue?vue&type=template&id=2169abba&");
/* harmony import */ var _StatusLabel_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./StatusLabel.vue?vue&type=script&lang=js& */ "./resources/js/admin/status/StatusLabel.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _StatusLabel_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _StatusLabel_vue_vue_type_template_id_2169abba___WEBPACK_IMPORTED_MODULE_0__.render,
  _StatusLabel_vue_vue_type_template_id_2169abba___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/admin/status/StatusLabel.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/common/tickets/AcceptEnginneringOfficeModal.vue":
/*!**********************************************************************!*\
  !*** ./resources/js/common/tickets/AcceptEnginneringOfficeModal.vue ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _AcceptEnginneringOfficeModal_vue_vue_type_template_id_147f24cd_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./AcceptEnginneringOfficeModal.vue?vue&type=template&id=147f24cd&scoped=true& */ "./resources/js/common/tickets/AcceptEnginneringOfficeModal.vue?vue&type=template&id=147f24cd&scoped=true&");
/* harmony import */ var _AcceptEnginneringOfficeModal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./AcceptEnginneringOfficeModal.vue?vue&type=script&lang=js& */ "./resources/js/common/tickets/AcceptEnginneringOfficeModal.vue?vue&type=script&lang=js&");
/* harmony import */ var _AcceptEnginneringOfficeModal_vue_vue_type_style_index_0_id_147f24cd_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./AcceptEnginneringOfficeModal.vue?vue&type=style&index=0&id=147f24cd&scoped=true&lang=css& */ "./resources/js/common/tickets/AcceptEnginneringOfficeModal.vue?vue&type=style&index=0&id=147f24cd&scoped=true&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _AcceptEnginneringOfficeModal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _AcceptEnginneringOfficeModal_vue_vue_type_template_id_147f24cd_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render,
  _AcceptEnginneringOfficeModal_vue_vue_type_template_id_147f24cd_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  "147f24cd",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/common/tickets/AcceptEnginneringOfficeModal.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/common/tickets/Edit.vue":
/*!**********************************************!*\
  !*** ./resources/js/common/tickets/Edit.vue ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Edit_vue_vue_type_template_id_651d25e8___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Edit.vue?vue&type=template&id=651d25e8& */ "./resources/js/common/tickets/Edit.vue?vue&type=template&id=651d25e8&");
/* harmony import */ var _Edit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Edit.vue?vue&type=script&lang=js& */ "./resources/js/common/tickets/Edit.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Edit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Edit_vue_vue_type_template_id_651d25e8___WEBPACK_IMPORTED_MODULE_0__.render,
  _Edit_vue_vue_type_template_id_651d25e8___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/common/tickets/Edit.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/common/tickets/List.vue":
/*!**********************************************!*\
  !*** ./resources/js/common/tickets/List.vue ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _List_vue_vue_type_template_id_55d4fe7c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./List.vue?vue&type=template&id=55d4fe7c& */ "./resources/js/common/tickets/List.vue?vue&type=template&id=55d4fe7c&");
/* harmony import */ var _List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./List.vue?vue&type=script&lang=js& */ "./resources/js/common/tickets/List.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _List_vue_vue_type_template_id_55d4fe7c___WEBPACK_IMPORTED_MODULE_0__.render,
  _List_vue_vue_type_template_id_55d4fe7c___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/common/tickets/List.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/admin/status/StatusLabel.vue?vue&type=script&lang=js&":
/*!****************************************************************************!*\
  !*** ./resources/js/admin/status/StatusLabel.vue?vue&type=script&lang=js& ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_StatusLabel_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StatusLabel.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/status/StatusLabel.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_StatusLabel_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/common/tickets/AcceptEnginneringOfficeModal.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************!*\
  !*** ./resources/js/common/tickets/AcceptEnginneringOfficeModal.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AcceptEnginneringOfficeModal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AcceptEnginneringOfficeModal.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/tickets/AcceptEnginneringOfficeModal.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AcceptEnginneringOfficeModal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/common/tickets/Edit.vue?vue&type=script&lang=js&":
/*!***********************************************************************!*\
  !*** ./resources/js/common/tickets/Edit.vue?vue&type=script&lang=js& ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Edit.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/tickets/Edit.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/common/tickets/List.vue?vue&type=script&lang=js&":
/*!***********************************************************************!*\
  !*** ./resources/js/common/tickets/List.vue?vue&type=script&lang=js& ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./List.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/tickets/List.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/common/tickets/AcceptEnginneringOfficeModal.vue?vue&type=style&index=0&id=147f24cd&scoped=true&lang=css&":
/*!*******************************************************************************************************************************!*\
  !*** ./resources/js/common/tickets/AcceptEnginneringOfficeModal.vue?vue&type=style&index=0&id=147f24cd&scoped=true&lang=css& ***!
  \*******************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_AcceptEnginneringOfficeModal_vue_vue_type_style_index_0_id_147f24cd_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AcceptEnginneringOfficeModal.vue?vue&type=style&index=0&id=147f24cd&scoped=true&lang=css& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/tickets/AcceptEnginneringOfficeModal.vue?vue&type=style&index=0&id=147f24cd&scoped=true&lang=css&");


/***/ }),

/***/ "./resources/js/admin/status/StatusLabel.vue?vue&type=template&id=2169abba&":
/*!**********************************************************************************!*\
  !*** ./resources/js/admin/status/StatusLabel.vue?vue&type=template&id=2169abba& ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StatusLabel_vue_vue_type_template_id_2169abba___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StatusLabel_vue_vue_type_template_id_2169abba___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StatusLabel_vue_vue_type_template_id_2169abba___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StatusLabel.vue?vue&type=template&id=2169abba& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/status/StatusLabel.vue?vue&type=template&id=2169abba&");


/***/ }),

/***/ "./resources/js/common/tickets/AcceptEnginneringOfficeModal.vue?vue&type=template&id=147f24cd&scoped=true&":
/*!*****************************************************************************************************************!*\
  !*** ./resources/js/common/tickets/AcceptEnginneringOfficeModal.vue?vue&type=template&id=147f24cd&scoped=true& ***!
  \*****************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_AcceptEnginneringOfficeModal_vue_vue_type_template_id_147f24cd_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_AcceptEnginneringOfficeModal_vue_vue_type_template_id_147f24cd_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_AcceptEnginneringOfficeModal_vue_vue_type_template_id_147f24cd_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AcceptEnginneringOfficeModal.vue?vue&type=template&id=147f24cd&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/tickets/AcceptEnginneringOfficeModal.vue?vue&type=template&id=147f24cd&scoped=true&");


/***/ }),

/***/ "./resources/js/common/tickets/Edit.vue?vue&type=template&id=651d25e8&":
/*!*****************************************************************************!*\
  !*** ./resources/js/common/tickets/Edit.vue?vue&type=template&id=651d25e8& ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_template_id_651d25e8___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_template_id_651d25e8___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_template_id_651d25e8___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Edit.vue?vue&type=template&id=651d25e8& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/tickets/Edit.vue?vue&type=template&id=651d25e8&");


/***/ }),

/***/ "./resources/js/common/tickets/List.vue?vue&type=template&id=55d4fe7c&":
/*!*****************************************************************************!*\
  !*** ./resources/js/common/tickets/List.vue?vue&type=template&id=55d4fe7c& ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_55d4fe7c___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_55d4fe7c___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_55d4fe7c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./List.vue?vue&type=template&id=55d4fe7c& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/tickets/List.vue?vue&type=template&id=55d4fe7c&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/status/StatusLabel.vue?vue&type=template&id=2169abba&":
/*!*************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/status/StatusLabel.vue?vue&type=template&id=2169abba& ***!
  \*************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "v-chip",
    { attrs: { label: "", small: "", color: _vm.color(_vm.status) } },
    [_c("small", [_vm._v(_vm._s(_vm.trans("messages." + _vm.status)))])]
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/tickets/AcceptEnginneringOfficeModal.vue?vue&type=template&id=147f24cd&scoped=true&":
/*!********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/tickets/AcceptEnginneringOfficeModal.vue?vue&type=template&id=147f24cd&scoped=true& ***!
  \********************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { attrs: { justify: "center" } },
    [
      _c(
        "v-dialog",
        {
          attrs: { persistent: "", "max-width": "550px" },
          model: {
            value: _vm.dialog,
            callback: function ($$v) {
              _vm.dialog = $$v
            },
            expression: "dialog",
          },
        },
        [
          _c(
            "v-card",
            [
              _c(
                "v-card-text",
                [
                  _c(
                    "v-form",
                    {
                      ref: "form",
                      attrs: { "lazy-validation": "" },
                      model: {
                        value: _vm.valid,
                        callback: function ($$v) {
                          _vm.valid = $$v
                        },
                        expression: "valid",
                      },
                    },
                    [
                      _c(
                        "v-container",
                        [
                          _c(
                            "div",
                            { attrs: { cols: "12", sm: "6" } },
                            [
                              _c("v-datetime-picker", {
                                attrs: {
                                  label: _vm.trans("data.visit_datetime"),
                                  datetime: _vm.dead_line_date,
                                },
                                model: {
                                  value: _vm.dead_line_date,
                                  callback: function ($$v) {
                                    _vm.dead_line_date = $$v
                                  },
                                  expression: "dead_line_date",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _vm.enginners.length > 0
                            ? _c(
                                "v-layout",
                                { attrs: { row: "" } },
                                [
                                  _c(
                                    "v-flex",
                                    { attrs: { xs12: "", md12: "" } },
                                    [
                                      _c("v-autocomplete", {
                                        attrs: {
                                          "item-text": "name",
                                          "item-value": "id",
                                          items: _vm.users,
                                          multiple: "",
                                          rules: [
                                            function (v) {
                                              return (
                                                !!v ||
                                                _vm.trans("messages.required", {
                                                  name: _vm.trans(
                                                    "data.enginner"
                                                  ),
                                                })
                                              )
                                            },
                                          ],
                                          label: _vm.trans("data.enginner"),
                                          "error-messages":
                                            _vm.errors.collect("enginner"),
                                          required: "",
                                        },
                                        on: {
                                          change: function (event) {
                                            return _vm.updatevalues(
                                              event,
                                              _vm.k
                                            )
                                          },
                                        },
                                        model: {
                                          value: _vm.enginners,
                                          callback: function ($$v) {
                                            _vm.enginners = $$v
                                          },
                                          expression: "enginners",
                                        },
                                      }),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              )
                            : _vm._e(),
                          _vm._v(" "),
                          _vm.enginners.length <= 0
                            ? _c(
                                "div",
                                _vm._l(_vm.inputs, function (input, k) {
                                  return _c(
                                    "v-layout",
                                    { key: k, attrs: { row: "" } },
                                    [
                                      _c(
                                        "v-flex",
                                        { attrs: { xs12: "", md5: "" } },
                                        [
                                          _c("v-autocomplete", {
                                            attrs: {
                                              "item-text": "name",
                                              "item-value": "id",
                                              items: _vm.users,
                                              rules: [
                                                function (v) {
                                                  return (
                                                    !!v ||
                                                    _vm.trans(
                                                      "messages.required",
                                                      {
                                                        name: _vm.trans(
                                                          "data.enginner"
                                                        ),
                                                      }
                                                    )
                                                  )
                                                },
                                              ],
                                              label: _vm.trans("data.enginner"),
                                              "error-messages":
                                                _vm.errors.collect("enginner"),
                                              required: "",
                                            },
                                            on: {
                                              change: function (event) {
                                                return _vm.updatevalues(
                                                  event,
                                                  k
                                                )
                                              },
                                            },
                                            model: {
                                              value: input.enginner_id,
                                              callback: function ($$v) {
                                                _vm.$set(
                                                  input,
                                                  "enginner_id",
                                                  $$v
                                                )
                                              },
                                              expression: "input.enginner_id",
                                            },
                                          }),
                                        ],
                                        1
                                      ),
                                      _vm._v(" "),
                                      _c(
                                        "v-flex",
                                        { attrs: { xs12: "", md3: "" } },
                                        [
                                          _c("v-checkbox", {
                                            attrs: {
                                              label:
                                                _vm.trans("data.is_default"),
                                            },
                                            model: {
                                              value: input.isDefault,
                                              callback: function ($$v) {
                                                _vm.$set(
                                                  input,
                                                  "isDefault",
                                                  $$v
                                                )
                                              },
                                              expression: "input.isDefault",
                                            },
                                          }),
                                        ],
                                        1
                                      ),
                                      _vm._v(" "),
                                      _c(
                                        "v-flex",
                                        { attrs: { xs12: "", md4: "" } },
                                        [
                                          _c(
                                            "v-btn",
                                            {
                                              directives: [
                                                {
                                                  name: "show",
                                                  rawName: "v-show",
                                                  value:
                                                    k ==
                                                      _vm.inputs.length - 1 &&
                                                    !_vm.isEdit,
                                                  expression:
                                                    "k == inputs.length - 1 && !isEdit",
                                                },
                                              ],
                                              staticStyle: {
                                                "background-color": "#06706d",
                                                color: "white",
                                              },
                                              attrs: { small: "", fab: "" },
                                              on: {
                                                click: function ($event) {
                                                  return _vm.add(k)
                                                },
                                              },
                                            },
                                            [
                                              _c(
                                                "v-icon",
                                                { attrs: { dark: "" } },
                                                [_vm._v(" add ")]
                                              ),
                                            ],
                                            1
                                          ),
                                          _vm._v(" "),
                                          _c(
                                            "v-btn",
                                            {
                                              directives: [
                                                {
                                                  name: "show",
                                                  rawName: "v-show",
                                                  value:
                                                    k ||
                                                    (!k &&
                                                      _vm.inputs.length > 1 &&
                                                      !_vm.isEdit),
                                                  expression:
                                                    "k || (!k && inputs.length > 1 && !isEdit)",
                                                },
                                              ],
                                              attrs: {
                                                small: "",
                                                fab: "",
                                                color: "red",
                                                dark: "",
                                              },
                                              on: {
                                                click: function ($event) {
                                                  return _vm.remove(k)
                                                },
                                              },
                                            },
                                            [
                                              _c("i", {
                                                staticClass:
                                                  "fas fa-minus-circle",
                                              }),
                                            ]
                                          ),
                                        ],
                                        1
                                      ),
                                    ],
                                    1
                                  )
                                }),
                                1
                              )
                            : _vm._e(),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "v-card-actions",
                [
                  _c("v-spacer"),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      staticStyle: { color: "#06706d" },
                      attrs: { text: "" },
                      on: {
                        click: function ($event) {
                          return _vm.close()
                        },
                      },
                    },
                    [
                      _vm._v(
                        "\n                        " +
                          _vm._s(_vm.trans("data.cancel")) +
                          "\n                    "
                      ),
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      staticStyle: {
                        "background-color": "#06706d",
                        color: "white",
                      },
                      attrs: {
                        color: "darken-1",
                        loading: _vm.loading,
                        disabled: _vm.loading,
                        text: "",
                      },
                      on: {
                        click: function ($event) {
                          return _vm.save()
                        },
                      },
                    },
                    [
                      _vm._v(
                        "\n                        " +
                          _vm._s(_vm.trans("data.save")) +
                          "\n                    "
                      ),
                    ]
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/tickets/Edit.vue?vue&type=template&id=651d25e8&":
/*!********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/tickets/Edit.vue?vue&type=template&id=651d25e8& ***!
  \********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "v-layout",
    { attrs: { row: "", "justify-center": "" } },
    [
      _c("CategoryAdd", { ref: "categoryAdd" }),
      _vm._v(" "),
      _c(
        "v-dialog",
        {
          model: {
            value: _vm.dialog,
            callback: function ($$v) {
              _vm.dialog = $$v
            },
            expression: "dialog",
          },
        },
        [
          _c(
            "v-card",
            [
              _c(
                "v-card-title",
                [
                  _c("v-icon", [_vm._v("live_help")]),
                  _vm._v(" "),
                  _c("span", { staticClass: "headline" }, [
                    _vm._v(
                      "\n                    " +
                        _vm._s(_vm.trans("messages.edit_ticket")) +
                        "\n                "
                    ),
                  ]),
                  _vm._v(" "),
                  _c("v-spacer"),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      attrs: { icon: "" },
                      on: {
                        click: function ($event) {
                          _vm.dialog = false
                        },
                      },
                    },
                    [_c("v-icon", [_vm._v("clear")])],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("v-divider"),
              _vm._v(" "),
              _c(
                "v-card-text",
                [
                  _c(
                    "v-container",
                    { attrs: { "grid-list-md": "" } },
                    [
                      _c(
                        "v-layout",
                        { attrs: { row: "", wrap: "" } },
                        [
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm6: "", md6: "" } },
                            [
                              _c("v-text-field", {
                                directives: [
                                  {
                                    name: "validate",
                                    rawName: "v-validate",
                                    value: "required",
                                    expression: "'required'",
                                  },
                                ],
                                attrs: {
                                  label: _vm.trans("messages.title"),
                                  "data-vv-name": "title",
                                  "data-vv-as": _vm.trans("messages.title"),
                                  "error-messages": _vm.errors.collect("title"),
                                  required: "",
                                },
                                model: {
                                  value: _vm.form_fields.title,
                                  callback: function ($$v) {
                                    _vm.$set(_vm.form_fields, "title", $$v)
                                  },
                                  expression: "form_fields.title",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs11: "", sm5: "", md5: "" } },
                            [
                              _c("v-autocomplete", {
                                directives: [
                                  {
                                    name: "validate",
                                    rawName: "v-validate",
                                    value: "required",
                                    expression: "'required'",
                                  },
                                ],
                                attrs: {
                                  "item-text": "name",
                                  "item-value": "id",
                                  items: _vm.ticket_types,
                                  label: _vm.trans("messages.ticket_type"),
                                  "data-vv-name": "ticket_type",
                                  "data-vv-as": _vm.trans(
                                    "messages.ticket_type"
                                  ),
                                  "error-messages":
                                    _vm.errors.collect("ticket_type"),
                                  required: "",
                                },
                                model: {
                                  value: _vm.form_fields.category_id,
                                  callback: function ($$v) {
                                    _vm.$set(
                                      _vm.form_fields,
                                      "category_id",
                                      $$v
                                    )
                                  },
                                  expression: "form_fields.category_id",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _vm.$hasRole("employee")
                            ? _c(
                                "v-flex",
                                { attrs: { xs1: "", sm1: "", md1: "" } },
                                [
                                  _c(
                                    "v-btn",
                                    {
                                      attrs: {
                                        small: "",
                                        color: "primary",
                                        fab: "",
                                        dark: "",
                                      },
                                      on: { click: _vm.createCategory },
                                    },
                                    [_c("v-icon", [_vm._v("add")])],
                                    1
                                  ),
                                ],
                                1
                              )
                            : _vm._e(),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "v-layout",
                        { attrs: { row: "" } },
                        [
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm12: "", md12: "" } },
                            [
                              _c("v-textarea", {
                                directives: [
                                  {
                                    name: "validate",
                                    rawName: "v-validate",
                                    value: "required",
                                    expression: "'required'",
                                  },
                                ],
                                attrs: {
                                  rows: "4",
                                  label: _vm.trans("messages.description"),
                                  "data-vv-name": "description",
                                  "data-vv-as": _vm.trans(
                                    "messages.description"
                                  ),
                                  "error-messages":
                                    _vm.errors.collect("description"),
                                  required: "",
                                },
                                model: {
                                  value: _vm.form_fields.description,
                                  callback: function ($$v) {
                                    _vm.$set(
                                      _vm.form_fields,
                                      "description",
                                      $$v
                                    )
                                  },
                                  expression: "form_fields.description",
                                },
                              }),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "v-layout",
                        { attrs: { row: "", wrap: "" } },
                        [
                          _vm.$hasRole("employee")
                            ? _c(
                                "v-flex",
                                { attrs: { xs12: "", sm6: "", md6: "" } },
                                [
                                  _c("v-autocomplete", {
                                    directives: [
                                      {
                                        name: "validate",
                                        rawName: "v-validate",
                                        value: "required",
                                        expression: "'required'",
                                      },
                                    ],
                                    attrs: {
                                      "item-text": "value",
                                      "item-value": "key",
                                      items: _vm.statuses,
                                      label: _vm.trans("messages.status"),
                                      "data-vv-name": "status",
                                      "data-vv-as":
                                        _vm.trans("messages.status"),
                                      "error-messages":
                                        _vm.errors.collect("status"),
                                      required: "",
                                    },
                                    model: {
                                      value: _vm.form_fields.status,
                                      callback: function ($$v) {
                                        _vm.$set(_vm.form_fields, "status", $$v)
                                      },
                                      expression: "form_fields.status",
                                    },
                                  }),
                                ],
                                1
                              )
                            : _vm._e(),
                          _vm._v(" "),
                          _vm.$hasRole("employee")
                            ? _c(
                                "v-flex",
                                { attrs: { xs12: "", sm6: "", md6: "" } },
                                [
                                  _c("v-autocomplete", {
                                    attrs: {
                                      "item-text": "value",
                                      "item-value": "key",
                                      items: _vm.priorities,
                                      label: _vm.trans("messages.priority"),
                                    },
                                    model: {
                                      value: _vm.form_fields.priority,
                                      callback: function ($$v) {
                                        _vm.$set(
                                          _vm.form_fields,
                                          "priority",
                                          $$v
                                        )
                                      },
                                      expression: "form_fields.priority",
                                    },
                                  }),
                                ],
                                1
                              )
                            : _vm._e(),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "v-layout",
                        { attrs: { row: "", wrap: "" } },
                        [
                          _vm.$hasRole("employee")
                            ? _c(
                                "v-flex",
                                { attrs: { xs12: "", sm6: "", md6: "" } },
                                [
                                  _c("v-autocomplete", {
                                    attrs: {
                                      "item-text": "name",
                                      "item-value": "id",
                                      items: _vm.employees,
                                      label: _vm.trans("messages.assigned_to"),
                                    },
                                    model: {
                                      value: _vm.form_fields.assigned_to,
                                      callback: function ($$v) {
                                        _vm.$set(
                                          _vm.form_fields,
                                          "assigned_to",
                                          $$v
                                        )
                                      },
                                      expression: "form_fields.assigned_to",
                                    },
                                  }),
                                ],
                                1
                              )
                            : _vm._e(),
                          _vm._v(" "),
                          _vm.$hasRole("employee")
                            ? _c(
                                "v-flex",
                                { attrs: { xs12: "", sm6: "", md6: "" } },
                                [
                                  _c("v-autocomplete", {
                                    directives: [
                                      {
                                        name: "validate",
                                        rawName: "v-validate",
                                        value: "required",
                                        expression: "'required'",
                                      },
                                    ],
                                    attrs: {
                                      "item-text": "company",
                                      "item-value": "id",
                                      items: _vm.customers,
                                      label: _vm.trans("messages.customer"),
                                      "data-vv-name": "customer",
                                      "data-vv-as":
                                        _vm.trans("messages.customer"),
                                      "error-messages":
                                        _vm.errors.collect("customer"),
                                      required: "",
                                    },
                                    model: {
                                      value: _vm.form_fields.customer_id,
                                      callback: function ($$v) {
                                        _vm.$set(
                                          _vm.form_fields,
                                          "customer_id",
                                          $$v
                                        )
                                      },
                                      expression: "form_fields.customer_id",
                                    },
                                  }),
                                ],
                                1
                              )
                            : _vm._e(),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("v-divider"),
              _vm._v(" "),
              _c(
                "v-card-actions",
                [
                  _c("v-spacer"),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      attrs: { color: "green darken-1", flat: "" },
                      on: {
                        click: function ($event) {
                          _vm.dialog = false
                        },
                      },
                    },
                    [
                      _vm._v(
                        "\n                    " +
                          _vm._s(_vm.trans("messages.close")) +
                          "\n                "
                      ),
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      attrs: {
                        color: "success",
                        loading: _vm.loading,
                        disabled: _vm.loading,
                      },
                      on: { click: _vm.store },
                    },
                    [
                      _vm._v(
                        "\n                    " +
                          _vm._s(_vm.trans("messages.update")) +
                          "\n                "
                      ),
                    ]
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/tickets/List.vue?vue&type=template&id=55d4fe7c&":
/*!********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/tickets/List.vue?vue&type=template&id=55d4fe7c& ***!
  \********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "v-container",
    {
      class: _vm.$vuetify.breakpoint.xsOnly ? "" : "",
      attrs: { "grid-list-md": "" },
    },
    [
      _c("AcceptEnginneringOfficeModal", {
        ref: "acceptenginneringoffice",
        on: {
          next: function ($event) {
            return _vm.getAllProjectRequest($event)
          },
        },
      }),
      _vm._v(" "),
      _c(
        "v-card",
        { staticClass: "mt-3" },
        [
          _c("ticket-edit", { ref: "ticketEdit" }),
          _vm._v(" "),
          _c(
            "v-card-title",
            { attrs: { "primary-title": "", xs8: "", sm8: "" } },
            [
              _c("div", [
                _c("div", { staticClass: "headline" }, [
                  _vm._v(
                    "\n                    " +
                      _vm._s(_vm.trans("data.visit_requests")) +
                      "\n                "
                  ),
                ]),
              ]),
              _vm._v(" "),
              _c("v-spacer"),
              _vm._v(" "),
              _vm.$can("tickets.create")
                ? _c(
                    "v-btn",
                    {
                      staticClass: "lighten-1",
                      staticStyle: {
                        "background-color": "#06706d",
                        color: "white",
                      },
                      on: {
                        click: function ($event) {
                          return _vm.$router.push({
                            name: "create_visit_request_list",
                            params: {
                              request_type: "visit_request",
                              project_id: _vm.id,
                            },
                          })
                        },
                      },
                    },
                    [
                      _vm._v(
                        "\n                " +
                          _vm._s(_vm.trans("messages.add")) +
                          "\n                "
                      ),
                      _c("v-icon", { attrs: { right: "", dark: "" } }, [
                        _vm._v("add"),
                      ]),
                    ],
                    1
                  )
                : _vm._e(),
            ],
            1
          ),
          _vm._v(" "),
          _c("v-divider"),
          _vm._v(" "),
          _c("v-data-table", {
            staticClass: "elevation-3",
            attrs: {
              headers: _vm.headers,
              pagination: _vm.pagination,
              "total-items": _vm.total_items,
              loading: _vm.loading,
              items: _vm.projects,
            },
            on: {
              "update:pagination": function ($event) {
                _vm.pagination = $event
              },
            },
            scopedSlots: _vm._u([
              {
                key: "items",
                fn: function (props) {
                  return [
                    _c("td", [
                      _c(
                        "div",
                        {
                          staticStyle: {
                            display: "inline-flex",
                            "padding-left": "30%",
                          },
                          attrs: { align: "center" },
                        },
                        [
                          _c(
                            "v-btn",
                            {
                              attrs: {
                                small: "",
                                fab: "",
                                dark: "",
                                color: "success",
                              },
                              on: {
                                click: function ($event) {
                                  return _vm.viewRequest(props.item)
                                },
                              },
                            },
                            [
                              _c("v-icon", { attrs: { color: "white" } }, [
                                _vm._v("info"),
                              ]),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ]),
                    _vm._v(" "),
                    _c("td", [
                      _c("div", { attrs: { align: "center" } }, [
                        _vm._v(
                          "\n                        " +
                            _vm._s(props.item.id) +
                            "\n                    "
                        ),
                      ]),
                    ]),
                    _vm._v(" "),
                    _c("td", [
                      _c(
                        "div",
                        { attrs: { align: "center" } },
                        [
                          props.item.status != ""
                            ? _c(
                                "v-chip",
                                {
                                  staticClass: "ma-2",
                                  attrs: {
                                    color: _vm.getColor(props.item.status),
                                    "text-color": "white",
                                  },
                                },
                                [
                                  _vm._v(
                                    "\n                            " +
                                      _vm._s(
                                        props.item.office_id == _vm.currentUser
                                          ? props.item.office_status
                                          : props.item.status
                                      ) +
                                      "\n                        "
                                  ),
                                ]
                              )
                            : _vm._e(),
                        ],
                        1
                      ),
                    ]),
                    _vm._v(" "),
                    _c("td", [
                      _c("div", { attrs: { align: "center" } }, [
                        _vm._v(
                          "\n                        " +
                            _vm._s(props.item.customer) +
                            "\n                    "
                        ),
                      ]),
                    ]),
                    _vm._v(" "),
                    _c("td", [
                      _c(
                        "div",
                        { attrs: { align: "center" } },
                        [
                          _c(
                            "v-btn",
                            {
                              attrs: {
                                small: "",
                                fab: "",
                                dark: "",
                                color: "teal",
                              },
                              on: {
                                click: function ($event) {
                                  return _vm.viewProject(props.item.projectId)
                                },
                              },
                            },
                            [
                              _vm._v(
                                "\n                            " +
                                  _vm._s(props.item.projectName) +
                                  "\n                            "
                              ),
                            ]
                          ),
                        ],
                        1
                      ),
                    ]),
                    _vm._v(" "),
                    _c("td", [
                      _c("div", { attrs: { align: "center" } }, [
                        _vm._v(
                          "\n                        " +
                            _vm._s(
                              props.item.created_at
                                ? _vm.createdDate(props.item.created_at)
                                : "-"
                            ) +
                            "\n                    "
                        ),
                      ]),
                    ]),
                  ]
                },
              },
            ]),
          }),
        ],
        1
      ),
      _vm._v(" "),
      _c("br"),
      _vm._v(" "),
      _c(
        "div",
        { attrs: { align: "center" } },
        [
          _vm.backBtn
            ? _c(
                "v-btn",
                {
                  staticStyle: {
                    "background-color": "#06706d",
                    color: "white",
                  },
                  on: {
                    click: function ($event) {
                      return _vm.$router.go(-1)
                    },
                  },
                },
                [
                  _vm._v(
                    "\n            " +
                      _vm._s(_vm.trans("messages.back")) +
                      "\n        "
                  ),
                ]
              )
            : _vm._e(),
        ],
        1
      ),
      _vm._v(" "),
      _c("br"),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);