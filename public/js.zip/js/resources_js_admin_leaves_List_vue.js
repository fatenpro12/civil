"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_admin_leaves_List_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/leaves/Edit.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/leaves/Edit.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  data: function data() {
    return {
      loading: false,
      dialog: false,
      start_date: null,
      end_date: null,
      reason: '',
      leave_id: null
    };
  },
  methods: {
    edit: function edit(leave_params) {
      var self = this;
      self.start_date = null;
      self.end_date = null;
      self.reason = '';
      self.leave_id = leave_params.id;
      axios.get('/leaves/' + leave_params.id + '/edit').then(function (response) {
        self.start_date = response.data.start_date;
        self.end_date = response.data.end_date;
        self.reason = response.data.reason;
        self.dialog = true;
      })["catch"](function (error) {
        console.log(error);
      });
    },
    store: function (_store) {
      function store() {
        return _store.apply(this, arguments);
      }
      store.toString = function () {
        return _store.toString();
      };
      return store;
    }(function () {
      var self = this;
      var data = {
        start_date: self.start_date,
        end_date: self.end_date,
        reason: self.reason
      };
      self.$validator.validateAll().then(function (result) {
        if (result == true) {
          self.loading = true;
          axios.put('/leaves/' + self.leave_id, data).then(function (response) {
            self.$validator.reset();
            self.loading = false;
            self.$store.commit('showSnackbar', {
              message: response.data.msg,
              color: response.data.success
            });
            if (response.data.success === true) {
              self.dialog = false;
              self.$eventBus.$emit('updateLeaveTable');
            }
          })["catch"](function (err) {
            console.log(err.response.status);
            if (err.response.status === 401) {
              store.dispatch('auth/handleResponse', err.response);
            }
          });
        }
      });
    })
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/leaves/List.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/leaves/List.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Add__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Add */ "./resources/js/admin/leaves/Add.vue");
/* harmony import */ var _Edit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Edit */ "./resources/js/admin/leaves/Edit.vue");
/* harmony import */ var _status_StatusLabel__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../status/StatusLabel */ "./resources/js/admin/status/StatusLabel.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  components: {
    LeaveAdd: _Add__WEBPACK_IMPORTED_MODULE_0__["default"],
    LeaveEdit: _Edit__WEBPACK_IMPORTED_MODULE_1__["default"],
    StatusLabel: _status_StatusLabel__WEBPACK_IMPORTED_MODULE_2__["default"]
  },
  data: function data() {
    var self = this;
    return {
      total_items: 0,
      loading: false,
      pagination: {
        totalItems: 0
      },
      headers: [{
        text: self.trans('messages.action'),
        value: false,
        align: 'left',
        sortable: false
      }, {
        text: self.trans('messages.applied_date'),
        value: 'applied_date',
        align: 'left',
        sortable: true
      }, {
        text: self.trans('messages.start_date'),
        value: 'start_date',
        align: 'left',
        sortable: true
      }, {
        text: self.trans('messages.end_date'),
        value: 'end_date',
        align: 'left',
        sortable: true
      }, {
        text: self.trans('messages.status'),
        value: 'status',
        align: 'left',
        sortable: true
      }, {
        text: self.trans('messages.reason'),
        value: 'reason',
        align: 'left',
        sortable: false
      }],
      items: [],
      statuses: [],
      leaves: [],
      employees: [],
      filterStatus: [],
      dates: []
    };
  },
  watch: {
    pagination: {
      handler: function handler() {
        this.getLeavesFromApi();
      }
    }
  },
  mounted: function mounted() {
    var self = this;
    if (self.$can('superadmin')) {
      var header = {
        text: self.trans('messages.name'),
        value: 'employee',
        align: 'left',
        sortable: true
      };
      self.headers.splice(1, 0, header);
    }
    self.getFilters();
    self.$eventBus.$on('updateLeaveTable', function (data) {
      self.getLeavesFromApi();
    });
  },
  beforeDestroy: function beforeDestroy() {
    var self = this;
    self.$eventBus.$off('updateLeaveTable');
  },
  methods: {
    getLeavesFromApi: function getLeavesFromApi() {
      this.loading = true;
      var _this$pagination = this.pagination,
        sortBy = _this$pagination.sortBy,
        descending = _this$pagination.descending,
        page = _this$pagination.page,
        rowsPerPage = _this$pagination.rowsPerPage;
      var self = this;
      var params = {
        sort_by: sortBy,
        descending: descending,
        page: page,
        rowsPerPage: rowsPerPage
      };
      if (self.leaves.user_id) {
        params['user_id'] = self.leaves.user_id;
      }
      if (self.leaves.status) {
        params['status'] = self.leaves.status;
      }
      if (self.leaves.date) {
        params['date'] = self.leaves.date;
      }
      axios.get('/leaves', {
        params: params
      }).then(function (response) {
        self.total_items = response.data.leaves.total;
        self.items = response.data.leaves.data;
        self.statuses = response.data.status;
        self.loading = false;
      })["catch"](function (error) {
        console.log(error);
      });
    },
    deleteLeaves: function deleteLeaves(leave) {
      var self = this;
      self.$store.commit('showDialog', {
        type: 'confirm',
        icon: 'warning',
        title: self.trans('messages.are_you_sure'),
        message: self.trans('messages.you_cant_restore_it'),
        okCb: function okCb() {
          axios["delete"]('/leaves/' + leave.id).then(function (response) {
            self.$store.commit('showSnackbar', {
              message: response.data.msg,
              color: response.data.success
            });
            if (response.data.success === true) {
              self.getLeavesFromApi();
            }
          })["catch"](function (err) {
            console.log(err.response.status);
            if (err.response.status === 401) {
              store.dispatch('auth/handleResponse', err.response);
            }
          });
        },
        cancelCb: function cancelCb() {
          console.log('CANCEL');
        }
      });
    },
    updateStatus: function updateStatus(status, leave) {
      var self = this;
      axios.get('/leaves/update-status', {
        params: {
          id: leave.id,
          status: status
        }
      }).then(function (response) {
        self.$store.commit('showSnackbar', {
          message: response.data.msg,
          color: response.data.success
        });
        if (response.data.success === true) {
          leave.status = status;
        }
      })["catch"](function (error) {
        console.log(error);
      });
    },
    getFilters: function getFilters() {
      var self = this;
      axios.get('/leaves/get-filters').then(function (response) {
        self.employees = response.data.employees;
        self.filterStatus = response.data.status;
        self.dates = response.data.date;
      })["catch"](function (error) {
        console.log(error);
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/status/StatusLabel.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/status/StatusLabel.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  props: ['status'],
  methods: {
    color: function color(status) {
      if (status === 'approved' || status === 'paid' || status === 'closed') {
        return 'green lighten-1';
      } else if (status === 'cancelled' || status === 'due' || status === 'new' || status === 'urgent') {
        return 'red accent-2';
      } else if (status === 'pending' || status === 'partial') {
        return 'cyan lighten-2';
      } else if (status === 'open') {
        return 'pink lighten-1';
      } else if (status === 'low') {
        return 'yellow darken-4';
      } else if (status === 'medium') {
        return 'deep-orange lighten-2';
      } else if (status === 'high') {
        return 'red accent-1';
      }
    }
  }
});

/***/ }),

/***/ "./resources/js/admin/leaves/Edit.vue":
/*!********************************************!*\
  !*** ./resources/js/admin/leaves/Edit.vue ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Edit_vue_vue_type_template_id_6badf3ef___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Edit.vue?vue&type=template&id=6badf3ef& */ "./resources/js/admin/leaves/Edit.vue?vue&type=template&id=6badf3ef&");
/* harmony import */ var _Edit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Edit.vue?vue&type=script&lang=js& */ "./resources/js/admin/leaves/Edit.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Edit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Edit_vue_vue_type_template_id_6badf3ef___WEBPACK_IMPORTED_MODULE_0__.render,
  _Edit_vue_vue_type_template_id_6badf3ef___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/admin/leaves/Edit.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/admin/leaves/List.vue":
/*!********************************************!*\
  !*** ./resources/js/admin/leaves/List.vue ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _List_vue_vue_type_template_id_5c65cc83___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./List.vue?vue&type=template&id=5c65cc83& */ "./resources/js/admin/leaves/List.vue?vue&type=template&id=5c65cc83&");
/* harmony import */ var _List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./List.vue?vue&type=script&lang=js& */ "./resources/js/admin/leaves/List.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _List_vue_vue_type_template_id_5c65cc83___WEBPACK_IMPORTED_MODULE_0__.render,
  _List_vue_vue_type_template_id_5c65cc83___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/admin/leaves/List.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/admin/status/StatusLabel.vue":
/*!***************************************************!*\
  !*** ./resources/js/admin/status/StatusLabel.vue ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _StatusLabel_vue_vue_type_template_id_2169abba___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./StatusLabel.vue?vue&type=template&id=2169abba& */ "./resources/js/admin/status/StatusLabel.vue?vue&type=template&id=2169abba&");
/* harmony import */ var _StatusLabel_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./StatusLabel.vue?vue&type=script&lang=js& */ "./resources/js/admin/status/StatusLabel.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _StatusLabel_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _StatusLabel_vue_vue_type_template_id_2169abba___WEBPACK_IMPORTED_MODULE_0__.render,
  _StatusLabel_vue_vue_type_template_id_2169abba___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/admin/status/StatusLabel.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/admin/leaves/Edit.vue?vue&type=script&lang=js&":
/*!*********************************************************************!*\
  !*** ./resources/js/admin/leaves/Edit.vue?vue&type=script&lang=js& ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Edit.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/leaves/Edit.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/admin/leaves/List.vue?vue&type=script&lang=js&":
/*!*********************************************************************!*\
  !*** ./resources/js/admin/leaves/List.vue?vue&type=script&lang=js& ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./List.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/leaves/List.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/admin/status/StatusLabel.vue?vue&type=script&lang=js&":
/*!****************************************************************************!*\
  !*** ./resources/js/admin/status/StatusLabel.vue?vue&type=script&lang=js& ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_StatusLabel_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StatusLabel.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/status/StatusLabel.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_StatusLabel_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/admin/leaves/Edit.vue?vue&type=template&id=6badf3ef&":
/*!***************************************************************************!*\
  !*** ./resources/js/admin/leaves/Edit.vue?vue&type=template&id=6badf3ef& ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_template_id_6badf3ef___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_template_id_6badf3ef___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_template_id_6badf3ef___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Edit.vue?vue&type=template&id=6badf3ef& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/leaves/Edit.vue?vue&type=template&id=6badf3ef&");


/***/ }),

/***/ "./resources/js/admin/leaves/List.vue?vue&type=template&id=5c65cc83&":
/*!***************************************************************************!*\
  !*** ./resources/js/admin/leaves/List.vue?vue&type=template&id=5c65cc83& ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_5c65cc83___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_5c65cc83___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_5c65cc83___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./List.vue?vue&type=template&id=5c65cc83& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/leaves/List.vue?vue&type=template&id=5c65cc83&");


/***/ }),

/***/ "./resources/js/admin/status/StatusLabel.vue?vue&type=template&id=2169abba&":
/*!**********************************************************************************!*\
  !*** ./resources/js/admin/status/StatusLabel.vue?vue&type=template&id=2169abba& ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StatusLabel_vue_vue_type_template_id_2169abba___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StatusLabel_vue_vue_type_template_id_2169abba___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StatusLabel_vue_vue_type_template_id_2169abba___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StatusLabel.vue?vue&type=template&id=2169abba& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/status/StatusLabel.vue?vue&type=template&id=2169abba&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/leaves/Edit.vue?vue&type=template&id=6badf3ef&":
/*!******************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/leaves/Edit.vue?vue&type=template&id=6badf3ef& ***!
  \******************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "v-layout",
        { attrs: { row: "", "justify-center": "" } },
        [
          _c(
            "v-dialog",
            {
              attrs: { width: "800" },
              model: {
                value: _vm.dialog,
                callback: function ($$v) {
                  _vm.dialog = $$v
                },
                expression: "dialog",
              },
            },
            [
              _c(
                "v-card",
                [
                  _c(
                    "v-card-title",
                    [
                      _c("v-icon", { attrs: { medium: "" } }, [
                        _vm._v("work_off"),
                      ]),
                      _vm._v(" "),
                      _c("span", { staticClass: "headline" }, [
                        _vm._v(
                          "\n                        " +
                            _vm._s(_vm.trans("messages.edit_applied_leave")) +
                            "\n                    "
                        ),
                      ]),
                      _vm._v(" "),
                      _c("v-spacer"),
                      _vm._v(" "),
                      _c(
                        "v-btn",
                        {
                          attrs: { flat: "", icon: "" },
                          on: {
                            click: function ($event) {
                              _vm.dialog = false
                            },
                          },
                        },
                        [_c("v-icon", [_vm._v("clear")])],
                        1
                      ),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("v-divider"),
                  _vm._v(" "),
                  _c(
                    "v-card-text",
                    [
                      _c(
                        "v-container",
                        { attrs: { "grid-list-md": "" } },
                        [
                          _c(
                            "v-layout",
                            { attrs: { row: "", wrap: "" } },
                            [
                              _c("v-flex", { attrs: { xs12: "", md6: "" } }, [
                                _c(
                                  "div",
                                  {
                                    staticClass:
                                      "v-input v-text-field theme--light",
                                  },
                                  [
                                    _c(
                                      "div",
                                      { staticClass: "v-input__control" },
                                      [
                                        _c(
                                          "div",
                                          { staticClass: "v-input__slot" },
                                          [
                                            _c(
                                              "div",
                                              {
                                                staticClass:
                                                  "v-text-field__slot",
                                              },
                                              [
                                                _c(
                                                  "label",
                                                  {
                                                    staticClass:
                                                      "v-label v-label--active theme--light flat_picker_label",
                                                    attrs: {
                                                      "aria-hidden": "true",
                                                    },
                                                  },
                                                  [
                                                    _vm._v(
                                                      "\n                                                    " +
                                                        _vm._s(
                                                          _vm.trans(
                                                            "messages.start_date"
                                                          )
                                                        ) +
                                                        "\n                                                "
                                                    ),
                                                  ]
                                                ),
                                                _vm._v(" "),
                                                _c("flat-pickr", {
                                                  directives: [
                                                    {
                                                      name: "validate",
                                                      rawName: "v-validate",
                                                      value: "required",
                                                      expression: "'required'",
                                                    },
                                                  ],
                                                  attrs: {
                                                    name: "start_date",
                                                    required: "",
                                                    config:
                                                      _vm.flatPickerDate(),
                                                    "data-vv-as": _vm.trans(
                                                      "messages.start_date"
                                                    ),
                                                  },
                                                  model: {
                                                    value: _vm.start_date,
                                                    callback: function ($$v) {
                                                      _vm.start_date = $$v
                                                    },
                                                    expression: "start_date",
                                                  },
                                                }),
                                              ],
                                              1
                                            ),
                                          ]
                                        ),
                                        _vm._v(" "),
                                        _c(
                                          "div",
                                          {
                                            staticClass:
                                              "v-messages theme--light error--text",
                                          },
                                          [
                                            _vm._v(
                                              "\n                                            " +
                                                _vm._s(
                                                  _vm.errors.first("start_date")
                                                ) +
                                                "\n                                        "
                                            ),
                                          ]
                                        ),
                                      ]
                                    ),
                                  ]
                                ),
                              ]),
                              _vm._v(" "),
                              _c("v-flex", { attrs: { xs12: "", md6: "" } }, [
                                _c(
                                  "div",
                                  {
                                    staticClass:
                                      "v-input v-text-field theme--light",
                                  },
                                  [
                                    _c(
                                      "div",
                                      { staticClass: "v-input__control" },
                                      [
                                        _c(
                                          "div",
                                          { staticClass: "v-input__slot" },
                                          [
                                            _c(
                                              "div",
                                              {
                                                staticClass:
                                                  "v-text-field__slot",
                                              },
                                              [
                                                _c(
                                                  "label",
                                                  {
                                                    staticClass:
                                                      "v-label v-label--active theme--light flat_picker_label",
                                                    attrs: {
                                                      "aria-hidden": "true",
                                                    },
                                                  },
                                                  [
                                                    _vm._v(
                                                      "\n                                                    " +
                                                        _vm._s(
                                                          _vm.trans(
                                                            "messages.end_date"
                                                          )
                                                        ) +
                                                        "\n                                                "
                                                    ),
                                                  ]
                                                ),
                                                _vm._v(" "),
                                                _c("flat-pickr", {
                                                  directives: [
                                                    {
                                                      name: "validate",
                                                      rawName: "v-validate",
                                                      value: "required",
                                                      expression: "'required'",
                                                    },
                                                  ],
                                                  attrs: {
                                                    name: "end_date",
                                                    required: "",
                                                    config:
                                                      _vm.flatPickerDate(),
                                                    "data-vv-as":
                                                      _vm.trans(
                                                        "messages.end_date"
                                                      ),
                                                  },
                                                  model: {
                                                    value: _vm.end_date,
                                                    callback: function ($$v) {
                                                      _vm.end_date = $$v
                                                    },
                                                    expression: "end_date",
                                                  },
                                                }),
                                              ],
                                              1
                                            ),
                                          ]
                                        ),
                                        _vm._v(" "),
                                        _c(
                                          "div",
                                          {
                                            staticClass:
                                              "v-messages theme--light error--text",
                                          },
                                          [
                                            _vm._v(
                                              "\n                                            " +
                                                _vm._s(
                                                  _vm.errors.first("end_date")
                                                ) +
                                                "\n                                        "
                                            ),
                                          ]
                                        ),
                                      ]
                                    ),
                                  ]
                                ),
                              ]),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-layout",
                            [
                              _c(
                                "v-flex",
                                { attrs: { xs12: "", sm12: "", md12: "" } },
                                [
                                  _c("v-textarea", {
                                    directives: [
                                      {
                                        name: "validate",
                                        rawName: "v-validate",
                                        value: "required",
                                        expression: "'required'",
                                      },
                                    ],
                                    attrs: {
                                      rows: "7",
                                      label: _vm.trans("messages.reason"),
                                      "data-vv-name": "reason",
                                      "data-vv-as":
                                        _vm.trans("messages.reason"),
                                      "error-messages":
                                        _vm.errors.collect("reason"),
                                      required: "",
                                    },
                                    model: {
                                      value: _vm.reason,
                                      callback: function ($$v) {
                                        _vm.reason = $$v
                                      },
                                      expression: "reason",
                                    },
                                  }),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "v-card-actions",
                    [
                      _c("v-spacer"),
                      _vm._v(" "),
                      _c(
                        "v-btn",
                        {
                          attrs: { color: "green darken-1", flat: "" },
                          on: {
                            click: function ($event) {
                              _vm.dialog = false
                            },
                          },
                        },
                        [
                          _vm._v(
                            "\n                        " +
                              _vm._s(_vm.trans("messages.close")) +
                              "\n                    "
                          ),
                        ]
                      ),
                      _vm._v(" "),
                      _c(
                        "v-btn",
                        {
                          attrs: {
                            color: "success",
                            loading: _vm.loading,
                            disabled: _vm.loading,
                          },
                          on: { click: _vm.store },
                        },
                        [
                          _vm._v(
                            "\n                        " +
                              _vm._s(_vm.trans("messages.apply")) +
                              "\n                    "
                          ),
                        ]
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/leaves/List.vue?vue&type=template&id=5c65cc83&":
/*!******************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/leaves/List.vue?vue&type=template&id=5c65cc83& ***!
  \******************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "component-wrap" },
    [
      _c("LeaveAdd", { ref: "applyLeave" }),
      _vm._v(" "),
      _c("LeaveEdit", { ref: "editAppliedLeave" }),
      _vm._v(" "),
      _c(
        "v-card",
        { staticClass: "mb-3" },
        [
          _c(
            "v-list",
            [
              _c(
                "v-list-group",
                { attrs: { "prepend-icon": "filter_list" } },
                [
                  _c(
                    "v-list-tile",
                    { attrs: { slot: "activator" }, slot: "activator" },
                    [
                      _c(
                        "v-list-tile-content",
                        [
                          _c("v-list-tile-title", [
                            _vm._v(
                              "\n                            " +
                                _vm._s(_vm.trans("messages.filters")) +
                                "\n                        "
                            ),
                          ]),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "v-list-tile-content",
                    [
                      _c(
                        "v-container",
                        { attrs: { "grid-list-md": "" } },
                        [
                          _c(
                            "v-layout",
                            { attrs: { wrap: "" } },
                            [
                              _vm.$can("superadmin")
                                ? _c(
                                    "v-flex",
                                    { attrs: { xs12: "", md4: "" } },
                                    [
                                      _c("v-autocomplete", {
                                        attrs: {
                                          "item-text": "name",
                                          "item-value": "id",
                                          items: _vm.employees,
                                          label: _vm.trans("messages.employee"),
                                        },
                                        on: { change: _vm.getLeavesFromApi },
                                        model: {
                                          value: _vm.leaves.user_id,
                                          callback: function ($$v) {
                                            _vm.$set(_vm.leaves, "user_id", $$v)
                                          },
                                          expression: "leaves.user_id",
                                        },
                                      }),
                                    ],
                                    1
                                  )
                                : _vm._e(),
                              _vm._v(" "),
                              _c(
                                "v-flex",
                                { attrs: { xs12: "", md4: "" } },
                                [
                                  _c("v-autocomplete", {
                                    attrs: {
                                      "item-text": "value",
                                      "item-value": "key",
                                      items: _vm.filterStatus,
                                      label: _vm.trans("messages.status"),
                                    },
                                    on: { change: _vm.getLeavesFromApi },
                                    model: {
                                      value: _vm.leaves.status,
                                      callback: function ($$v) {
                                        _vm.$set(_vm.leaves, "status", $$v)
                                      },
                                      expression: "leaves.status",
                                    },
                                  }),
                                ],
                                1
                              ),
                              _vm._v(" "),
                              _c(
                                "v-flex",
                                { attrs: { xs12: "", md4: "" } },
                                [
                                  _c("v-autocomplete", {
                                    attrs: {
                                      "item-text": "value",
                                      "item-value": "key",
                                      items: _vm.dates,
                                      label: _vm.trans("messages.date"),
                                    },
                                    on: { change: _vm.getLeavesFromApi },
                                    model: {
                                      value: _vm.leaves.date,
                                      callback: function ($$v) {
                                        _vm.$set(_vm.leaves, "date", $$v)
                                      },
                                      expression: "leaves.date",
                                    },
                                  }),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "v-card",
        [
          _c(
            "v-card-title",
            [
              _c("div", [
                _c("div", { staticClass: "headline" }, [
                  _vm._v(
                    "\n                    " +
                      _vm._s(_vm.trans("messages.all_leaves")) +
                      "\n                "
                  ),
                ]),
              ]),
              _vm._v(" "),
              _c("v-spacer"),
              _vm._v(" "),
              _vm.$can("leaves.create")
                ? _c(
                    "v-btn",
                    {
                      staticClass: "primary lighten-1",
                      attrs: { dark: "" },
                      on: {
                        click: function ($event) {
                          return _vm.$refs.applyLeave.create()
                        },
                      },
                    },
                    [
                      _vm._v(
                        "\n                " +
                          _vm._s(_vm.trans("messages.apply_leave")) +
                          "\n                "
                      ),
                      _c("v-icon", { attrs: { right: "", dark: "" } }, [
                        _vm._v("add"),
                      ]),
                    ],
                    1
                  )
                : _vm._e(),
            ],
            1
          ),
          _vm._v(" "),
          _c("v-divider"),
          _vm._v(" "),
          _c("v-data-table", {
            staticClass: "elevation-3",
            attrs: {
              headers: _vm.headers,
              pagination: _vm.pagination,
              "total-items": _vm.total_items,
              loading: _vm.loading,
              items: _vm.items,
            },
            on: {
              "update:pagination": function ($event) {
                _vm.pagination = $event
              },
            },
            scopedSlots: _vm._u([
              {
                key: "headerCell",
                fn: function (props) {
                  return [
                    props.header.value == "start_date"
                      ? _c("span", [
                          _vm._v(
                            "\n                    " +
                              _vm._s(props.header.text) +
                              "\n                "
                          ),
                        ])
                      : props.header.value == "end_date"
                      ? _c("span", [
                          _vm._v(
                            "\n                    " +
                              _vm._s(props.header.text) +
                              "\n                "
                          ),
                        ])
                      : props.header.value == "status"
                      ? _c("span", [
                          _vm._v(
                            "\n                    " +
                              _vm._s(props.header.text) +
                              "\n                "
                          ),
                        ])
                      : props.header.value == "reason"
                      ? _c("span", [
                          _vm._v(
                            "\n                    " +
                              _vm._s(props.header.text) +
                              "\n                "
                          ),
                        ])
                      : _c("span", [_vm._v(_vm._s(props.header.text))]),
                  ]
                },
              },
              {
                key: "items",
                fn: function (props) {
                  return [
                    _c(
                      "td",
                      [
                        _c(
                          "v-menu",
                          {
                            attrs: {
                              transition: "slide-x-transition",
                              right: "",
                            },
                          },
                          [
                            _c(
                              "v-btn",
                              {
                                attrs: { slot: "activator", icon: "" },
                                slot: "activator",
                              },
                              [_c("v-icon", [_vm._v("more_vert")])],
                              1
                            ),
                            _vm._v(" "),
                            _c(
                              "v-list",
                              [
                                _c(
                                  "v-menu",
                                  {
                                    attrs: {
                                      transition: "slide-x-transition",
                                      "offset-x": "",
                                      "open-on-hover": "",
                                    },
                                  },
                                  [
                                    _vm.$can("superadmin")
                                      ? _c(
                                          "v-list-tile",
                                          {
                                            attrs: { slot: "activator" },
                                            slot: "activator",
                                          },
                                          [
                                            _c(
                                              "v-list-tile-title",
                                              [
                                                _c(
                                                  "v-icon",
                                                  { attrs: { small: "" } },
                                                  [_vm._v(" check ")]
                                                ),
                                                _vm._v(
                                                  "\n                                        " +
                                                    _vm._s(
                                                      _vm.trans(
                                                        "messages.status"
                                                      )
                                                    ) +
                                                    "\n                                    "
                                                ),
                                              ],
                                              1
                                            ),
                                          ],
                                          1
                                        )
                                      : _vm._e(),
                                    _vm._v(" "),
                                    _c(
                                      "v-list",
                                      { attrs: { dense: "" } },
                                      _vm._l(_vm.statuses, function (status) {
                                        return _c(
                                          "v-list-tile",
                                          {
                                            key: status.key,
                                            attrs: {
                                              disabled:
                                                props.item.status ===
                                                status.key,
                                            },
                                            on: {
                                              click: function ($event) {
                                                return _vm.updateStatus(
                                                  status.key,
                                                  props.item
                                                )
                                              },
                                            },
                                          },
                                          [
                                            _c("v-list-tile-title", [
                                              _vm._v(
                                                "\n                                            " +
                                                  _vm._s(status.value) +
                                                  "\n                                        "
                                              ),
                                            ]),
                                          ],
                                          1
                                        )
                                      }),
                                      1
                                    ),
                                  ],
                                  1
                                ),
                                _vm._v(" "),
                                (_vm.$can("leaves.edit") &&
                                  props.item.status === "pending") ||
                                _vm.$can("superadmin")
                                  ? _c(
                                      "v-list-tile",
                                      {
                                        on: {
                                          click: function ($event) {
                                            return _vm.$refs.editAppliedLeave.edit(
                                              props.item
                                            )
                                          },
                                        },
                                      },
                                      [
                                        _c(
                                          "v-list-tile-title",
                                          [
                                            _c(
                                              "v-icon",
                                              {
                                                staticClass: "mr-2",
                                                attrs: { small: "" },
                                              },
                                              [_vm._v(" edit ")]
                                            ),
                                            _vm._v(
                                              "\n                                    " +
                                                _vm._s(
                                                  _vm.trans("messages.edit")
                                                ) +
                                                "\n                                "
                                            ),
                                          ],
                                          1
                                        ),
                                      ],
                                      1
                                    )
                                  : _vm._e(),
                                _vm._v(" "),
                                _vm.$can("superadmin")
                                  ? _c(
                                      "v-list-tile",
                                      {
                                        on: {
                                          click: function ($event) {
                                            return _vm.deleteLeaves(props.item)
                                          },
                                        },
                                      },
                                      [
                                        _c(
                                          "v-list-tile-title",
                                          [
                                            _c(
                                              "v-icon",
                                              {
                                                staticClass: "mr-2",
                                                attrs: { small: "" },
                                              },
                                              [_vm._v(" delete_forever ")]
                                            ),
                                            _vm._v(
                                              "\n                                    " +
                                                _vm._s(
                                                  _vm.trans("messages.delete")
                                                ) +
                                                "\n                                "
                                            ),
                                          ],
                                          1
                                        ),
                                      ],
                                      1
                                    )
                                  : _vm._e(),
                              ],
                              1
                            ),
                          ],
                          1
                        ),
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _vm.$can("superadmin")
                      ? _c("td", [_vm._v(_vm._s(props.item.employee))])
                      : _vm._e(),
                    _vm._v(" "),
                    _c("td", [
                      _vm._v(
                        _vm._s(_vm._f("formatDate")(props.item.applied_date))
                      ),
                    ]),
                    _vm._v(" "),
                    _c("td", [
                      _vm._v(
                        _vm._s(_vm._f("formatDate")(props.item.start_date))
                      ),
                    ]),
                    _vm._v(" "),
                    _c("td", [
                      _vm._v(_vm._s(_vm._f("formatDate")(props.item.end_date))),
                    ]),
                    _vm._v(" "),
                    _c(
                      "td",
                      [
                        _c("status-label", {
                          attrs: { status: props.item.status },
                        }),
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c("td", [_vm._v(_vm._s(props.item.reason))]),
                  ]
                },
              },
            ]),
          }),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/status/StatusLabel.vue?vue&type=template&id=2169abba&":
/*!*************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/status/StatusLabel.vue?vue&type=template&id=2169abba& ***!
  \*************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "v-chip",
    { attrs: { label: "", small: "", color: _vm.color(_vm.status) } },
    [_c("small", [_vm._v(_vm._s(_vm.trans("messages." + _vm.status)))])]
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);