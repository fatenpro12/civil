"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_admin_main_components_NewAuthorizationRequests_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/main/components/NewAuthorizationRequests.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/main/components/NewAuthorizationRequests.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  components: {},
  data: function data() {
    var self = this;
    return {
      newAuthorizationRequests: [],
      loading: false,
      total_items: 0,
      pagination: {
        totalItems: 0
      },
      headers: [{
        text: self.trans('messages.action'),
        value: false,
        align: 'centre',
        sortable: false
      }, {
        text: self.trans('data.id'),
        value: 'id',
        align: 'centre',
        sortable: true
      }, {
        text: self.trans('data.authorization_request_number'),
        value: 'authorization_request_number',
        align: 'centre',
        sortable: true
      }, {
        text: self.trans('data.license_number'),
        value: 'license_number',
        align: 'centre',
        sortable: true
      }, {
        text: self.trans('data.beneficiary_id_number'),
        value: 'beneficiary_id_number',
        align: 'centre',
        sortable: true
      }, {
        text: self.trans('data.beneficiary_id_type'),
        value: 'beneficiary_id_type',
        align: 'centre',
        sortable: true
      }, {
        text: self.trans('data.beneficiary_name'),
        value: 'beneficiary_name',
        align: 'centre',
        sortable: true
      }, {
        text: self.trans('data.type_of_request'),
        value: 'type_of_request',
        align: 'centre',
        sortable: true
      }, {
        text: self.trans('data.plot_number'),
        value: 'plot_number',
        align: 'centre',
        sortable: true
      }, {
        text: self.trans('data.beneficiary_data'),
        value: 'beneficiary_data',
        align: 'centre',
        sortable: true
      }, {
        text: self.trans('data.cadastral_decision_number'),
        value: 'cadastral_decision_number',
        align: 'centre',
        sortable: true
      }, {
        text: self.trans('messages.mobile'),
        value: 'mobile',
        align: 'centre',
        sortable: true
      }, {
        text: self.trans('messages.status'),
        value: 'status',
        align: 'centre',
        sortable: true
      }]
    };
  },
  created: function created() {},
  methods: {}
});

/***/ }),

/***/ "./resources/js/admin/main/components/NewAuthorizationRequests.vue":
/*!*************************************************************************!*\
  !*** ./resources/js/admin/main/components/NewAuthorizationRequests.vue ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _NewAuthorizationRequests_vue_vue_type_template_id_161949fe___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./NewAuthorizationRequests.vue?vue&type=template&id=161949fe& */ "./resources/js/admin/main/components/NewAuthorizationRequests.vue?vue&type=template&id=161949fe&");
/* harmony import */ var _NewAuthorizationRequests_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./NewAuthorizationRequests.vue?vue&type=script&lang=js& */ "./resources/js/admin/main/components/NewAuthorizationRequests.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _NewAuthorizationRequests_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _NewAuthorizationRequests_vue_vue_type_template_id_161949fe___WEBPACK_IMPORTED_MODULE_0__.render,
  _NewAuthorizationRequests_vue_vue_type_template_id_161949fe___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/admin/main/components/NewAuthorizationRequests.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/admin/main/components/NewAuthorizationRequests.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************!*\
  !*** ./resources/js/admin/main/components/NewAuthorizationRequests.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NewAuthorizationRequests_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./NewAuthorizationRequests.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/main/components/NewAuthorizationRequests.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NewAuthorizationRequests_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/admin/main/components/NewAuthorizationRequests.vue?vue&type=template&id=161949fe&":
/*!********************************************************************************************************!*\
  !*** ./resources/js/admin/main/components/NewAuthorizationRequests.vue?vue&type=template&id=161949fe& ***!
  \********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_NewAuthorizationRequests_vue_vue_type_template_id_161949fe___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_NewAuthorizationRequests_vue_vue_type_template_id_161949fe___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_NewAuthorizationRequests_vue_vue_type_template_id_161949fe___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./NewAuthorizationRequests.vue?vue&type=template&id=161949fe& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/main/components/NewAuthorizationRequests.vue?vue&type=template&id=161949fe&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/main/components/NewAuthorizationRequests.vue?vue&type=template&id=161949fe&":
/*!***********************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/main/components/NewAuthorizationRequests.vue?vue&type=template&id=161949fe& ***!
  \***********************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "component-wrap" },
    [
      _c(
        "v-container",
        { attrs: { "grid-list-md": "" } },
        [
          _c("v-flex", { attrs: { "pt-3": "", "pb-5": "" } }, [
            _c(
              "h1",
              {
                staticClass: "text-md-center",
                staticStyle: { color: "#0000008a" },
              },
              [
                _vm._v(
                  " " + _vm._s(_vm.trans("data.Engineering_offices_system"))
                ),
              ]
            ),
          ]),
          _vm._v(" "),
          _c(
            "v-card",
            { attrs: { "pt-3": "" } },
            [
              _c(
                "v-card-text",
                [
                  _c(
                    "v-container",
                    { attrs: { "grid-list-lg": "" } },
                    [
                      _c(
                        "v-layout",
                        { attrs: { wrap: "" } },
                        [
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm6: "", md12: "" } },
                            [
                              _c(
                                "v-flex",
                                { attrs: { xs12: "", sm12: "", md12: "" } },
                                [
                                  _c("v-card-text", [
                                    _c(
                                      "div",
                                      { staticClass: "text-md-center mt-2" },
                                      [
                                        _c("v-data-table", {
                                          staticClass: "elevation-3 w-full",
                                          attrs: {
                                            headers: _vm.headers,
                                            pagination: _vm.pagination,
                                            "total-items": _vm.total_items,
                                            loading: _vm.loading,
                                            items: _vm.newAuthorizationRequests,
                                          },
                                          on: {
                                            "update:pagination": function (
                                              $event
                                            ) {
                                              _vm.pagination = $event
                                            },
                                          },
                                          scopedSlots: _vm._u([
                                            {
                                              key: "items",
                                              fn: function (props) {
                                                return [
                                                  _c("td", [
                                                    _c(
                                                      "div",
                                                      {
                                                        staticStyle: {
                                                          display: "flex",
                                                        },
                                                      },
                                                      [
                                                        _vm.$can(
                                                          "project." +
                                                            props.item.id +
                                                            ".status"
                                                        ) ||
                                                        _vm.$can(
                                                          "project." +
                                                            props.item.id +
                                                            ".edit"
                                                        ) ||
                                                        _vm.$can(
                                                          "project." +
                                                            props.item.id +
                                                            ".delete"
                                                        )
                                                          ? _c(
                                                              "v-btn",
                                                              {
                                                                attrs: {
                                                                  slot: "activator",
                                                                  color:
                                                                    "success",
                                                                  small: "",
                                                                },
                                                                on: {
                                                                  click:
                                                                    function (
                                                                      $event
                                                                    ) {
                                                                      return _vm.$router.push(
                                                                        {
                                                                          name: "projects.project-tasks.list",
                                                                          params:
                                                                            {
                                                                              id: props
                                                                                .item
                                                                                .id,
                                                                            },
                                                                        }
                                                                      )
                                                                    },
                                                                },
                                                                slot: "activator",
                                                              },
                                                              [
                                                                _c(
                                                                  "v-icon",
                                                                  {
                                                                    attrs: {
                                                                      small: "",
                                                                    },
                                                                  },
                                                                  [
                                                                    _vm._v(
                                                                      "visibility"
                                                                    ),
                                                                  ]
                                                                ),
                                                                _vm._v(
                                                                  " \n                                                        " +
                                                                    _vm._s(
                                                                      _vm.trans(
                                                                        "messages.view"
                                                                      )
                                                                    ) +
                                                                    "\n                                                    "
                                                                ),
                                                              ],
                                                              1
                                                            )
                                                          : _vm._e(),
                                                        _vm._v(" "),
                                                        _vm.$can(
                                                          "project." +
                                                            props.item.id +
                                                            ".edit"
                                                        )
                                                          ? _c(
                                                              "v-btn",
                                                              {
                                                                attrs: {
                                                                  slot: "activator",
                                                                  color:
                                                                    "primary",
                                                                  small: "",
                                                                },
                                                                on: {
                                                                  click:
                                                                    function (
                                                                      $event
                                                                    ) {
                                                                      return _vm.$router.push(
                                                                        {
                                                                          name: "projects.project-tasks.list",
                                                                          params:
                                                                            {
                                                                              id: props
                                                                                .item
                                                                                .id,
                                                                            },
                                                                        }
                                                                      )
                                                                    },
                                                                },
                                                                slot: "activator",
                                                              },
                                                              [
                                                                _c(
                                                                  "v-icon",
                                                                  {
                                                                    attrs: {
                                                                      small: "",
                                                                    },
                                                                  },
                                                                  [
                                                                    _vm._v(
                                                                      "edit"
                                                                    ),
                                                                  ]
                                                                ),
                                                                _vm._v(
                                                                  " \n                                                        " +
                                                                    _vm._s(
                                                                      _vm.trans(
                                                                        "messages.edit"
                                                                      )
                                                                    ) +
                                                                    "\n                                                    "
                                                                ),
                                                              ],
                                                              1
                                                            )
                                                          : _vm._e(),
                                                        _vm._v(" "),
                                                        _vm.$can(
                                                          "project." +
                                                            props.item.id +
                                                            ".delete"
                                                        )
                                                          ? _c(
                                                              "v-btn",
                                                              {
                                                                attrs: {
                                                                  slot: "activator",
                                                                  color:
                                                                    "error",
                                                                  small: "",
                                                                },
                                                                on: {
                                                                  click:
                                                                    function (
                                                                      $event
                                                                    ) {
                                                                      return _vm.deleteProject(
                                                                        props
                                                                          .item
                                                                          .id
                                                                      )
                                                                    },
                                                                },
                                                                slot: "activator",
                                                              },
                                                              [
                                                                _c(
                                                                  "v-icon",
                                                                  {
                                                                    attrs: {
                                                                      small: "",
                                                                    },
                                                                  },
                                                                  [
                                                                    _vm._v(
                                                                      "delete_outline"
                                                                    ),
                                                                  ]
                                                                ),
                                                                _vm._v(
                                                                  " \n                                                        " +
                                                                    _vm._s(
                                                                      _vm.trans(
                                                                        "messages.delete"
                                                                      )
                                                                    ) +
                                                                    "\n                                                    "
                                                                ),
                                                              ],
                                                              1
                                                            )
                                                          : _vm._e(),
                                                      ],
                                                      1
                                                    ),
                                                  ]),
                                                  _vm._v(" "),
                                                  _c("td", [
                                                    _vm._v(
                                                      _vm._s(props.item.id)
                                                    ),
                                                  ]),
                                                  _vm._v(" "),
                                                  _c("td", [
                                                    _vm._v(
                                                      _vm._s(props.item.name)
                                                    ),
                                                  ]),
                                                  _vm._v(" "),
                                                  _c("td", [
                                                    _vm._v(
                                                      " " +
                                                        _vm._s(
                                                          props.item.customer
                                                            .company
                                                        )
                                                    ),
                                                  ]),
                                                  _vm._v(" "),
                                                  _c(
                                                    "td",
                                                    [
                                                      _c(
                                                        "v-chip",
                                                        {
                                                          staticClass: "ma-2",
                                                          attrs: {
                                                            color: "red",
                                                            "text-color":
                                                              "white",
                                                          },
                                                        },
                                                        [
                                                          _vm._v(
                                                            _vm._s(
                                                              _vm.trans(
                                                                "messages." +
                                                                  props.item
                                                                    .status
                                                              )
                                                            ) +
                                                              "\n                                                "
                                                          ),
                                                        ]
                                                      ),
                                                    ],
                                                    1
                                                  ),
                                                  _vm._v(" "),
                                                  _c(
                                                    "td",
                                                    [
                                                      _c(
                                                        "v-btn",
                                                        {
                                                          attrs: { icon: "" },
                                                          on: {
                                                            click: function (
                                                              $event
                                                            ) {
                                                              return _vm.markAsFavorite(
                                                                props.item
                                                              )
                                                            },
                                                          },
                                                        },
                                                        [
                                                          _c(
                                                            "v-icon",
                                                            {
                                                              attrs: {
                                                                color:
                                                                  _vm.toggleFavorite(
                                                                    props.item
                                                                  ),
                                                              },
                                                            },
                                                            [_vm._v(" star ")]
                                                          ),
                                                        ],
                                                        1
                                                      ),
                                                    ],
                                                    1
                                                  ),
                                                  _vm._v(" "),
                                                  _c(
                                                    "td",
                                                    [
                                                      _c("avatar", {
                                                        staticClass: "mr-2",
                                                        attrs: {
                                                          members:
                                                            props.item.members,
                                                        },
                                                      }),
                                                    ],
                                                    1
                                                  ),
                                                  _vm._v(" "),
                                                  _c("td", [
                                                    _vm._v(
                                                      _vm._s(
                                                        _vm.projectProgress(
                                                          props.item
                                                            .tasks_count,
                                                          props.item
                                                            .completed_task
                                                        )
                                                      )
                                                    ),
                                                  ]),
                                                ]
                                              },
                                            },
                                          ]),
                                        }),
                                      ],
                                      1
                                    ),
                                  ]),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);