"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_enginnering_office_tasks_List_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/tasks/Edit.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/tasks/Edit.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _category_Add__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../category/Add */ "./resources/js/common/projects/category/Add.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  components: {
    CategoryAdd: _category_Add__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  data: function data() {
    return {
      dialog: false,
      task: [],
      start_date: null,
      due_date: null,
      projectId: null,
      priority: [],
      projectMembers: [],
      taskMembers: [],
      billingType: null,
      project: [],
      categories: [],
      category_id: null,
      loading: false,
      task_id: null
    };
  },
  mounted: function mounted() {
    var self = this;
    self.$eventBus.$on('updateCategoryList', function (data) {
      self.categories.push(data);
      self.category_id = data.id;
    });
  },
  beforeDestroy: function beforeDestroy() {
    var self = this;
    self.$eventBus.$off('updateCategoryList');
  },
  methods: {
    edit: function edit(task_params) {
      var self = this;
      self.$validator.reset();
      self.projectId = task_params.project_id;
      self.task_id = task_params.task_id;
      axios.get('/project-tasks/' + task_params.task_id + '/edit', {
        params: {
          project_id: task_params.project_id
        }
      }).then(function (response) {
        self.task = response.data.task;
        self.task.user_id = response.data.task_members;
        self.task.show_to_customer = response.data.task.show_to_customer.toString();
        self.category_id = response.data.task.category_id;
        self.start_date = response.data.task.start_date;
        self.due_date = response.data.task.due_date;
        self.priority = response.data.priority;
        self.projectMembers = response.data.project.members;
        self.categories = response.data.categories;
        self.dialog = true;
      })["catch"](function (error) {
        console.log(error);
      });
    },
    store: function (_store) {
      function store() {
        return _store.apply(this, arguments);
      }
      store.toString = function () {
        return _store.toString();
      };
      return store;
    }(function () {
      var self = this;
      var data = {
        project_id: self.projectId,
        subject: self.task.subject,
        hourly_rate: self.task.hourly_rate,
        priority: self.task.priority,
        description: self.task.description,
        show_to_customer: self.task.show_to_customer,
        user_id: self.task.user_id,
        start_date: self.start_date,
        due_date: self.due_date,
        category_id: self.category_id
      };
      self.$validator.validateAll().then(function (result) {
        if (result == true) {
          self.loading = true;
          axios.put('/project-tasks/' + self.task_id, data).then(function (response) {
            self.loading = false;
            self.dialog = false;
            self.$store.commit('showSnackbar', {
              message: response.data.msg,
              color: response.data.success
            });
            if (response.data.success === true) {
              self.$eventBus.$emit('updateTaskTable', response.data.task);
              self.$eventBus.$emit('updateDashboard', response.data.task);
              self.$emit('savedTask');
            }
          })["catch"](function (err) {
            console.log(err.response.status);
            if (err.response.status === 401) {
              store.dispatch('auth/handleResponse', err.response);
            }
          });
        }
      });
    }),
    createCategory: function createCategory() {
      var self = this;
      var data = {
        type: 'tasks',
        project_id: self.projectId
      };
      self.$refs.categoryAdd.create(data);
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/tasks/List.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/tasks/List.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Show__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Show */ "./resources/js/common/projects/tasks/Show.vue");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _tasks_Add__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../tasks/Add */ "./resources/js/common/projects/tasks/Add.vue");
/* harmony import */ var _tasks_Edit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../tasks/Edit */ "./resources/js/common/projects/tasks/Edit.vue");
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  components: {
    TaskShow: _Show__WEBPACK_IMPORTED_MODULE_0__["default"],
    TaskFormAdd: _tasks_Add__WEBPACK_IMPORTED_MODULE_2__["default"],
    TaskFormEdit: _tasks_Edit__WEBPACK_IMPORTED_MODULE_3__["default"]
  },
  props: {
    backBtn: true
  },
  data: function data() {
    var _ref;
    var self = this;
    return _ref = {
      items: [],
      total_items: 0,
      loading: false,
      pagination: {
        rowsPerPage: 10
      },
      headers: [{
        text: self.trans('messages.action'),
        value: false,
        align: 'center',
        sortable: true
      }, {
        text: self.trans('data.id'),
        value: 'id',
        align: 'center',
        sortable: false
      }, {
        text: self.trans('messages.subject'),
        value: 'subject',
        align: 'center',
        sortable: true
      }, {
        text: self.trans('data.project_name'),
        value: 'project_id',
        align: 'center',
        sortable: true
      }, {
        text: self.trans('messages.due_date'),
        value: 'due_date',
        align: 'center',
        sortable: true
      }, {
        text: self.trans('messages.created_at'),
        value: 'created_at',
        align: 'center',
        sortable: true
      }],
      projectId: null,
      taskLists: [],
      //  url: null,
      filters: [],
      user_filter_type: null,
      usersList: [{
        id: 0,
        name: self.trans('messages.all')
      }],
      statuses: [{
        name: self.trans('messages.all'),
        value: ''
      }, {
        name: self.trans('messages.completed'),
        value: 'completed'
      }, {
        name: self.trans('messages.incompleted'),
        value: 'incompleted'
      }, {
        name: self.trans('messages.over_due'),
        value: 'over_due'
      }],
      view_style: 'grid',
      currentHover: null,
      projectCategories: [],
      project_list: [{
        id: 0,
        name: self.trans('messages.all')
      }],
      projects: []
    }, _defineProperty(_ref, "filters", {
      project_id: '',
      status: ''
    }), _defineProperty(_ref, "statistics", []), _ref;
  },
  watch: {
    'pagination.page': function paginationPage() {
      var self = this;
      //  self.url = 'project-tasks';
      self.getTaskList(self.projectId);
    },
    'pagination.rowsPerPage': function paginationRowsPerPage() {
      var self = this;
      self.getTaskList(self.projectId);
    },
    'filters.project_id': function filtersProject_id() {
      var self = this;
      self.getTaskList(self.projectId);
    },
    'filters.status': function filtersStatus() {
      var self = this;
      self.getTaskList(self.projectId);
    }
  },
  created: function created() {
    var self = this;
    self.filters.status = '';
    self.projectId = self.$route.params.id;
    //  self.url = 'project-tasks';
    self.getProjects();
    self.$eventBus.$on('updateTaskTable', function (data) {
      // self.url = 'project-tasks';
      self.taskLists = [];
      self.projects = self.projects.filter(function (x) {
        return x.id == data;
      });
      self.getTaskList(self.projectId);
    });
  },
  beforeDestroy: function beforeDestroy() {
    var self = this;
    self.$eventBus.$off('updateTaskTable');
  },
  methods: {
    createTask: function createTask() {
      this.$refs.taskAdd.create(this.projectId);
    },
    editTask: function editTask(task) {
      this.$refs.taskEdit.edit({
        project_id: this.projectId,
        task_id: task.id
      });
    },
    deleteTask: function deleteTask(id) {
      var self = this;
      self.$store.commit('showDialog', {
        type: 'confirm',
        icon: 'warning',
        title: self.trans('messages.are_you_sure'),
        message: self.trans('messages.you_cant_restore_it'),
        okCb: function okCb() {
          axios["delete"]('project-tasks/' + id).then(function (response) {
            self.$store.commit('showSnackbar', {
              message: response.data.msg,
              color: response.data.success
            });
            if (response.data.success === true) {
              // self.getTaskList(self.projectId)
              self.$eventBus.$emit('updateTaskTable', response.data.task);
            }
          })["catch"](function (error) {
            console.log(error);
          });
        },
        cancelCb: function cancelCb() {
          console.log('CANCEL');
        }
      });
    },
    getTaskList: function getTaskList(projectId) {
      var self = this;
      self.projectId = projectId;
      var params = {
        page: self.pagination.page,
        per_page: self.pagination.rowsPerPage
      };

      /*   if (self.filters.project_id) {
          params['project_id'] = self.filters.project_id;
      }*/
      if (self.filters.status) {
        params['status'] = self.filters.status;
      }
      if (projectId) {
        params['project_id'] = projectId;
      } else {
        params['project_id'] = self.filters.project_id;
      }
      console.log(params);
      axios.get('project-tasks', {
        params: params
      }).then(function (response) {
        var tasks = [];
        tasks = response.data.tasks;
        console.log(response.data.tasks);
        self.items = response.data.tasks.data;
        self.totalItems = response.data.tasks.total;
        self.pagination.totalItems = response.data.tasks.total;
        self.taskLists = lodash__WEBPACK_IMPORTED_MODULE_1___default().concat(self.taskLists, tasks);

        //  self.url = _.get(response, 'data.next_page_url', null);
        self.projectCategories = response.data.project_categories;
        self.projectCategories.push({
          id: ''
        });
      })["catch"](function (err) {
        console.log(err.response.status);
        if (err.response.status === 401) {
          store.dispatch('auth/handleResponse', err.response);
        }
      });
      ;
      //  }
    },
    view: function view(task) {
      var self = this;
      self.$refs.taskShow.view(task);
    },
    dueDateColor: function dueDateColor(task) {
      var date_passed = moment().isAfter(task.due_date);
      if (date_passed && task.is_completed == 0) {
        return 'red';
      } else {
        return 'primary grey--text text--lighten-1';
      }
    },
    createdDate: function createdDate(date) {
      var current_datetime = new Date(date);
      return current_datetime.toLocaleDateString('en-US');
    },
    getFilterData: function getFilterData() {
      var self = this;
      axios.get('project-tasks/filter-data/' + self.projectId).then(function (response) {
        if (response.data.members) {
          self.user_filter_type = 'dropdown';
          self.usersList = lodash__WEBPACK_IMPORTED_MODULE_1___default().concat(self.usersList, response.data.members);
        } else {
          self.user_filter_type = 'checkbox';
        }
        if (response.data.projects) {
          self.project_list = lodash__WEBPACK_IMPORTED_MODULE_1___default().concat(self.project_list, response.data.projects);
        }
      })["catch"](function (err) {
        console.log(err.response.status);
        if (err.response.status === 401) {
          store.dispatch('auth/handleResponse', err.response);
        }
      });
      ;
    },
    filterChanged: function filterChanged() {
      var self = this;
      //  self.url = 'project-tasks';
      self.taskLists = [];
      self.getTaskList(self.projectId);
    },
    getListBg: function getListBg(is_completed) {
      var task_id = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
      var self = this;
      var bg_class = '';
      if (task_id !== null && task_id == self.currentHover) {
        bg_class += 'elevation-15 ';
      }
      if (is_completed) {
        bg_class += 'list-faded';
      }
      return bg_class;
    },
    getProjects: function getProjects() {
      var self = this;
      axios.get('get-project-customer').then(function (response) {
        if (!response.data.error_code) {
          self.projects = response.data.data;
        }
      })["catch"](function (err) {
        console.log(err.response.status);
        if (err.response.status === 401) {
          store.dispatch('auth/handleResponse', err.response);
        }
      });
      ;
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/enginnering_office/tasks/List.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/enginnering_office/tasks/List.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _common_projects_tasks_List__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../common/projects/tasks/List */ "./resources/js/common/projects/tasks/List.vue");
//
//
//


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  components: {
    TasksList: _common_projects_tasks_List__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  data: function data() {
    return {
      project_id: null,
      show_all_task: true
    };
  },
  methods: {
    tasks: function tasks() {
      var self = this;
      self.$eventBus.$emit('updateTaskTable');
    }
  }
});

/***/ }),

/***/ "./resources/js/common/projects/tasks/Edit.vue":
/*!*****************************************************!*\
  !*** ./resources/js/common/projects/tasks/Edit.vue ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Edit_vue_vue_type_template_id_dada6ccc___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Edit.vue?vue&type=template&id=dada6ccc& */ "./resources/js/common/projects/tasks/Edit.vue?vue&type=template&id=dada6ccc&");
/* harmony import */ var _Edit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Edit.vue?vue&type=script&lang=js& */ "./resources/js/common/projects/tasks/Edit.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Edit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Edit_vue_vue_type_template_id_dada6ccc___WEBPACK_IMPORTED_MODULE_0__.render,
  _Edit_vue_vue_type_template_id_dada6ccc___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/common/projects/tasks/Edit.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/common/projects/tasks/List.vue":
/*!*****************************************************!*\
  !*** ./resources/js/common/projects/tasks/List.vue ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _List_vue_vue_type_template_id_f96abba4___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./List.vue?vue&type=template&id=f96abba4& */ "./resources/js/common/projects/tasks/List.vue?vue&type=template&id=f96abba4&");
/* harmony import */ var _List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./List.vue?vue&type=script&lang=js& */ "./resources/js/common/projects/tasks/List.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _List_vue_vue_type_template_id_f96abba4___WEBPACK_IMPORTED_MODULE_0__.render,
  _List_vue_vue_type_template_id_f96abba4___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/common/projects/tasks/List.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/enginnering_office/tasks/List.vue":
/*!********************************************************!*\
  !*** ./resources/js/enginnering_office/tasks/List.vue ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _List_vue_vue_type_template_id_6fcc376f___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./List.vue?vue&type=template&id=6fcc376f& */ "./resources/js/enginnering_office/tasks/List.vue?vue&type=template&id=6fcc376f&");
/* harmony import */ var _List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./List.vue?vue&type=script&lang=js& */ "./resources/js/enginnering_office/tasks/List.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _List_vue_vue_type_template_id_6fcc376f___WEBPACK_IMPORTED_MODULE_0__.render,
  _List_vue_vue_type_template_id_6fcc376f___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/enginnering_office/tasks/List.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/common/projects/tasks/Edit.vue?vue&type=script&lang=js&":
/*!******************************************************************************!*\
  !*** ./resources/js/common/projects/tasks/Edit.vue?vue&type=script&lang=js& ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Edit.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/tasks/Edit.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/common/projects/tasks/List.vue?vue&type=script&lang=js&":
/*!******************************************************************************!*\
  !*** ./resources/js/common/projects/tasks/List.vue?vue&type=script&lang=js& ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./List.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/tasks/List.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/enginnering_office/tasks/List.vue?vue&type=script&lang=js&":
/*!*********************************************************************************!*\
  !*** ./resources/js/enginnering_office/tasks/List.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./List.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/enginnering_office/tasks/List.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/common/projects/tasks/Edit.vue?vue&type=template&id=dada6ccc&":
/*!************************************************************************************!*\
  !*** ./resources/js/common/projects/tasks/Edit.vue?vue&type=template&id=dada6ccc& ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_template_id_dada6ccc___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_template_id_dada6ccc___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_template_id_dada6ccc___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Edit.vue?vue&type=template&id=dada6ccc& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/tasks/Edit.vue?vue&type=template&id=dada6ccc&");


/***/ }),

/***/ "./resources/js/common/projects/tasks/List.vue?vue&type=template&id=f96abba4&":
/*!************************************************************************************!*\
  !*** ./resources/js/common/projects/tasks/List.vue?vue&type=template&id=f96abba4& ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_f96abba4___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_f96abba4___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_f96abba4___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./List.vue?vue&type=template&id=f96abba4& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/tasks/List.vue?vue&type=template&id=f96abba4&");


/***/ }),

/***/ "./resources/js/enginnering_office/tasks/List.vue?vue&type=template&id=6fcc376f&":
/*!***************************************************************************************!*\
  !*** ./resources/js/enginnering_office/tasks/List.vue?vue&type=template&id=6fcc376f& ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_6fcc376f___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_6fcc376f___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_6fcc376f___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./List.vue?vue&type=template&id=6fcc376f& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/enginnering_office/tasks/List.vue?vue&type=template&id=6fcc376f&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/tasks/Edit.vue?vue&type=template&id=dada6ccc&":
/*!***************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/tasks/Edit.vue?vue&type=template&id=dada6ccc& ***!
  \***************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "v-layout",
    { attrs: { row: "", "justify-center": "" } },
    [
      _c("CategoryAdd", { ref: "categoryAdd" }),
      _vm._v(" "),
      _c(
        "v-dialog",
        {
          model: {
            value: _vm.dialog,
            callback: function ($$v) {
              _vm.dialog = $$v
            },
            expression: "dialog",
          },
        },
        [
          _c(
            "v-card",
            [
              _c(
                "v-card-title",
                [
                  _c("v-icon", [_vm._v("assignment")]),
                  _vm._v(" "),
                  _c("span", { staticClass: "headline" }, [
                    _vm._v(
                      "\n                    " +
                        _vm._s(_vm.trans("messages.edit_task")) +
                        "\n                "
                    ),
                  ]),
                  _vm._v(" "),
                  _c("v-spacer"),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      attrs: { flat: "", icon: "" },
                      on: {
                        click: function ($event) {
                          _vm.dialog = false
                        },
                      },
                    },
                    [_c("v-icon", [_vm._v("clear")])],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("v-divider"),
              _vm._v(" "),
              _c(
                "v-card-text",
                [
                  _c(
                    "v-container",
                    { attrs: { "grid-list-md": "" } },
                    [
                      _c(
                        "v-layout",
                        { attrs: { row: "", wrap: "" } },
                        [
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", md12: "" } },
                            [
                              _c("v-text-field", {
                                directives: [
                                  {
                                    name: "validate",
                                    rawName: "v-validate",
                                    value: "required",
                                    expression: "'required'",
                                  },
                                ],
                                attrs: {
                                  label: _vm.trans("messages.subject"),
                                  "data-vv-name": "subject",
                                  "data-vv-as": _vm.trans("messages.subject"),
                                  "error-messages":
                                    _vm.errors.collect("subject"),
                                  required: "",
                                },
                                model: {
                                  value: _vm.task.subject,
                                  callback: function ($$v) {
                                    _vm.$set(_vm.task, "subject", $$v)
                                  },
                                  expression: "task.subject",
                                },
                              }),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "v-layout",
                        { attrs: { row: "", wrap: "" } },
                        [
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm12: "", md12: "" } },
                            [
                              _vm._v(
                                "\n                            " +
                                  _vm._s(_vm.trans("messages.description")) +
                                  "\n                            "
                              ),
                              _c("quill-editor", {
                                model: {
                                  value: _vm.task.description,
                                  callback: function ($$v) {
                                    _vm.$set(_vm.task, "description", $$v)
                                  },
                                  expression: "task.description",
                                },
                              }),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "v-layout",
                        { staticClass: "mt-5", attrs: { row: "", wrap: "" } },
                        [
                          _c("v-flex", { attrs: { xs12: "", md4: "" } }, [
                            _c(
                              "div",
                              {
                                staticClass:
                                  "v-input v-text-field theme--light",
                              },
                              [
                                _c("div", { staticClass: "v-input__control" }, [
                                  _c("div", { staticClass: "v-input__slot" }, [
                                    _c(
                                      "div",
                                      { staticClass: "v-text-field__slot" },
                                      [
                                        _c(
                                          "label",
                                          {
                                            staticClass:
                                              "v-label v-label--active theme--light flat_picker_label",
                                            attrs: { "aria-hidden": "true" },
                                          },
                                          [
                                            _vm._v(
                                              "\n                                                " +
                                                _vm._s(
                                                  _vm.trans(
                                                    "messages.start_date"
                                                  )
                                                ) +
                                                "\n                                            "
                                            ),
                                          ]
                                        ),
                                        _vm._v(" "),
                                        _c("flat-pickr", {
                                          attrs: {
                                            name: "start_date",
                                            required: "",
                                            config: _vm.flatPickerDateTime(),
                                          },
                                          model: {
                                            value: _vm.start_date,
                                            callback: function ($$v) {
                                              _vm.start_date = $$v
                                            },
                                            expression: "start_date",
                                          },
                                        }),
                                      ],
                                      1
                                    ),
                                  ]),
                                ]),
                              ]
                            ),
                          ]),
                          _vm._v(" "),
                          _c("v-flex", { attrs: { xs12: "", md4: "" } }, [
                            _c(
                              "div",
                              {
                                staticClass:
                                  "v-input v-text-field theme--light",
                              },
                              [
                                _c("div", { staticClass: "v-input__control" }, [
                                  _c("div", { staticClass: "v-input__slot" }, [
                                    _c(
                                      "div",
                                      { staticClass: "v-text-field__slot" },
                                      [
                                        _c(
                                          "label",
                                          {
                                            staticClass:
                                              "v-label v-label--active theme--light flat_picker_label",
                                            attrs: { "aria-hidden": "true" },
                                          },
                                          [
                                            _vm._v(
                                              "\n                                                " +
                                                _vm._s(
                                                  _vm.trans("messages.due_date")
                                                ) +
                                                "\n                                            "
                                            ),
                                          ]
                                        ),
                                        _vm._v(" "),
                                        _c("flat-pickr", {
                                          attrs: {
                                            name: "due_date",
                                            required: "",
                                            config: _vm.flatPickerDateTime(),
                                          },
                                          model: {
                                            value: _vm.due_date,
                                            callback: function ($$v) {
                                              _vm.due_date = $$v
                                            },
                                            expression: "due_date",
                                          },
                                        }),
                                      ],
                                      1
                                    ),
                                  ]),
                                ]),
                              ]
                            ),
                          ]),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", md4: "" } },
                            [
                              _c("v-select", {
                                attrs: {
                                  "item-text": "value",
                                  "item-value": "key",
                                  items: _vm.priority,
                                  label: _vm.trans("messages.priority"),
                                },
                                model: {
                                  value: _vm.task.priority,
                                  callback: function ($$v) {
                                    _vm.$set(_vm.task, "priority", $$v)
                                  },
                                  expression: "task.priority",
                                },
                              }),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "v-layout",
                        { attrs: { row: "", wrap: "" } },
                        [
                          _vm.billingType == "task_hours"
                            ? _c(
                                "v-flex",
                                { attrs: { xs12: "", md4: "" } },
                                [
                                  _c("v-text-field", {
                                    attrs: {
                                      label: _vm.trans("messages.hourly_rate"),
                                    },
                                    model: {
                                      value: _vm.task.hourly_rate,
                                      callback: function ($$v) {
                                        _vm.$set(_vm.task, "hourly_rate", $$v)
                                      },
                                      expression: "task.hourly_rate",
                                    },
                                  }),
                                ],
                                1
                              )
                            : _vm._e(),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", md4: "" } },
                            [
                              _c("v-autocomplete", {
                                directives: [
                                  {
                                    name: "validate",
                                    rawName: "v-validate",
                                    value: "required",
                                    expression: "'required'",
                                  },
                                ],
                                attrs: {
                                  "item-text": "name",
                                  "item-value": "id",
                                  items: _vm.projectMembers,
                                  label: _vm.trans("messages.assign_to"),
                                  multiple: "",
                                  "data-vv-name": "assign_to",
                                  "data-vv-as": _vm.trans("messages.assign_to"),
                                  "error-messages":
                                    _vm.errors.collect("assign_to"),
                                  required: "",
                                },
                                model: {
                                  value: _vm.task.user_id,
                                  callback: function ($$v) {
                                    _vm.$set(_vm.task, "user_id", $$v)
                                  },
                                  expression: "task.user_id",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", md5: "" } },
                            [
                              _c("v-autocomplete", {
                                attrs: {
                                  "item-text": "name",
                                  "item-value": "id",
                                  items: _vm.categories,
                                  label: _vm.trans("messages.category"),
                                },
                                model: {
                                  value: _vm.category_id,
                                  callback: function ($$v) {
                                    _vm.category_id = $$v
                                  },
                                  expression: "category_id",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { md1: "" } },
                            [
                              _c(
                                "v-btn",
                                {
                                  attrs: {
                                    small: "",
                                    color: "primary",
                                    fab: "",
                                    dark: "",
                                  },
                                  on: { click: _vm.createCategory },
                                },
                                [_c("v-icon", [_vm._v("add")])],
                                1
                              ),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _vm.$hasRole("employee")
                            ? _c(
                                "v-flex",
                                { attrs: { xs12: "", md2: "" } },
                                [
                                  _c("v-checkbox", {
                                    attrs: {
                                      label: _vm.trans(
                                        "messages.show_to_customer"
                                      ),
                                      color: "primary",
                                      value: "1",
                                      "hide-details": "",
                                    },
                                    model: {
                                      value: _vm.task.show_to_customer,
                                      callback: function ($$v) {
                                        _vm.$set(
                                          _vm.task,
                                          "show_to_customer",
                                          $$v
                                        )
                                      },
                                      expression: "task.show_to_customer",
                                    },
                                  }),
                                ],
                                1
                              )
                            : _vm._e(),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "v-card-actions",
                [
                  _c("v-spacer"),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      attrs: { color: "green darken-1", flat: "" },
                      on: {
                        click: function ($event) {
                          _vm.dialog = false
                        },
                      },
                    },
                    [
                      _vm._v(
                        "\n                    " +
                          _vm._s(_vm.trans("messages.close")) +
                          "\n                "
                      ),
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      attrs: {
                        color: "success",
                        loading: _vm.loading,
                        disabled: _vm.loading,
                      },
                      on: { click: _vm.store },
                    },
                    [
                      _vm._v(
                        "\n                    " +
                          _vm._s(_vm.trans("messages.update")) +
                          "\n                "
                      ),
                    ]
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/tasks/List.vue?vue&type=template&id=f96abba4&":
/*!***************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/tasks/List.vue?vue&type=template&id=f96abba4& ***!
  \***************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "component-wrap" },
    [
      _c("TaskShow", { ref: "taskShow" }),
      _vm._v(" "),
      _c("TaskFormAdd", { ref: "taskAdd" }),
      _vm._v(" "),
      _c("TaskFormEdit", { ref: "taskEdit" }),
      _vm._v(" "),
      _c(
        "v-flex",
        { attrs: { xs12: "", sm8: "" } },
        [
          _c(
            "v-card",
            [
              _c(
                "v-list",
                [
                  _c(
                    "v-list-group",
                    { attrs: { "prepend-icon": "filter_list" } },
                    [
                      _c(
                        "v-list-tile",
                        { attrs: { slot: "activator" }, slot: "activator" },
                        [
                          _c(
                            "v-list-tile-content",
                            [
                              _c("v-list-tile-title", [
                                _vm._v(
                                  "\n                                " +
                                    _vm._s(_vm.trans("messages.filters")) +
                                    "\n                            "
                                ),
                              ]),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "v-list-tile-content",
                        [
                          _c(
                            "v-layout",
                            [
                              _c(
                                "v-flex",
                                { attrs: { xs12: "", sm12: "" } },
                                [
                                  _c(
                                    "v-container",
                                    { attrs: { "grid-list-md": "" } },
                                    [
                                      _c(
                                        "v-layout",
                                        [
                                          _c(
                                            "v-flex",
                                            { attrs: { xs12: "", sm12: "" } },
                                            [
                                              _c(
                                                "v-container",
                                                {
                                                  attrs: { "grid-list-md": "" },
                                                },
                                                [
                                                  _c(
                                                    "v-layout",
                                                    {
                                                      attrs: {
                                                        row: "",
                                                        wrap: "",
                                                      },
                                                    },
                                                    [
                                                      _c(
                                                        "v-flex",
                                                        {
                                                          attrs: {
                                                            xs12: "",
                                                            md6: "",
                                                          },
                                                        },
                                                        [
                                                          _c("v-select", {
                                                            attrs: {
                                                              "item-text":
                                                                "name",
                                                              "item-value":
                                                                "id",
                                                              clear: true,
                                                              items:
                                                                _vm.projects,
                                                              label:
                                                                _vm.trans(
                                                                  "data.project_name"
                                                                ),
                                                            },
                                                            on: {
                                                              change:
                                                                _vm.filterChanged,
                                                            },
                                                            model: {
                                                              value:
                                                                _vm.filters
                                                                  .project_id,
                                                              callback:
                                                                function ($$v) {
                                                                  _vm.$set(
                                                                    _vm.filters,
                                                                    "project_id",
                                                                    $$v
                                                                  )
                                                                },
                                                              expression:
                                                                "filters.project_id",
                                                            },
                                                          }),
                                                        ],
                                                        1
                                                      ),
                                                      _vm._v(" "),
                                                      _c(
                                                        "v-flex",
                                                        {
                                                          attrs: {
                                                            xs12: "",
                                                            md6: "",
                                                          },
                                                        },
                                                        [
                                                          _c("v-select", {
                                                            attrs: {
                                                              "item-text":
                                                                "name",
                                                              "item-value":
                                                                "value",
                                                              items:
                                                                _vm.statuses,
                                                              label:
                                                                _vm.trans(
                                                                  "messages.status"
                                                                ),
                                                            },
                                                            on: {
                                                              change:
                                                                _vm.filterChanged,
                                                            },
                                                            model: {
                                                              value:
                                                                _vm.filters
                                                                  .status,
                                                              callback:
                                                                function ($$v) {
                                                                  _vm.$set(
                                                                    _vm.filters,
                                                                    "status",
                                                                    $$v
                                                                  )
                                                                },
                                                              expression:
                                                                "filters.status",
                                                            },
                                                          }),
                                                        ],
                                                        1
                                                      ),
                                                    ],
                                                    1
                                                  ),
                                                ],
                                                1
                                              ),
                                            ],
                                            1
                                          ),
                                        ],
                                        1
                                      ),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "v-card",
        { staticClass: "mt-3" },
        [
          _c(
            "v-card-title",
            [
              _c("div", [
                _vm._v(
                  "\n                    " +
                    _vm._s(_vm.trans("data.tasks")) +
                    "\n                "
                ),
              ]),
              _vm._v(" "),
              _c("v-spacer"),
              _vm._v(" "),
              _vm.$can("task.create")
                ? _c(
                    "v-btn",
                    {
                      staticStyle: { color: "#06706d" },
                      on: { click: _vm.createTask },
                    },
                    [
                      _vm._v(
                        "\n            " +
                          _vm._s(_vm.trans("data.add_task")) +
                          "\n        "
                      ),
                    ]
                  )
                : _vm._e(),
            ],
            1
          ),
          _vm._v(" "),
          _c("v-divider"),
          _vm._v(" "),
          _c("v-data-table", {
            staticClass: "elevation-3",
            attrs: {
              headers: _vm.headers,
              pagination: _vm.pagination,
              "total-items": _vm.total_items,
              loading: _vm.loading,
              items: _vm.items,
            },
            on: {
              "update:pagination": function ($event) {
                _vm.pagination = $event
              },
            },
            scopedSlots: _vm._u([
              {
                key: "items",
                fn: function (props) {
                  return [
                    _c("td", [
                      _c(
                        "div",
                        { attrs: { align: "center" } },
                        [
                          _c(
                            "v-menu",
                            [
                              _c(
                                "v-btn",
                                {
                                  attrs: { slot: "activator", icon: "" },
                                  slot: "activator",
                                },
                                [_c("v-icon", [_vm._v("more_vert")])],
                                1
                              ),
                              _vm._v(" "),
                              _c(
                                "v-list",
                                [
                                  _c(
                                    "v-list-tile",
                                    {
                                      on: {
                                        click: function ($event) {
                                          return _vm.view(props.item)
                                        },
                                      },
                                    },
                                    [
                                      _c(
                                        "v-list-tile-title",
                                        [
                                          _c(
                                            "v-icon",
                                            {
                                              staticClass: "mr-2",
                                              attrs: { small: "" },
                                            },
                                            [_vm._v(" visibility ")]
                                          ),
                                          _vm._v(
                                            "\n                                        " +
                                              _vm._s(
                                                _vm.trans("messages.view")
                                              ) +
                                              "\n                                    "
                                          ),
                                        ],
                                        1
                                      ),
                                    ],
                                    1
                                  ),
                                  _vm._v(" "),
                                  _c(
                                    "v-list-tile",
                                    {
                                      on: {
                                        click: function ($event) {
                                          return _vm.editTask(props.item)
                                        },
                                      },
                                    },
                                    [
                                      _c(
                                        "v-list-tile-title",
                                        [
                                          _c(
                                            "v-icon",
                                            {
                                              staticClass: "mr-2",
                                              attrs: { small: "" },
                                            },
                                            [_vm._v(" edit ")]
                                          ),
                                          _vm._v(
                                            "\n                                        " +
                                              _vm._s(
                                                _vm.trans("messages.edit")
                                              ) +
                                              "\n                                    "
                                          ),
                                        ],
                                        1
                                      ),
                                    ],
                                    1
                                  ),
                                  _vm._v(" "),
                                  _c(
                                    "v-list-tile",
                                    {
                                      on: {
                                        click: function ($event) {
                                          return _vm.deleteTask(props.item.id)
                                        },
                                      },
                                    },
                                    [
                                      _c(
                                        "v-list-tile-title",
                                        [
                                          _c(
                                            "v-icon",
                                            {
                                              staticClass: "mr-2",
                                              attrs: { small: "" },
                                            },
                                            [_vm._v(" delete ")]
                                          ),
                                          _vm._v(
                                            "\n                                        " +
                                              _vm._s(
                                                _vm.trans("messages.delete")
                                              ) +
                                              "\n                                    "
                                          ),
                                        ],
                                        1
                                      ),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ]),
                    _vm._v(" "),
                    _c("td", [
                      _c("div", { attrs: { align: "center" } }, [
                        _vm._v(
                          "\n                        " +
                            _vm._s(props.item.id) +
                            "\n                    "
                        ),
                      ]),
                    ]),
                    _vm._v(" "),
                    _c("td", [
                      _c("div", { attrs: { align: "center" } }, [
                        _vm._v(
                          "\n                        " +
                            _vm._s(props.item.subject) +
                            "\n                    "
                        ),
                      ]),
                    ]),
                    _vm._v(" "),
                    _c("td", [
                      _c("div", { attrs: { align: "center" } }, [
                        _vm._v(
                          "\n                        " +
                            _vm._s(
                              props.item.project != undefined
                                ? props.item.project.name
                                : ""
                            ) +
                            "\n                    "
                        ),
                      ]),
                    ]),
                    _vm._v(" "),
                    _c("td", [
                      _c("div", { attrs: { align: "center" } }, [
                        _vm._v(
                          "\n                        " +
                            _vm._s(
                              props.item.due_date
                                ? _vm.createdDate(props.item.due_date)
                                : "-"
                            ) +
                            "\n                    "
                        ),
                      ]),
                    ]),
                    _vm._v(" "),
                    _c("td", [
                      _c("div", { attrs: { align: "center" } }, [
                        _vm._v(
                          "\n                        " +
                            _vm._s(
                              props.item.created_at
                                ? _vm.createdDate(props.item.created_at)
                                : "-"
                            ) +
                            "\n                    "
                        ),
                      ]),
                    ]),
                  ]
                },
              },
            ]),
          }),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "div",
        { attrs: { align: "center" } },
        [
          _vm.backBtn
            ? _c(
                "v-btn",
                {
                  staticStyle: {
                    "background-color": "#06706d",
                    color: "white",
                  },
                  on: {
                    click: function ($event) {
                      return _vm.$router.go(-1)
                    },
                  },
                },
                [
                  _vm._v(
                    "\n            " +
                      _vm._s(_vm.trans("messages.back")) +
                      "\n        "
                  ),
                ]
              )
            : _vm._e(),
        ],
        1
      ),
      _vm._v(" "),
      _c("br"),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/enginnering_office/tasks/List.vue?vue&type=template&id=6fcc376f&":
/*!******************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/enginnering_office/tasks/List.vue?vue&type=template&id=6fcc376f& ***!
  \******************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("TasksList", {
    attrs: { id: _vm.project_id, ShowAllTask: _vm.show_all_task },
  })
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);