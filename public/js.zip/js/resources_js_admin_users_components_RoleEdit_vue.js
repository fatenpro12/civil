"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_admin_users_components_RoleEdit_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/users/components/RoleEdit.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/users/components/RoleEdit.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  data: function data() {
    return {
      role_name: '',
      loading: false,
      permissions: [],
      is_primary: '',
      roleId: null
    };
  },
  created: function created() {
    var self = this;
    self.roleId = self.$route.params.id;
    self.getRole(self.roleId);
  },
  methods: {
    getRole: function getRole(role_id) {
      var self = this;
      axios.get('/admin/roles/' + role_id + '/edit').then(function (response) {
        self.role_name = response.data.role.name;
        self.is_primary = response.data.role.is_primary;
        self.permissions = response.data.permissions;
      })["catch"](function (err) {
        console.log(err.response.status);
        if (err.response.status === 401) {
          store.dispatch('auth/handleResponse', err.response);
        }
      });
    },
    store: function store() {
      var self = this;
      var data = {
        name: self.role_name,
        permissions: self.permissions,
        is_primary: self.is_primary
      };
      self.$validator.validateAll().then(function (result) {
        if (result == true) {
          self.loading = true;
          axios.put('/admin/roles/' + self.roleId, data).then(function (response) {
            self.loading = false;
            self.$validator.reset();
            self.$store.commit('showSnackbar', {
              message: response.data.msg,
              color: response.data.success
            });
            if (response.data.success === true) {
              self.goBack();
            }
          })["catch"](function (error) {
            console.log(error);
          });
        }
      });
    }
  }
});

/***/ }),

/***/ "./resources/js/admin/users/components/RoleEdit.vue":
/*!**********************************************************!*\
  !*** ./resources/js/admin/users/components/RoleEdit.vue ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _RoleEdit_vue_vue_type_template_id_2af3ef78___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./RoleEdit.vue?vue&type=template&id=2af3ef78& */ "./resources/js/admin/users/components/RoleEdit.vue?vue&type=template&id=2af3ef78&");
/* harmony import */ var _RoleEdit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./RoleEdit.vue?vue&type=script&lang=js& */ "./resources/js/admin/users/components/RoleEdit.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _RoleEdit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _RoleEdit_vue_vue_type_template_id_2af3ef78___WEBPACK_IMPORTED_MODULE_0__.render,
  _RoleEdit_vue_vue_type_template_id_2af3ef78___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/admin/users/components/RoleEdit.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/admin/users/components/RoleEdit.vue?vue&type=script&lang=js&":
/*!***********************************************************************************!*\
  !*** ./resources/js/admin/users/components/RoleEdit.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_RoleEdit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./RoleEdit.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/users/components/RoleEdit.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_RoleEdit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/admin/users/components/RoleEdit.vue?vue&type=template&id=2af3ef78&":
/*!*****************************************************************************************!*\
  !*** ./resources/js/admin/users/components/RoleEdit.vue?vue&type=template&id=2af3ef78& ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_RoleEdit_vue_vue_type_template_id_2af3ef78___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_RoleEdit_vue_vue_type_template_id_2af3ef78___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_RoleEdit_vue_vue_type_template_id_2af3ef78___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./RoleEdit.vue?vue&type=template&id=2af3ef78& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/users/components/RoleEdit.vue?vue&type=template&id=2af3ef78&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/users/components/RoleEdit.vue?vue&type=template&id=2af3ef78&":
/*!********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/users/components/RoleEdit.vue?vue&type=template&id=2af3ef78& ***!
  \********************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "component-wrap" },
    [
      _c(
        "v-card",
        [
          _c(
            "v-card-title",
            [
              _c("v-icon", { attrs: { medium: "" } }, [
                _vm._v("control_point"),
              ]),
              _vm._v(" "),
              _c("span", { staticClass: "headline" }, [
                _vm._v(
                  "\n                    " +
                    _vm._s(_vm.trans("messages.edit_role")) +
                    "\n                "
                ),
              ]),
            ],
            1
          ),
          _vm._v(" "),
          _c("v-divider"),
          _vm._v(" "),
          _c(
            "v-card-text",
            [
              _c(
                "v-layout",
                { attrs: { row: "", wrap: "" } },
                [
                  _c(
                    "v-flex",
                    { attrs: { xs12: "", sm6: "", md6: "" } },
                    [
                      _c("v-text-field", {
                        directives: [
                          {
                            name: "validate",
                            rawName: "v-validate",
                            value: "required",
                            expression: "'required'",
                          },
                        ],
                        attrs: {
                          label: _vm.trans("messages.role_name"),
                          "data-vv-name": "role_name",
                          "data-vv-as": _vm.trans("messages.role_name"),
                          "error-messages": _vm.errors.collect("role_name"),
                          required: "",
                        },
                        model: {
                          value: _vm.role_name,
                          callback: function ($$v) {
                            _vm.role_name = $$v
                          },
                          expression: "role_name",
                        },
                      }),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "v-flex",
                    {
                      staticStyle: { "padding-left": "5%" },
                      attrs: { xs12: "", sm6: "", md6: "" },
                    },
                    [
                      _c("v-checkbox", {
                        attrs: { label: _vm.trans("data.is_primary") },
                        model: {
                          value: _vm.is_primary,
                          callback: function ($$v) {
                            _vm.is_primary = $$v
                          },
                          expression: "is_primary",
                        },
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "v-container",
                { attrs: { "grid-list-md": "" } },
                [
                  _c(
                    "v-layout",
                    { attrs: { row: "" } },
                    [
                      _c(
                        "v-flex",
                        { attrs: { xs12: "", sm12: "", md12: "" } },
                        [
                          _c("v-icon", { attrs: { small: "" } }, [
                            _vm._v(" control_point_duplicate "),
                          ]),
                          _vm._v(" "),
                          _c("span", { staticClass: "subheading" }, [
                            _vm._v(
                              "\n                                " +
                                _vm._s(_vm.trans("messages.permissions")) +
                                "\n                            "
                            ),
                          ]),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _vm.$can("role.view") ||
                  _vm.$can("role.create") ||
                  _vm.$can("role.edit") ||
                  _vm.$can("role.delete")
                    ? _c("v-divider", { staticClass: "mt-1" })
                    : _vm._e(),
                  _vm._v(" "),
                  _c(
                    "v-layout",
                    { staticClass: "mt-3", attrs: { row: "", wrap: "" } },
                    [
                      _c("v-flex", { attrs: { xs12: "", sm3: "", md3: "" } }, [
                        _c("h4", [_vm._v(_vm._s(_vm.trans("data.Roles")))]),
                      ]),
                      _vm._v(" "),
                      _vm.$can("role.view") ||
                      _vm.$can("role.create") ||
                      _vm.$can("role.edit") ||
                      _vm.$can("role.delete")
                        ? _c(
                            "v-flex",
                            { attrs: { xs12: "", sm5: "", md5: "" } },
                            [
                              _vm.$can("role.create")
                                ? _c("v-checkbox", {
                                    attrs: {
                                      label: _vm.trans("data.create_role"),
                                      value: "role.create",
                                    },
                                    model: {
                                      value: _vm.permissions,
                                      callback: function ($$v) {
                                        _vm.permissions = $$v
                                      },
                                      expression: "permissions",
                                    },
                                  })
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.$can("role.edit")
                                ? _c("v-checkbox", {
                                    attrs: {
                                      label: _vm.trans("data.edit_role"),
                                      value: "role.edit",
                                    },
                                    model: {
                                      value: _vm.permissions,
                                      callback: function ($$v) {
                                        _vm.permissions = $$v
                                      },
                                      expression: "permissions",
                                    },
                                  })
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.$can("role.view")
                                ? _c("v-checkbox", {
                                    attrs: {
                                      label: _vm.trans("data.view_role"),
                                      value: "role.view",
                                    },
                                    model: {
                                      value: _vm.permissions,
                                      callback: function ($$v) {
                                        _vm.permissions = $$v
                                      },
                                      expression: "permissions",
                                    },
                                  })
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.$can("role.delete")
                                ? _c("v-checkbox", {
                                    attrs: {
                                      label: _vm.trans("data.delete_role"),
                                      value: "role.delete",
                                    },
                                    model: {
                                      value: _vm.permissions,
                                      callback: function ($$v) {
                                        _vm.permissions = $$v
                                      },
                                      expression: "permissions",
                                    },
                                  })
                                : _vm._e(),
                            ],
                            1
                          )
                        : _vm._e(),
                      _vm._v(" "),
                      _vm.$can("employeeNote.edit") ||
                      _vm.$can("employeeNote.view") ||
                      _vm.$can("employeeNote.delete") ||
                      _vm.$can("employeeNote.create")
                        ? _c(
                            "v-flex",
                            { attrs: { xs12: "", sm4: "", md4: "" } },
                            [
                              _vm.$can("employeeNote.create")
                                ? _c("v-checkbox", {
                                    attrs: {
                                      label: _vm.trans(
                                        "messages.add_employee_note"
                                      ),
                                      value: "employeeNote.create",
                                    },
                                    model: {
                                      value: _vm.permissions,
                                      callback: function ($$v) {
                                        _vm.permissions = $$v
                                      },
                                      expression: "permissions",
                                    },
                                  })
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.$can("employeeNote.view")
                                ? _c("v-checkbox", {
                                    attrs: {
                                      label: _vm.trans(
                                        "messages.view_employee_note"
                                      ),
                                      value: "employeeNote.view",
                                    },
                                    model: {
                                      value: _vm.permissions,
                                      callback: function ($$v) {
                                        _vm.permissions = $$v
                                      },
                                      expression: "permissions",
                                    },
                                  })
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.$can("employeeNote.edit")
                                ? _c("v-checkbox", {
                                    attrs: {
                                      label: _vm.trans(
                                        "messages.edit_employee_note"
                                      ),
                                      value: "employeeNote.edit",
                                    },
                                    model: {
                                      value: _vm.permissions,
                                      callback: function ($$v) {
                                        _vm.permissions = $$v
                                      },
                                      expression: "permissions",
                                    },
                                  })
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.$can("employeeNote.delete")
                                ? _c("v-checkbox", {
                                    attrs: {
                                      label: _vm.trans(
                                        "messages.delete_employee_note"
                                      ),
                                      value: "employeeNote.delete",
                                    },
                                    model: {
                                      value: _vm.permissions,
                                      callback: function ($$v) {
                                        _vm.permissions = $$v
                                      },
                                      expression: "permissions",
                                    },
                                  })
                                : _vm._e(),
                            ],
                            1
                          )
                        : _vm._e(),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _vm.$can("employee.edit") ||
                  _vm.$can("employee.view") ||
                  _vm.$can("employee.delete") ||
                  _vm.$can("employee.create")
                    ? _c("v-divider", { staticClass: "mt-1" })
                    : _vm._e(),
                  _vm._v(" "),
                  _c(
                    "v-layout",
                    { staticClass: "mt-3", attrs: { row: "", wrap: "" } },
                    [
                      _vm.$can("employee.edit") ||
                      _vm.$can("employee.view") ||
                      _vm.$can("employee.delete") ||
                      _vm.$can("employee.create")
                        ? _c(
                            "v-flex",
                            { attrs: { xs12: "", sm3: "", md3: "" } },
                            [
                              _c("h4", [
                                _vm._v(_vm._s(_vm.trans("messages.employee"))),
                              ]),
                            ]
                          )
                        : _vm._e(),
                      _vm._v(" "),
                      _c(
                        "v-flex",
                        { attrs: { xs12: "", sm4: "", md4: "" } },
                        [
                          _vm.$can("employee.create")
                            ? _c("v-checkbox", {
                                attrs: {
                                  label: _vm.trans("messages.add_employee"),
                                  value: "employee.create",
                                },
                                model: {
                                  value: _vm.permissions,
                                  callback: function ($$v) {
                                    _vm.permissions = $$v
                                  },
                                  expression: "permissions",
                                },
                              })
                            : _vm._e(),
                          _vm._v(" "),
                          _vm.$can("employee.view")
                            ? _c("v-checkbox", {
                                attrs: {
                                  label: _vm.trans("messages.view_employee"),
                                  value: "employee.view",
                                },
                                model: {
                                  value: _vm.permissions,
                                  callback: function ($$v) {
                                    _vm.permissions = $$v
                                  },
                                  expression: "permissions",
                                },
                              })
                            : _vm._e(),
                          _vm._v(" "),
                          _vm.$can("employee.edit")
                            ? _c("v-checkbox", {
                                attrs: {
                                  label: _vm.trans("messages.edit_employee"),
                                  value: "employee.edit",
                                },
                                model: {
                                  value: _vm.permissions,
                                  callback: function ($$v) {
                                    _vm.permissions = $$v
                                  },
                                  expression: "permissions",
                                },
                              })
                            : _vm._e(),
                          _vm._v(" "),
                          _vm.$can("employee.delete")
                            ? _c("v-checkbox", {
                                attrs: {
                                  label: _vm.trans("messages.delete_employee"),
                                  value: "employee.delete",
                                },
                                model: {
                                  value: _vm.permissions,
                                  callback: function ($$v) {
                                    _vm.permissions = $$v
                                  },
                                  expression: "permissions",
                                },
                              })
                            : _vm._e(),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _vm.$can("employeeNote.edit") ||
                      _vm.$can("employeeNote.view") ||
                      _vm.$can("employeeNote.delete") ||
                      _vm.$can("employeeNote.create")
                        ? _c(
                            "v-flex",
                            { attrs: { xs12: "", sm5: "", md5: "" } },
                            [
                              _vm.$can("employeeNote.create")
                                ? _c("v-checkbox", {
                                    attrs: {
                                      label: _vm.trans(
                                        "messages.add_employee_note"
                                      ),
                                      value: "employeeNote.create",
                                    },
                                    model: {
                                      value: _vm.permissions,
                                      callback: function ($$v) {
                                        _vm.permissions = $$v
                                      },
                                      expression: "permissions",
                                    },
                                  })
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.$can("employeeNote.view")
                                ? _c("v-checkbox", {
                                    attrs: {
                                      label: _vm.trans(
                                        "messages.view_employee_note"
                                      ),
                                      value: "employeeNote.view",
                                    },
                                    model: {
                                      value: _vm.permissions,
                                      callback: function ($$v) {
                                        _vm.permissions = $$v
                                      },
                                      expression: "permissions",
                                    },
                                  })
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.$can("employeeNote.edit")
                                ? _c("v-checkbox", {
                                    attrs: {
                                      label: _vm.trans(
                                        "messages.edit_employee_note"
                                      ),
                                      value: "employeeNote.edit",
                                    },
                                    model: {
                                      value: _vm.permissions,
                                      callback: function ($$v) {
                                        _vm.permissions = $$v
                                      },
                                      expression: "permissions",
                                    },
                                  })
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.$can("employeeNote.delete")
                                ? _c("v-checkbox", {
                                    attrs: {
                                      label: _vm.trans(
                                        "messages.delete_employee_note"
                                      ),
                                      value: "employeeNote.delete",
                                    },
                                    model: {
                                      value: _vm.permissions,
                                      callback: function ($$v) {
                                        _vm.permissions = $$v
                                      },
                                      expression: "permissions",
                                    },
                                  })
                                : _vm._e(),
                            ],
                            1
                          )
                        : _vm._e(),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _vm.$can("customer.edit") ||
                  _vm.$can("customer.view") ||
                  _vm.$can("customer.delete") ||
                  _vm.$can("customer.create")
                    ? _c("v-divider")
                    : _vm._e(),
                  _vm._v(" "),
                  _c(
                    "v-layout",
                    { staticClass: "mt-2", attrs: { row: "", wrap: "" } },
                    [
                      _vm.$can("customer.edit") ||
                      _vm.$can("customer.view") ||
                      _vm.$can("customer.delete") ||
                      _vm.$can("customer.create")
                        ? _c(
                            "v-flex",
                            { attrs: { xs12: "", sm3: "", md3: "" } },
                            [
                              _c("h4", [
                                _vm._v(_vm._s(_vm.trans("messages.customer"))),
                              ]),
                            ]
                          )
                        : _vm._e(),
                      _vm._v(" "),
                      _c(
                        "v-flex",
                        { attrs: { xs12: "", sm3: "", md3: "" } },
                        [
                          _vm.$can("customer.create")
                            ? _c("v-checkbox", {
                                attrs: {
                                  label: _vm.trans("messages.add_customer"),
                                  value: "customer.create",
                                },
                                model: {
                                  value: _vm.permissions,
                                  callback: function ($$v) {
                                    _vm.permissions = $$v
                                  },
                                  expression: "permissions",
                                },
                              })
                            : _vm._e(),
                          _vm._v(" "),
                          _vm.$can("customer.view")
                            ? _c("v-checkbox", {
                                attrs: {
                                  label: _vm.trans("messages.view_customer"),
                                  value: "customer.view",
                                },
                                model: {
                                  value: _vm.permissions,
                                  callback: function ($$v) {
                                    _vm.permissions = $$v
                                  },
                                  expression: "permissions",
                                },
                              })
                            : _vm._e(),
                          _vm._v(" "),
                          _vm.$can("customer.edit")
                            ? _c("v-checkbox", {
                                attrs: {
                                  label: _vm.trans("messages.edit_customer"),
                                  value: "customer.edit",
                                },
                                model: {
                                  value: _vm.permissions,
                                  callback: function ($$v) {
                                    _vm.permissions = $$v
                                  },
                                  expression: "permissions",
                                },
                              })
                            : _vm._e(),
                          _vm._v(" "),
                          _vm.$can("customer.delete")
                            ? _c("v-checkbox", {
                                attrs: {
                                  label: _vm.trans("messages.delete_customer"),
                                  value: "customer.delete",
                                },
                                model: {
                                  value: _vm.permissions,
                                  callback: function ($$v) {
                                    _vm.permissions = $$v
                                  },
                                  expression: "permissions",
                                },
                              })
                            : _vm._e(),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _vm.$can("contact.edit") ||
                      _vm.$can("contact.view") ||
                      _vm.$can("contact.delete") ||
                      _vm.$can("contact.create")
                        ? _c(
                            "v-flex",
                            { attrs: { xs12: "", sm3: "", md3: "" } },
                            [
                              _vm.$can("contact.create")
                                ? _c("v-checkbox", {
                                    attrs: {
                                      label: _vm.trans("messages.add_contact"),
                                      value: "contact.create",
                                    },
                                    model: {
                                      value: _vm.permissions,
                                      callback: function ($$v) {
                                        _vm.permissions = $$v
                                      },
                                      expression: "permissions",
                                    },
                                  })
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.$can("contact.view")
                                ? _c("v-checkbox", {
                                    attrs: {
                                      label: _vm.trans("messages.view_contact"),
                                      value: "contact.view",
                                    },
                                    model: {
                                      value: _vm.permissions,
                                      callback: function ($$v) {
                                        _vm.permissions = $$v
                                      },
                                      expression: "permissions",
                                    },
                                  })
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.$can("contact.edit")
                                ? _c("v-checkbox", {
                                    attrs: {
                                      label: _vm.trans("messages.edit_contact"),
                                      value: "contact.edit",
                                    },
                                    model: {
                                      value: _vm.permissions,
                                      callback: function ($$v) {
                                        _vm.permissions = $$v
                                      },
                                      expression: "permissions",
                                    },
                                  })
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.$can("contact.delete")
                                ? _c("v-checkbox", {
                                    attrs: {
                                      label: _vm.trans(
                                        "messages.delete_contact"
                                      ),
                                      value: "contact.delete",
                                    },
                                    model: {
                                      value: _vm.permissions,
                                      callback: function ($$v) {
                                        _vm.permissions = $$v
                                      },
                                      expression: "permissions",
                                    },
                                  })
                                : _vm._e(),
                            ],
                            1
                          )
                        : _vm._e(),
                      _vm._v(" "),
                      _vm.$can("customerNote.edit") ||
                      _vm.$can("customerNote.view") ||
                      _vm.$can("customerNote.delete") ||
                      _vm.$can("customerNote.create")
                        ? _c(
                            "v-flex",
                            { attrs: { xs12: "", sm3: "", md3: "" } },
                            [
                              _vm.$can("customerNote.create")
                                ? _c("v-checkbox", {
                                    attrs: {
                                      label: _vm.trans(
                                        "messages.add_customer_note"
                                      ),
                                      value: "customerNote.create",
                                    },
                                    model: {
                                      value: _vm.permissions,
                                      callback: function ($$v) {
                                        _vm.permissions = $$v
                                      },
                                      expression: "permissions",
                                    },
                                  })
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.$can("customerNote.view")
                                ? _c("v-checkbox", {
                                    attrs: {
                                      label: _vm.trans(
                                        "messages.view_customer_note"
                                      ),
                                      value: "customerNote.view",
                                    },
                                    model: {
                                      value: _vm.permissions,
                                      callback: function ($$v) {
                                        _vm.permissions = $$v
                                      },
                                      expression: "permissions",
                                    },
                                  })
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.$can("customerNote.edit")
                                ? _c("v-checkbox", {
                                    attrs: {
                                      label: _vm.trans(
                                        "messages.edit_customer_note"
                                      ),
                                      value: "customerNote.edit",
                                    },
                                    model: {
                                      value: _vm.permissions,
                                      callback: function ($$v) {
                                        _vm.permissions = $$v
                                      },
                                      expression: "permissions",
                                    },
                                  })
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.$can("customerNote.delete")
                                ? _c("v-checkbox", {
                                    attrs: {
                                      label: _vm.trans(
                                        "messages.delete_customer_note"
                                      ),
                                      value: "customerNote.delete",
                                    },
                                    model: {
                                      value: _vm.permissions,
                                      callback: function ($$v) {
                                        _vm.permissions = $$v
                                      },
                                      expression: "permissions",
                                    },
                                  })
                                : _vm._e(),
                            ],
                            1
                          )
                        : _vm._e(),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _vm.$can("knowledge_base.edit") ||
                  _vm.$can("knowledge_base.view") ||
                  _vm.$can("knowledge_base.delete") ||
                  _vm.$can("knowledge_base.create")
                    ? _c("v-divider")
                    : _vm._e(),
                  _vm._v(" "),
                  _c(
                    "v-layout",
                    { staticClass: "mt-2", attrs: { row: "", wrap: "" } },
                    [
                      _vm.$can("knowledge_base.edit") ||
                      _vm.$can("knowledge_base.view") ||
                      _vm.$can("knowledge_base.delete") ||
                      _vm.$can("knowledge_base.create")
                        ? _c(
                            "v-flex",
                            { attrs: { xs12: "", sm3: "", md3: "" } },
                            [
                              _c("h4", [
                                _vm._v(
                                  _vm._s(_vm.trans("messages.knowladge_base"))
                                ),
                              ]),
                            ]
                          )
                        : _vm._e(),
                      _vm._v(" "),
                      _c(
                        "v-flex",
                        { attrs: { xs12: "", sm3: "", md3: "" } },
                        [
                          _vm.$can("knowledge_base.create")
                            ? _c("v-checkbox", {
                                attrs: {
                                  label: _vm.trans(
                                    "messages.add_knowledge_base"
                                  ),
                                  value: "knowledge_base.create",
                                },
                                model: {
                                  value: _vm.permissions,
                                  callback: function ($$v) {
                                    _vm.permissions = $$v
                                  },
                                  expression: "permissions",
                                },
                              })
                            : _vm._e(),
                          _vm._v(" "),
                          _vm.$can("knowledge_base.view")
                            ? _c("v-checkbox", {
                                attrs: {
                                  label: _vm.trans(
                                    "messages.view_knowledge_base"
                                  ),
                                  value: "knowledge_base.view",
                                },
                                model: {
                                  value: _vm.permissions,
                                  callback: function ($$v) {
                                    _vm.permissions = $$v
                                  },
                                  expression: "permissions",
                                },
                              })
                            : _vm._e(),
                          _vm._v(" "),
                          _vm.$can("knowledge_base.edit")
                            ? _c("v-checkbox", {
                                attrs: {
                                  label: _vm.trans(
                                    "messages.edit_knowledge_base"
                                  ),
                                  value: "knowledge_base.edit",
                                },
                                model: {
                                  value: _vm.permissions,
                                  callback: function ($$v) {
                                    _vm.permissions = $$v
                                  },
                                  expression: "permissions",
                                },
                              })
                            : _vm._e(),
                          _vm._v(" "),
                          _vm.$can("knowledge_base.delete")
                            ? _c("v-checkbox", {
                                attrs: {
                                  label: _vm.trans(
                                    "messages.delete_knowledge_base"
                                  ),
                                  value: "knowledge_base.delete",
                                },
                                model: {
                                  value: _vm.permissions,
                                  callback: function ($$v) {
                                    _vm.permissions = $$v
                                  },
                                  expression: "permissions",
                                },
                              })
                            : _vm._e(),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _vm.$can("expense.edit") ||
                  _vm.$can("expense.delete") ||
                  _vm.$can("expense.create")
                    ? _c("v-divider")
                    : _vm._e(),
                  _vm._v(" "),
                  _c(
                    "v-layout",
                    { staticClass: "mt-2", attrs: { row: "", wrap: "" } },
                    [
                      _vm.$can("expense.edit") ||
                      _vm.$can("expense.delete") ||
                      _vm.$can("expense.create")
                        ? _c(
                            "v-flex",
                            { attrs: { xs12: "", sm3: "", md3: "" } },
                            [
                              _c("h4", [
                                _vm._v(_vm._s(_vm.trans("messages.expense"))),
                              ]),
                            ]
                          )
                        : _vm._e(),
                      _vm._v(" "),
                      _c(
                        "v-flex",
                        { attrs: { xs12: "", sm3: "", md3: "" } },
                        [
                          _vm.$can("expense.create")
                            ? _c("v-checkbox", {
                                attrs: {
                                  label: _vm.trans("messages.add_expense"),
                                  value: "expense.create",
                                },
                                model: {
                                  value: _vm.permissions,
                                  callback: function ($$v) {
                                    _vm.permissions = $$v
                                  },
                                  expression: "permissions",
                                },
                              })
                            : _vm._e(),
                          _vm._v(" "),
                          _vm.$can("expense.edit")
                            ? _c("v-checkbox", {
                                attrs: {
                                  label: _vm.trans("messages.edit_expense"),
                                  value: "expense.edit",
                                },
                                model: {
                                  value: _vm.permissions,
                                  callback: function ($$v) {
                                    _vm.permissions = $$v
                                  },
                                  expression: "permissions",
                                },
                              })
                            : _vm._e(),
                          _vm._v(" "),
                          _vm.$can("expense.delete")
                            ? _c("v-checkbox", {
                                attrs: {
                                  label: _vm.trans("messages.delete_expense"),
                                  value: "expense.delete",
                                },
                                model: {
                                  value: _vm.permissions,
                                  callback: function ($$v) {
                                    _vm.permissions = $$v
                                  },
                                  expression: "permissions",
                                },
                              })
                            : _vm._e(),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _vm.$can("leaves.edit") ||
                  _vm.$can("leaves.delete") ||
                  _vm.$can("leaves.create")
                    ? _c("v-divider")
                    : _vm._e(),
                  _vm._v(" "),
                  _c(
                    "v-layout",
                    { staticClass: "mt-2", attrs: { row: "", wrap: "" } },
                    [
                      _vm.$can("leaves.edit") ||
                      _vm.$can("leaves.delete") ||
                      _vm.$can("leaves.create")
                        ? _c(
                            "v-flex",
                            { attrs: { xs12: "", sm3: "", md3: "" } },
                            [
                              _c("h4", [
                                _vm._v(_vm._s(_vm.trans("messages.leaves"))),
                              ]),
                            ]
                          )
                        : _vm._e(),
                      _vm._v(" "),
                      _c(
                        "v-flex",
                        { attrs: { xs12: "", sm3: "", md3: "" } },
                        [
                          _vm.$can("leaves.create")
                            ? _c("v-checkbox", {
                                attrs: {
                                  label: _vm.trans("messages.add_leaves"),
                                  value: "leaves.create",
                                },
                                model: {
                                  value: _vm.permissions,
                                  callback: function ($$v) {
                                    _vm.permissions = $$v
                                  },
                                  expression: "permissions",
                                },
                              })
                            : _vm._e(),
                          _vm._v(" "),
                          _vm.$can("leaves.edit")
                            ? _c("v-checkbox", {
                                attrs: {
                                  label: _vm.trans("messages.edit_leaves"),
                                  value: "leaves.edit",
                                },
                                model: {
                                  value: _vm.permissions,
                                  callback: function ($$v) {
                                    _vm.permissions = $$v
                                  },
                                  expression: "permissions",
                                },
                              })
                            : _vm._e(),
                          _vm._v(" "),
                          _vm.$can("leaves.delete")
                            ? _c("v-checkbox", {
                                attrs: {
                                  label: _vm.trans("messages.delete_leaves"),
                                  value: "leaves.delete",
                                },
                                model: {
                                  value: _vm.permissions,
                                  callback: function ($$v) {
                                    _vm.permissions = $$v
                                  },
                                  expression: "permissions",
                                },
                              })
                            : _vm._e(),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _vm.$can("tickets.edit") ||
                  _vm.$can("tickets.delete") ||
                  _vm.$can("tickets.create") ||
                  _vm.$can("tickets.view")
                    ? _c("v-divider")
                    : _vm._e(),
                  _vm._v(" "),
                  _c(
                    "v-layout",
                    { staticClass: "mt-2", attrs: { row: "", wrap: "" } },
                    [
                      _c("v-flex", { attrs: { xs12: "", sm3: "", md3: "" } }, [
                        _c("h4", [
                          _vm._v(_vm._s(_vm.trans("messages.tickets"))),
                        ]),
                      ]),
                      _vm._v(" "),
                      _vm.$can("tickets.edit") ||
                      _vm.$can("tickets.delete") ||
                      _vm.$can("tickets.create") ||
                      _vm.$can("tickets.view")
                        ? _c(
                            "v-flex",
                            { attrs: { xs12: "", sm3: "", md3: "" } },
                            [
                              _vm.$can("tickets.create")
                                ? _c("v-checkbox", {
                                    attrs: {
                                      label: _vm.trans("messages.add_ticket"),
                                      value: "tickets.create",
                                    },
                                    model: {
                                      value: _vm.permissions,
                                      callback: function ($$v) {
                                        _vm.permissions = $$v
                                      },
                                      expression: "permissions",
                                    },
                                  })
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.$can("tickets.view")
                                ? _c("v-checkbox", {
                                    attrs: {
                                      label: _vm.trans("messages.view_ticket"),
                                      value: "tickets.view",
                                    },
                                    model: {
                                      value: _vm.permissions,
                                      callback: function ($$v) {
                                        _vm.permissions = $$v
                                      },
                                      expression: "permissions",
                                    },
                                  })
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.$can("tickets.edit")
                                ? _c("v-checkbox", {
                                    attrs: {
                                      label: _vm.trans("messages.edit_ticket"),
                                      value: "tickets.edit",
                                    },
                                    model: {
                                      value: _vm.permissions,
                                      callback: function ($$v) {
                                        _vm.permissions = $$v
                                      },
                                      expression: "permissions",
                                    },
                                  })
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.$can("tickets.delete")
                                ? _c("v-checkbox", {
                                    attrs: {
                                      label: _vm.trans(
                                        "messages.delete_ticket"
                                      ),
                                      value: "tickets.delete",
                                    },
                                    model: {
                                      value: _vm.permissions,
                                      callback: function ($$v) {
                                        _vm.permissions = $$v
                                      },
                                      expression: "permissions",
                                    },
                                  })
                                : _vm._e(),
                            ],
                            1
                          )
                        : _vm._e(),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _vm.$can("project.edit") ||
                  _vm.$can("project.delete") ||
                  _vm.$can("project.create") ||
                  _vm.$can("project.list")
                    ? _c("v-divider")
                    : _vm._e(),
                  _vm._v(" "),
                  _c(
                    "v-layout",
                    { staticClass: "mt-2", attrs: { row: "", wrap: "" } },
                    [
                      _vm.$can("project.edit") ||
                      _vm.$can("project.delete") ||
                      _vm.$can("project.create") ||
                      _vm.$can("project.list")
                        ? _c(
                            "v-flex",
                            { attrs: { xs12: "", sm3: "", md3: "" } },
                            [
                              _c("h4", [
                                _vm._v(_vm._s(_vm.trans("messages.project"))),
                              ]),
                            ]
                          )
                        : _vm._e(),
                      _vm._v(" "),
                      _c(
                        "v-flex",
                        { attrs: { xs12: "", sm3: "", md3: "" } },
                        [
                          _vm.$can("project.create")
                            ? _c("v-checkbox", {
                                attrs: {
                                  label: _vm.trans("messages.add_project"),
                                  value: "project.create",
                                },
                                model: {
                                  value: _vm.permissions,
                                  callback: function ($$v) {
                                    _vm.permissions = $$v
                                  },
                                  expression: "permissions",
                                },
                              })
                            : _vm._e(),
                          _vm._v(" "),
                          _vm.$can("project.list")
                            ? _c("v-checkbox", {
                                attrs: {
                                  label: _vm.trans("messages.view_project"),
                                  value: "project.list",
                                },
                                model: {
                                  value: _vm.permissions,
                                  callback: function ($$v) {
                                    _vm.permissions = $$v
                                  },
                                  expression: "permissions",
                                },
                              })
                            : _vm._e(),
                          _vm._v(" "),
                          _vm.$can("project.edit")
                            ? _c("v-checkbox", {
                                attrs: {
                                  label: _vm.trans("messages.edit_project"),
                                  value: "project.edit",
                                },
                                model: {
                                  value: _vm.permissions,
                                  callback: function ($$v) {
                                    _vm.permissions = $$v
                                  },
                                  expression: "permissions",
                                },
                              })
                            : _vm._e(),
                          _vm._v(" "),
                          _vm.$can("project.delete")
                            ? _c("v-checkbox", {
                                attrs: {
                                  label: _vm.trans("data.delete_project"),
                                  value: "project.delete",
                                },
                                model: {
                                  value: _vm.permissions,
                                  callback: function ($$v) {
                                    _vm.permissions = $$v
                                  },
                                  expression: "permissions",
                                },
                              })
                            : _vm._e(),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _vm.$can("report.edit") ||
                  _vm.$can("report.delete") ||
                  _vm.$can("report.create") ||
                  _vm.$can("report.view")
                    ? _c("v-divider")
                    : _vm._e(),
                  _vm._v(" "),
                  _c(
                    "v-layout",
                    { staticClass: "mt-2", attrs: { row: "", wrap: "" } },
                    [
                      _vm.$can("report.edit") ||
                      _vm.$can("report.delete") ||
                      _vm.$can("report.create") ||
                      _vm.$can("report.view")
                        ? _c(
                            "v-flex",
                            { attrs: { xs12: "", sm3: "", md3: "" } },
                            [
                              _c("h4", [
                                _vm._v(_vm._s(_vm.trans("data.report"))),
                              ]),
                            ]
                          )
                        : _vm._e(),
                      _vm._v(" "),
                      _vm.$can("report.edit") ||
                      _vm.$can("report.delete") ||
                      _vm.$can("report.create") ||
                      _vm.$can("report.view")
                        ? _c(
                            "v-flex",
                            { attrs: { xs12: "", sm3: "", md3: "" } },
                            [
                              _vm.$can("report.create")
                                ? _c("v-checkbox", {
                                    attrs: {
                                      label: _vm.trans("data.add_report"),
                                      value: "report.create",
                                    },
                                    model: {
                                      value: _vm.permissions,
                                      callback: function ($$v) {
                                        _vm.permissions = $$v
                                      },
                                      expression: "permissions",
                                    },
                                  })
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.$can("report.view")
                                ? _c("v-checkbox", {
                                    attrs: {
                                      label: _vm.trans("data.view_report"),
                                      value: "report.view",
                                    },
                                    model: {
                                      value: _vm.permissions,
                                      callback: function ($$v) {
                                        _vm.permissions = $$v
                                      },
                                      expression: "permissions",
                                    },
                                  })
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.$can("report.edit")
                                ? _c("v-checkbox", {
                                    attrs: {
                                      label: _vm.trans("data.edit_report"),
                                      value: "report.edit",
                                    },
                                    model: {
                                      value: _vm.permissions,
                                      callback: function ($$v) {
                                        _vm.permissions = $$v
                                      },
                                      expression: "permissions",
                                    },
                                  })
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.$can("report.delete")
                                ? _c("v-checkbox", {
                                    attrs: {
                                      label: _vm.trans("data.delete_report"),
                                      value: "report.delete",
                                    },
                                    model: {
                                      value: _vm.permissions,
                                      callback: function ($$v) {
                                        _vm.permissions = $$v
                                      },
                                      expression: "permissions",
                                    },
                                  })
                                : _vm._e(),
                            ],
                            1
                          )
                        : _vm._e(),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("v-divider"),
                  _vm._v(" "),
                  _c("v-divider"),
                  _vm._v(" "),
                  _vm.$can("task.edit") ||
                  _vm.$can("task.delete") ||
                  _vm.$can("task.create") ||
                  _vm.$can("task.view")
                    ? _c("v-divider")
                    : _vm._e(),
                  _vm._v(" "),
                  _c(
                    "v-layout",
                    { staticClass: "mt-2", attrs: { row: "", wrap: "" } },
                    [
                      _vm.$can("task.edit") ||
                      _vm.$can("task.delete") ||
                      _vm.$can("task.create") ||
                      _vm.$can("task.view")
                        ? _c(
                            "v-flex",
                            { attrs: { xs12: "", sm3: "", md3: "" } },
                            [_c("h4", [_vm._v(_vm._s(_vm.trans("data.task")))])]
                          )
                        : _vm._e(),
                      _vm._v(" "),
                      _vm.$can("task.edit") ||
                      _vm.$can("task.delete") ||
                      _vm.$can("task.create") ||
                      _vm.$can("task.view")
                        ? _c(
                            "v-flex",
                            { attrs: { xs12: "", sm3: "", md3: "" } },
                            [
                              _vm.$can("task.create")
                                ? _c("v-checkbox", {
                                    attrs: {
                                      label: _vm.trans("data.add_task"),
                                      value: "task.create",
                                    },
                                    model: {
                                      value: _vm.permissions,
                                      callback: function ($$v) {
                                        _vm.permissions = $$v
                                      },
                                      expression: "permissions",
                                    },
                                  })
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.$can("task.view")
                                ? _c("v-checkbox", {
                                    attrs: {
                                      label: _vm.trans("data.view_task"),
                                      value: "task.view",
                                    },
                                    model: {
                                      value: _vm.permissions,
                                      callback: function ($$v) {
                                        _vm.permissions = $$v
                                      },
                                      expression: "permissions",
                                    },
                                  })
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.$can("task.edit")
                                ? _c("v-checkbox", {
                                    attrs: {
                                      label: _vm.trans("data.edit_task"),
                                      value: "task.edit",
                                    },
                                    model: {
                                      value: _vm.permissions,
                                      callback: function ($$v) {
                                        _vm.permissions = $$v
                                      },
                                      expression: "permissions",
                                    },
                                  })
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.$can("task.delete")
                                ? _c("v-checkbox", {
                                    attrs: {
                                      label: _vm.trans("data.delete_task"),
                                      value: "task.delete",
                                    },
                                    model: {
                                      value: _vm.permissions,
                                      callback: function ($$v) {
                                        _vm.permissions = $$v
                                      },
                                      expression: "permissions",
                                    },
                                  })
                                : _vm._e(),
                            ],
                            1
                          )
                        : _vm._e(),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "v-layout",
                    { staticClass: "mt-2", attrs: { row: "", wrap: "" } },
                    [
                      _vm.$can("serviceType.edit") ||
                      _vm.$can("serviceType.delete") ||
                      _vm.$can("serviceType.create") ||
                      _vm.$can("serviceType.view")
                        ? _c(
                            "v-flex",
                            { attrs: { xs12: "", sm3: "", md3: "" } },
                            [
                              _c("h4", [
                                _vm._v(
                                  _vm._s(_vm.trans("data.service_types_list"))
                                ),
                              ]),
                            ]
                          )
                        : _vm._e(),
                      _vm._v(" "),
                      _vm.$can("serviceType.edit") ||
                      _vm.$can("serviceType.delete") ||
                      _vm.$can("serviceType.create") ||
                      _vm.$can("serviceType.view")
                        ? _c(
                            "v-flex",
                            { attrs: { xs12: "", sm3: "", md3: "" } },
                            [
                              _c("v-checkbox", {
                                attrs: {
                                  label: _vm.trans("data.create_service_type"),
                                  value: "serviceType.add",
                                },
                                model: {
                                  value: _vm.permissions,
                                  callback: function ($$v) {
                                    _vm.permissions = $$v
                                  },
                                  expression: "permissions",
                                },
                              }),
                              _vm._v(" "),
                              _c("v-checkbox", {
                                attrs: {
                                  label: _vm.trans("data.all_service_types"),
                                  value: "serviceType.view",
                                },
                                model: {
                                  value: _vm.permissions,
                                  callback: function ($$v) {
                                    _vm.permissions = $$v
                                  },
                                  expression: "permissions",
                                },
                              }),
                              _vm._v(" "),
                              _c("v-checkbox", {
                                attrs: {
                                  label: _vm.trans("data.edit_service_type"),
                                  value: "serviceType.edit",
                                },
                                model: {
                                  value: _vm.permissions,
                                  callback: function ($$v) {
                                    _vm.permissions = $$v
                                  },
                                  expression: "permissions",
                                },
                              }),
                              _vm._v(" "),
                              _c("v-checkbox", {
                                attrs: {
                                  label: _vm.trans("data.delete"),
                                  value: "serviceType.delete",
                                },
                                model: {
                                  value: _vm.permissions,
                                  callback: function ($$v) {
                                    _vm.permissions = $$v
                                  },
                                  expression: "permissions",
                                },
                              }),
                            ],
                            1
                          )
                        : _vm._e(),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("v-divider"),
                  _vm._v(" "),
                  _c(
                    "v-layout",
                    { staticClass: "mt-2", attrs: { row: "", wrap: "" } },
                    [
                      _vm.$can("setting") ||
                      _vm.$can("profile.edit") ||
                      _vm.$can("sales.invoices")
                        ? _c(
                            "v-flex",
                            { attrs: { xs12: "", sm3: "", md3: "" } },
                            [
                              _c("h4", [
                                _vm._v(_vm._s(_vm.trans("messages.other"))),
                              ]),
                            ]
                          )
                        : _vm._e(),
                      _vm._v(" "),
                      _c(
                        "v-flex",
                        { attrs: { xs12: "", sm3: "", md3: "" } },
                        [
                          _vm.$can("setting")
                            ? _c("v-checkbox", {
                                attrs: {
                                  label: _vm.trans("messages.system_setting"),
                                  value: "setting",
                                },
                                model: {
                                  value: _vm.permissions,
                                  callback: function ($$v) {
                                    _vm.permissions = $$v
                                  },
                                  expression: "permissions",
                                },
                              })
                            : _vm._e(),
                          _vm._v(" "),
                          _vm.$can("profile.edit")
                            ? _c("v-checkbox", {
                                attrs: {
                                  label: _vm.trans("messages.edit_profile"),
                                  value: "profile.edit",
                                },
                                model: {
                                  value: _vm.permissions,
                                  callback: function ($$v) {
                                    _vm.permissions = $$v
                                  },
                                  expression: "permissions",
                                },
                              })
                            : _vm._e(),
                          _vm._v(" "),
                          _vm.$can("sales.invoices")
                            ? _c("v-checkbox", {
                                attrs: {
                                  label: _vm.trans("messages.view_sales"),
                                  value: "sales.invoices",
                                },
                                model: {
                                  value: _vm.permissions,
                                  callback: function ($$v) {
                                    _vm.permissions = $$v
                                  },
                                  expression: "permissions",
                                },
                              })
                            : _vm._e(),
                          _vm._v(" "),
                          _c("v-checkbox", {
                            attrs: {
                              label: _vm.trans("data.archive"),
                              value: "archive",
                            },
                            model: {
                              value: _vm.permissions,
                              callback: function ($$v) {
                                _vm.permissions = $$v
                              },
                              expression: "permissions",
                            },
                          }),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "v-layout",
            { attrs: { "justify-center": "" } },
            [
              _c(
                "v-card-actions",
                [
                  _c("v-spacer"),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      attrs: {
                        color: "success",
                        loading: _vm.loading,
                        disabled: _vm.loading,
                      },
                      on: { click: _vm.store },
                    },
                    [
                      _vm._v(
                        "\n                        " +
                          _vm._s(_vm.trans("messages.update")) +
                          "\n                    "
                      ),
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      staticStyle: { color: "#06706d" },
                      on: {
                        click: function ($event) {
                          return _vm.$router.go(-1)
                        },
                      },
                    },
                    [
                      _vm._v(
                        "\n                        " +
                          _vm._s(_vm.trans("messages.back")) +
                          "\n                    "
                      ),
                    ]
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);