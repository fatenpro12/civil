"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_common_projects_milestones_Lists_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/milestones/Add.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/milestones/Add.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  data: function data() {
    return {
      dialog: false,
      projectId: '',
      due_date: '',
      milestone: [],
      loading: false
    };
  },
  created: function created() {
    var self = this;
    self.$eventBus.$on('createMilestoneAdd', function (data) {
      self.projectId = data;
      self.due_date = '';
      self.milestone = [];
      self.$validator.reset();
      self.dialog = true;
    });
  },
  beforeDestroy: function beforeDestroy() {
    var self = this;
    self.$eventBus.$off('createMilestoneAdd');
  },
  methods: {
    store: function (_store) {
      function store() {
        return _store.apply(this, arguments);
      }
      store.toString = function () {
        return _store.toString();
      };
      return store;
    }(function () {
      var self = this;
      var data = {
        project_id: self.projectId,
        name: self.milestone.name,
        description: self.milestone.description,
        due_date: self.due_date
      };
      self.$validator.validateAll().then(function (result) {
        if (result == true) {
          self.loading = true;
          axios.post('/project-milestones', data).then(function (response) {
            self.loading = false;
            self.$store.commit('showSnackbar', {
              message: response.data.msg,
              color: response.data.success
            });
            if (response.data.success === true) {
              self.dialog = false;
              self.$eventBus.$emit('updateMilestoneList', '');
            }
          })["catch"](function (err) {
            console.log(err.response.status);
            if (err.response.status === 401) {
              store.dispatch('auth/handleResponse', err.response);
            }
          });
        }
      });
    })
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/milestones/Edit.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/milestones/Edit.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  data: function data() {
    return {
      dialog: false,
      due_date: null,
      milestone: [],
      milestoneId: null,
      project_id: null,
      loading: false
    };
  },
  methods: {
    edit: function edit(data) {
      var self = this;
      self.milestoneId = data.id;
      self.project_id = data.project_id;
      self.due_date = null;
      self.milestone = [];
      self.$validator.reset();
      axios.get('/project-milestones/' + data.id + '/edit', {
        params: {
          project_id: data.project_id
        }
      }).then(function (response) {
        self.milestone = response.data;
        self.due_date = response.data.due_date;
        self.dialog = true;
      })["catch"](function (error) {
        console.log(error);
      });
    },
    update: function update() {
      var self = this;
      var data = {
        name: self.milestone.name,
        description: self.milestone.description,
        due_date: self.due_date,
        project_id: self.project_id
      };
      self.$validator.validateAll().then(function (result) {
        if (result == true) {
          self.loading = true;
          axios.put('/project-milestones/' + self.milestoneId, data).then(function (response) {
            self.loading = false;
            self.$store.commit('showSnackbar', {
              message: response.data.msg,
              color: response.data.success
            });
            if (response.data.success === true) {
              self.dialog = false;
              self.$eventBus.$emit('updateMilestoneList', '');
            }
          })["catch"](function (err) {
            console.log(err.response.status);
            if (err.response.status === 401) {
              store.dispatch('auth/handleResponse', err.response);
            }
          });
        }
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/milestones/Lists.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/milestones/Lists.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _projects_milestones_Add__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../projects/milestones/Add */ "./resources/js/common/projects/milestones/Add.vue");
/* harmony import */ var _projects_milestones_Show__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../projects/milestones/Show */ "./resources/js/common/projects/milestones/Show.vue");
/* harmony import */ var _projects_milestones_Edit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../projects/milestones/Edit */ "./resources/js/common/projects/milestones/Edit.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  components: {
    MilestoneFormAdd: _projects_milestones_Add__WEBPACK_IMPORTED_MODULE_0__["default"],
    MilestoneShow: _projects_milestones_Show__WEBPACK_IMPORTED_MODULE_1__["default"],
    MilestoneFormEdit: _projects_milestones_Edit__WEBPACK_IMPORTED_MODULE_2__["default"]
  },
  data: function data() {
    return {
      projectId: null,
      milestones: []
    };
  },
  created: function created() {
    var self = this;
    self.projectId = self.projectId = self.$route.params.project_id;
    ;
    self.getMilestoneList();
    self.$eventBus.$on('updateMilestoneList', function (data) {
      self.getMilestoneList();
    });
  },
  beforeDestroy: function beforeDestroy() {
    var self = this;
    self.$eventBus.$off('updateMilestoneList');
  },
  methods: {
    create: function create() {
      var self = this;
      self.$eventBus.$emit('createMilestoneAdd', self.projectId);
    },
    getMilestoneList: function getMilestoneList() {
      var self = this;
      if (self.$can('project.' + self.projectId + '.milestone.view')) {
        axios.get('/project-milestones', {
          params: {
            project_id: self.projectId
          }
        }).then(function (response) {
          self.milestones = response.data;
        })["catch"](function (error) {
          console.log(error);
        });
      }
    },
    view: function view(id) {
      var self = this;
      var data = {
        id: id,
        project_id: self.projectId
      };
      self.$refs.milestoneShow.view(data);
    },
    edit: function edit(id) {
      var self = this;
      var data = {
        id: id,
        project_id: self.projectId
      };
      self.$refs.milestoneEdit.edit(data);
    },
    dueDateColor: function dueDateColor(milestone) {
      var date_passed = moment().isAfter(milestone.due_date);
      if (date_passed) {
        return 'red';
      } else {
        return 'primary';
      }
    },
    deleteMilestone: function deleteMilestone(id) {
      var self = this;
      self.$store.commit('showDialog', {
        type: 'confirm',
        icon: 'warning',
        title: self.trans('messages.are_you_sure'),
        message: self.trans('messages.you_cant_restore_it'),
        okCb: function okCb() {
          axios["delete"]('/project-milestones/' + id, {
            params: {
              project_id: self.projectId
            }
          }).then(function (response) {
            self.$store.commit('showSnackbar', {
              message: response.data.msg,
              color: response.data.success
            });
            if (response.data.success === true) {
              self.getMilestoneList();
            }
          })["catch"](function (err) {
            console.log(err.response.status);
            if (err.response.status === 401) {
              store.dispatch('auth/handleResponse', err.response);
            }
          });
        },
        cancelCb: function cancelCb() {
          console.log('CANCEL');
        }
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/milestones/Show.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/milestones/Show.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  data: function data() {
    return {
      dialog: false,
      styleObject: {
        'white-space': 'pre-line'
      },
      milestone: []
    };
  },
  methods: {
    view: function view(data) {
      var self = this;
      axios.get('/project-milestones/' + data.id, {
        params: {
          project_id: data.project_id
        }
      }).then(function (response) {
        self.milestone = response.data;
        self.dialog = true;
      })["catch"](function (error) {
        console.log(error);
      });
    }
  }
});

/***/ }),

/***/ "./resources/js/common/projects/milestones/Add.vue":
/*!*********************************************************!*\
  !*** ./resources/js/common/projects/milestones/Add.vue ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Add_vue_vue_type_template_id_40e86a84___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Add.vue?vue&type=template&id=40e86a84& */ "./resources/js/common/projects/milestones/Add.vue?vue&type=template&id=40e86a84&");
/* harmony import */ var _Add_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Add.vue?vue&type=script&lang=js& */ "./resources/js/common/projects/milestones/Add.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Add_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Add_vue_vue_type_template_id_40e86a84___WEBPACK_IMPORTED_MODULE_0__.render,
  _Add_vue_vue_type_template_id_40e86a84___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/common/projects/milestones/Add.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/common/projects/milestones/Edit.vue":
/*!**********************************************************!*\
  !*** ./resources/js/common/projects/milestones/Edit.vue ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Edit_vue_vue_type_template_id_f028e592___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Edit.vue?vue&type=template&id=f028e592& */ "./resources/js/common/projects/milestones/Edit.vue?vue&type=template&id=f028e592&");
/* harmony import */ var _Edit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Edit.vue?vue&type=script&lang=js& */ "./resources/js/common/projects/milestones/Edit.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Edit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Edit_vue_vue_type_template_id_f028e592___WEBPACK_IMPORTED_MODULE_0__.render,
  _Edit_vue_vue_type_template_id_f028e592___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/common/projects/milestones/Edit.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/common/projects/milestones/Lists.vue":
/*!***********************************************************!*\
  !*** ./resources/js/common/projects/milestones/Lists.vue ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Lists_vue_vue_type_template_id_c1161690___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Lists.vue?vue&type=template&id=c1161690& */ "./resources/js/common/projects/milestones/Lists.vue?vue&type=template&id=c1161690&");
/* harmony import */ var _Lists_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Lists.vue?vue&type=script&lang=js& */ "./resources/js/common/projects/milestones/Lists.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Lists_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Lists_vue_vue_type_template_id_c1161690___WEBPACK_IMPORTED_MODULE_0__.render,
  _Lists_vue_vue_type_template_id_c1161690___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/common/projects/milestones/Lists.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/common/projects/milestones/Show.vue":
/*!**********************************************************!*\
  !*** ./resources/js/common/projects/milestones/Show.vue ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Show_vue_vue_type_template_id_143c48aa___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Show.vue?vue&type=template&id=143c48aa& */ "./resources/js/common/projects/milestones/Show.vue?vue&type=template&id=143c48aa&");
/* harmony import */ var _Show_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Show.vue?vue&type=script&lang=js& */ "./resources/js/common/projects/milestones/Show.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Show_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Show_vue_vue_type_template_id_143c48aa___WEBPACK_IMPORTED_MODULE_0__.render,
  _Show_vue_vue_type_template_id_143c48aa___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/common/projects/milestones/Show.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/common/projects/milestones/Add.vue?vue&type=script&lang=js&":
/*!**********************************************************************************!*\
  !*** ./resources/js/common/projects/milestones/Add.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Add_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Add.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/milestones/Add.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Add_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/common/projects/milestones/Edit.vue?vue&type=script&lang=js&":
/*!***********************************************************************************!*\
  !*** ./resources/js/common/projects/milestones/Edit.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Edit.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/milestones/Edit.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/common/projects/milestones/Lists.vue?vue&type=script&lang=js&":
/*!************************************************************************************!*\
  !*** ./resources/js/common/projects/milestones/Lists.vue?vue&type=script&lang=js& ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Lists_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Lists.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/milestones/Lists.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Lists_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/common/projects/milestones/Show.vue?vue&type=script&lang=js&":
/*!***********************************************************************************!*\
  !*** ./resources/js/common/projects/milestones/Show.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Show_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Show.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/milestones/Show.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Show_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/common/projects/milestones/Add.vue?vue&type=template&id=40e86a84&":
/*!****************************************************************************************!*\
  !*** ./resources/js/common/projects/milestones/Add.vue?vue&type=template&id=40e86a84& ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Add_vue_vue_type_template_id_40e86a84___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Add_vue_vue_type_template_id_40e86a84___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Add_vue_vue_type_template_id_40e86a84___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Add.vue?vue&type=template&id=40e86a84& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/milestones/Add.vue?vue&type=template&id=40e86a84&");


/***/ }),

/***/ "./resources/js/common/projects/milestones/Edit.vue?vue&type=template&id=f028e592&":
/*!*****************************************************************************************!*\
  !*** ./resources/js/common/projects/milestones/Edit.vue?vue&type=template&id=f028e592& ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_template_id_f028e592___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_template_id_f028e592___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_template_id_f028e592___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Edit.vue?vue&type=template&id=f028e592& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/milestones/Edit.vue?vue&type=template&id=f028e592&");


/***/ }),

/***/ "./resources/js/common/projects/milestones/Lists.vue?vue&type=template&id=c1161690&":
/*!******************************************************************************************!*\
  !*** ./resources/js/common/projects/milestones/Lists.vue?vue&type=template&id=c1161690& ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Lists_vue_vue_type_template_id_c1161690___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Lists_vue_vue_type_template_id_c1161690___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Lists_vue_vue_type_template_id_c1161690___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Lists.vue?vue&type=template&id=c1161690& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/milestones/Lists.vue?vue&type=template&id=c1161690&");


/***/ }),

/***/ "./resources/js/common/projects/milestones/Show.vue?vue&type=template&id=143c48aa&":
/*!*****************************************************************************************!*\
  !*** ./resources/js/common/projects/milestones/Show.vue?vue&type=template&id=143c48aa& ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Show_vue_vue_type_template_id_143c48aa___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Show_vue_vue_type_template_id_143c48aa___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Show_vue_vue_type_template_id_143c48aa___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Show.vue?vue&type=template&id=143c48aa& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/milestones/Show.vue?vue&type=template&id=143c48aa&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/milestones/Add.vue?vue&type=template&id=40e86a84&":
/*!*******************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/milestones/Add.vue?vue&type=template&id=40e86a84& ***!
  \*******************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "v-layout",
    { attrs: { row: "", "justify-center": "" } },
    [
      _c(
        "v-dialog",
        {
          model: {
            value: _vm.dialog,
            callback: function ($$v) {
              _vm.dialog = $$v
            },
            expression: "dialog",
          },
        },
        [
          _c(
            "v-card",
            [
              _c(
                "v-card-title",
                [
                  _c("v-icon", { attrs: { medium: "" } }, [
                    _vm._v("outlined_flag"),
                  ]),
                  _vm._v(" "),
                  _c("span", { staticClass: "headline" }, [
                    _vm._v(
                      "\n                    " +
                        _vm._s(_vm.trans("messages.add")) +
                        "\n                "
                    ),
                  ]),
                  _vm._v(" "),
                  _c("v-spacer"),
                  _vm._v(" "),
                  _c(
                    "v-icon",
                    {
                      on: {
                        click: function ($event) {
                          _vm.dialog = false
                        },
                      },
                    },
                    [_vm._v("clear")]
                  ),
                  _c("br"),
                ],
                1
              ),
              _vm._v(" "),
              _c("v-divider"),
              _vm._v(" "),
              _c(
                "v-card-text",
                [
                  _c(
                    "v-container",
                    { attrs: { "grid-list-md": "" } },
                    [
                      _c(
                        "v-layout",
                        { attrs: { wrap: "" } },
                        [
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm6: "", md6: "" } },
                            [
                              _c("v-text-field", {
                                directives: [
                                  {
                                    name: "validate",
                                    rawName: "v-validate",
                                    value: "required",
                                    expression: "'required'",
                                  },
                                ],
                                attrs: {
                                  label: _vm.trans("messages.name"),
                                  "data-vv-name": "name",
                                  "data-vv-as": _vm.trans("messages.name"),
                                  "error-messages": _vm.errors.collect("name"),
                                  required: "",
                                },
                                model: {
                                  value: _vm.milestone.name,
                                  callback: function ($$v) {
                                    _vm.$set(_vm.milestone, "name", $$v)
                                  },
                                  expression: "milestone.name",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm6: "", md6: "" } },
                            [
                              _c(
                                "div",
                                {
                                  staticClass:
                                    "v-input v-text-field theme--light",
                                },
                                [
                                  _c(
                                    "div",
                                    { staticClass: "v-input__control" },
                                    [
                                      _c(
                                        "div",
                                        { staticClass: "v-input__slot" },
                                        [
                                          _c(
                                            "div",
                                            {
                                              staticClass: "v-text-field__slot",
                                            },
                                            [
                                              _c(
                                                "label",
                                                {
                                                  staticClass:
                                                    "v-label v-label--active theme--light flat_picker_label",
                                                  attrs: {
                                                    "aria-hidden": "true",
                                                  },
                                                },
                                                [
                                                  _vm._v(
                                                    "\n                                                " +
                                                      _vm._s(
                                                        _vm.trans(
                                                          "messages.due_date"
                                                        )
                                                      ) +
                                                      "\n                                            "
                                                  ),
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c("flat-pickr", {
                                                directives: [
                                                  {
                                                    name: "validate",
                                                    rawName: "v-validate",
                                                    value: "required",
                                                    expression: "'required'",
                                                  },
                                                ],
                                                attrs: {
                                                  name: "due_date",
                                                  required: "",
                                                  config:
                                                    _vm.flatPickerDateTime(),
                                                  "data-vv-as":
                                                    _vm.trans(
                                                      "messages.due_date"
                                                    ),
                                                },
                                                model: {
                                                  value: _vm.due_date,
                                                  callback: function ($$v) {
                                                    _vm.due_date = $$v
                                                  },
                                                  expression: "due_date",
                                                },
                                              }),
                                            ],
                                            1
                                          ),
                                        ]
                                      ),
                                      _vm._v(" "),
                                      _c(
                                        "div",
                                        {
                                          staticClass:
                                            "v-messages theme--light error--text",
                                        },
                                        [
                                          _vm._v(
                                            "\n                                        " +
                                              _vm._s(
                                                _vm.errors.first("due_date")
                                              ) +
                                              "\n                                    "
                                          ),
                                        ]
                                      ),
                                    ]
                                  ),
                                ]
                              ),
                            ]
                          ),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "v-layout",
                        { attrs: { row: "", wrap: "" } },
                        [
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm12: "", md12: "" } },
                            [
                              _vm._v(
                                "\n                            " +
                                  _vm._s(_vm.trans("messages.description")) +
                                  "\n                            "
                              ),
                              _c("quill-editor", {
                                model: {
                                  value: _vm.milestone.description,
                                  callback: function ($$v) {
                                    _vm.$set(_vm.milestone, "description", $$v)
                                  },
                                  expression: "milestone.description",
                                },
                              }),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "v-card-actions",
                [
                  _c("v-spacer"),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      attrs: { color: "teal", small: "", outline: "" },
                      on: {
                        click: function ($event) {
                          _vm.dialog = false
                        },
                      },
                    },
                    [
                      _vm._v(
                        "\n                    " +
                          _vm._s(_vm.trans("messages.close")) +
                          "\n                "
                      ),
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      staticStyle: {
                        "background-color": "#06706d",
                        color: "white",
                      },
                      attrs: {
                        small: "",
                        loading: _vm.loading,
                        disabled: _vm.loading,
                      },
                      on: { click: _vm.store },
                    },
                    [
                      _vm._v(
                        "\n                    " +
                          _vm._s(_vm.trans("messages.save")) +
                          "\n                "
                      ),
                    ]
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/milestones/Edit.vue?vue&type=template&id=f028e592&":
/*!********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/milestones/Edit.vue?vue&type=template&id=f028e592& ***!
  \********************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "v-layout",
    { attrs: { row: "", "justify-center": "" } },
    [
      _c(
        "v-dialog",
        {
          model: {
            value: _vm.dialog,
            callback: function ($$v) {
              _vm.dialog = $$v
            },
            expression: "dialog",
          },
        },
        [
          _c(
            "v-card",
            [
              _c(
                "v-card-title",
                [
                  _c("v-icon", { attrs: { medium: "" } }, [
                    _vm._v("outlined_flag"),
                  ]),
                  _vm._v(" "),
                  _c("span", { staticClass: "headline" }, [
                    _vm._v(
                      "\n                    " +
                        _vm._s(_vm.trans("messages.edit")) +
                        "\n                "
                    ),
                  ]),
                  _vm._v(" "),
                  _c("v-spacer"),
                  _vm._v(" "),
                  _c(
                    "v-icon",
                    {
                      on: {
                        click: function ($event) {
                          _vm.dialog = false
                        },
                      },
                    },
                    [_vm._v("clear")]
                  ),
                  _c("br"),
                ],
                1
              ),
              _vm._v(" "),
              _c("v-divider"),
              _vm._v(" "),
              _c(
                "v-card-text",
                [
                  _c(
                    "v-container",
                    { attrs: { "grid-list-md": "" } },
                    [
                      _c(
                        "v-layout",
                        { attrs: { wrap: "" } },
                        [
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm6: "", md6: "" } },
                            [
                              _c("v-text-field", {
                                directives: [
                                  {
                                    name: "validate",
                                    rawName: "v-validate",
                                    value: "required",
                                    expression: "'required'",
                                  },
                                ],
                                attrs: {
                                  label: _vm.trans("messages.name"),
                                  "data-vv-name": "name",
                                  "data-vv-as": _vm.trans("messages.name"),
                                  "error-messages": _vm.errors.collect("name"),
                                  required: "",
                                },
                                model: {
                                  value: _vm.milestone.name,
                                  callback: function ($$v) {
                                    _vm.$set(_vm.milestone, "name", $$v)
                                  },
                                  expression: "milestone.name",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm6: "", md6: "" } },
                            [
                              _c(
                                "div",
                                {
                                  staticClass:
                                    "v-input v-text-field theme--light",
                                },
                                [
                                  _c(
                                    "div",
                                    { staticClass: "v-input__control" },
                                    [
                                      _c(
                                        "div",
                                        { staticClass: "v-input__slot" },
                                        [
                                          _c(
                                            "div",
                                            {
                                              staticClass: "v-text-field__slot",
                                            },
                                            [
                                              _c(
                                                "label",
                                                {
                                                  staticClass:
                                                    "v-label v-label--active theme--light flat_picker_label",
                                                  attrs: {
                                                    "aria-hidden": "true",
                                                  },
                                                },
                                                [
                                                  _vm._v(
                                                    "\n                                                " +
                                                      _vm._s(
                                                        _vm.trans(
                                                          "messages.due_date"
                                                        )
                                                      ) +
                                                      "\n                                            "
                                                  ),
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c("flat-pickr", {
                                                directives: [
                                                  {
                                                    name: "validate",
                                                    rawName: "v-validate",
                                                    value: "required",
                                                    expression: "'required'",
                                                  },
                                                ],
                                                attrs: {
                                                  name: "due_date",
                                                  required: "",
                                                  config:
                                                    _vm.flatPickerDateTime(),
                                                  "data-vv-as":
                                                    _vm.trans(
                                                      "messages.due_date"
                                                    ),
                                                },
                                                model: {
                                                  value: _vm.due_date,
                                                  callback: function ($$v) {
                                                    _vm.due_date = $$v
                                                  },
                                                  expression: "due_date",
                                                },
                                              }),
                                            ],
                                            1
                                          ),
                                        ]
                                      ),
                                      _vm._v(" "),
                                      _c(
                                        "div",
                                        {
                                          staticClass:
                                            "v-messages theme--light error--text",
                                        },
                                        [
                                          _vm._v(
                                            "\n                                        " +
                                              _vm._s(
                                                _vm.errors.first("due_date")
                                              ) +
                                              "\n                                    "
                                          ),
                                        ]
                                      ),
                                    ]
                                  ),
                                ]
                              ),
                            ]
                          ),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "v-layout",
                        { attrs: { row: "", wrap: "" } },
                        [
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm12: "", md12: "" } },
                            [
                              _vm._v(
                                "\n                            " +
                                  _vm._s(_vm.trans("messages.description")) +
                                  "\n                            "
                              ),
                              _c("quill-editor", {
                                model: {
                                  value: _vm.milestone.description,
                                  callback: function ($$v) {
                                    _vm.$set(_vm.milestone, "description", $$v)
                                  },
                                  expression: "milestone.description",
                                },
                              }),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "v-card-actions",
                [
                  _c("v-spacer"),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      attrs: { color: "teal", small: "", outline: "" },
                      on: {
                        click: function ($event) {
                          _vm.dialog = false
                        },
                      },
                    },
                    [
                      _vm._v(
                        "\n                    " +
                          _vm._s(_vm.trans("messages.close")) +
                          "\n                "
                      ),
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      staticStyle: {
                        "background-color": "#06706d",
                        color: "white",
                      },
                      attrs: {
                        small: "",
                        loading: _vm.loading,
                        disabled: _vm.loading,
                      },
                      on: { click: _vm.update },
                    },
                    [
                      _vm._v(
                        "\n                    " +
                          _vm._s(_vm.trans("messages.update")) +
                          "\n                "
                      ),
                    ]
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/milestones/Lists.vue?vue&type=template&id=c1161690&":
/*!*********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/milestones/Lists.vue?vue&type=template&id=c1161690& ***!
  \*********************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "v-container",
    { attrs: { "grid-list-md": "" } },
    [
      _c("MilestoneFormAdd"),
      _vm._v(" "),
      _c("MilestoneShow", { ref: "milestoneShow" }),
      _vm._v(" "),
      _c("MilestoneFormEdit", { ref: "milestoneEdit" }),
      _vm._v(" "),
      _c(
        "v-layout",
        { attrs: { row: "", wrap: "" } },
        [
          _c("span", [_vm._v(_vm._s(_vm.trans("data.schedule")))]),
          _vm._v(" "),
          _c("v-spacer"),
          _vm._v(" "),
          _vm.$can("project." + _vm.projectId + ".milestone.create")
            ? _c(
                "v-btn",
                {
                  staticClass: "lighten-1",
                  staticStyle: {
                    "background-color": "#06706d",
                    color: "white",
                  },
                  attrs: { dark: "" },
                  on: { click: _vm.create },
                },
                [
                  _vm._v(
                    "\n            " +
                      _vm._s(_vm.trans("messages.add")) +
                      "\n            "
                  ),
                  _c("v-icon", { attrs: { right: "" } }, [_vm._v("add")]),
                ],
                1
              )
            : _vm._e(),
        ],
        1
      ),
      _vm._v(" "),
      _c("v-divider"),
      _vm._v(" "),
      _vm.milestones.length
        ? _c(
            "v-list",
            { attrs: { subheader: "", "three-line": "" } },
            [
              _c("v-subheader"),
              _vm._v(" "),
              _vm._l(_vm.milestones, function (milestone) {
                return _c(
                  "div",
                  { key: milestone.id },
                  [
                    _c(
                      "v-list-tile",
                      [
                        _c(
                          "v-list-tile-content",
                          [
                            _c("v-list-tile-title", [
                              _c("span", [
                                _vm._v(" " + _vm._s(milestone.name) + " "),
                              ]),
                            ]),
                            _vm._v(" "),
                            _c(
                              "v-list-tile-sub-title",
                              [
                                _c(
                                  "v-chip",
                                  {
                                    attrs: {
                                      color: _vm.dueDateColor(milestone),
                                      small: "",
                                    },
                                  },
                                  [
                                    _vm._v(
                                      "\n                            " +
                                        _vm._s(
                                          _vm._f("formatDateTime")(
                                            milestone.due_date
                                          )
                                        ) +
                                        "\n                        "
                                    ),
                                  ]
                                ),
                              ],
                              1
                            ),
                            _vm._v(" "),
                            _c(
                              "v-list-tile-sub-title",
                              [
                                _vm.$can(
                                  "project." + _vm.projectId + ".milestone.view"
                                )
                                  ? _c(
                                      "v-btn",
                                      {
                                        attrs: { flat: "", icon: "" },
                                        on: {
                                          click: function ($event) {
                                            return _vm.view(milestone.id)
                                          },
                                        },
                                      },
                                      [
                                        _c("v-icon", { attrs: { small: "" } }, [
                                          _vm._v(" visibility "),
                                        ]),
                                      ],
                                      1
                                    )
                                  : _vm._e(),
                                _vm._v(" "),
                                _vm.$can(
                                  "project." + _vm.projectId + ".milestone.edit"
                                )
                                  ? _c(
                                      "v-btn",
                                      {
                                        attrs: { flat: "", icon: "" },
                                        on: {
                                          click: function ($event) {
                                            return _vm.edit(milestone.id)
                                          },
                                        },
                                      },
                                      [
                                        _c("v-icon", { attrs: { small: "" } }, [
                                          _vm._v(" edit "),
                                        ]),
                                      ],
                                      1
                                    )
                                  : _vm._e(),
                                _vm._v(" "),
                                _vm.$can(
                                  "project." +
                                    _vm.projectId +
                                    ".milestone.delete"
                                )
                                  ? _c(
                                      "v-btn",
                                      {
                                        attrs: { flat: "", icon: "" },
                                        on: {
                                          click: function ($event) {
                                            return _vm.deleteMilestone(
                                              milestone.id
                                            )
                                          },
                                        },
                                      },
                                      [
                                        _c("v-icon", { attrs: { small: "" } }, [
                                          _vm._v(" delete_outline "),
                                        ]),
                                      ],
                                      1
                                    )
                                  : _vm._e(),
                              ],
                              1
                            ),
                          ],
                          1
                        ),
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c("v-divider"),
                  ],
                  1
                )
              }),
            ],
            2
          )
        : _c(
            "v-layout",
            { attrs: { row: "", wrap: "" } },
            [
              _c("v-flex", { attrs: { xs12: "", sm12: "" } }, [
                _c(
                  "div",
                  [
                    _c(
                      "v-alert",
                      { attrs: { value: true, color: "teal", outline: "" } },
                      [
                        _vm._v(
                          "\n                    " +
                            _vm._s(_vm.trans("messages.no_records_found")) +
                            "\n                "
                        ),
                      ]
                    ),
                  ],
                  1
                ),
              ]),
            ],
            1
          ),
      _vm._v(" "),
      _c(
        "div",
        { attrs: { align: "right" } },
        [
          _c(
            "v-btn",
            {
              staticStyle: { "background-color": "#06706d", color: "white" },
              on: {
                click: function ($event) {
                  return _vm.$router.go(-1)
                },
              },
            },
            [
              _vm._v(
                "\n            " +
                  _vm._s(_vm.trans("messages.back")) +
                  "\n        "
              ),
            ]
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/milestones/Show.vue?vue&type=template&id=143c48aa&":
/*!********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/milestones/Show.vue?vue&type=template&id=143c48aa& ***!
  \********************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "v-layout",
    { attrs: { row: "", "justify-center": "" } },
    [
      _c(
        "v-dialog",
        {
          attrs: { "max-width": "900" },
          model: {
            value: _vm.dialog,
            callback: function ($$v) {
              _vm.dialog = $$v
            },
            expression: "dialog",
          },
        },
        [
          _c(
            "v-card",
            [
              _c(
                "v-card-title",
                { staticClass: "headline" },
                [
                  _c("v-icon", { attrs: { medium: "" } }, [
                    _vm._v("outlined_flag"),
                  ]),
                  _vm._v(
                    "\n                " +
                      _vm._s(_vm.trans("messages.view")) +
                      "\n                "
                  ),
                  _c("v-spacer"),
                  _vm._v(" "),
                  _c(
                    "v-icon",
                    {
                      on: {
                        click: function ($event) {
                          _vm.dialog = false
                        },
                      },
                    },
                    [_vm._v("clear")]
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("v-divider"),
              _vm._v(" "),
              _c(
                "v-card-text",
                [
                  _c(
                    "v-container",
                    { attrs: { "align-center": "" } },
                    [
                      _c(
                        "v-layout",
                        { attrs: { row: "", wrap: "" } },
                        [
                          _c("v-flex", { attrs: { xs12: "", md6: "" } }, [
                            _c("strong", [
                              _vm._v(
                                _vm._s(_vm.trans("messages.name")) + " : "
                              ),
                            ]),
                            _vm._v(
                              "\n                            " +
                                _vm._s(_vm.milestone.name) +
                                "\n                        "
                            ),
                          ]),
                          _vm._v(" "),
                          _c("v-flex", { attrs: { xs12: "", md6: "" } }, [
                            _c("strong", [
                              _vm._v(
                                _vm._s(_vm.trans("messages.due_date")) + " : "
                              ),
                            ]),
                            _vm._v(
                              "\n                            " +
                                _vm._s(
                                  _vm._f("formatDateTime")(
                                    _vm.milestone.due_date
                                  )
                                ) +
                                "\n                        "
                            ),
                          ]),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "v-layout",
                        { attrs: { wrap: "" } },
                        [
                          _c("v-flex", { attrs: { xs12: "", md12: "" } }, [
                            _c("strong", [
                              _vm._v(
                                _vm._s(_vm.trans("messages.description")) +
                                  " : "
                              ),
                            ]),
                            _vm._v(" "),
                            _c("br"),
                            _vm._v(" "),
                            _c("span", {
                              domProps: {
                                innerHTML: _vm._s(_vm.milestone.description),
                              },
                            }),
                          ]),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("v-divider"),
              _vm._v(" "),
              _c(
                "v-card-actions",
                [
                  _c("v-spacer"),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      attrs: { color: "teal", small: "", outline: "" },
                      on: {
                        click: function ($event) {
                          _vm.dialog = false
                        },
                      },
                    },
                    [
                      _vm._v(
                        "\n                    " +
                          _vm._s(_vm.trans("messages.close")) +
                          "\n                "
                      ),
                    ]
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);