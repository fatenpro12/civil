"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_estate_owner_tickets_List_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/List.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/List.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _view_visit_request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./view_visit_request */ "./resources/js/common/visit-request/view_visit_request.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  components: {
    ViewVisitRequest: _view_visit_request__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  props: {
    url: {
      type: String
    },
    params: {
      type: Object,
      "default": null
    }
  },
  data: function data() {
    var self = this;
    return {
      expand: true,
      currentUser: '',
      projects: [],
      total_items: 0,
      loading: false,
      pagination: {
        totalItems: 0
      },
      projectRequests: [],
      request_types: [],
      headers: [{
        text: self.trans('messages.action'),
        value: false,
        align: 'center',
        sortable: false
      }, {
        text: self.trans('data.id'),
        value: false,
        align: 'center',
        sortable: true
      }, {
        text: self.trans('messages.status'),
        value: 'status',
        align: 'center',
        sortable: true
      }, {
        text: self.trans('messages.customer'),
        value: 'customer',
        align: 'center',
        sortable: true
      }, {
        text: self.trans('data.project_name'),
        value: 'project_name',
        align: 'center',
        sortable: true
      }, {
        text: self.trans('data.enginnering_type'),
        value: 'enginnering_type',
        align: 'center',
        sortable: true
      }, {
        text: self.trans('messages.created_at'),
        value: 'created_at',
        align: 'center',
        sortable: true
      }],
      items: [],
      type: '',
      project_name: ''
    };
  },
  watch: {
    pagination: {
      handler: function handler() {
        this.getAllProjectRequest();
      }
    }
  },
  mounted: function mounted() {
    var self = this;
    self.$eventBus.$on('updateTicketsTable', function (data) {
      self.projectRequest = [];
      self.projects = [];
      self.getAllProjectRequest();
    });
  },
  beforeDestroy: function beforeDestroy() {
    var self = this;
    self.$eventBus.$off('updateTicketsTable');
  },
  methods: {
    viewReport: function viewReport(item) {
      this.$router.push({
        name: 'edit_report',
        params: {
          id: item.id
          //  id: item.report.media[item.report.media.length-1].full_url?item.report.media[item.report.media.length-1].full_url:item.report.media[item.report.media.length-1].original_url
        }
      });
    },
    editRequest: function editRequest(request) {
      this.$router.push({
        name: 'edit_visit_request_estate_list',
        params: {
          id: request.id
        }
      });
    },
    sendRequest: function sendRequest(request) {
      var self = this;
      self.$store.commit('showDialog', {
        type: 'confirm',
        icon: 'warning',
        title: self.trans('messages.are_you_sure'),
        okCb: function okCb() {
          axios.post('confirm-send', {
            request_id: request.id
          }).then(function (response) {
            self.projectRequest = [];
            self.projects = [];
            self.$store.commit('showSnackbar', {
              message: response.data.data,
              color: 'green'
            });
            self.getAllProjectRequest();
          })["catch"](function (error) {
            console.log(error);
          });
        },
        cancelCb: function cancelCb() {
          console.log('CANCEL');
        }
      });
    },
    removeProject: function removeProject(id) {
      var self = this;
      self.$store.commit('showDialog', {
        type: 'confirm',
        icon: 'warning',
        title: self.trans('messages.are_you_sure'),
        message: self.trans('messages.you_cant_restore_it'),
        okCb: function okCb() {
          axios["delete"]('request/' + id).then(function (response) {
            self.$store.commit('showSnackbar', {
              message: response.data.msg,
              color: response.data.success
            });
            self.projectRequest = [];
            self.projects = [];
            self.getAllProjectRequest();
          })["catch"](function (error) {
            console.log(error);
          });
        },
        cancelCb: function cancelCb() {
          console.log('CANCEL');
        }
      });
    },
    viewRequest: function viewRequest(request) {
      this.$refs.viewVisitRequest.create(request.id);
    },
    getVisitRequestType: function getVisitRequestType(id) {
      var self = this;
      axios.get('/visit-request-type/' + id).then(function (response) {
        self.type = response.data.data;
      })["catch"](function (error) {
        self.type = '-';
      });
      return self.type;
    },
    getAllProjectRequest: function getAllProjectRequest() {
      var self = this;
      self.loading = true;
      axios.get(self.url, {
        params: self.params
      }).then(function (response) {
        self.total_items = response.data.length;
        self.projectRequests = response.data.data;
        self.projects = response.data;
        self.loading = false;
      })["catch"](function (err) {
        console.log(err.response.status);
        if (err.response.status === 401) {
          store.dispatch('auth/handleResponse', err.response);
        }
      });
      ;
    },
    viewProject: function viewProject(id) {
      var self = this;
      self.$router.push({
        name: 'view_project',
        params: {
          id: id
        }
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/view_visit_request.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/view_visit_request.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../store */ "./resources/js/store/index.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  data: function data() {
    return {
      propRequestId: null,
      dialog: false,
      project_name: '',
      loading: false,
      request_type: '',
      customer: '',
      dead_line_date: null,
      note: '',
      //
      enginnering_type: '',
      request_enginners: [],
      offices: []
    };
  },
  methods: {
    getEnginners: function getEnginners() {
      var self = this;
      axios.get('get-requests-enginners/' + self.propRequestId).then(function (response) {
        self.request_enginners = response.data;
      });
    },
    create: function create(data) {
      this.dialog = true;
      this.propRequestId = data;
      var self = this;
      self.getEnginners();
      this.loadRequest(function () {});
    },
    loadRequest: function loadRequest() {
      var self = this;
      axios.get('request/' + self.propRequestId).then(function (response) {
        console.log(response.data.msg);
        if (response.data.success) {
          var tem = response.data.msg;
          self.enginnering_type = tem.request.specialties ? tem.request.specialties.map(function (x) {
            return x.name;
          }).join(',') : '';
          self.request_type = tem.request.request_type;
          self.project_name = tem.request.projectName;
          self.customer = tem.request.customer;
          self.offices = tem.request.offices;
          self.note = tem.request.note;
          self.dead_line_date = tem.request.dead_line_date;
        } else {
          self.$store.commit('showSnackbar', {
            message: response.data.msg,
            color: response.data.success
          });
        }
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/estate_owner/tickets/List.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/estate_owner/tickets/List.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _common_visit_request_List__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../common/visit-request/List */ "./resources/js/common/visit-request/List.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  components: {
    VisitRequest: _common_visit_request_List__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  methods: {}
});

/***/ }),

/***/ "./resources/js/common/visit-request/List.vue":
/*!****************************************************!*\
  !*** ./resources/js/common/visit-request/List.vue ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _List_vue_vue_type_template_id_540dc196___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./List.vue?vue&type=template&id=540dc196& */ "./resources/js/common/visit-request/List.vue?vue&type=template&id=540dc196&");
/* harmony import */ var _List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./List.vue?vue&type=script&lang=js& */ "./resources/js/common/visit-request/List.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _List_vue_vue_type_template_id_540dc196___WEBPACK_IMPORTED_MODULE_0__.render,
  _List_vue_vue_type_template_id_540dc196___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/common/visit-request/List.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/common/visit-request/view_visit_request.vue":
/*!******************************************************************!*\
  !*** ./resources/js/common/visit-request/view_visit_request.vue ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _view_visit_request_vue_vue_type_template_id_68e2c6d9___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./view_visit_request.vue?vue&type=template&id=68e2c6d9& */ "./resources/js/common/visit-request/view_visit_request.vue?vue&type=template&id=68e2c6d9&");
/* harmony import */ var _view_visit_request_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./view_visit_request.vue?vue&type=script&lang=js& */ "./resources/js/common/visit-request/view_visit_request.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _view_visit_request_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _view_visit_request_vue_vue_type_template_id_68e2c6d9___WEBPACK_IMPORTED_MODULE_0__.render,
  _view_visit_request_vue_vue_type_template_id_68e2c6d9___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/common/visit-request/view_visit_request.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/estate_owner/tickets/List.vue":
/*!****************************************************!*\
  !*** ./resources/js/estate_owner/tickets/List.vue ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _List_vue_vue_type_template_id_05296187___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./List.vue?vue&type=template&id=05296187& */ "./resources/js/estate_owner/tickets/List.vue?vue&type=template&id=05296187&");
/* harmony import */ var _List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./List.vue?vue&type=script&lang=js& */ "./resources/js/estate_owner/tickets/List.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _List_vue_vue_type_template_id_05296187___WEBPACK_IMPORTED_MODULE_0__.render,
  _List_vue_vue_type_template_id_05296187___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/estate_owner/tickets/List.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/common/visit-request/List.vue?vue&type=script&lang=js&":
/*!*****************************************************************************!*\
  !*** ./resources/js/common/visit-request/List.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./List.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/List.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/common/visit-request/view_visit_request.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************!*\
  !*** ./resources/js/common/visit-request/view_visit_request.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_view_visit_request_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./view_visit_request.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/view_visit_request.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_view_visit_request_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/estate_owner/tickets/List.vue?vue&type=script&lang=js&":
/*!*****************************************************************************!*\
  !*** ./resources/js/estate_owner/tickets/List.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./List.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/estate_owner/tickets/List.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/common/visit-request/List.vue?vue&type=template&id=540dc196&":
/*!***********************************************************************************!*\
  !*** ./resources/js/common/visit-request/List.vue?vue&type=template&id=540dc196& ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_540dc196___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_540dc196___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_540dc196___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./List.vue?vue&type=template&id=540dc196& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/List.vue?vue&type=template&id=540dc196&");


/***/ }),

/***/ "./resources/js/common/visit-request/view_visit_request.vue?vue&type=template&id=68e2c6d9&":
/*!*************************************************************************************************!*\
  !*** ./resources/js/common/visit-request/view_visit_request.vue?vue&type=template&id=68e2c6d9& ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_view_visit_request_vue_vue_type_template_id_68e2c6d9___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_view_visit_request_vue_vue_type_template_id_68e2c6d9___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_view_visit_request_vue_vue_type_template_id_68e2c6d9___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./view_visit_request.vue?vue&type=template&id=68e2c6d9& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/view_visit_request.vue?vue&type=template&id=68e2c6d9&");


/***/ }),

/***/ "./resources/js/estate_owner/tickets/List.vue?vue&type=template&id=05296187&":
/*!***********************************************************************************!*\
  !*** ./resources/js/estate_owner/tickets/List.vue?vue&type=template&id=05296187& ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_05296187___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_05296187___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_05296187___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./List.vue?vue&type=template&id=05296187& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/estate_owner/tickets/List.vue?vue&type=template&id=05296187&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/List.vue?vue&type=template&id=540dc196&":
/*!**************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/List.vue?vue&type=template&id=540dc196& ***!
  \**************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "v-container",
    {
      class: _vm.$vuetify.breakpoint.xsOnly ? "pt-4" : "",
      attrs: { "grid-list-md": "" },
    },
    [
      _c("ViewVisitRequest", { ref: "viewVisitRequest" }),
      _vm._v(" "),
      _c(
        "v-card",
        { staticClass: "mt-3" },
        [
          _c(
            "v-card-title",
            { attrs: { "primary-title": "", xs8: "", sm8: "" } },
            [
              _c("div", [
                _c("div", { staticClass: "headline" }, [
                  _vm._v(
                    "\n                    " +
                      _vm._s(_vm.trans("data.visit_requests")) +
                      "\n                "
                  ),
                ]),
              ]),
              _vm._v(" "),
              _c("v-spacer"),
              _vm._v(" "),
              _c(
                "v-btn",
                {
                  staticClass: "lighten-1",
                  staticStyle: {
                    "background-color": "#06706d",
                    color: "white",
                  },
                  attrs: { disabled: !_vm.checkActive() },
                  on: {
                    click: function ($event) {
                      return _vm.$router.push({
                        name: "create_visit_estate_request_list",
                        params: { request_type: "visit_request" },
                      })
                    },
                  },
                },
                [
                  _vm._v(
                    "\n                " +
                      _vm._s(_vm.trans("messages.add")) +
                      "\n                "
                  ),
                  _c("v-icon", { attrs: { right: "", dark: "" } }, [
                    _vm._v("add"),
                  ]),
                ],
                1
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c("v-divider"),
          _vm._v(" "),
          _c("v-data-table", {
            staticClass: "elevation-3",
            attrs: {
              headers: _vm.headers,
              pagination: _vm.pagination,
              "total-items": _vm.total_items,
              loading: _vm.loading,
              items: _vm.projects,
              expand: _vm.expand,
            },
            on: {
              "update:pagination": function ($event) {
                _vm.pagination = $event
              },
            },
            scopedSlots: _vm._u(
              [
                {
                  key: "items",
                  fn: function (props) {
                    return [
                      _c("tr", [
                        _c("td", [
                          _c(
                            "div",
                            {
                              staticStyle: {
                                display: "inline-flex",
                                "padding-left": "30%",
                              },
                              attrs: { align: "center" },
                            },
                            [
                              _vm._t("expandIcon", null, { props: props }),
                              _vm._v(" "),
                              _c(
                                "v-btn",
                                {
                                  attrs: {
                                    small: "",
                                    fab: "",
                                    dark: "",
                                    color: "success",
                                  },
                                  on: {
                                    click: function ($event) {
                                      return _vm.viewRequest(props.item)
                                    },
                                  },
                                },
                                [
                                  _c("v-icon", { attrs: { color: "white" } }, [
                                    _vm._v("info"),
                                  ]),
                                ],
                                1
                              ),
                              _vm._v(" "),
                              _vm._t("actions", null, { props: props }),
                              _vm._v(" "),
                              props.item.status == "new"
                                ? _c(
                                    "v-btn",
                                    {
                                      attrs: {
                                        disabled: !_vm.checkActive(),
                                        small: "",
                                        fab: "",
                                        color: "success",
                                      },
                                      on: {
                                        click: function ($event) {
                                          return _vm.editRequest(props.item)
                                        },
                                      },
                                    },
                                    [
                                      _c(
                                        "v-icon",
                                        { attrs: { color: "white" } },
                                        [_vm._v("edit")]
                                      ),
                                    ],
                                    1
                                  )
                                : _vm._e(),
                              _vm._v(" "),
                              _c(
                                "div",
                                [
                                  props.item.sent == 0 &&
                                  props.item.status == "new"
                                    ? _c(
                                        "v-btn",
                                        {
                                          attrs: {
                                            color: "primary",
                                            small: "",
                                            fab: "",
                                            disabled: !_vm.checkActive(),
                                          },
                                          on: {
                                            click: function ($event) {
                                              return _vm.sendRequest(props.item)
                                            },
                                          },
                                        },
                                        [
                                          _c(
                                            "v-icon",
                                            { attrs: { color: "white" } },
                                            [_vm._v("mail")]
                                          ),
                                        ],
                                        1
                                      )
                                    : _vm._e(),
                                ],
                                1
                              ),
                              _vm._v(" "),
                              props.item.status == "new" ||
                              props.item.status == "rejected"
                                ? _c(
                                    "v-btn",
                                    {
                                      attrs: {
                                        color: "error",
                                        disabled: !_vm.checkActive(),
                                        small: "",
                                        fab: "",
                                      },
                                      on: {
                                        click: function ($event) {
                                          return _vm.removeProject(
                                            props.item.id
                                          )
                                        },
                                      },
                                    },
                                    [
                                      _c(
                                        "v-icon",
                                        { attrs: { color: "white" } },
                                        [_vm._v("delete")]
                                      ),
                                    ],
                                    1
                                  )
                                : _vm._e(),
                            ],
                            2
                          ),
                        ]),
                        _vm._v(" "),
                        _c("td", [
                          _c("div", { attrs: { align: "center" } }, [
                            _vm._v(
                              "\n                        " +
                                _vm._s(props.item.id) +
                                "\n                    "
                            ),
                          ]),
                        ]),
                        _vm._v(" "),
                        _c("td", [
                          _c(
                            "div",
                            { attrs: { align: "center" } },
                            [
                              props.item.status != ""
                                ? _c(
                                    "v-chip",
                                    {
                                      staticClass: "ma-2",
                                      attrs: {
                                        disabled: !_vm.checkActive(),
                                        color: _vm.getColor(props.item.status),
                                        "text-color": "white",
                                      },
                                    },
                                    [
                                      _vm._v(
                                        "\n                            " +
                                          _vm._s(
                                            props.item.office_id ==
                                              _vm.currentUser
                                              ? props.item.office_status
                                              : props.item.status
                                          ) +
                                          "\n                        "
                                      ),
                                    ]
                                  )
                                : _vm._e(),
                            ],
                            1
                          ),
                        ]),
                        _vm._v(" "),
                        _c("td", [
                          _c("div", { attrs: { align: "center" } }, [
                            _vm._v(
                              "\n                        " +
                                _vm._s(props.item.customer) +
                                "\n                    "
                            ),
                          ]),
                        ]),
                        _vm._v(" "),
                        _c("td", [
                          _c(
                            "div",
                            { attrs: { align: "center" } },
                            [
                              _c(
                                "v-btn",
                                {
                                  attrs: {
                                    small: "",
                                    fab: "",
                                    dark: "",
                                    color: "teal",
                                  },
                                  on: {
                                    click: function ($event) {
                                      return _vm.viewProject(
                                        props.item.projectId
                                      )
                                    },
                                  },
                                },
                                [
                                  _vm._v(
                                    "\n                            " +
                                      _vm._s(props.item.projectName) +
                                      "\n                            "
                                  ),
                                ]
                              ),
                            ],
                            1
                          ),
                        ]),
                        _vm._v(" "),
                        _c("td", [
                          _c("div", { attrs: { align: "center" } }, [
                            _vm._v(
                              "\n                        " +
                                _vm._s(
                                  props.item.specialties != null
                                    ? props.item.specialties
                                        .map(function (x) {
                                          return x.name
                                        })
                                        .join(",")
                                    : ""
                                ) +
                                "\n                    "
                            ),
                          ]),
                        ]),
                        _vm._v(" "),
                        _c("td", [
                          _c("div", { attrs: { align: "center" } }, [
                            _vm._v(
                              "\n                        " +
                                _vm._s(
                                  props.item.created_at
                                    ? _vm.createdDate(props.item.created_at)
                                    : "-"
                                ) +
                                "\n                    "
                            ),
                          ]),
                        ]),
                      ]),
                    ]
                  },
                },
                {
                  key: "expand",
                  fn: function (props) {
                    return [_vm._t("offices", null, { props: props })]
                  },
                },
              ],
              null,
              true
            ),
          }),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "div",
        { attrs: { align: "center" } },
        [
          _c(
            "v-btn",
            {
              staticStyle: { "background-color": "#06706d", color: "white" },
              on: {
                click: function ($event) {
                  return _vm.$router.go(-1)
                },
              },
            },
            [
              _vm._v(
                "\n            " +
                  _vm._s(_vm.trans("messages.back")) +
                  "\n        "
              ),
            ]
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/view_visit_request.vue?vue&type=template&id=68e2c6d9&":
/*!****************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/view_visit_request.vue?vue&type=template&id=68e2c6d9& ***!
  \****************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "v-layout",
    { attrs: { row: "", "justify-center": "" } },
    [
      _c(
        "v-dialog",
        {
          attrs: { persistent: "", "max-width": "600px" },
          model: {
            value: _vm.dialog,
            callback: function ($$v) {
              _vm.dialog = $$v
            },
            expression: "dialog",
          },
        },
        [
          _c(
            "div",
            {
              staticClass:
                "overflow-hidden bg-white shadow sm:rounded-lg mx-auto",
              class: _vm.$vuetify.breakpoint.xsOnly ? "w-full mt-5" : "",
            },
            [
              _c(
                "div",
                { staticClass: "px-4 py-3 sm:px-6 flex" },
                [
                  _c(
                    "h3",
                    {
                      staticClass:
                        "text-lg mt-2 font-medium leading-6 text-gray-900",
                    },
                    [_vm._v(_vm._s(_vm.trans("data.visit_request_detaile")))]
                  ),
                  _vm._v(" "),
                  _c("v-spacer"),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      attrs: { flat: "", icon: "" },
                      on: {
                        click: function ($event) {
                          _vm.dialog = false
                        },
                      },
                    },
                    [_c("v-icon", [_vm._v("clear")])],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("div", { staticClass: "border-t border-gray-200" }, [
                _c("dl", [
                  _c(
                    "div",
                    {
                      staticClass:
                        "bg-gray-50 px-4 py-3 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6",
                      class: _vm.$vuetify.breakpoint.xsOnly
                        ? "flex justify-around"
                        : "",
                    },
                    [
                      _c(
                        "dt",
                        { staticClass: "text-md font-medium text-gray-500" },
                        [_vm._v(_vm._s(_vm.trans("data.project_name")))]
                      ),
                      _vm._v(" "),
                      _c(
                        "dd",
                        {
                          staticClass:
                            "mt-1 text-md text-gray-900 sm:col-span-2 sm:mt-0",
                        },
                        [_vm._v(_vm._s(_vm.project_name))]
                      ),
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      staticClass:
                        "bg-white px-4 py-3 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6",
                      class: _vm.$vuetify.breakpoint.xsOnly
                        ? "flex justify-around"
                        : "",
                    },
                    [
                      _c(
                        "dt",
                        { staticClass: "text-md font-medium text-gray-500" },
                        [_vm._v(_vm._s(_vm.trans("messages.customer")))]
                      ),
                      _vm._v(" "),
                      _c(
                        "dd",
                        {
                          staticClass:
                            "mt-1 text-md text-gray-900 sm:col-span-2 sm:mt-0",
                        },
                        [_vm._v(_vm._s(_vm.customer))]
                      ),
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      staticClass:
                        "bg-gray-50 px-4 py-3 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6",
                      class: _vm.$vuetify.breakpoint.xsOnly
                        ? "flex justify-around"
                        : "",
                    },
                    [
                      _c(
                        "dt",
                        { staticClass: "text-md font-medium text-gray-500" },
                        [_vm._v(_vm._s(_vm.trans("data.visit_datetime")))]
                      ),
                      _vm._v(" "),
                      _c(
                        "dd",
                        {
                          staticClass:
                            "mt-1 text-md text-gray-900 sm:col-span-2 sm:mt-0",
                        },
                        [_vm._v(_vm._s(_vm.dead_line_date))]
                      ),
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      staticClass:
                        "bg-white px-4 py-3 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6",
                      class: _vm.$vuetify.breakpoint.xsOnly
                        ? "flex justify-around"
                        : "",
                    },
                    [
                      _c(
                        "dt",
                        { staticClass: "text-md font-medium text-gray-500" },
                        [_vm._v(_vm._s(_vm.trans("data.enginnering_type")))]
                      ),
                      _vm._v(" "),
                      _c(
                        "dd",
                        {
                          staticClass:
                            "mt-1 text-md text-gray-900 sm:col-span-2 sm:mt-0",
                        },
                        [_vm._v(_vm._s(_vm.enginnering_type))]
                      ),
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      staticClass:
                        "bg-gray-50 px-4 py-3 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6",
                      class: _vm.$vuetify.breakpoint.xsOnly
                        ? "flex justify-around"
                        : "",
                    },
                    [
                      _c(
                        "dt",
                        { staticClass: "text-md font-medium text-gray-500" },
                        [_vm._v(_vm._s(_vm.trans("data.note")))]
                      ),
                      _vm._v(" "),
                      _c(
                        "dd",
                        {
                          staticClass:
                            "mt-1 text-md text-gray-900 sm:col-span-2 sm:mt-0",
                        },
                        [_vm._v(_vm._s(_vm.note))]
                      ),
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      staticClass:
                        "bg-white px-4 py-3 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6",
                      class: _vm.$vuetify.breakpoint.xsOnly
                        ? "flex justify-around"
                        : "",
                    },
                    [
                      _c(
                        "dt",
                        { staticClass: "text-md font-medium text-gray-500" },
                        [
                          _vm._v(
                            _vm._s(_vm.trans("data.enginnering_office_name"))
                          ),
                        ]
                      ),
                      _vm._v(" "),
                      _c(
                        "dd",
                        {
                          staticClass:
                            "mt-1 text-md text-gray-900 sm:col-span-2 sm:mt-0",
                        },
                        [
                          _vm._v(
                            _vm._s(_vm.offices[0] ? _vm.offices[0].name : "")
                          ),
                        ]
                      ),
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      staticClass:
                        "bg-gray-50 px-4 py-3 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6",
                    },
                    [
                      _c(
                        "dt",
                        { staticClass: "text-md font-medium text-gray-500" },
                        [
                          _vm._v(
                            _vm._s(_vm.trans("data.employee_and_Dead_lines"))
                          ),
                        ]
                      ),
                      _vm._v(" "),
                      _c(
                        "dd",
                        {
                          staticClass:
                            "mt-1 text-md text-gray-900 sm:col-span-2 sm:mt-0",
                        },
                        [
                          _c(
                            "ul",
                            {
                              staticClass:
                                "divide-y divide-gray-200 rounded-md border border-gray-200",
                              attrs: { role: "list" },
                            },
                            _vm._l(_vm.request_enginners, function (enginner) {
                              return _c(
                                "li",
                                {
                                  key: enginner.id,
                                  staticClass:
                                    "flex items-center justify-between py-3 px-2 text-md",
                                },
                                [
                                  _c(
                                    "span",
                                    {
                                      staticClass:
                                        "ml-2 w-0 flex-1 min-w-fit truncate",
                                    },
                                    [_vm._v(_vm._s(enginner.employee.name))]
                                  ),
                                  _vm._v(" "),
                                  _c(
                                    "span",
                                    {
                                      staticClass:
                                        "ml-2 w-0 flex-1 min-w-fit truncate",
                                    },
                                    [
                                      _vm._v(
                                        _vm._s(
                                          enginner.dead_line_date != null
                                            ? enginner.dead_line_date
                                            : "لم يحدد بعد"
                                        )
                                      ),
                                    ]
                                  ),
                                ]
                              )
                            }),
                            0
                          ),
                        ]
                      ),
                    ]
                  ),
                ]),
                _vm._v(" "),
                _c(
                  "div",
                  { staticClass: "mx-auto my-2 flex justify-center" },
                  [
                    _c(
                      "v-btn",
                      {
                        staticStyle: { color: "#06706d" },
                        on: {
                          click: function ($event) {
                            _vm.dialog = false
                          },
                        },
                      },
                      [
                        _vm._v(
                          "\r\n                        " +
                            _vm._s(_vm.trans("data.close")) +
                            "\r\n                    "
                        ),
                      ]
                    ),
                  ],
                  1
                ),
              ]),
            ]
          ),
        ]
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/estate_owner/tickets/List.vue?vue&type=template&id=05296187&":
/*!**************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/estate_owner/tickets/List.vue?vue&type=template&id=05296187& ***!
  \**************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c("VisitRequest", {
        attrs: { url: "get-requests" },
        scopedSlots: _vm._u([
          {
            key: "expandIcon",
            fn: function (ref) {
              var props = ref.props
              return [
                props.item.offices.length > 0
                  ? _c(
                      "v-icon",
                      {
                        on: {
                          click: function ($event) {
                            props.expanded = !props.expanded
                          },
                        },
                      },
                      [_vm._v("arrow_drop_down")]
                    )
                  : _vm._e(),
              ]
            },
          },
          {
            key: "offices",
            fn: function (ref) {
              var props = ref.props
              return [
                _c(
                  "v-card",
                  { attrs: { flat: "" } },
                  [
                    props.item.offices.length > 0
                      ? _c("v-card-text", [
                          _c("table", [
                            _c("tr", [
                              _c("td", { attrs: { width: "30%" } }, [
                                _c("span", [
                                  _vm._v(_vm._s(props.item.offices[0].name)),
                                ]),
                              ]),
                              _vm._v(" "),
                              _c(
                                "td",
                                { attrs: { width: "30%" } },
                                [
                                  _c(
                                    "v-chip",
                                    {
                                      attrs: {
                                        disabled: !_vm.checkActive(),
                                        color: _vm.getColor(
                                          props.item.offices[0].pivot
                                            .office_status
                                        ),
                                        "text-color": "white",
                                      },
                                    },
                                    [
                                      _vm._v(
                                        "\n                             " +
                                          _vm._s(
                                            _vm.trans("data.office_status") +
                                              " " +
                                              props.item.offices[0].pivot
                                                .office_status
                                          ) +
                                          "\n                        "
                                      ),
                                    ]
                                  ),
                                ],
                                1
                              ),
                              _vm._v(" "),
                              _c(
                                "td",
                                { attrs: { width: "30%" } },
                                [
                                  props.item.report &&
                                  props.item.offices[0].pivot.office_status ==
                                    "accepted"
                                    ? _c(
                                        "v-btn",
                                        {
                                          attrs: { dark: "", color: "success" },
                                          on: {
                                            click: function ($event) {
                                              return _vm.viewReport(props.item)
                                            },
                                          },
                                        },
                                        [
                                          _vm._v(
                                            "\n                            " +
                                              _vm._s(_vm.trans("data.report")) +
                                              "\n                        "
                                          ),
                                        ]
                                      )
                                    : _vm._e(),
                                ],
                                1
                              ),
                            ]),
                          ]),
                        ])
                      : _vm._e(),
                  ],
                  1
                ),
              ]
            },
          },
        ]),
      }),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);