"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_common_tickets_editVisitRequest_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/tickets/editVisitRequest.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/tickets/editVisitRequest.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _AddRequestType__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./AddRequestType */ "./resources/js/common/tickets/AddRequestType.vue");
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../store */ "./resources/js/store/index.js");
var _methods;
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  components: {
    AddRequestType: _AddRequestType__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  props: {
    propRequestId: {
      required: true
    }
  },
  data: function data() {
    var _ref;
    return _ref = {
      valid: true,
      id: '',
      type: '',
      isView: false,
      project_id: '',
      projects: [],
      enginnering_types: [],
      visit_request: null,
      loading: false,
      title: '',
      request_type: ''
    }, _defineProperty(_ref, "project_id", ''), _defineProperty(_ref, "description", ''), _defineProperty(_ref, "status", 'new'), _defineProperty(_ref, "priority", ''), _defineProperty(_ref, "customer_id", ''), _defineProperty(_ref, "statuses", []), _defineProperty(_ref, "employees", []), _defineProperty(_ref, "request_types", []), _defineProperty(_ref, "customers", []), _defineProperty(_ref, "priorities", []), _defineProperty(_ref, "request_type", ''), _defineProperty(_ref, "engennering_offices", []), _defineProperty(_ref, "office_id", ''), _defineProperty(_ref, "dead_line_date", null), _defineProperty(_ref, "note", ''), _defineProperty(_ref, "enginnering_type", ''), _ref;
  },
  created: function created() {},
  beforeDestroy: function beforeDestroy() {
    var self = this;
    self.$eventBus.$off('updateCategoryList');
  },
  mounted: function mounted() {
    var self = this;
    self.getCustomerProject();
    self.getEnginneringTypes();
    self.getCustomers();
    self.getOffices();
    this.loadRequest(function () {});
    self.$eventBus.$on('updateRequestTypeList', function (data) {
      //  self.request_types = [];
      // self.request_types = data;
    });
  },
  methods: (_methods = {
    getEnginneringTypes: function getEnginneringTypes() {
      var self = this;
      axios.get('/get-enginnering-types').then(function (response) {
        self.enginnering_types = response.data;
      })["catch"](function (err) {
        console.log(err.response.status);
        if (err.response.status === 401) {
          _store__WEBPACK_IMPORTED_MODULE_1__["default"].dispatch('auth/handleResponse', err.response);
        }
      });
      ;
    },
    validate: function validate() {
      this.$refs.form.validate();
    },
    reset: function reset() {
      this.$refs.form.reset();
    },
    resetValidation: function resetValidation() {
      this.$refs.form.resetValidation();
    },
    loadRequest: function loadRequest() {
      var self = this;
      axios.get('request/' + self.propRequestId).then(function (response) {
        var tmp = response.data.msg;
        self.id = tmp.request.id;
        self.enginnering_type = tmp.request.specialties != undefined ? tmp.request.specialties.map(function (x) {
          return x.id;
        }) : '';
        self.request_types = tmp.request_types;
        self.request_type = tmp.request.request_type;
        self.project_id = tmp.request.project_id;
        self.description = tmp.request.description;
        self.status = tmp.request.status;
        self.customer_id = tmp.request.customer_id;
        self.office_id = tmp.request.office_id;
        self.note = tmp.request.note;
        self.dead_line_date = tmp.request.dead_line_date;
      });
    },
    getCustomers: function getCustomers() {
      var self = this;
      axios.get('all-customers-admin').then(function (response) {
        self.customers = response.data;
      })["catch"](function (err) {
        console.log(err.response.status);
        if (err.response.status === 401) {
          _store__WEBPACK_IMPORTED_MODULE_1__["default"].dispatch('auth/handleResponse', err.response);
        }
      });
      ;
    },
    getOffices: function getOffices() {
      var self = this;
      axios.get('/get-offices').then(function (response) {
        self.engennering_offices = response.data;
      })["catch"](function (err) {
        console.log(err.response.status);
        if (err.response.status === 401) {
          _store__WEBPACK_IMPORTED_MODULE_1__["default"].dispatch('auth/handleResponse', err.response);
        }
      });
      ;
    }
  }, _defineProperty(_methods, "reset", function reset() {
    var self = this;
    self.title = '';
    self.request_type = '';
    self.project_id = '';
    self.description = '';
    self.status = '';
    self.priority = '';
    self.customer_id = '';
    self.office_id = '';
    self.note = ''; //
    self.enginnering_type = '';
  }), _defineProperty(_methods, "getCustomerProject", function getCustomerProject() {
    var self = this;
    axios.get('/projects-customer').then(function (response) {
      self.projects = response.data;
    })["catch"](function (err) {
      console.log(err.response.status);
      if (err.response.status === 401) {
        _store__WEBPACK_IMPORTED_MODULE_1__["default"].dispatch('auth/handleResponse', err.response);
      }
    });
    ;
  }), _defineProperty(_methods, "createRequestType", function createRequestType() {
    var self = this;
    self.$refs.RequestTypeAdd.create();
  }), _defineProperty(_methods, "updateEmployee", function updateEmployee(value, key) {
    var self = this;
    axios.get('get-customer-project/' + value).then(function (response) {
      self.customer_id = response.data.id;
    })["catch"](function (err) {
      console.log(err.response.status);
      if (err.response.status === 401) {
        _store__WEBPACK_IMPORTED_MODULE_1__["default"].dispatch('auth/handleResponse', err.response);
      }
    });
    ;
  }), _defineProperty(_methods, "update", function update() {
    var self = this;
    var data = {
      title: self.title,
      request_type: self.request_type,
      project_id: self.project_id,
      description: self.description,
      status: 'new',
      priority: self.priority,
      customer_id: self.customer_id,
      office_id: self.office_id,
      note: self.note,
      //
      dead_line_date: self.dead_line_date,
      enginnering_type: self.enginnering_type
    };
    if (this.$refs.form.validate()) {
      self.loading = true;
      axios.put('/request/' + self.id, data).then(function (response) {
        self.loading = false;
        self.$store.commit('showSnackbar', {
          message: response.data.msg,
          color: response.data.success
        });
        if (response.data.success === true) {
          self.$router.push({
            name: 'visit_request_list'
          });
        }
        self.reset();
      })["catch"](function (error) {
        console.log(error);
      });
    }
  }), _methods)
});

/***/ }),

/***/ "./resources/js/common/tickets/editVisitRequest.vue":
/*!**********************************************************!*\
  !*** ./resources/js/common/tickets/editVisitRequest.vue ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _editVisitRequest_vue_vue_type_template_id_75e17eac___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./editVisitRequest.vue?vue&type=template&id=75e17eac& */ "./resources/js/common/tickets/editVisitRequest.vue?vue&type=template&id=75e17eac&");
/* harmony import */ var _editVisitRequest_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./editVisitRequest.vue?vue&type=script&lang=js& */ "./resources/js/common/tickets/editVisitRequest.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _editVisitRequest_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _editVisitRequest_vue_vue_type_template_id_75e17eac___WEBPACK_IMPORTED_MODULE_0__.render,
  _editVisitRequest_vue_vue_type_template_id_75e17eac___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/common/tickets/editVisitRequest.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/common/tickets/editVisitRequest.vue?vue&type=script&lang=js&":
/*!***********************************************************************************!*\
  !*** ./resources/js/common/tickets/editVisitRequest.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_editVisitRequest_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./editVisitRequest.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/tickets/editVisitRequest.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_editVisitRequest_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/common/tickets/editVisitRequest.vue?vue&type=template&id=75e17eac&":
/*!*****************************************************************************************!*\
  !*** ./resources/js/common/tickets/editVisitRequest.vue?vue&type=template&id=75e17eac& ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_editVisitRequest_vue_vue_type_template_id_75e17eac___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_editVisitRequest_vue_vue_type_template_id_75e17eac___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_editVisitRequest_vue_vue_type_template_id_75e17eac___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./editVisitRequest.vue?vue&type=template&id=75e17eac& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/tickets/editVisitRequest.vue?vue&type=template&id=75e17eac&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/tickets/editVisitRequest.vue?vue&type=template&id=75e17eac&":
/*!********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/tickets/editVisitRequest.vue?vue&type=template&id=75e17eac& ***!
  \********************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "v-container",
    { attrs: { row: "", "justify-center": "" } },
    [
      _c("AddRequestType", { ref: "RequestTypeAdd" }),
      _vm._v(" "),
      _c(
        "v-card",
        [
          _c(
            "v-form",
            {
              ref: "form",
              attrs: { "lazy-validation": "" },
              model: {
                value: _vm.valid,
                callback: function ($$v) {
                  _vm.valid = $$v
                },
                expression: "valid",
              },
            },
            [
              _c("v-divider"),
              _vm._v(" "),
              _c(
                "v-card-text",
                [
                  _c(
                    "v-container",
                    { attrs: { "grid-list-md": "" } },
                    [
                      _c(
                        "v-layout",
                        { attrs: { row: "", wrap: "" } },
                        [
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm6: "", md6: "" } },
                            [
                              _c("v-autocomplete", {
                                attrs: {
                                  "item-text": "name",
                                  "item-value": "id",
                                  items: _vm.projects,
                                  label: _vm.trans("data.project_name"),
                                  rules: [
                                    function (v) {
                                      return (
                                        !!v ||
                                        _vm.trans("messages.required", {
                                          name: _vm.trans("data.project_name"),
                                        })
                                      )
                                    },
                                  ],
                                  required: "",
                                },
                                on: {
                                  change: function (event) {
                                    return _vm.updateEmployee(event, _vm.k)
                                  },
                                },
                                model: {
                                  value: _vm.project_id,
                                  callback: function ($$v) {
                                    _vm.project_id = $$v
                                  },
                                  expression: "project_id",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm6: "", md6: "" } },
                            [
                              _c("v-autocomplete", {
                                attrs: {
                                  "item-text": "name",
                                  "item-value": "id",
                                  readonly: true,
                                  items: _vm.customers,
                                  label: _vm.trans("messages.customer"),
                                  rules: [
                                    function (v) {
                                      return (
                                        !!v ||
                                        _vm.trans("messages.required", {
                                          name: _vm.trans("messages.customer"),
                                        })
                                      )
                                    },
                                  ],
                                  required: "",
                                },
                                model: {
                                  value: _vm.customer_id,
                                  callback: function ($$v) {
                                    _vm.customer_id = $$v
                                  },
                                  expression: "customer_id",
                                },
                              }),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "v-layout",
                        { attrs: { row: "" } },
                        [
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm6: "", md6: "" } },
                            [
                              _c("v-autocomplete", {
                                attrs: {
                                  "item-text": "name",
                                  "item-value": "id",
                                  items: _vm.engennering_offices,
                                  label: _vm.trans(
                                    "data.enginnering_office_name"
                                  ),
                                  rules: [
                                    function (v) {
                                      return (
                                        !!v ||
                                        _vm.trans("messages.required", {
                                          name: _vm.trans("messages.customer"),
                                        })
                                      )
                                    },
                                  ],
                                  required: "",
                                },
                                model: {
                                  value: _vm.office_id,
                                  callback: function ($$v) {
                                    _vm.office_id = $$v
                                  },
                                  expression: "office_id",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm6: "", md6: "" } },
                            [
                              _c("v-datetime-picker", {
                                attrs: {
                                  label: _vm.trans("data.visit_datetime"),
                                  datetime: _vm.dead_line_date,
                                  okText: _vm.trans("data.ok"),
                                  clearText: _vm.trans("data.clear"),
                                },
                                model: {
                                  value: _vm.dead_line_date,
                                  callback: function ($$v) {
                                    _vm.dead_line_date = $$v
                                  },
                                  expression: "dead_line_date",
                                },
                              }),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "v-layout",
                        { attrs: { row: "" } },
                        [
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm12: "", md12: "" } },
                            [
                              _c("v-autocomplete", {
                                attrs: {
                                  "item-text": "value",
                                  "item-value": "key",
                                  items: _vm.enginnering_types,
                                  label: _vm.trans("data.enginnering_type"),
                                  multiple: "",
                                  "data-vv-name": "enginnering_type",
                                  "data-vv-as": _vm.trans(
                                    "data.enginnering_type"
                                  ),
                                  "error-messages":
                                    _vm.errors.collect("enginnering_type"),
                                  required: "",
                                },
                                model: {
                                  value: _vm.enginnering_type,
                                  callback: function ($$v) {
                                    _vm.enginnering_type = $$v
                                  },
                                  expression: "enginnering_type",
                                },
                              }),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "v-layout",
                        { attrs: { row: "" } },
                        [
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm12: "", md12: "" } },
                            [
                              _c("v-text-field", {
                                attrs: { label: _vm.trans("data.note") },
                                model: {
                                  value: _vm.note,
                                  callback: function ($$v) {
                                    _vm.note = $$v
                                  },
                                  expression: "note",
                                },
                              }),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("v-divider"),
              _vm._v(" "),
              _c(
                "v-layout",
                { attrs: { "justify-center": "" } },
                [
                  _c(
                    "v-card-actions",
                    [
                      _c("v-spacer"),
                      _vm._v(" "),
                      _c(
                        "v-btn",
                        {
                          staticClass: "mr-4",
                          attrs: { color: "error" },
                          on: { click: _vm.reset },
                        },
                        [
                          _vm._v(
                            "\n                        " +
                              _vm._s(_vm.trans("data.reset")) +
                              "\n                    "
                          ),
                        ]
                      ),
                      _vm._v(" "),
                      _c(
                        "v-btn",
                        {
                          staticClass: "mr-4",
                          attrs: { disabled: !_vm.valid, color: "success" },
                          on: { click: _vm.update },
                        },
                        [
                          _vm._v(
                            "\n                        " +
                              _vm._s(_vm.trans("messages.update")) +
                              "\n                    "
                          ),
                        ]
                      ),
                      _vm._v(" "),
                      _c(
                        "v-btn",
                        {
                          staticStyle: { color: "#06706d" },
                          on: {
                            click: function ($event) {
                              return _vm.$router.go(-1)
                            },
                          },
                        },
                        [
                          _vm._v(
                            "\n                        " +
                              _vm._s(_vm.trans("messages.back")) +
                              "\n                    "
                          ),
                        ]
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);