"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_admin_expenses_List_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/expenses/Edit.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/expenses/Edit.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _common_projects_category_Add__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../common/projects/category/Add */ "./resources/js/common/projects/category/Add.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  components: {
    CategoryAdd: _common_projects_category_Add__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  data: function data() {
    return {
      dialog: false,
      categories: [],
      employees: [],
      projects: [],
      category_id: null,
      expense: [],
      transaction_date: '',
      due_date: '',
      loading: false,
      expense_id: null
    };
  },
  mounted: function mounted() {
    var self = this;
    self.$eventBus.$on('updateCategoryList', function (data) {
      self.categories.push(data);
      self.category_id = data.id;
    });
  },
  beforeDestroy: function beforeDestroy() {
    var self = this;
    self.$eventBus.$off('updateCategoryList');
  },
  methods: {
    edit: function edit(expense_id) {
      var self = this;
      self.$validator.reset();
      self.employees = [];
      self.categories = [];
      self.projects = [];
      self.expense = [];
      self.expense_id = expense_id;
      axios.get('/expenses/' + expense_id + '/edit').then(function (response) {
        self.expense = response.data.transaction;
        self.category_id = response.data.transaction.category_id;
        self.transaction_date = response.data.transaction.transaction_date;
        self.due_date = response.data.transaction.due_date;
        self.employees = response.data.employees;
        self.categories = response.data.categories;
        self.projects = response.data.projects;
        self.dialog = true;
      })["catch"](function (error) {
        console.log(error);
      });
    },
    createCategory: function createCategory() {
      var self = this;
      var data = {
        type: 'expenses'
      };
      self.$refs.categoryAdd.create(data);
    },
    store: function (_store) {
      function store() {
        return _store.apply(this, arguments);
      }
      store.toString = function () {
        return _store.toString();
      };
      return store;
    }(function () {
      var self = this;
      var data = _.pick(self.expense, ['ref_no', 'total', 'expense_for', 'project_id', 'notes']);
      data.category_id = self.category_id;
      data.transaction_date = self.transaction_date;
      data.due_date = self.due_date;
      self.$validator.validateAll().then(function (result) {
        if (result == true) {
          self.loading = true;
          axios.put('/expenses/' + self.expense_id, data).then(function (response) {
            self.loading = false;
            self.$store.commit('showSnackbar', {
              message: response.data.msg,
              color: response.data.success
            });
            if (response.data.success === true) {
              self.dialog = false;
              self.$eventBus.$emit('updateExpenseTable');
            }
          })["catch"](function (err) {
            console.log(err.response.status);
            if (err.response.status === 401) {
              store.dispatch('auth/handleResponse', err.response);
            }
          });
        }
      });
    })
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/expenses/List.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/expenses/List.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Add__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Add */ "./resources/js/admin/expenses/Add.vue");
/* harmony import */ var _Edit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Edit */ "./resources/js/admin/expenses/Edit.vue");
/* harmony import */ var _common_projects_invoices_payment_InvoicePayment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../common/projects/invoices/payment/InvoicePayment */ "./resources/js/common/projects/invoices/payment/InvoicePayment.vue");
/* harmony import */ var _common_projects_invoices_payment_ViewPayment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../common/projects/invoices/payment/ViewPayment */ "./resources/js/common/projects/invoices/payment/ViewPayment.vue");
/* harmony import */ var _status_StatusLabel__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../status/StatusLabel */ "./resources/js/admin/status/StatusLabel.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//






/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  components: {
    ExpenseAdd: _Add__WEBPACK_IMPORTED_MODULE_0__["default"],
    ExpenseEdit: _Edit__WEBPACK_IMPORTED_MODULE_1__["default"],
    ExpensePayment: _common_projects_invoices_payment_InvoicePayment__WEBPACK_IMPORTED_MODULE_2__["default"],
    ViewPayment: _common_projects_invoices_payment_ViewPayment__WEBPACK_IMPORTED_MODULE_3__["default"],
    StatusLabel: _status_StatusLabel__WEBPACK_IMPORTED_MODULE_4__["default"]
  },
  data: function data() {
    var self = this;
    return {
      total_items: 0,
      loading: false,
      pagination: {
        totalItems: 0
      },
      headers: [{
        text: self.trans('messages.action'),
        value: false,
        align: 'left',
        sortable: false
      }, {
        text: self.trans('data.id'),
        value: 'id',
        align: 'left',
        sortable: true
      }, {
        text: self.trans('messages.date'),
        value: 'transaction_date',
        align: 'left',
        sortable: true
      }, {
        text: self.trans('messages.due_date'),
        value: 'due_date',
        align: 'left',
        sortable: true
      }, {
        text: self.trans('messages.ref_no'),
        value: 'ref_no',
        align: 'left',
        sortable: true
      }, {
        text: self.trans('messages.payment_status'),
        value: 'payment_status',
        align: 'left',
        sortable: true
      }, {
        text: self.trans('messages.total_amount'),
        value: 'total',
        align: 'left',
        sortable: true
      }, {
        text: self.trans('messages.payment_due'),
        value: 'payment_due',
        align: 'left',
        sortable: true
      }, {
        text: self.trans('messages.expense_category'),
        value: 'category',
        align: 'left',
        sortable: true
      }, {
        text: self.trans('messages.expense_for'),
        value: 'expense_for',
        align: 'left',
        sortable: true
      }, {
        text: self.trans('messages.notes'),
        value: 'notes',
        align: 'left',
        sortable: false
      }],
      items: [],
      employees: [],
      expense: [],
      categories: [],
      paymentStatus: [],
      business_currency: [],
      tabs: 'tab-1',
      expense_stats: [],
      paid_amount: 0
    };
  },
  watch: {
    pagination: {
      handler: function handler() {
        this.getDataFromApi();
      }
    }
  },
  mounted: function mounted() {
    var self = this;
    self.getFilters();
    self.getStatistics();
    self.$eventBus.$on('updateExpenseTable', function (data) {
      self.getDataFromApi();
      self.getStatistics();
    });
    self.$eventBus.$on('updatePaymentTransaction', function (data) {
      self.getDataFromApi();
      self.getStatistics();
    });
  },
  beforeDestroy: function beforeDestroy() {
    var self = this;
    self.$eventBus.$off('updateExpenseTable');
    self.$eventBus.$off('updatePaymentTransaction');
  },
  methods: {
    getDataFromApi: function getDataFromApi() {
      var self = this;
      self.loading = true;
      var _self$pagination = self.pagination,
        sortBy = _self$pagination.sortBy,
        descending = _self$pagination.descending,
        page = _self$pagination.page,
        rowsPerPage = _self$pagination.rowsPerPage;
      var params = {
        sort_by: sortBy,
        descending: descending,
        page: page,
        rowsPerPage: rowsPerPage
      };
      if (self.expense.expense_for) {
        params['expense_for'] = self.expense.expense_for;
      }
      if (self.expense.category_id) {
        params['category_id'] = self.expense.category_id;
      }
      if (self.expense.payment_status) {
        params['payment_status'] = self.expense.payment_status;
      }
      axios.get('/expenses', {
        params: params
      }).then(function (response) {
        self.total_items = response.data.total;
        self.items = response.data.data;
        self.loading = false;
      })["catch"](function (error) {
        console.log(error);
      });
    },
    deleteExpense: function deleteExpense(expense) {
      var self = this;
      self.$store.commit('showDialog', {
        type: 'confirm',
        icon: 'warning',
        title: self.trans('messages.are_you_sure'),
        message: self.trans('messages.you_cant_restore_it'),
        okCb: function okCb() {
          axios["delete"]('/expenses/' + expense.id).then(function (response) {
            self.$store.commit('showSnackbar', {
              message: response.data.msg,
              color: response.data.success
            });
            if (response.data.success === true) {
              self.getDataFromApi();
              self.getStatistics();
            }
          })["catch"](function (err) {
            console.log(err.response.status);
            if (err.response.status === 401) {
              store.dispatch('auth/handleResponse', err.response);
            }
          });
        },
        cancelCb: function cancelCb() {
          console.log('CANCEL');
        }
      });
    },
    getFilters: function getFilters() {
      var self = this;
      axios.get('/expenses/get-filters').then(function (response) {
        self.employees = response.data.employees;
        self.categories = response.data.categories;
        self.paymentStatus = response.data.payment_statuses;
        self.business_currency = response.data.business_currency;
      })["catch"](function (error) {
        console.log(error);
      });
    },
    payDueAmountForExpense: function payDueAmountForExpense(item) {
      var data = {
        transaction_id: item.id,
        type: 'expense'
      };
      this.$refs.expensePayment.create(data);
    },
    viewPayment: function viewPayment(transaction_id) {
      var data = {
        transaction_id: transaction_id,
        type: 'expense'
      };
      this.$refs.viewPayment.view(data);
    },
    getStatistics: function getStatistics() {
      var self = this;
      axios.get('/expense-statistics').then(function (response) {
        self.expense_stats = response.data.payment_stats;
        self.paid_amount = response.data.paid_amount.paid_amount;
      })["catch"](function (error) {
        console.log(error);
      });
    },
    totalTransactionCount: function totalTransactionCount(transactions) {
      var total = 0;
      _.forEach(transactions, function (transaction) {
        total = _.add(total, parseInt(transaction.payment_status_count));
      });
      return total;
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/status/StatusLabel.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/status/StatusLabel.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  props: ['status'],
  methods: {
    color: function color(status) {
      if (status === 'approved' || status === 'paid' || status === 'closed') {
        return 'green lighten-1';
      } else if (status === 'cancelled' || status === 'due' || status === 'new' || status === 'urgent') {
        return 'red accent-2';
      } else if (status === 'pending' || status === 'partial') {
        return 'cyan lighten-2';
      } else if (status === 'open') {
        return 'pink lighten-1';
      } else if (status === 'low') {
        return 'yellow darken-4';
      } else if (status === 'medium') {
        return 'deep-orange lighten-2';
      } else if (status === 'high') {
        return 'red accent-1';
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/invoices/payment/InvoicePayment.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/invoices/payment/InvoicePayment.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _admin_popover_Popover__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../admin/popover/Popover */ "./resources/js/admin/popover/Popover.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  components: {
    Popover: _admin_popover_Popover__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  data: function data() {
    return {
      dialog: false,
      paid_on: null,
      transaction_id: null,
      transaction_total: null,
      payment_details: null,
      conversion_rate: null,
      show_conversion_rate: null,
      final_amount: null,
      max_val: null,
      loading: false
    };
  },
  methods: {
    create: function create(invoice_params) {
      var self = this;
      self.$validator.reset();
      self.payment_details = null;
      self.transaction_total = null;
      self.paid_on = null;
      self.conversion_rate = null;
      self.final_amount = null;
      self.transaction_id = invoice_params.transaction_id;
      axios.get('/transaction-payments/create', {
        params: {
          transaction_id: invoice_params.transaction_id,
          type: invoice_params.type
        }
      }).then(function (response) {
        self.transaction_total = response.data.transaction_total;
        self.max_val = response.data.transaction_total;
        self.show_conversion_rate = response.data.conversion_rate;
        self.dialog = true;
      })["catch"](function (error) {
        console.log(error);
      });
    },
    calculateFinalAmount: function calculateFinalAmount() {
      var self = this;
      var final_amount = _.multiply(self.transaction_total, self.conversion_rate);
      self.final_amount = _.floor(final_amount, 2);
    },
    calculateConversionRate: function calculateConversionRate() {
      var self = this;
      var rate = _.divide(self.final_amount, self.transaction_total);
      self.conversion_rate = _.floor(rate);
    },
    store: function (_store) {
      function store() {
        return _store.apply(this, arguments);
      }
      store.toString = function () {
        return _store.toString();
      };
      return store;
    }(function () {
      var self = this;
      var data = {
        transaction_id: self.transaction_id,
        amount: self.transaction_total,
        paid_on: self.paid_on,
        payment_details: self.payment_details,
        conversion_rate: self.conversion_rate
      };
      self.$validator.validateAll().then(function (result) {
        if (result == true) {
          self.loading = true;
          axios.post('/transaction-payments', data).then(function (response) {
            self.loading = false;
            self.dialog = false;
            self.$store.commit('showSnackbar', {
              message: response.data.msg,
              color: response.data.success
            });
            if (response.data.success === true) {
              self.$eventBus.$emit('updatePaymentTransaction');
            }
          })["catch"](function (err) {
            console.log(err.response.status);
            if (err.response.status === 401) {
              store.dispatch('auth/handleResponse', err.response);
            }
          });
        }
      });
    })
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/invoices/payment/ViewPayment.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/invoices/payment/ViewPayment.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  data: function data() {
    return {
      dialog: false,
      transaction: [],
      payments: [],
      employee: [],
      project: [],
      customer: [],
      customer_currency: [],
      business_currency: []
    };
  },
  methods: {
    view: function view(invoice_params) {
      var self = this;
      axios.get('/transaction-payments/' + invoice_params.transaction_id, {
        params: {
          type: invoice_params.type
        }
      }).then(function (response) {
        self.transaction = response.data.transaction;
        self.payments = response.data.transaction.payments;
        self.project = response.data.transaction.project;
        self.employee = response.data.transaction.expense_for;
        self.customer = response.data.transaction.customer;
        self.customer_currency = response.data.currency.customer;
        self.business_currency = response.data.currency.business;
        self.dialog = true;
      })["catch"](function (error) {
        console.log(error);
      });
    }
  }
});

/***/ }),

/***/ "./resources/js/admin/expenses/Edit.vue":
/*!**********************************************!*\
  !*** ./resources/js/admin/expenses/Edit.vue ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Edit_vue_vue_type_template_id_7d93f9d0___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Edit.vue?vue&type=template&id=7d93f9d0& */ "./resources/js/admin/expenses/Edit.vue?vue&type=template&id=7d93f9d0&");
/* harmony import */ var _Edit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Edit.vue?vue&type=script&lang=js& */ "./resources/js/admin/expenses/Edit.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Edit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Edit_vue_vue_type_template_id_7d93f9d0___WEBPACK_IMPORTED_MODULE_0__.render,
  _Edit_vue_vue_type_template_id_7d93f9d0___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/admin/expenses/Edit.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/admin/expenses/List.vue":
/*!**********************************************!*\
  !*** ./resources/js/admin/expenses/List.vue ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _List_vue_vue_type_template_id_6e4bd264___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./List.vue?vue&type=template&id=6e4bd264& */ "./resources/js/admin/expenses/List.vue?vue&type=template&id=6e4bd264&");
/* harmony import */ var _List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./List.vue?vue&type=script&lang=js& */ "./resources/js/admin/expenses/List.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _List_vue_vue_type_template_id_6e4bd264___WEBPACK_IMPORTED_MODULE_0__.render,
  _List_vue_vue_type_template_id_6e4bd264___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/admin/expenses/List.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/admin/status/StatusLabel.vue":
/*!***************************************************!*\
  !*** ./resources/js/admin/status/StatusLabel.vue ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _StatusLabel_vue_vue_type_template_id_2169abba___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./StatusLabel.vue?vue&type=template&id=2169abba& */ "./resources/js/admin/status/StatusLabel.vue?vue&type=template&id=2169abba&");
/* harmony import */ var _StatusLabel_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./StatusLabel.vue?vue&type=script&lang=js& */ "./resources/js/admin/status/StatusLabel.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _StatusLabel_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _StatusLabel_vue_vue_type_template_id_2169abba___WEBPACK_IMPORTED_MODULE_0__.render,
  _StatusLabel_vue_vue_type_template_id_2169abba___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/admin/status/StatusLabel.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/common/projects/invoices/payment/InvoicePayment.vue":
/*!**************************************************************************!*\
  !*** ./resources/js/common/projects/invoices/payment/InvoicePayment.vue ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _InvoicePayment_vue_vue_type_template_id_d154f0a8___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./InvoicePayment.vue?vue&type=template&id=d154f0a8& */ "./resources/js/common/projects/invoices/payment/InvoicePayment.vue?vue&type=template&id=d154f0a8&");
/* harmony import */ var _InvoicePayment_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./InvoicePayment.vue?vue&type=script&lang=js& */ "./resources/js/common/projects/invoices/payment/InvoicePayment.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _InvoicePayment_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _InvoicePayment_vue_vue_type_template_id_d154f0a8___WEBPACK_IMPORTED_MODULE_0__.render,
  _InvoicePayment_vue_vue_type_template_id_d154f0a8___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/common/projects/invoices/payment/InvoicePayment.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/common/projects/invoices/payment/ViewPayment.vue":
/*!***********************************************************************!*\
  !*** ./resources/js/common/projects/invoices/payment/ViewPayment.vue ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _ViewPayment_vue_vue_type_template_id_62673fc4___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ViewPayment.vue?vue&type=template&id=62673fc4& */ "./resources/js/common/projects/invoices/payment/ViewPayment.vue?vue&type=template&id=62673fc4&");
/* harmony import */ var _ViewPayment_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ViewPayment.vue?vue&type=script&lang=js& */ "./resources/js/common/projects/invoices/payment/ViewPayment.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _ViewPayment_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _ViewPayment_vue_vue_type_template_id_62673fc4___WEBPACK_IMPORTED_MODULE_0__.render,
  _ViewPayment_vue_vue_type_template_id_62673fc4___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/common/projects/invoices/payment/ViewPayment.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/admin/expenses/Edit.vue?vue&type=script&lang=js&":
/*!***********************************************************************!*\
  !*** ./resources/js/admin/expenses/Edit.vue?vue&type=script&lang=js& ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Edit.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/expenses/Edit.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/admin/expenses/List.vue?vue&type=script&lang=js&":
/*!***********************************************************************!*\
  !*** ./resources/js/admin/expenses/List.vue?vue&type=script&lang=js& ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./List.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/expenses/List.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/admin/status/StatusLabel.vue?vue&type=script&lang=js&":
/*!****************************************************************************!*\
  !*** ./resources/js/admin/status/StatusLabel.vue?vue&type=script&lang=js& ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_StatusLabel_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StatusLabel.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/status/StatusLabel.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_StatusLabel_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/common/projects/invoices/payment/InvoicePayment.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************!*\
  !*** ./resources/js/common/projects/invoices/payment/InvoicePayment.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InvoicePayment_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./InvoicePayment.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/invoices/payment/InvoicePayment.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_InvoicePayment_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/common/projects/invoices/payment/ViewPayment.vue?vue&type=script&lang=js&":
/*!************************************************************************************************!*\
  !*** ./resources/js/common/projects/invoices/payment/ViewPayment.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ViewPayment_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./ViewPayment.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/invoices/payment/ViewPayment.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ViewPayment_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/admin/expenses/Edit.vue?vue&type=template&id=7d93f9d0&":
/*!*****************************************************************************!*\
  !*** ./resources/js/admin/expenses/Edit.vue?vue&type=template&id=7d93f9d0& ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_template_id_7d93f9d0___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_template_id_7d93f9d0___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_template_id_7d93f9d0___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Edit.vue?vue&type=template&id=7d93f9d0& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/expenses/Edit.vue?vue&type=template&id=7d93f9d0&");


/***/ }),

/***/ "./resources/js/admin/expenses/List.vue?vue&type=template&id=6e4bd264&":
/*!*****************************************************************************!*\
  !*** ./resources/js/admin/expenses/List.vue?vue&type=template&id=6e4bd264& ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_6e4bd264___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_6e4bd264___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_6e4bd264___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./List.vue?vue&type=template&id=6e4bd264& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/expenses/List.vue?vue&type=template&id=6e4bd264&");


/***/ }),

/***/ "./resources/js/admin/status/StatusLabel.vue?vue&type=template&id=2169abba&":
/*!**********************************************************************************!*\
  !*** ./resources/js/admin/status/StatusLabel.vue?vue&type=template&id=2169abba& ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StatusLabel_vue_vue_type_template_id_2169abba___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StatusLabel_vue_vue_type_template_id_2169abba___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_StatusLabel_vue_vue_type_template_id_2169abba___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./StatusLabel.vue?vue&type=template&id=2169abba& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/status/StatusLabel.vue?vue&type=template&id=2169abba&");


/***/ }),

/***/ "./resources/js/common/projects/invoices/payment/InvoicePayment.vue?vue&type=template&id=d154f0a8&":
/*!*********************************************************************************************************!*\
  !*** ./resources/js/common/projects/invoices/payment/InvoicePayment.vue?vue&type=template&id=d154f0a8& ***!
  \*********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_InvoicePayment_vue_vue_type_template_id_d154f0a8___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_InvoicePayment_vue_vue_type_template_id_d154f0a8___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_InvoicePayment_vue_vue_type_template_id_d154f0a8___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./InvoicePayment.vue?vue&type=template&id=d154f0a8& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/invoices/payment/InvoicePayment.vue?vue&type=template&id=d154f0a8&");


/***/ }),

/***/ "./resources/js/common/projects/invoices/payment/ViewPayment.vue?vue&type=template&id=62673fc4&":
/*!******************************************************************************************************!*\
  !*** ./resources/js/common/projects/invoices/payment/ViewPayment.vue?vue&type=template&id=62673fc4& ***!
  \******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ViewPayment_vue_vue_type_template_id_62673fc4___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ViewPayment_vue_vue_type_template_id_62673fc4___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ViewPayment_vue_vue_type_template_id_62673fc4___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./ViewPayment.vue?vue&type=template&id=62673fc4& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/invoices/payment/ViewPayment.vue?vue&type=template&id=62673fc4&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/expenses/Edit.vue?vue&type=template&id=7d93f9d0&":
/*!********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/expenses/Edit.vue?vue&type=template&id=7d93f9d0& ***!
  \********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "v-layout",
    { attrs: { row: "", "justify-center": "" } },
    [
      _c("CategoryAdd", { ref: "categoryAdd" }),
      _vm._v(" "),
      _c(
        "v-dialog",
        {
          attrs: { width: "950" },
          model: {
            value: _vm.dialog,
            callback: function ($$v) {
              _vm.dialog = $$v
            },
            expression: "dialog",
          },
        },
        [
          _c(
            "v-card",
            [
              _c(
                "v-card-title",
                [
                  _c("v-icon", { attrs: { medium: "" } }, [
                    _vm._v("remove_circle_outline"),
                  ]),
                  _vm._v(" "),
                  _c("span", { staticClass: "headline" }, [
                    _vm._v(
                      "\n                    " +
                        _vm._s(_vm.trans("messages.edit_expense")) +
                        "\n                "
                    ),
                  ]),
                  _vm._v(" "),
                  _c("v-spacer"),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      attrs: { flat: "", icon: "" },
                      on: {
                        click: function ($event) {
                          _vm.dialog = false
                        },
                      },
                    },
                    [_c("v-icon", [_vm._v("clear")])],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("v-divider"),
              _vm._v(" "),
              _c(
                "v-card-text",
                [
                  _c(
                    "v-container",
                    { attrs: { "grid-list-md": "" } },
                    [
                      _c(
                        "v-layout",
                        { attrs: { wrap: "" } },
                        [
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", md3: "" } },
                            [
                              _c("v-autocomplete", {
                                directives: [
                                  {
                                    name: "validate",
                                    rawName: "v-validate",
                                    value: "required",
                                    expression: "'required'",
                                  },
                                ],
                                attrs: {
                                  "item-text": "name",
                                  "item-value": "id",
                                  items: _vm.categories,
                                  label: _vm.trans("messages.category"),
                                  "data-vv-name": "category",
                                  "data-vv-as": _vm.trans("messages.category"),
                                  "error-messages":
                                    _vm.errors.collect("category"),
                                  required: "",
                                },
                                model: {
                                  value: _vm.category_id,
                                  callback: function ($$v) {
                                    _vm.category_id = $$v
                                  },
                                  expression: "category_id",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { md1: "" } },
                            [
                              _c(
                                "v-btn",
                                {
                                  attrs: {
                                    small: "",
                                    color: "primary",
                                    fab: "",
                                    dark: "",
                                  },
                                  on: { click: _vm.createCategory },
                                },
                                [_c("v-icon", [_vm._v("add")])],
                                1
                              ),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs6: "", md4: "" } },
                            [
                              _c("v-text-field", {
                                attrs: { label: _vm.trans("messages.ref_no") },
                                model: {
                                  value: _vm.expense.ref_no,
                                  callback: function ($$v) {
                                    _vm.$set(_vm.expense, "ref_no", $$v)
                                  },
                                  expression: "expense.ref_no",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c("v-flex", { attrs: { xs12: "", md4: "" } }, [
                            _c(
                              "div",
                              {
                                staticClass:
                                  "v-input v-text-field theme--light",
                              },
                              [
                                _c("div", { staticClass: "v-input__control" }, [
                                  _c("div", { staticClass: "v-input__slot" }, [
                                    _c(
                                      "div",
                                      { staticClass: "v-text-field__slot" },
                                      [
                                        _c(
                                          "label",
                                          {
                                            staticClass:
                                              "v-label v-label--active theme--light flat_picker_label",
                                            attrs: { "aria-hidden": "true" },
                                          },
                                          [
                                            _vm._v(
                                              "\n                                                " +
                                                _vm._s(
                                                  _vm.trans("messages.date")
                                                ) +
                                                "\n                                            "
                                            ),
                                          ]
                                        ),
                                        _vm._v(" "),
                                        _c("flat-pickr", {
                                          directives: [
                                            {
                                              name: "validate",
                                              rawName: "v-validate",
                                              value: "required",
                                              expression: "'required'",
                                            },
                                          ],
                                          attrs: {
                                            name: "date",
                                            required: "",
                                            config: _vm.flatPickerDate(),
                                            "data-vv-as":
                                              _vm.trans("messages.date"),
                                          },
                                          model: {
                                            value: _vm.transaction_date,
                                            callback: function ($$v) {
                                              _vm.transaction_date = $$v
                                            },
                                            expression: "transaction_date",
                                          },
                                        }),
                                      ],
                                      1
                                    ),
                                  ]),
                                  _vm._v(" "),
                                  _c(
                                    "div",
                                    {
                                      staticClass:
                                        "v-messages theme--light error--text",
                                    },
                                    [
                                      _vm._v(
                                        "\n                                        " +
                                          _vm._s(_vm.errors.first("date")) +
                                          "\n                                    "
                                      ),
                                    ]
                                  ),
                                ]),
                              ]
                            ),
                          ]),
                          _vm._v(" "),
                          _c("v-flex", { attrs: { xs12: "", md3: "" } }, [
                            _c(
                              "div",
                              {
                                staticClass:
                                  "v-input v-text-field theme--light",
                              },
                              [
                                _c("div", { staticClass: "v-input__control" }, [
                                  _c("div", { staticClass: "v-input__slot" }, [
                                    _c(
                                      "div",
                                      { staticClass: "v-text-field__slot" },
                                      [
                                        _c(
                                          "label",
                                          {
                                            staticClass:
                                              "v-label v-label--active theme--light flat_picker_label",
                                            attrs: { "aria-hidden": "true" },
                                          },
                                          [
                                            _vm._v(
                                              "\n                                                " +
                                                _vm._s(
                                                  _vm.trans("messages.due_date")
                                                ) +
                                                "\n                                            "
                                            ),
                                          ]
                                        ),
                                        _vm._v(" "),
                                        _c("flat-pickr", {
                                          attrs: {
                                            name: "due_date",
                                            config: _vm.flatPickerDate(),
                                          },
                                          model: {
                                            value: _vm.due_date,
                                            callback: function ($$v) {
                                              _vm.due_date = $$v
                                            },
                                            expression: "due_date",
                                          },
                                        }),
                                      ],
                                      1
                                    ),
                                  ]),
                                ]),
                              ]
                            ),
                          ]),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", md3: "" } },
                            [
                              _c("v-text-field", {
                                directives: [
                                  {
                                    name: "validate",
                                    rawName: "v-validate",
                                    value: "required",
                                    expression: "'required'",
                                  },
                                ],
                                attrs: {
                                  type: "number",
                                  label: _vm.trans("messages.total"),
                                  "data-vv-name": "total",
                                  "data-vv-as": _vm.trans("messages.total"),
                                  "error-messages": _vm.errors.collect("total"),
                                  required: "",
                                },
                                model: {
                                  value: _vm.expense.total,
                                  callback: function ($$v) {
                                    _vm.$set(_vm.expense, "total", $$v)
                                  },
                                  expression: "expense.total",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", md3: "" } },
                            [
                              _c("v-autocomplete", {
                                attrs: {
                                  "item-text": "name",
                                  "item-value": "id",
                                  items: _vm.employees,
                                  label: _vm.trans("messages.expense_for"),
                                },
                                model: {
                                  value: _vm.expense.expense_for,
                                  callback: function ($$v) {
                                    _vm.$set(_vm.expense, "expense_for", $$v)
                                  },
                                  expression: "expense.expense_for",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", md3: "" } },
                            [
                              _c("v-autocomplete", {
                                attrs: {
                                  "item-text": "name",
                                  "item-value": "id",
                                  items: _vm.projects,
                                  label: _vm.trans("messages.project"),
                                },
                                model: {
                                  value: _vm.expense.project_id,
                                  callback: function ($$v) {
                                    _vm.$set(_vm.expense, "project_id", $$v)
                                  },
                                  expression: "expense.project_id",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm12: "", md12: "" } },
                            [
                              _c("v-textarea", {
                                attrs: {
                                  rows: "3",
                                  label: _vm.trans("messages.notes"),
                                },
                                model: {
                                  value: _vm.expense.notes,
                                  callback: function ($$v) {
                                    _vm.$set(_vm.expense, "notes", $$v)
                                  },
                                  expression: "expense.notes",
                                },
                              }),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("v-divider"),
              _vm._v(" "),
              _c(
                "v-card-actions",
                [
                  _c("v-spacer"),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      attrs: { color: "green darken-1", flat: "" },
                      on: {
                        click: function ($event) {
                          _vm.dialog = false
                        },
                      },
                    },
                    [
                      _vm._v(
                        "\n                    " +
                          _vm._s(_vm.trans("messages.close")) +
                          "\n                "
                      ),
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      attrs: {
                        color: "success",
                        loading: _vm.loading,
                        disabled: _vm.loading,
                      },
                      on: { click: _vm.store },
                    },
                    [
                      _vm._v(
                        "\n                    " +
                          _vm._s(_vm.trans("messages.update")) +
                          "\n                "
                      ),
                    ]
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/expenses/List.vue?vue&type=template&id=6e4bd264&":
/*!********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/expenses/List.vue?vue&type=template&id=6e4bd264& ***!
  \********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "component-wrap" },
    [
      _c("ExpenseAdd", { ref: "expenseAdd" }),
      _vm._v(" "),
      _c("ExpenseEdit", { ref: "expenseEdit" }),
      _vm._v(" "),
      _c("ExpensePayment", { ref: "expensePayment" }),
      _vm._v(" "),
      _c("ViewPayment", { ref: "viewPayment" }),
      _vm._v(" "),
      _c(
        "v-tabs",
        {
          staticClass: "elevation-3",
          attrs: { "fixed-tabs": "", height: "47" },
          model: {
            value: _vm.tabs,
            callback: function ($$v) {
              _vm.tabs = $$v
            },
            expression: "tabs",
          },
        },
        [
          _vm.$can("superadmin")
            ? _c(
                "v-tab",
                { attrs: { href: "#tab-1" }, on: { click: _vm.getStatistics } },
                [
                  _c("v-icon", [_vm._v("bar_chart")]),
                  _vm._v(
                    "\n            " +
                      _vm._s(_vm.trans("messages.statistics")) +
                      "\n        "
                  ),
                ],
                1
              )
            : _vm._e(),
          _vm._v(" "),
          _c(
            "v-tab",
            { attrs: { href: "#tab-2" } },
            [
              _c("v-icon", [_vm._v("filter_list")]),
              _vm._v(
                "\n            " +
                  _vm._s(_vm.trans("messages.filters")) +
                  "\n        "
              ),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "v-tabs-items",
        {
          model: {
            value: _vm.tabs,
            callback: function ($$v) {
              _vm.tabs = $$v
            },
            expression: "tabs",
          },
        },
        [
          _c("v-divider"),
          _vm._v(" "),
          _vm.$can("superadmin")
            ? _c(
                "v-tab-item",
                { attrs: { value: "tab-1" } },
                [
                  _c(
                    "v-card",
                    { staticClass: "elevation-2", attrs: { flat: "" } },
                    [
                      _c(
                        "v-card-text",
                        [
                          _c(
                            "v-container",
                            { attrs: { "grid-list-md": "" } },
                            [
                              _c(
                                "v-layout",
                                { attrs: { row: "", wrap: "" } },
                                [
                                  _c(
                                    "v-flex",
                                    { attrs: { xs12: "", sm3: "", md3: "" } },
                                    [
                                      _c(
                                        "span",
                                        {
                                          staticClass:
                                            "subheading font-weight-medium primary--text",
                                        },
                                        [
                                          _vm._v(
                                            "\n                                    " +
                                              _vm._s(
                                                _vm.trans("messages.total")
                                              ) +
                                              ":\n                                    " +
                                              _vm._s(
                                                _vm.totalTransactionCount(
                                                  _vm.expense_stats
                                                )
                                              ) +
                                              "\n                                "
                                          ),
                                        ]
                                      ),
                                    ]
                                  ),
                                  _vm._v(" "),
                                  _vm._l(
                                    _vm.expense_stats,
                                    function (payment, index) {
                                      return _c(
                                        "v-flex",
                                        {
                                          key: index,
                                          attrs: { xs12: "", sm3: "", md3: "" },
                                        },
                                        [
                                          _vm._.includes(
                                            ["due"],
                                            payment.payment_status
                                          )
                                            ? _c(
                                                "span",
                                                {
                                                  staticClass:
                                                    "subheading font-weight-medium error--text",
                                                },
                                                [
                                                  _vm._v(
                                                    "\n                                    " +
                                                      _vm._s(
                                                        _vm.trans(
                                                          "messages.due"
                                                        )
                                                      ) +
                                                      ":\n                                    " +
                                                      _vm._s(
                                                        payment.payment_status_count
                                                      ) +
                                                      "\n                                "
                                                  ),
                                                ]
                                              )
                                            : _vm._e(),
                                          _vm._v(" "),
                                          _vm._.includes(
                                            ["partial"],
                                            payment.payment_status
                                          )
                                            ? _c(
                                                "span",
                                                {
                                                  staticClass:
                                                    "subheading font-weight-medium cyan--text",
                                                },
                                                [
                                                  _vm._v(
                                                    "\n                                    " +
                                                      _vm._s(
                                                        _vm.trans(
                                                          "messages.partial"
                                                        )
                                                      ) +
                                                      ":\n                                    " +
                                                      _vm._s(
                                                        payment.payment_status_count
                                                      ) +
                                                      "\n                                "
                                                  ),
                                                ]
                                              )
                                            : _vm._e(),
                                          _vm._v(" "),
                                          _vm._.includes(
                                            ["paid"],
                                            payment.payment_status
                                          )
                                            ? _c(
                                                "span",
                                                {
                                                  staticClass:
                                                    "subheading font-weight-medium success--text",
                                                },
                                                [
                                                  _vm._v(
                                                    "\n                                    " +
                                                      _vm._s(
                                                        _vm.trans(
                                                          "messages.paid"
                                                        )
                                                      ) +
                                                      ":\n                                    " +
                                                      _vm._s(
                                                        payment.payment_status_count
                                                      ) +
                                                      "\n                                "
                                                  ),
                                                ]
                                              )
                                            : _vm._e(),
                                        ]
                                      )
                                    }
                                  ),
                                  _vm._v(" "),
                                  _c(
                                    "v-flex",
                                    { attrs: { xs12: "", sm3: "", md3: "" } },
                                    [
                                      _c(
                                        "span",
                                        {
                                          staticClass:
                                            "subheading font-weight-medium success--text",
                                        },
                                        [
                                          _vm._v(
                                            "\n                                    " +
                                              _vm._s(
                                                _vm.trans(
                                                  "messages.paid_amount"
                                                )
                                              ) +
                                              ":\n                                    " +
                                              _vm._s(
                                                _vm._f("formatMoney")(
                                                  _vm.paid_amount,
                                                  _vm.business_currency.symbol
                                                )
                                              ) +
                                              "\n                                "
                                          ),
                                        ]
                                      ),
                                    ]
                                  ),
                                ],
                                2
                              ),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              )
            : _vm._e(),
          _vm._v(" "),
          _c(
            "v-tab-item",
            { attrs: { value: "tab-2" } },
            [
              _c(
                "v-card",
                { staticClass: "elevation-2", attrs: { flat: "" } },
                [
                  _c(
                    "v-card-text",
                    [
                      _c(
                        "v-container",
                        { attrs: { "grid-list-md": "" } },
                        [
                          _c(
                            "v-layout",
                            { attrs: { wrap: "" } },
                            [
                              _c(
                                "v-flex",
                                { attrs: { xs12: "", md4: "" } },
                                [
                                  _c("v-autocomplete", {
                                    attrs: {
                                      "item-text": "name",
                                      "item-value": "id",
                                      items: _vm.employees,
                                      label: _vm.trans("messages.expense_for"),
                                    },
                                    on: { change: _vm.getDataFromApi },
                                    model: {
                                      value: _vm.expense.expense_for,
                                      callback: function ($$v) {
                                        _vm.$set(
                                          _vm.expense,
                                          "expense_for",
                                          $$v
                                        )
                                      },
                                      expression: "expense.expense_for",
                                    },
                                  }),
                                ],
                                1
                              ),
                              _vm._v(" "),
                              _c(
                                "v-flex",
                                { attrs: { xs12: "", md4: "" } },
                                [
                                  _c("v-autocomplete", {
                                    attrs: {
                                      "item-text": "name",
                                      "item-value": "id",
                                      items: _vm.categories,
                                      label: _vm.trans("messages.category"),
                                    },
                                    on: { change: _vm.getDataFromApi },
                                    model: {
                                      value: _vm.expense.category_id,
                                      callback: function ($$v) {
                                        _vm.$set(
                                          _vm.expense,
                                          "category_id",
                                          $$v
                                        )
                                      },
                                      expression: "expense.category_id",
                                    },
                                  }),
                                ],
                                1
                              ),
                              _vm._v(" "),
                              _c(
                                "v-flex",
                                { attrs: { xs12: "", md4: "" } },
                                [
                                  _c("v-autocomplete", {
                                    attrs: {
                                      "item-text": "label",
                                      "item-value": "value",
                                      items: _vm.paymentStatus,
                                      label: _vm.trans(
                                        "messages.payment_status"
                                      ),
                                    },
                                    on: { change: _vm.getDataFromApi },
                                    model: {
                                      value: _vm.expense.payment_status,
                                      callback: function ($$v) {
                                        _vm.$set(
                                          _vm.expense,
                                          "payment_status",
                                          $$v
                                        )
                                      },
                                      expression: "expense.payment_status",
                                    },
                                  }),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "v-card",
        { staticClass: "mt-3" },
        [
          _c(
            "v-card-title",
            [
              _c("div", [
                _c("div", { staticClass: "headline" }, [
                  _vm._v(
                    "\n                    " +
                      _vm._s(_vm.trans("messages.all_expenses")) +
                      "\n                "
                  ),
                ]),
              ]),
              _vm._v(" "),
              _c("v-spacer"),
              _vm._v(" "),
              _vm.$can("expense.create")
                ? _c(
                    "v-btn",
                    {
                      staticClass: "primary lighten-1",
                      attrs: { dark: "" },
                      on: {
                        click: function ($event) {
                          return _vm.$refs.expenseAdd.create()
                        },
                      },
                    },
                    [
                      _vm._v(
                        "\n                " +
                          _vm._s(_vm.trans("messages.add_expense")) +
                          "\n                "
                      ),
                      _c("v-icon", { attrs: { right: "", dark: "" } }, [
                        _vm._v("add"),
                      ]),
                    ],
                    1
                  )
                : _vm._e(),
            ],
            1
          ),
          _vm._v(" "),
          _c("v-divider"),
          _vm._v(" "),
          _c("v-data-table", {
            staticClass: "elevation-3 w-full",
            attrs: {
              headers: _vm.headers,
              pagination: _vm.pagination,
              "total-items": _vm.total_items,
              loading: _vm.loading,
              items: _vm.items,
            },
            on: {
              "update:pagination": function ($event) {
                _vm.pagination = $event
              },
            },
            scopedSlots: _vm._u([
              {
                key: "headerCell",
                fn: function (props) {
                  return [
                    props.header.value == "transaction_date"
                      ? _c("span", [
                          _vm._v(
                            "\n                    " +
                              _vm._s(props.header.text) +
                              "\n                "
                          ),
                        ])
                      : props.header.value == "ref_no"
                      ? _c("span", [
                          _vm._v(
                            "\n                    " +
                              _vm._s(props.header.text) +
                              "\n                "
                          ),
                        ])
                      : props.header.value == "category"
                      ? _c("span", [
                          _vm._v(
                            "\n                    " +
                              _vm._s(props.header.text) +
                              "\n                "
                          ),
                        ])
                      : props.header.value == "payment_status"
                      ? _c("span", [
                          _vm._v(
                            "\n                    " +
                              _vm._s(props.header.text) +
                              "\n                "
                          ),
                        ])
                      : props.header.value == "total"
                      ? _c("span", [
                          _vm._v(
                            "\n                    " +
                              _vm._s(props.header.text) +
                              "\n                "
                          ),
                        ])
                      : props.header.value == "notes"
                      ? _c("span", [
                          _vm._v(
                            "\n                    " +
                              _vm._s(props.header.text) +
                              "\n                "
                          ),
                        ])
                      : _c("span", [_vm._v(_vm._s(props.header.text))]),
                  ]
                },
              },
              {
                key: "items",
                fn: function (props) {
                  return [
                    _c(
                      "td",
                      [
                        _c(
                          "v-menu",
                          [
                            _c(
                              "v-btn",
                              {
                                attrs: { slot: "activator", icon: "" },
                                slot: "activator",
                              },
                              [_c("v-icon", [_vm._v("more_vert")])],
                              1
                            ),
                            _vm._v(" "),
                            _c(
                              "v-list",
                              [
                                _vm.$can("expense.edit")
                                  ? _c(
                                      "v-list-tile",
                                      {
                                        on: {
                                          click: function ($event) {
                                            return _vm.$refs.expenseEdit.edit(
                                              props.item.id
                                            )
                                          },
                                        },
                                      },
                                      [
                                        _c(
                                          "v-list-tile-title",
                                          [
                                            _c(
                                              "v-icon",
                                              {
                                                staticClass: "mr-2",
                                                attrs: { small: "" },
                                              },
                                              [_vm._v(" edit ")]
                                            ),
                                            _vm._v(
                                              "\n                                    " +
                                                _vm._s(
                                                  _vm.trans("messages.edit")
                                                ) +
                                                "\n                                "
                                            ),
                                          ],
                                          1
                                        ),
                                      ],
                                      1
                                    )
                                  : _vm._e(),
                                _vm._v(" "),
                                _vm.$can("expense.delete")
                                  ? _c(
                                      "v-list-tile",
                                      {
                                        on: {
                                          click: function ($event) {
                                            return _vm.deleteExpense(props.item)
                                          },
                                        },
                                      },
                                      [
                                        _c(
                                          "v-list-tile-title",
                                          [
                                            _c(
                                              "v-icon",
                                              {
                                                staticClass: "mr-2",
                                                attrs: { small: "" },
                                              },
                                              [_vm._v(" delete_forever ")]
                                            ),
                                            _vm._v(
                                              "\n                                    " +
                                                _vm._s(
                                                  _vm.trans("messages.delete")
                                                ) +
                                                "\n                                "
                                            ),
                                          ],
                                          1
                                        ),
                                      ],
                                      1
                                    )
                                  : _vm._e(),
                                _vm._v(" "),
                                props.item.payment_status !== "paid" &&
                                props.item.status === "final" &&
                                _vm.$can("expense.create")
                                  ? _c(
                                      "v-list-tile",
                                      {
                                        on: {
                                          click: function ($event) {
                                            return _vm.payDueAmountForExpense(
                                              props.item
                                            )
                                          },
                                        },
                                      },
                                      [
                                        _c(
                                          "v-list-tile-title",
                                          [
                                            _c(
                                              "v-icon",
                                              {
                                                staticClass: "mr-2",
                                                attrs: { small: "" },
                                              },
                                              [_vm._v(" credit_card ")]
                                            ),
                                            _vm._v(
                                              "\n                                    " +
                                                _vm._s(
                                                  _vm.trans(
                                                    "messages.pay_due_amount"
                                                  )
                                                ) +
                                                "\n                                "
                                            ),
                                          ],
                                          1
                                        ),
                                      ],
                                      1
                                    )
                                  : _vm._e(),
                                _vm._v(" "),
                                props.item.payment_status !== "due" &&
                                _vm.$can("expense.create")
                                  ? _c(
                                      "v-list-tile",
                                      {
                                        on: {
                                          click: function ($event) {
                                            return _vm.viewPayment(
                                              props.item.id
                                            )
                                          },
                                        },
                                      },
                                      [
                                        _c(
                                          "v-list-tile-title",
                                          [
                                            _c(
                                              "v-icon",
                                              {
                                                staticClass: "mr-2",
                                                attrs: { small: "" },
                                              },
                                              [_vm._v(" visibility ")]
                                            ),
                                            _vm._v(
                                              "\n                                    " +
                                                _vm._s(
                                                  _vm.trans(
                                                    "messages.view_payment"
                                                  )
                                                ) +
                                                "\n                                "
                                            ),
                                          ],
                                          1
                                        ),
                                      ],
                                      1
                                    )
                                  : _vm._e(),
                              ],
                              1
                            ),
                          ],
                          1
                        ),
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c("td", [_vm._v(_vm._s(props.item.id))]),
                    _vm._v(" "),
                    _c("td", [
                      _vm._v(
                        _vm._s(
                          _vm._f("formatDate")(props.item.transaction_date)
                        )
                      ),
                    ]),
                    _vm._v(" "),
                    _c("td", [
                      _vm._v(_vm._s(_vm._f("formatDate")(props.item.due_date))),
                    ]),
                    _vm._v(" "),
                    _c("td", [_vm._v(_vm._s(props.item.ref_no))]),
                    _vm._v(" "),
                    _c(
                      "td",
                      [
                        _c("status-label", {
                          attrs: { status: props.item.payment_status },
                        }),
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c("td", [
                      _vm._v(
                        _vm._s(
                          _vm._f("formatMoney")(
                            props.item.total,
                            _vm.business_currency.symbol
                          )
                        )
                      ),
                    ]),
                    _vm._v(" "),
                    _c("td", [
                      _vm._v(
                        _vm._s(
                          _vm._f("formatMoney")(
                            props.item.payment_due,
                            _vm.business_currency.symbol
                          )
                        )
                      ),
                    ]),
                    _vm._v(" "),
                    _c("td", [_vm._v(_vm._s(props.item.category))]),
                    _vm._v(" "),
                    _c("td", [_vm._v(_vm._s(props.item.expense_for))]),
                    _vm._v(" "),
                    _c("td", [_vm._v(_vm._s(props.item.notes))]),
                  ]
                },
              },
            ]),
          }),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/status/StatusLabel.vue?vue&type=template&id=2169abba&":
/*!*************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/status/StatusLabel.vue?vue&type=template&id=2169abba& ***!
  \*************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "v-chip",
    { attrs: { label: "", small: "", color: _vm.color(_vm.status) } },
    [_c("small", [_vm._v(_vm._s(_vm.trans("messages." + _vm.status)))])]
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/invoices/payment/InvoicePayment.vue?vue&type=template&id=d154f0a8&":
/*!************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/invoices/payment/InvoicePayment.vue?vue&type=template&id=d154f0a8& ***!
  \************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "component-wrap" },
    [
      _c(
        "v-layout",
        { attrs: { row: "", "justify-center": "" } },
        [
          _c(
            "v-dialog",
            {
              attrs: { "max-width": "700" },
              model: {
                value: _vm.dialog,
                callback: function ($$v) {
                  _vm.dialog = $$v
                },
                expression: "dialog",
              },
            },
            [
              _c(
                "v-card",
                [
                  _c(
                    "v-card-title",
                    [
                      _c("v-icon", { attrs: { medium: "" } }, [
                        _vm._v("money"),
                      ]),
                      _vm._v(" "),
                      _c("span", { staticClass: "headline" }, [
                        _vm._v(
                          "\n                        " +
                            _vm._s(_vm.trans("messages.payment")) +
                            "\n                    "
                        ),
                      ]),
                      _vm._v(" "),
                      _c("v-spacer"),
                      _vm._v(" "),
                      _c(
                        "v-btn",
                        {
                          attrs: { flat: "", small: "", icon: "" },
                          on: {
                            click: function ($event) {
                              _vm.dialog = false
                            },
                          },
                        },
                        [_c("v-icon", [_vm._v("clear")])],
                        1
                      ),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("v-divider"),
                  _vm._v(" "),
                  _c(
                    "v-card-text",
                    [
                      _c(
                        "v-container",
                        { attrs: { "grid-list-md": "" } },
                        [
                          _c(
                            "v-layout",
                            { attrs: { wrap: "" } },
                            [
                              _c(
                                "v-flex",
                                { attrs: { xs12: "", sm6: "", md6: "" } },
                                [
                                  _c("v-text-field", {
                                    directives: [
                                      {
                                        name: "validate",
                                        rawName: "v-validate",
                                        value: "max_value:" + _vm.max_val,
                                        expression: "'max_value:' + max_val",
                                      },
                                    ],
                                    attrs: {
                                      type: "number",
                                      label: _vm.trans("messages.amount"),
                                      "data-vv-name": "amount",
                                      "data-vv-as":
                                        _vm.trans("messages.amount"),
                                      "error-messages":
                                        _vm.errors.collect("amount"),
                                      required: "",
                                    },
                                    model: {
                                      value: _vm.transaction_total,
                                      callback: function ($$v) {
                                        _vm.transaction_total = $$v
                                      },
                                      expression: "transaction_total",
                                    },
                                  }),
                                ],
                                1
                              ),
                              _vm._v(" "),
                              _vm.show_conversion_rate == "true"
                                ? _c(
                                    "v-flex",
                                    { attrs: { xs12: "", sm6: "", md6: "" } },
                                    [
                                      _c(
                                        "v-text-field",
                                        {
                                          directives: [
                                            {
                                              name: "validate",
                                              rawName: "v-validate",
                                              value: "required",
                                              expression: "'required'",
                                            },
                                          ],
                                          attrs: {
                                            type: "number",
                                            label: _vm.trans(
                                              "messages.conversion_rate"
                                            ),
                                            "data-vv-name": "conversion_rate",
                                            "data-vv-as": _vm.trans(
                                              "messages.conversion_rate"
                                            ),
                                            "error-messages":
                                              _vm.errors.collect(
                                                "conversion_rate"
                                              ),
                                            required: "",
                                          },
                                          on: {
                                            change: _vm.calculateFinalAmount,
                                          },
                                          model: {
                                            value: _vm.conversion_rate,
                                            callback: function ($$v) {
                                              _vm.conversion_rate = $$v
                                            },
                                            expression: "conversion_rate",
                                          },
                                        },
                                        [
                                          _c("Popover", {
                                            attrs: {
                                              slot: "append",
                                              helptext: _vm.trans(
                                                "messages.tooltip_conversion_rate"
                                              ),
                                            },
                                            slot: "append",
                                          }),
                                        ],
                                        1
                                      ),
                                    ],
                                    1
                                  )
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.show_conversion_rate == "true"
                                ? _c(
                                    "v-flex",
                                    { attrs: { xs12: "", sm6: "", md6: "" } },
                                    [
                                      _c(
                                        "v-text-field",
                                        {
                                          directives: [
                                            {
                                              name: "validate",
                                              rawName: "v-validate",
                                              value: "required",
                                              expression: "'required'",
                                            },
                                          ],
                                          attrs: {
                                            type: "number",
                                            label: _vm.trans(
                                              "messages.final_amount"
                                            ),
                                            "data-vv-name": "final_amount",
                                            "data-vv-as": _vm.trans(
                                              "messages.final_amount"
                                            ),
                                            "error-messages":
                                              _vm.errors.collect(
                                                "final_amount"
                                              ),
                                            required: "",
                                          },
                                          on: {
                                            change: _vm.calculateConversionRate,
                                          },
                                          model: {
                                            value: _vm.final_amount,
                                            callback: function ($$v) {
                                              _vm.final_amount = $$v
                                            },
                                            expression: "final_amount",
                                          },
                                        },
                                        [
                                          _c("Popover", {
                                            attrs: {
                                              slot: "append",
                                              helptext: _vm.trans(
                                                "messages.tooltip_final_amount"
                                              ),
                                            },
                                            slot: "append",
                                          }),
                                        ],
                                        1
                                      ),
                                    ],
                                    1
                                  )
                                : _vm._e(),
                              _vm._v(" "),
                              _c(
                                "v-flex",
                                { attrs: { xs12: "", sm6: "", md6: "" } },
                                [
                                  _c(
                                    "div",
                                    {
                                      staticClass:
                                        "v-input v-text-field theme--light",
                                    },
                                    [
                                      _c(
                                        "div",
                                        { staticClass: "v-input__control" },
                                        [
                                          _c(
                                            "div",
                                            { staticClass: "v-input__slot" },
                                            [
                                              _c(
                                                "div",
                                                {
                                                  staticClass:
                                                    "v-text-field__slot",
                                                },
                                                [
                                                  _c(
                                                    "label",
                                                    {
                                                      staticClass:
                                                        "v-label v-label--active theme--light flat_picker_label",
                                                      attrs: {
                                                        "aria-hidden": "true",
                                                      },
                                                    },
                                                    [
                                                      _vm._v(
                                                        "\n                                                    " +
                                                          _vm._s(
                                                            _vm.trans(
                                                              "messages.paid_on"
                                                            )
                                                          ) +
                                                          "\n                                                "
                                                      ),
                                                    ]
                                                  ),
                                                  _vm._v(" "),
                                                  _c("flat-pickr", {
                                                    directives: [
                                                      {
                                                        name: "validate",
                                                        rawName: "v-validate",
                                                        value: "required",
                                                        expression:
                                                          "'required'",
                                                      },
                                                    ],
                                                    attrs: {
                                                      name: "paid_on",
                                                      required: "",
                                                      config:
                                                        _vm.flatPickerDate(),
                                                      "data-vv-as":
                                                        _vm.trans(
                                                          "messages.paid_on"
                                                        ),
                                                    },
                                                    model: {
                                                      value: _vm.paid_on,
                                                      callback: function ($$v) {
                                                        _vm.paid_on = $$v
                                                      },
                                                      expression: "paid_on",
                                                    },
                                                  }),
                                                ],
                                                1
                                              ),
                                            ]
                                          ),
                                          _vm._v(" "),
                                          _c(
                                            "div",
                                            {
                                              staticClass:
                                                "v-messages theme--light error--text",
                                            },
                                            [
                                              _vm._v(
                                                "\n                                            " +
                                                  _vm._s(
                                                    _vm.errors.first("paid_on")
                                                  ) +
                                                  "\n                                        "
                                              ),
                                            ]
                                          ),
                                        ]
                                      ),
                                    ]
                                  ),
                                ]
                              ),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-layout",
                            { attrs: { wrap: "" } },
                            [
                              _c(
                                "v-flex",
                                { attrs: { xs12: "", sm12: "", md12: "" } },
                                [
                                  _c("v-textarea", {
                                    attrs: {
                                      rows: "3",
                                      label: _vm.trans(
                                        "messages.payment_details"
                                      ),
                                    },
                                    model: {
                                      value: _vm.payment_details,
                                      callback: function ($$v) {
                                        _vm.payment_details = $$v
                                      },
                                      expression: "payment_details",
                                    },
                                  }),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "v-card-actions",
                    [
                      _c("v-spacer"),
                      _vm._v(" "),
                      _c(
                        "v-btn",
                        {
                          attrs: { color: "green darken-1", flat: "" },
                          on: {
                            click: function ($event) {
                              _vm.dialog = false
                            },
                          },
                        },
                        [
                          _vm._v(
                            "\n                        " +
                              _vm._s(_vm.trans("messages.close")) +
                              "\n                    "
                          ),
                        ]
                      ),
                      _vm._v(" "),
                      _c(
                        "v-btn",
                        {
                          attrs: {
                            color: "success",
                            loading: _vm.loading,
                            disabled: _vm.loading,
                          },
                          on: { click: _vm.store },
                        },
                        [
                          _vm._v(
                            "\n                        " +
                              _vm._s(_vm.trans("messages.pay")) +
                              "\n                    "
                          ),
                        ]
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/invoices/payment/ViewPayment.vue?vue&type=template&id=62673fc4&":
/*!*********************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/invoices/payment/ViewPayment.vue?vue&type=template&id=62673fc4& ***!
  \*********************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "component-wrap" },
    [
      _c(
        "v-layout",
        { attrs: { row: "", "justify-center": "" } },
        [
          _c(
            "v-dialog",
            {
              attrs: { "max-width": "700" },
              model: {
                value: _vm.dialog,
                callback: function ($$v) {
                  _vm.dialog = $$v
                },
                expression: "dialog",
              },
            },
            [
              _c(
                "v-card",
                [
                  _c(
                    "v-card-title",
                    [
                      _c("v-icon", { attrs: { medium: "" } }, [
                        _vm._v("money"),
                      ]),
                      _vm._v(" "),
                      _c("span", { staticClass: "headline" }, [
                        _vm._v(
                          " " + _vm._s(_vm.trans("messages.view_payment")) + " "
                        ),
                      ]),
                      _vm._v(" "),
                      _c("v-spacer"),
                      _vm._v(" "),
                      _c(
                        "v-btn",
                        {
                          attrs: { flat: "", small: "", icon: "" },
                          on: {
                            click: function ($event) {
                              _vm.dialog = false
                            },
                          },
                        },
                        [_c("v-icon", [_vm._v("clear")])],
                        1
                      ),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("v-divider"),
                  _vm._v(" "),
                  _c(
                    "v-card-text",
                    [
                      _c(
                        "v-container",
                        { attrs: { "grid-list-md": "" } },
                        [
                          _c(
                            "v-layout",
                            { attrs: { wrap: "" } },
                            [
                              _c(
                                "v-flex",
                                { attrs: { xs12: "", sm4: "", md4: "" } },
                                [
                                  _vm.transaction.ref_no
                                    ? _c("div", [
                                        _c("strong", [
                                          _vm._v(
                                            " " +
                                              _vm._s(
                                                _vm.trans("messages.ref_no")
                                              ) +
                                              ": "
                                          ),
                                        ]),
                                        _vm._v(" "),
                                        _c("span", [
                                          _vm._v(
                                            " " + _vm._s(_vm.transaction.ref_no)
                                          ),
                                        ]),
                                        _vm._v(" "),
                                        _c("br"),
                                      ])
                                    : _vm._e(),
                                  _vm._v(" "),
                                  _c("strong", [
                                    _vm._v(
                                      " " +
                                        _vm._s(
                                          _vm.trans("messages.payment_status")
                                        ) +
                                        ": "
                                    ),
                                  ]),
                                  _vm._v(
                                    "\n                                " +
                                      _vm._s(
                                        _vm.trans(
                                          "messages." +
                                            _vm.transaction.payment_status
                                        )
                                      ) +
                                      "\n                                "
                                  ),
                                  _c("br"),
                                  _vm._v(" "),
                                  _c("strong", [
                                    _vm._v(
                                      " " +
                                        _vm._s(_vm.trans("messages.date")) +
                                        " : "
                                    ),
                                  ]),
                                  _vm._v(" "),
                                  _c("span", [
                                    _vm._v(
                                      "\n                                    " +
                                        _vm._s(
                                          _vm._f("formatDate")(
                                            _vm.transaction.transaction_date
                                          )
                                        ) +
                                        "\n                                "
                                    ),
                                  ]),
                                  _vm._v(" "),
                                  _c("br"),
                                  _vm._v(" "),
                                  _vm.transaction.type == "invoice"
                                    ? _c("div", [
                                        _c("strong", [
                                          _vm._v(
                                            " " +
                                              _vm._s(
                                                _vm.trans(
                                                  "messages.total_amount"
                                                )
                                              ) +
                                              " : "
                                          ),
                                        ]),
                                        _vm._v(" "),
                                        _c("span", [
                                          _vm._v(
                                            "\n                                        " +
                                              _vm._s(
                                                _vm._f("formatMoney")(
                                                  _vm.transaction.total,
                                                  _vm.customer_currency.symbol
                                                )
                                              ) +
                                              "\n                                    "
                                          ),
                                        ]),
                                        _vm._v(" "),
                                        _c("br"),
                                      ])
                                    : _vm._e(),
                                  _vm._v(" "),
                                  _vm.transaction.type == "expense"
                                    ? _c("div", [
                                        _c("strong", [
                                          _vm._v(
                                            " " +
                                              _vm._s(
                                                _vm.trans(
                                                  "messages.total_amount"
                                                )
                                              ) +
                                              " : "
                                          ),
                                        ]),
                                        _vm._v(" "),
                                        _c("span", [
                                          _vm._v(
                                            "\n                                        " +
                                              _vm._s(
                                                _vm._f("formatMoney")(
                                                  _vm.transaction.total,
                                                  _vm.business_currency.symbol
                                                )
                                              ) +
                                              "\n                                    "
                                          ),
                                        ]),
                                        _vm._v(" "),
                                        _c("br"),
                                      ])
                                    : _vm._e(),
                                  _vm._v(" "),
                                  !_vm._.isNull(_vm.transaction.due_date)
                                    ? _c("div", [
                                        _c("strong", [
                                          _vm._v(
                                            " " +
                                              _vm._s(
                                                _vm.trans("messages.due_date")
                                              ) +
                                              ": "
                                          ),
                                        ]),
                                        _vm._v(" "),
                                        _c("span", [
                                          _vm._v(
                                            "\n                                        " +
                                              _vm._s(
                                                _vm._f("formatDate")(
                                                  _vm.transaction.due_date
                                                )
                                              ) +
                                              "\n                                    "
                                          ),
                                        ]),
                                        _vm._v(" "),
                                        _c("br"),
                                      ])
                                    : _vm._e(),
                                  _vm._v(" "),
                                  _vm.transaction.type == "invoice"
                                    ? _c("div", [
                                        _c("strong", [
                                          _vm._v(
                                            " " +
                                              _vm._s(
                                                _vm.trans(
                                                  "messages.discount_type"
                                                )
                                              ) +
                                              " : "
                                          ),
                                        ]),
                                        _vm._v(
                                          "\n                                    " +
                                            _vm._s(
                                              _vm.trans(
                                                "messages." +
                                                  _vm.transaction.discount_type
                                              )
                                            ) +
                                            " "
                                        ),
                                        _c("br"),
                                      ])
                                    : _vm._e(),
                                ]
                              ),
                              _vm._v(" "),
                              _vm.employee
                                ? _c(
                                    "v-flex",
                                    { attrs: { xs12: "", sm4: "", md4: "" } },
                                    [
                                      _c("strong", [
                                        _vm._v(
                                          " " +
                                            _vm._s(
                                              _vm.trans("messages.expense_for")
                                            ) +
                                            " : "
                                        ),
                                      ]),
                                      _vm._v(
                                        "\n                                " +
                                          _vm._s(_vm.employee.name) +
                                          " "
                                      ),
                                      _c("br"),
                                      _vm._v(" "),
                                      _c("strong", [
                                        _vm._v(
                                          " " +
                                            _vm._s(
                                              _vm.trans("messages.email")
                                            ) +
                                            " : "
                                        ),
                                      ]),
                                      _vm._v(
                                        "\n                                " +
                                          _vm._s(_vm.employee.email) +
                                          " "
                                      ),
                                      _c("br"),
                                      _vm._v(" "),
                                      _vm.employee.mobile
                                        ? _c("div", [
                                            _c("strong", [
                                              _vm._v(
                                                " " +
                                                  _vm._s(
                                                    _vm.trans("messages.mobile")
                                                  ) +
                                                  " : "
                                              ),
                                            ]),
                                            _vm._v(
                                              "\n                                    " +
                                                _vm._s(_vm.employee.mobile) +
                                                " "
                                            ),
                                            _c("br"),
                                          ])
                                        : _vm._e(),
                                    ]
                                  )
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.project
                                ? _c(
                                    "v-flex",
                                    { attrs: { xs12: "", sm4: "", md4: "" } },
                                    [
                                      _c("strong", [
                                        _vm._v(
                                          " " +
                                            _vm._s(
                                              _vm.trans("messages.project")
                                            ) +
                                            " : "
                                        ),
                                      ]),
                                      _vm._v(
                                        "\n                                " +
                                          _vm._s(_vm.project.name) +
                                          " "
                                      ),
                                      _c("br"),
                                      _vm._v(" "),
                                      _c("strong", [
                                        _vm._v(
                                          " " +
                                            _vm._s(
                                              _vm.trans("messages.status")
                                            ) +
                                            " : "
                                        ),
                                      ]),
                                      _vm._v(
                                        "\n                                " +
                                          _vm._s(
                                            _vm.trans(
                                              "messages." + _vm.project.status
                                            )
                                          ) +
                                          " "
                                      ),
                                      _c("br"),
                                      _vm._v(" "),
                                      _c("strong", [
                                        _vm._v(
                                          " " +
                                            _vm._s(
                                              _vm.trans("messages.end_date")
                                            ) +
                                            " : "
                                        ),
                                      ]),
                                      _vm._v(
                                        "\n                                " +
                                          _vm._s(
                                            _vm._f("formatDate")(
                                              _vm.project.end_date
                                            )
                                          ) +
                                          " "
                                      ),
                                      _c("br"),
                                    ]
                                  )
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.customer
                                ? _c(
                                    "v-flex",
                                    { attrs: { xs12: "", sm4: "", md4: "" } },
                                    [
                                      _c("strong", [
                                        _vm._v(
                                          " " +
                                            _vm._s(
                                              _vm.trans("messages.customer")
                                            ) +
                                            " : "
                                        ),
                                      ]),
                                      _vm._v(
                                        "\n                                " +
                                          _vm._s(_vm.customer.company) +
                                          " "
                                      ),
                                      _c("br"),
                                      _vm._v(" "),
                                      _c("strong", [
                                        _vm._v(
                                          " " +
                                            _vm._s(
                                              _vm.trans("messages.tax_number")
                                            ) +
                                            " : "
                                        ),
                                      ]),
                                      _vm._v(
                                        "\n                                " +
                                          _vm._s(_vm.customer.tax_number) +
                                          " "
                                      ),
                                      _c("br"),
                                      _vm._v(" "),
                                      _c("strong", [
                                        _vm._v(
                                          " " +
                                            _vm._s(
                                              _vm.trans("messages.email")
                                            ) +
                                            " : "
                                        ),
                                      ]),
                                      _vm._v(
                                        "\n                                " +
                                          _vm._s(_vm.customer.email) +
                                          " "
                                      ),
                                      _c("br"),
                                      _vm._v(" "),
                                      _c("strong", [
                                        _vm._v(
                                          " " +
                                            _vm._s(
                                              _vm.trans("messages.mobile")
                                            ) +
                                            " : "
                                        ),
                                      ]),
                                      _vm._v(
                                        "\n                                " +
                                          _vm._s(_vm.customer.mobile) +
                                          " "
                                      ),
                                      _c("br"),
                                    ]
                                  )
                                : _vm._e(),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c("v-divider"),
                      _vm._v(" "),
                      _c(
                        "v-container",
                        { attrs: { "grid-list-md": "", "text-xs-center": "" } },
                        [
                          _c(
                            "v-layout",
                            { attrs: { row: "", wrap: "" } },
                            [
                              _c("v-flex", { attrs: { md3: "" } }, [
                                _c("h4", [
                                  _vm._v(_vm._s(_vm.trans("messages.date"))),
                                ]),
                              ]),
                              _vm._v(" "),
                              _c("v-flex", { attrs: { md3: "" } }, [
                                _c("h4", [
                                  _vm._v(_vm._s(_vm.trans("messages.amount"))),
                                ]),
                              ]),
                              _vm._v(" "),
                              _c("v-flex", { attrs: { md6: "" } }, [
                                _c("h4", [
                                  _vm._v(_vm._s(_vm.trans("messages.notes"))),
                                ]),
                              ]),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-layout",
                            { attrs: { row: "", wrap: "" } },
                            [
                              _vm._l(_vm.payments, function (payment) {
                                return [
                                  _c("v-flex", { attrs: { md3: "" } }, [
                                    _vm._v(
                                      "\n                                    " +
                                        _vm._s(
                                          _vm._f("formatDate")(payment.paid_on)
                                        ) +
                                        "\n                                "
                                    ),
                                  ]),
                                  _vm._v(" "),
                                  _c("v-flex", { attrs: { md3: "" } }, [
                                    _vm.transaction.type == "invoice"
                                      ? _c("span", [
                                          _vm._v(
                                            "\n                                        " +
                                              _vm._s(
                                                _vm._f("formatMoney")(
                                                  payment.amount,
                                                  _vm.customer_currency.symbol
                                                )
                                              ) +
                                              "\n                                        "
                                          ),
                                          _c("br"),
                                          _vm._v(" "),
                                          _c("small", [
                                            _vm._v(
                                              "\n                                            ( 1" +
                                                _vm._s(
                                                  _vm.business_currency.symbol
                                                ) +
                                                " =\n                                            " +
                                                _vm._s(
                                                  payment.conversion_rate
                                                ) +
                                                _vm._s(
                                                  _vm.customer_currency.symbol
                                                ) +
                                                ",\n                                            " +
                                                _vm._s(
                                                  _vm._f("formatMoney")(
                                                    payment.final_amount,
                                                    _vm.business_currency.symbol
                                                  )
                                                ) +
                                                ")\n                                        "
                                            ),
                                          ]),
                                        ])
                                      : _vm._e(),
                                    _vm._v(" "),
                                    _vm.transaction.type == "expense"
                                      ? _c("span", [
                                          _vm._v(
                                            "\n                                        " +
                                              _vm._s(
                                                _vm._f("formatMoney")(
                                                  payment.amount,
                                                  _vm.business_currency.symbol
                                                )
                                              ) +
                                              "\n                                        "
                                          ),
                                          _c("br"),
                                        ])
                                      : _vm._e(),
                                  ]),
                                  _vm._v(" "),
                                  _c("v-flex", { attrs: { md6: "" } }, [
                                    _c("span", {
                                      domProps: {
                                        innerHTML: _vm._s(
                                          payment.payment_details
                                        ),
                                      },
                                    }),
                                  ]),
                                ]
                              }),
                            ],
                            2
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "v-card-actions",
                    [
                      _c("v-spacer"),
                      _vm._v(" "),
                      _c(
                        "v-btn",
                        {
                          attrs: { color: "green darken-1", flat: "" },
                          on: {
                            click: function ($event) {
                              _vm.dialog = false
                            },
                          },
                        },
                        [
                          _vm._v(
                            "\n                        " +
                              _vm._s(_vm.trans("messages.close")) +
                              "\n                    "
                          ),
                        ]
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);