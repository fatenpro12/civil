"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_estate_owner_dashboard_List_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/estate_owner/dashboard/List.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/estate_owner/dashboard/List.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../store */ "./resources/js/store/index.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  components: {},
  data: function data() {
    var self = this;
    return {
      loading: false,
      total_items: 0,
      items: [],
      pagination: {
        totalItems: 0
      },
      headersNotifications: [{
        text: self.trans('messages.action'),
        value: false,
        align: 'centre',
        sortable: false
      }, {
        text: self.trans('data.notice_date'),
        value: 'notice_date',
        align: 'centre',
        sortable: true
      }, {
        text: self.trans('data.notice_message'),
        value: 'notice_message',
        align: 'centre',
        sortable: true
      }],
      headers: [{
        text: self.trans('messages.action'),
        value: false,
        align: 'centre',
        sortable: false
      }, {
        text: self.trans('data.warrning_date'),
        value: 'warrning_date',
        align: 'centre',
        sortable: true
      }, {
        text: self.trans('data.warrning_message'),
        value: 'warrning_message',
        align: 'centre',
        sortable: true
      }],
      notificationsmessage: '',
      project_counts: [],
      project_counts_completed: [],
      task_counts: [],
      invoice_counts: [],
      invoice_paid_amount: null,
      invoice_totals: [],
      currencies: [],
      currency_symbols: [],
      selected_currency: null,
      total_amount: null,
      selected_currency_symbol: null,
      business_currency: [],
      sticky_notes: null
    };
  },
  mounted: function mounted() {
    var self = this;
    self.getDashboardDataFromApi();
    self.$eventBus.$on('updateDashboard', function (data) {
      self.getDashboardDataFromApi();
    });
  },
  beforeDestroy: function beforeDestroy() {
    var self = this;
    self.$eventBus.$off('updateDashboard');
  },
  created: function created() {
    //    console.log(this.desserts);
  },
  watch: {
    pagination: {
      handler: function handler() {
        this.getDataFromApi();
      }
    }
  },
  methods: {
    getDataFromApi: function getDataFromApi() {
      var self = this;
      //self.loading = true;
      var _self$pagination = self.pagination,
        sortBy = _self$pagination.sortBy,
        descending = _self$pagination.descending,
        page = _self$pagination.page,
        rowsPerPage = _self$pagination.rowsPerPage;
      var params = {
        sort_by: sortBy,
        descending: descending,
        page: page,
        rowsPerPage: rowsPerPage
      };
    },
    goToProjects: function goToProjects() {
      this.$router.push('/project');
    },
    goToReview: function goToReview() {
      this.$router.push('/');
    },
    getDashboardDataFromApi: function getDashboardDataFromApi() {
      var self = this;
      axios.get('/estate_owner/dashboards').then(function (response) {
        self.project_counts = response.data.project_counts;
        self.project_counts_completed = response.data.project_counts_completed;
        self.task_counts = response.data.task_counts;
        self.invoice_counts = response.data.invoice_counts;
        self.invoice_totals = response.data.invoice_totals;
        self.initTicketPieChart(response.data.ticket_pie_chart_label, response.data.ticket_pie_chart_dataset);
        self.paymentStatusCount(response.data.payment_status_count);
        self.currenciesInArray(response.data.currencies);
        self.selected_currency = response.data.business_currency.id;
        self.business_currency = response.data.business_currency;
        self.currencyChanged();
        self.sticky_notes = response.data.sticky_notes;
        if (self.$can('superadmin')) {
          self.initTransactionPieChart(response.data.transaction_pie_chart_label, response.data.transaction_pie_chart_datasets);
        }
      })["catch"](function (error) {
        console.log(error);
      });
    },
    currencyChanged: function currencyChanged() {
      var self = this;
      for (var key in self.invoice_counts) {
        if (self.selected_currency == self.invoice_counts[key].currency_id) {
          self.invoice_paid_amount = self.invoice_counts[key].paid_amount;
          self.total_amount = self.invoice_counts[key].total_amount;
          self.selected_currency_symbol = self.invoice_counts[key].currency_symbol;
        }
      }
    },
    currenciesInArray: function currenciesInArray(currencies) {
      var self = this;
      var result = Object.keys(currencies).map(function (key) {
        return currencies[key];
      });
      self.currencies = result;
    },
    paymentStatusCount: function paymentStatusCount(paymentStatus) {
      var total_counts = 0;
      var total_not_paid = 0;
      var total_due = 0;
      var total_paid = 0;
      var total_partials = 0;
      _.forEach(paymentStatus, function (status) {
        total_counts = _.add(total_counts, parseInt(status.count));
        if (status.payment_status !== 'paid') {
          total_not_paid = _.add(total_not_paid, parseInt(status.count));
        }
        if (status.payment_status == 'paid') {
          total_paid = _.add(total_paid, parseInt(status.count));
        }
        if (status.payment_status == 'due') {
          total_due = _.add(total_due, parseInt(status.count));
        }
        if (status.payment_status == 'partial') {
          total_partials = _.add(total_partials, parseInt(status.count));
        }
      });
      this.invoice_totals.total_counts = total_counts;
      this.invoice_totals.total_not_paid = total_not_paid;
      this.invoice_totals.total_paid = total_paid;
      this.invoice_totals.total_due = total_due;
      this.invoice_totals.total_partials = total_partials;
    },
    saveStickyNotes: function saveStickyNotes() {
      axios.post('/admin/save-stick-notes', {
        sticky_notes: this.sticky_notes
      });
    },
    initTicketPieChart: function initTicketPieChart(labels, datasets) {
      var ctx = document.getElementById('ticketPieChart');
      var ticketPieChart = new Chart(ctx, {
        type: 'pie',
        data: {
          labels: labels,
          datasets: [{
            data: datasets,
            backgroundColor: ['red', 'blue', 'green']
          }]
        }
      });
    },
    initTransactionPieChart: function initTransactionPieChart(labels, datasets) {
      var ctx = document.getElementById('transactionPieChart');
      var ticketPieChart = new Chart(ctx, {
        type: 'pie',
        data: {
          labels: labels,
          datasets: [{
            data: datasets,
            backgroundColor: ['green', 'red']
          }]
        }
      });
    }
  }
});

/***/ }),

/***/ "./resources/js/estate_owner/dashboard/List.vue":
/*!******************************************************!*\
  !*** ./resources/js/estate_owner/dashboard/List.vue ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _List_vue_vue_type_template_id_685ba23a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./List.vue?vue&type=template&id=685ba23a& */ "./resources/js/estate_owner/dashboard/List.vue?vue&type=template&id=685ba23a&");
/* harmony import */ var _List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./List.vue?vue&type=script&lang=js& */ "./resources/js/estate_owner/dashboard/List.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _List_vue_vue_type_template_id_685ba23a___WEBPACK_IMPORTED_MODULE_0__.render,
  _List_vue_vue_type_template_id_685ba23a___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/estate_owner/dashboard/List.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/estate_owner/dashboard/List.vue?vue&type=script&lang=js&":
/*!*******************************************************************************!*\
  !*** ./resources/js/estate_owner/dashboard/List.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./List.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/estate_owner/dashboard/List.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/estate_owner/dashboard/List.vue?vue&type=template&id=685ba23a&":
/*!*************************************************************************************!*\
  !*** ./resources/js/estate_owner/dashboard/List.vue?vue&type=template&id=685ba23a& ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_685ba23a___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_685ba23a___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_685ba23a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./List.vue?vue&type=template&id=685ba23a& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/estate_owner/dashboard/List.vue?vue&type=template&id=685ba23a&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/estate_owner/dashboard/List.vue?vue&type=template&id=685ba23a&":
/*!****************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/estate_owner/dashboard/List.vue?vue&type=template&id=685ba23a& ***!
  \****************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "component-wrap" },
    [
      _c(
        "v-container",
        { attrs: { "grid-list-md": "" } },
        [
          _c("v-flex", { attrs: { "pt-3": "", "pb-4": "" } }, [
            _c(
              "h1",
              {
                staticClass: "text-md-center",
                staticStyle: { color: "#0000008a" },
              },
              [
                _vm._v(
                  " " + _vm._s(_vm.trans("data.Engineering_offices_system"))
                ),
              ]
            ),
          ]),
          _vm._v(" "),
          _c(
            "v-container",
            { attrs: { "grid-list-lg": "" } },
            [
              _c(
                "v-layout",
                { attrs: { wrap: "" } },
                [
                  _c(
                    "v-flex",
                    { attrs: { xs12: "", sm12: "", md6: "" } },
                    [
                      _c("v-hover", {
                        attrs: { "open-delay": "100", "close-delay": "100" },
                        scopedSlots: _vm._u([
                          {
                            key: "default",
                            fn: function (ref) {
                              var hover = ref.hover
                              return [
                                _c(
                                  "v-card",
                                  {
                                    staticClass: "w-full",
                                    attrs: { elevation: hover ? 16 : 2 },
                                  },
                                  [
                                    _c("v-card-text", [
                                      _c(
                                        "div",
                                        { staticClass: "my-2" },
                                        [
                                          _c(
                                            "v-flex",
                                            {
                                              staticClass: "text-md-center",
                                              attrs: {
                                                xs12: "",
                                                sm12: "",
                                                md12: "",
                                              },
                                            },
                                            [
                                              _c(
                                                "v-progress-circular",
                                                {
                                                  attrs: {
                                                    rotate: 180,
                                                    size: 100,
                                                    width: 10,
                                                    value: _vm.projectProgress(
                                                      _vm
                                                        .project_counts_completed
                                                        .total,
                                                      _vm
                                                        .project_counts_completed
                                                        .completed
                                                    ),
                                                    color: "teal",
                                                  },
                                                },
                                                [
                                                  _vm._v(
                                                    "\n                                            " +
                                                      _vm._s(
                                                        _vm.projectProgress(
                                                          _vm
                                                            .project_counts_completed
                                                            .total,
                                                          _vm
                                                            .project_counts_completed
                                                            .completed
                                                        )
                                                      ) +
                                                      "\n                                        "
                                                  ),
                                                ]
                                              ),
                                            ],
                                            1
                                          ),
                                          _vm._v(" "),
                                          _c(
                                            "div",
                                            {
                                              staticClass:
                                                "text-md-center mt-2",
                                            },
                                            [
                                              _c(
                                                "v-btn",
                                                {
                                                  attrs: {
                                                    outline: "",
                                                    large: "",
                                                    color: "#06706d",
                                                  },
                                                  on: {
                                                    click: function ($event) {
                                                      return _vm.$router.push(
                                                        "/finished-projects"
                                                      )
                                                    },
                                                  },
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(
                                                      _vm.trans(
                                                        "data.finished_projects"
                                                      )
                                                    )
                                                  ),
                                                ]
                                              ),
                                            ],
                                            1
                                          ),
                                        ],
                                        1
                                      ),
                                    ]),
                                  ],
                                  1
                                ),
                              ]
                            },
                          },
                        ]),
                      }),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "v-flex",
                    { attrs: { xs12: "", sm12: "", md6: "" } },
                    [
                      _c("v-hover", {
                        attrs: { "open-delay": "100", "close-delay": "100" },
                        scopedSlots: _vm._u([
                          {
                            key: "default",
                            fn: function (ref) {
                              var hover = ref.hover
                              return [
                                _c(
                                  "v-card",
                                  {
                                    staticClass: "w-full",
                                    attrs: { elevation: hover ? 16 : 2 },
                                  },
                                  [
                                    _c("v-card-text", [
                                      _c(
                                        "div",
                                        { staticClass: "my-2" },
                                        [
                                          _c(
                                            "v-flex",
                                            {
                                              staticClass: "text-md-center",
                                              attrs: {
                                                xs12: "",
                                                sm12: "",
                                                md12: "",
                                              },
                                            },
                                            [
                                              _c(
                                                "v-progress-circular",
                                                {
                                                  attrs: {
                                                    rotate: 180,
                                                    size: 100,
                                                    width: 10,
                                                    value: _vm.projectProgress(
                                                      _vm.project_counts.total,
                                                      _vm.project_counts
                                                        .incompleted
                                                    ),
                                                    color: "teal",
                                                  },
                                                },
                                                [
                                                  _vm._v(
                                                    "\n                                            " +
                                                      _vm._s(
                                                        _vm.projectProgress(
                                                          _vm.project_counts
                                                            .total,
                                                          _vm.project_counts
                                                            .incompleted
                                                        )
                                                      ) +
                                                      "\n                                        "
                                                  ),
                                                ]
                                              ),
                                            ],
                                            1
                                          ),
                                          _vm._v(" "),
                                          _c(
                                            "div",
                                            {
                                              staticClass:
                                                "text-md-center mt-2",
                                            },
                                            [
                                              _c(
                                                "v-btn",
                                                {
                                                  attrs: {
                                                    outline: "",
                                                    large: "",
                                                    color: "#06706d",
                                                  },
                                                  on: {
                                                    click: _vm.goToProjects,
                                                  },
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(
                                                      _vm.trans(
                                                        "data.current_projects"
                                                      )
                                                    )
                                                  ),
                                                ]
                                              ),
                                            ],
                                            1
                                          ),
                                        ],
                                        1
                                      ),
                                    ]),
                                  ],
                                  1
                                ),
                              ]
                            },
                          },
                        ]),
                      }),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "v-layout",
            { attrs: { "row-wrap": "", "mb-2": "" } },
            [
              _c(
                "v-flex",
                [
                  _c(
                    "v-card",
                    { attrs: { elevation: "4", xs12: "", sm4: "", md4: "" } },
                    [
                      _c("v-card-title", [
                        _c(
                          "span",
                          { staticClass: "headline" },
                          [
                            _c("v-icon", [_vm._v("receipt")]),
                            _vm._v(
                              "\n                        " +
                                _vm._s(_vm.trans("data.warnings")) +
                                " & " +
                                _vm._s(_vm.trans("data.notification")) +
                                "\n                    "
                            ),
                          ],
                          1
                        ),
                      ]),
                      _vm._v(" "),
                      _c("v-divider"),
                      _vm._v(" "),
                      _c(
                        "v-card-text",
                        [
                          _c(
                            "v-container",
                            { attrs: { "grid-list-lg": "" } },
                            [
                              _c(
                                "v-layout",
                                { attrs: { wrap: "" } },
                                [
                                  _c(
                                    "v-flex",
                                    { attrs: { xs12: "", sm12: "", md6: "" } },
                                    [
                                      _c("v-data-table", {
                                        staticClass: "elevation-3",
                                        attrs: {
                                          headers: _vm.headers,
                                          pagination: _vm.pagination,
                                          "total-items": _vm.total_items,
                                          loading: _vm.loading,
                                          items: _vm.items,
                                        },
                                        on: {
                                          "update:pagination": function (
                                            $event
                                          ) {
                                            _vm.pagination = $event
                                          },
                                        },
                                        scopedSlots: _vm._u([
                                          {
                                            key: "headerCell",
                                            fn: function (props) {
                                              return [
                                                props.header.value ==
                                                "warrning_date"
                                                  ? _c("span", [
                                                      _vm._v(
                                                        "\n                                                    " +
                                                          _vm._s(
                                                            props.header.text
                                                          ) +
                                                          "\n                                                "
                                                      ),
                                                    ])
                                                  : props.header.value ==
                                                    "warrning_message"
                                                  ? _c("span", [
                                                      _vm._v(
                                                        "\n                                                    " +
                                                          _vm._s(
                                                            props.header.text
                                                          ) +
                                                          "\n                                                "
                                                      ),
                                                    ])
                                                  : _c("span", [
                                                      _vm._v(
                                                        _vm._s(
                                                          props.header.text
                                                        )
                                                      ),
                                                    ]),
                                              ]
                                            },
                                          },
                                          {
                                            key: "items",
                                            fn: function (props) {
                                              return [
                                                _c(
                                                  "td",
                                                  [
                                                    _c(
                                                      "v-menu",
                                                      [
                                                        _c(
                                                          "v-btn",
                                                          {
                                                            attrs: {
                                                              slot: "activator",
                                                              icon: "",
                                                            },
                                                            slot: "activator",
                                                          },
                                                          [
                                                            _c("v-icon", [
                                                              _vm._v(
                                                                "more_vert"
                                                              ),
                                                            ]),
                                                          ],
                                                          1
                                                        ),
                                                        _vm._v(" "),
                                                        _c(
                                                          "v-list",
                                                          [
                                                            _c(
                                                              "v-list-tile",
                                                              {
                                                                on: {
                                                                  click:
                                                                    function (
                                                                      $event
                                                                    ) {
                                                                      return _vm.$router.push(
                                                                        {
                                                                          name: "customers.show",
                                                                          params:
                                                                            {
                                                                              id: props
                                                                                .item
                                                                                .id,
                                                                            },
                                                                        }
                                                                      )
                                                                    },
                                                                },
                                                              },
                                                              [
                                                                _c(
                                                                  "v-list-tile-title",
                                                                  [
                                                                    _c(
                                                                      "v-icon",
                                                                      {
                                                                        staticClass:
                                                                          "mr-2",
                                                                        attrs: {
                                                                          small:
                                                                            "",
                                                                        },
                                                                      },
                                                                      [
                                                                        _vm._v(
                                                                          " visibility "
                                                                        ),
                                                                      ]
                                                                    ),
                                                                    _vm._v(
                                                                      "\n                                                                        " +
                                                                        _vm._s(
                                                                          _vm.trans(
                                                                            "messages.view"
                                                                          )
                                                                        ) +
                                                                        "\n                                                                    "
                                                                    ),
                                                                  ],
                                                                  1
                                                                ),
                                                              ],
                                                              1
                                                            ),
                                                            _vm._v(" "),
                                                            _c(
                                                              "v-list-tile",
                                                              {
                                                                on: {
                                                                  click:
                                                                    function (
                                                                      $event
                                                                    ) {
                                                                      return _vm.edit(
                                                                        props
                                                                          .item
                                                                          .id
                                                                      )
                                                                    },
                                                                },
                                                              },
                                                              [
                                                                _c(
                                                                  "v-list-tile-title",
                                                                  [
                                                                    _c(
                                                                      "v-icon",
                                                                      {
                                                                        staticClass:
                                                                          "mr-2",
                                                                        attrs: {
                                                                          small:
                                                                            "",
                                                                        },
                                                                      },
                                                                      [
                                                                        _vm._v(
                                                                          " edit "
                                                                        ),
                                                                      ]
                                                                    ),
                                                                    _vm._v(
                                                                      "\n                                                                        " +
                                                                        _vm._s(
                                                                          _vm.trans(
                                                                            "messages.edit"
                                                                          )
                                                                        ) +
                                                                        "\n                                                                    "
                                                                    ),
                                                                  ],
                                                                  1
                                                                ),
                                                              ],
                                                              1
                                                            ),
                                                            _vm._v(" "),
                                                            _c(
                                                              "v-list-tile",
                                                              {
                                                                on: {
                                                                  click:
                                                                    function (
                                                                      $event
                                                                    ) {
                                                                      return _vm.deleteCustomer(
                                                                        props.item
                                                                      )
                                                                    },
                                                                },
                                                              },
                                                              [
                                                                _c(
                                                                  "v-list-tile-title",
                                                                  [
                                                                    _c(
                                                                      "v-icon",
                                                                      {
                                                                        staticClass:
                                                                          "mr-2",
                                                                        attrs: {
                                                                          small:
                                                                            "",
                                                                        },
                                                                      },
                                                                      [
                                                                        _vm._v(
                                                                          " delete_forever "
                                                                        ),
                                                                      ]
                                                                    ),
                                                                    _vm._v(
                                                                      "\n                                                                        " +
                                                                        _vm._s(
                                                                          _vm.trans(
                                                                            "messages.delete"
                                                                          )
                                                                        ) +
                                                                        "\n                                                                    "
                                                                    ),
                                                                  ],
                                                                  1
                                                                ),
                                                              ],
                                                              1
                                                            ),
                                                          ],
                                                          1
                                                        ),
                                                      ],
                                                      1
                                                    ),
                                                  ],
                                                  1
                                                ),
                                                _vm._v(" "),
                                                _c("td"),
                                                _vm._v(" "),
                                                _c("td"),
                                              ]
                                            },
                                          },
                                        ]),
                                      }),
                                    ],
                                    1
                                  ),
                                  _vm._v(" "),
                                  _c(
                                    "v-flex",
                                    { attrs: { xs12: "", sm12: "", md6: "" } },
                                    [
                                      _c("v-data-table", {
                                        staticClass: "elevation-3",
                                        attrs: {
                                          headers: _vm.headersNotifications,
                                          pagination: _vm.pagination,
                                          "total-items": _vm.total_items,
                                          loading: _vm.loading,
                                          items: _vm.items,
                                        },
                                        on: {
                                          "update:pagination": function (
                                            $event
                                          ) {
                                            _vm.pagination = $event
                                          },
                                        },
                                        scopedSlots: _vm._u([
                                          {
                                            key: "headerCell",
                                            fn: function (props) {
                                              return [
                                                props.header.value ==
                                                "warrning_date"
                                                  ? _c("span", [
                                                      _vm._v(
                                                        "\n                                                        " +
                                                          _vm._s(
                                                            props.header.text
                                                          ) +
                                                          "\n                                                    "
                                                      ),
                                                    ])
                                                  : props.header.value ==
                                                    "warrning_message"
                                                  ? _c("span", [
                                                      _vm._v(
                                                        "\n                                                        " +
                                                          _vm._s(
                                                            props.header.text
                                                          ) +
                                                          "\n                                                    "
                                                      ),
                                                    ])
                                                  : _c("span", [
                                                      _vm._v(
                                                        _vm._s(
                                                          props.header.text
                                                        )
                                                      ),
                                                    ]),
                                              ]
                                            },
                                          },
                                          {
                                            key: "items",
                                            fn: function (props) {
                                              return [
                                                _c(
                                                  "td",
                                                  [
                                                    _c(
                                                      "v-menu",
                                                      [
                                                        _c(
                                                          "v-btn",
                                                          {
                                                            attrs: {
                                                              slot: "activator",
                                                              icon: "",
                                                            },
                                                            slot: "activator",
                                                          },
                                                          [
                                                            _c("v-icon", [
                                                              _vm._v(
                                                                "more_vert"
                                                              ),
                                                            ]),
                                                          ],
                                                          1
                                                        ),
                                                        _vm._v(" "),
                                                        _c(
                                                          "v-list",
                                                          [
                                                            _c(
                                                              "v-list-tile",
                                                              {
                                                                on: {
                                                                  click:
                                                                    function (
                                                                      $event
                                                                    ) {
                                                                      return _vm.$router.push(
                                                                        {
                                                                          name: "customers.show",
                                                                          params:
                                                                            {
                                                                              id: props
                                                                                .item
                                                                                .id,
                                                                            },
                                                                        }
                                                                      )
                                                                    },
                                                                },
                                                              },
                                                              [
                                                                _c(
                                                                  "v-list-tile-title",
                                                                  [
                                                                    _c(
                                                                      "v-icon",
                                                                      {
                                                                        staticClass:
                                                                          "mr-2",
                                                                        attrs: {
                                                                          small:
                                                                            "",
                                                                        },
                                                                      },
                                                                      [
                                                                        _vm._v(
                                                                          " visibility "
                                                                        ),
                                                                      ]
                                                                    ),
                                                                    _vm._v(
                                                                      "\n                                                                        " +
                                                                        _vm._s(
                                                                          _vm.trans(
                                                                            "messages.view"
                                                                          )
                                                                        ) +
                                                                        "\n                                                                    "
                                                                    ),
                                                                  ],
                                                                  1
                                                                ),
                                                              ],
                                                              1
                                                            ),
                                                            _vm._v(" "),
                                                            _c(
                                                              "v-list-tile",
                                                              {
                                                                on: {
                                                                  click:
                                                                    function (
                                                                      $event
                                                                    ) {
                                                                      return _vm.edit(
                                                                        props
                                                                          .item
                                                                          .id
                                                                      )
                                                                    },
                                                                },
                                                              },
                                                              [
                                                                _c(
                                                                  "v-list-tile-title",
                                                                  [
                                                                    _c(
                                                                      "v-icon",
                                                                      {
                                                                        staticClass:
                                                                          "mr-2",
                                                                        attrs: {
                                                                          small:
                                                                            "",
                                                                        },
                                                                      },
                                                                      [
                                                                        _vm._v(
                                                                          " edit "
                                                                        ),
                                                                      ]
                                                                    ),
                                                                    _vm._v(
                                                                      "\n                                                                        " +
                                                                        _vm._s(
                                                                          _vm.trans(
                                                                            "messages.edit"
                                                                          )
                                                                        ) +
                                                                        "\n                                                                    "
                                                                    ),
                                                                  ],
                                                                  1
                                                                ),
                                                              ],
                                                              1
                                                            ),
                                                            _vm._v(" "),
                                                            _c(
                                                              "v-list-tile",
                                                              {
                                                                on: {
                                                                  click:
                                                                    function (
                                                                      $event
                                                                    ) {
                                                                      return _vm.deleteCustomer(
                                                                        props.item
                                                                      )
                                                                    },
                                                                },
                                                              },
                                                              [
                                                                _c(
                                                                  "v-list-tile-title",
                                                                  [
                                                                    _c(
                                                                      "v-icon",
                                                                      {
                                                                        staticClass:
                                                                          "mr-2",
                                                                        attrs: {
                                                                          small:
                                                                            "",
                                                                        },
                                                                      },
                                                                      [
                                                                        _vm._v(
                                                                          " delete_forever "
                                                                        ),
                                                                      ]
                                                                    ),
                                                                    _vm._v(
                                                                      "\n                                                                        " +
                                                                        _vm._s(
                                                                          _vm.trans(
                                                                            "messages.delete"
                                                                          )
                                                                        ) +
                                                                        "\n                                                                    "
                                                                    ),
                                                                  ],
                                                                  1
                                                                ),
                                                              ],
                                                              1
                                                            ),
                                                          ],
                                                          1
                                                        ),
                                                      ],
                                                      1
                                                    ),
                                                  ],
                                                  1
                                                ),
                                                _vm._v(" "),
                                                _c("td", [_vm._v("test")]),
                                              ]
                                            },
                                          },
                                        ]),
                                      }),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);