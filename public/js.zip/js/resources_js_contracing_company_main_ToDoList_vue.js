"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_contracing_company_main_ToDoList_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/contracing_company/main/ToDoList.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/contracing_company/main/ToDoList.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components_AskPermissionModal_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./components/AskPermissionModal.vue */ "./resources/js/contracing_company/main/components/AskPermissionModal.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  components: {
    AskPermissionModal: _components_AskPermissionModal_vue__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  data: function data() {
    return {
      loading: false
    };
  },
  mounted: function mounted() {
    var user = this.$store.getters['auth/user'];
    this.$store.commit('setRequests', user.id);
  },
  methods: {
    askforpermission: function askforpermission() {
      var self = this;
      self.$refs.permissionref.create();
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/contracing_company/main/components/AskPermissionModal.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/contracing_company/main/components/AskPermissionModal.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../store */ "./resources/js/store/index.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: 'permission',
  data: function data() {
    return {
      valid: true,
      permissions: [],
      nameRules: [
        // (v) => (v && v.length <= 10) || 'Name must be less than 10 characters',
      ,],
      permission: '',
      note: '',
      fileName: '',
      url: '',
      fileObject: null,
      cardResult: '',
      name: '',
      size: '',
      type: '',
      lastModifiedDate: '',
      dialog: false,
      loading: false,
      formData: new FormData()
    };
  },
  mounted: function mounted() {
    var self = this;
    self.loadRolesAndGenders();
  },
  methods: {
    //detects location from browser
    loadRolesAndGenders: function loadRolesAndGenders() {
      var self = this;
      axios.get('get-roles-permission').then(function (response) {
        //self.gender_types = response.data.gender_types;
        self.permissions = response.data.roles;
      })["catch"](function (err) {
        console.log(err.response.status);
        if (err.response.status === 401) {
          _store__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch('auth/handleResponse', err.response);
        }
      });
      ;
    },
    create: function create() {
      var self = this;
      self.dialog = true;
    },
    save: function save() {
      var self = this;
      var data = {
        permission: self.permission,
        note: self.note
      };

      // self.$validator.validateAll().then((result) => {
      //     if (result == true) 
      self.formData.append('permission', self.permission);
      self.formData.append('note', self.note);
      if (this.$refs.form.validate()) {
        self.loading = true;
        axios.post('ask-for-permission', self.formData, {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        }).then(function (response) {
          if (!response.data.error_code) {
            self.loading = false;
            self.$store.commit('showSnackbar', {
              message: 'asked successfully',
              color: 'green'
            });
            self.dialog = false;
            self.reset();
          } else {
            self.loading = false;
            self.$store.commit('showSnackbar', {
              message: response.data.error_description,
              color: 'red'
            });
          }
        });
      }
      // });
    },
    close: function close() {
      var self = this;
      self.dialog = false;
      self.loading = false;
      self.reset();
      self.resetValidation();
    },
    reset: function reset() {
      this.$refs.form.reset();
    },
    resetValidation: function resetValidation() {
      this.$refs.form.resetValidation();
    },
    onPickFile: function onPickFile() {
      this.$refs.fileInput.click();
    },
    onFilePicked: function onFilePicked(event) {
      var _this = this;
      var files = event.target.files;
      if (files[0] !== undefined) {
        this.fileName = files[0].name;
        // Check validity of file
        if (this.fileName.lastIndexOf('.') <= 0) {
          return;
        }
        // If valid, continue
        var fr = new FileReader();
        fr.readAsDataURL(files[0]);
        fr.addEventListener('load', function () {
          _this.url = fr.result;
          _this.fileObject = files[0];
          _this.formData.append('file', _this.fileObject);
          // this is an file that can be sent to server...
        });
      } else {
        this.fileName = '';
        this.fileObject = null;
        this.url = '';
      }
    },
    onUploadSelectedFileClick: function onUploadSelectedFileClick() {
      this.loading = true;
      console.log(this.fileObject);
      // A file is not chosen!
      if (!this.fileObject) {
        alert('No file!!');
      }
      // DO YOUR JOB HERE with fileObjectToUpload
      // https://developer.mozilla.org/en-US/docs/Web/API/File/File
      this.name = this.fileObject.name;
      this.size = this.fileObject.size;
      this.type = this.fileObject.type;
      this.lastModifiedDate = this.fileObject.lastModifiedDate;
      // DO YOUR JOB HERE with fileObjectToUpload
      this.loading = false;
    }
  }
});

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/contracing_company/main/ToDoList.vue?vue&type=style&index=0&id=c2f90472&scoped=true&lang=css&":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/contracing_company/main/ToDoList.vue?vue&type=style&index=0&id=c2f90472&scoped=true&lang=css& ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\r\n/* .not_working {\r\n   // background-color: red;\r\n} */\r\n", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/contracing_company/main/ToDoList.vue?vue&type=style&index=1&id=c2f90472&scoped=true&lang=css&":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/contracing_company/main/ToDoList.vue?vue&type=style&index=1&id=c2f90472&scoped=true&lang=css& ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "\n.v-card[data-v-c2f90472] {\n    width: 100%\n}\n", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/contracing_company/main/components/AskPermissionModal.vue?vue&type=style&index=0&id=79f638aa&scoped=true&lang=css&":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/contracing_company/main/components/AskPermissionModal.vue?vue&type=style&index=0&id=79f638aa&scoped=true&lang=css& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "\n.style_rtl[data-v-79f638aa] {\r\n    padding-left: 5px;\n}\n.style_ltr[data-v-79f638aa] {\r\n    padding-right: 5px;\n}\r\n", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/contracing_company/main/ToDoList.vue?vue&type=style&index=0&id=c2f90472&scoped=true&lang=css&":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/contracing_company/main/ToDoList.vue?vue&type=style&index=0&id=c2f90472&scoped=true&lang=css& ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_ToDoList_vue_vue_type_style_index_0_id_c2f90472_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./ToDoList.vue?vue&type=style&index=0&id=c2f90472&scoped=true&lang=css& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/contracing_company/main/ToDoList.vue?vue&type=style&index=0&id=c2f90472&scoped=true&lang=css&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_ToDoList_vue_vue_type_style_index_0_id_c2f90472_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_ToDoList_vue_vue_type_style_index_0_id_c2f90472_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/contracing_company/main/ToDoList.vue?vue&type=style&index=1&id=c2f90472&scoped=true&lang=css&":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/contracing_company/main/ToDoList.vue?vue&type=style&index=1&id=c2f90472&scoped=true&lang=css& ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_ToDoList_vue_vue_type_style_index_1_id_c2f90472_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./ToDoList.vue?vue&type=style&index=1&id=c2f90472&scoped=true&lang=css& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/contracing_company/main/ToDoList.vue?vue&type=style&index=1&id=c2f90472&scoped=true&lang=css&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_ToDoList_vue_vue_type_style_index_1_id_c2f90472_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_ToDoList_vue_vue_type_style_index_1_id_c2f90472_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/contracing_company/main/components/AskPermissionModal.vue?vue&type=style&index=0&id=79f638aa&scoped=true&lang=css&":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/contracing_company/main/components/AskPermissionModal.vue?vue&type=style&index=0&id=79f638aa&scoped=true&lang=css& ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_AskPermissionModal_vue_vue_type_style_index_0_id_79f638aa_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AskPermissionModal.vue?vue&type=style&index=0&id=79f638aa&scoped=true&lang=css& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/contracing_company/main/components/AskPermissionModal.vue?vue&type=style&index=0&id=79f638aa&scoped=true&lang=css&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_AskPermissionModal_vue_vue_type_style_index_0_id_79f638aa_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_AskPermissionModal_vue_vue_type_style_index_0_id_79f638aa_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./resources/js/contracing_company/main/ToDoList.vue":
/*!***********************************************************!*\
  !*** ./resources/js/contracing_company/main/ToDoList.vue ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _ToDoList_vue_vue_type_template_id_c2f90472_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ToDoList.vue?vue&type=template&id=c2f90472&scoped=true& */ "./resources/js/contracing_company/main/ToDoList.vue?vue&type=template&id=c2f90472&scoped=true&");
/* harmony import */ var _ToDoList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ToDoList.vue?vue&type=script&lang=js& */ "./resources/js/contracing_company/main/ToDoList.vue?vue&type=script&lang=js&");
/* harmony import */ var _ToDoList_vue_vue_type_style_index_0_id_c2f90472_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ToDoList.vue?vue&type=style&index=0&id=c2f90472&scoped=true&lang=css& */ "./resources/js/contracing_company/main/ToDoList.vue?vue&type=style&index=0&id=c2f90472&scoped=true&lang=css&");
/* harmony import */ var _ToDoList_vue_vue_type_style_index_1_id_c2f90472_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ToDoList.vue?vue&type=style&index=1&id=c2f90472&scoped=true&lang=css& */ "./resources/js/contracing_company/main/ToDoList.vue?vue&type=style&index=1&id=c2f90472&scoped=true&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;



/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__["default"])(
  _ToDoList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _ToDoList_vue_vue_type_template_id_c2f90472_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render,
  _ToDoList_vue_vue_type_template_id_c2f90472_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  "c2f90472",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/contracing_company/main/ToDoList.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/contracing_company/main/components/AskPermissionModal.vue":
/*!********************************************************************************!*\
  !*** ./resources/js/contracing_company/main/components/AskPermissionModal.vue ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _AskPermissionModal_vue_vue_type_template_id_79f638aa_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./AskPermissionModal.vue?vue&type=template&id=79f638aa&scoped=true& */ "./resources/js/contracing_company/main/components/AskPermissionModal.vue?vue&type=template&id=79f638aa&scoped=true&");
/* harmony import */ var _AskPermissionModal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./AskPermissionModal.vue?vue&type=script&lang=js& */ "./resources/js/contracing_company/main/components/AskPermissionModal.vue?vue&type=script&lang=js&");
/* harmony import */ var _AskPermissionModal_vue_vue_type_style_index_0_id_79f638aa_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./AskPermissionModal.vue?vue&type=style&index=0&id=79f638aa&scoped=true&lang=css& */ "./resources/js/contracing_company/main/components/AskPermissionModal.vue?vue&type=style&index=0&id=79f638aa&scoped=true&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _AskPermissionModal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _AskPermissionModal_vue_vue_type_template_id_79f638aa_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render,
  _AskPermissionModal_vue_vue_type_template_id_79f638aa_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  "79f638aa",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/contracing_company/main/components/AskPermissionModal.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/contracing_company/main/ToDoList.vue?vue&type=script&lang=js&":
/*!************************************************************************************!*\
  !*** ./resources/js/contracing_company/main/ToDoList.vue?vue&type=script&lang=js& ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ToDoList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./ToDoList.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/contracing_company/main/ToDoList.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ToDoList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/contracing_company/main/components/AskPermissionModal.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************!*\
  !*** ./resources/js/contracing_company/main/components/AskPermissionModal.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AskPermissionModal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AskPermissionModal.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/contracing_company/main/components/AskPermissionModal.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AskPermissionModal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/contracing_company/main/ToDoList.vue?vue&type=style&index=0&id=c2f90472&scoped=true&lang=css&":
/*!********************************************************************************************************************!*\
  !*** ./resources/js/contracing_company/main/ToDoList.vue?vue&type=style&index=0&id=c2f90472&scoped=true&lang=css& ***!
  \********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_ToDoList_vue_vue_type_style_index_0_id_c2f90472_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./ToDoList.vue?vue&type=style&index=0&id=c2f90472&scoped=true&lang=css& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/contracing_company/main/ToDoList.vue?vue&type=style&index=0&id=c2f90472&scoped=true&lang=css&");


/***/ }),

/***/ "./resources/js/contracing_company/main/ToDoList.vue?vue&type=style&index=1&id=c2f90472&scoped=true&lang=css&":
/*!********************************************************************************************************************!*\
  !*** ./resources/js/contracing_company/main/ToDoList.vue?vue&type=style&index=1&id=c2f90472&scoped=true&lang=css& ***!
  \********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_ToDoList_vue_vue_type_style_index_1_id_c2f90472_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./ToDoList.vue?vue&type=style&index=1&id=c2f90472&scoped=true&lang=css& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/contracing_company/main/ToDoList.vue?vue&type=style&index=1&id=c2f90472&scoped=true&lang=css&");


/***/ }),

/***/ "./resources/js/contracing_company/main/components/AskPermissionModal.vue?vue&type=style&index=0&id=79f638aa&scoped=true&lang=css&":
/*!*****************************************************************************************************************************************!*\
  !*** ./resources/js/contracing_company/main/components/AskPermissionModal.vue?vue&type=style&index=0&id=79f638aa&scoped=true&lang=css& ***!
  \*****************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_AskPermissionModal_vue_vue_type_style_index_0_id_79f638aa_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/style-loader/dist/cjs.js!../../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AskPermissionModal.vue?vue&type=style&index=0&id=79f638aa&scoped=true&lang=css& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/contracing_company/main/components/AskPermissionModal.vue?vue&type=style&index=0&id=79f638aa&scoped=true&lang=css&");


/***/ }),

/***/ "./resources/js/contracing_company/main/ToDoList.vue?vue&type=template&id=c2f90472&scoped=true&":
/*!******************************************************************************************************!*\
  !*** ./resources/js/contracing_company/main/ToDoList.vue?vue&type=template&id=c2f90472&scoped=true& ***!
  \******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ToDoList_vue_vue_type_template_id_c2f90472_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ToDoList_vue_vue_type_template_id_c2f90472_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ToDoList_vue_vue_type_template_id_c2f90472_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./ToDoList.vue?vue&type=template&id=c2f90472&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/contracing_company/main/ToDoList.vue?vue&type=template&id=c2f90472&scoped=true&");


/***/ }),

/***/ "./resources/js/contracing_company/main/components/AskPermissionModal.vue?vue&type=template&id=79f638aa&scoped=true&":
/*!***************************************************************************************************************************!*\
  !*** ./resources/js/contracing_company/main/components/AskPermissionModal.vue?vue&type=template&id=79f638aa&scoped=true& ***!
  \***************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_AskPermissionModal_vue_vue_type_template_id_79f638aa_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_AskPermissionModal_vue_vue_type_template_id_79f638aa_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_AskPermissionModal_vue_vue_type_template_id_79f638aa_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AskPermissionModal.vue?vue&type=template&id=79f638aa&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/contracing_company/main/components/AskPermissionModal.vue?vue&type=template&id=79f638aa&scoped=true&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/contracing_company/main/ToDoList.vue?vue&type=template&id=c2f90472&scoped=true&":
/*!*********************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/contracing_company/main/ToDoList.vue?vue&type=template&id=c2f90472&scoped=true& ***!
  \*********************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "component-wrap" },
    [
      _c("AskPermissionModal", { ref: "permissionref" }),
      _vm._v(" "),
      _c(
        "v-container",
        { attrs: { "grid-list-md": "" } },
        [
          _c("v-flex", { attrs: { "pt-3": "", "pb-5": "" } }, [
            _c(
              "h1",
              {
                staticClass: "text-md-center",
                staticStyle: { color: "#0000008a" },
              },
              [
                _vm._v(
                  "\n                " +
                    _vm._s(_vm.trans("data.Engineering_offices_system")) +
                    "\n            "
                ),
              ]
            ),
          ]),
          _vm._v(" "),
          _c(
            "v-card",
            { attrs: { "pt-3": "" } },
            [
              _c(
                "v-card-text",
                [
                  _c(
                    "v-container",
                    { attrs: { "grid-list-lg": "" } },
                    [
                      _c(
                        "v-layout",
                        { attrs: { wrap: "" } },
                        [
                          _vm.$can("tickets.view")
                            ? _c(
                                "v-flex",
                                { attrs: { xs12: "", sm12: "", md4: "" } },
                                [
                                  _c(
                                    "v-flex",
                                    { attrs: { xs12: "", sm12: "", md12: "" } },
                                    [
                                      _c("v-hover", {
                                        attrs: {
                                          "open-delay": "100",
                                          "close-delay": "100",
                                        },
                                        scopedSlots: _vm._u(
                                          [
                                            {
                                              key: "default",
                                              fn: function (ref) {
                                                var hover = ref.hover
                                                return [
                                                  _c(
                                                    "v-card",
                                                    {
                                                      staticClass:
                                                        "not_working",
                                                      attrs: {
                                                        elevation: hover
                                                          ? 16
                                                          : 2,
                                                      },
                                                      on: {
                                                        click: function (
                                                          $event
                                                        ) {
                                                          return _vm.$router.push(
                                                            {
                                                              name: "contractor_request_list",
                                                            }
                                                          )
                                                        },
                                                      },
                                                    },
                                                    [
                                                      _c("v-card-text", [
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "text-md-center mt-2",
                                                          },
                                                          [
                                                            _c(
                                                              "p",
                                                              {
                                                                staticStyle: {
                                                                  "font-size":
                                                                    "18px",
                                                                  color:
                                                                    "#06706d",
                                                                },
                                                                attrs: {
                                                                  "x-large": "",
                                                                },
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n                                                    " +
                                                                    _vm._s(
                                                                      _vm.trans(
                                                                        "data.contractor_request"
                                                                      ) +
                                                                        " (" +
                                                                        _vm
                                                                          .$store
                                                                          .state
                                                                          .Store
                                                                          .countContractorRequest +
                                                                        ")"
                                                                    ) +
                                                                    "  \n                                                    "
                                                                ),
                                                                _c(
                                                                  "v-icon",
                                                                  {
                                                                    attrs: {
                                                                      color:
                                                                        "#06706d",
                                                                    },
                                                                  },
                                                                  [
                                                                    _vm._v(
                                                                      "settings"
                                                                    ),
                                                                  ]
                                                                ),
                                                              ],
                                                              1
                                                            ),
                                                          ]
                                                        ),
                                                      ]),
                                                    ],
                                                    1
                                                  ),
                                                ]
                                              },
                                            },
                                          ],
                                          null,
                                          false,
                                          2637123831
                                        ),
                                      }),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              )
                            : _vm._e(),
                          _vm._v(" "),
                          _vm.$can("archive")
                            ? _c(
                                "v-flex",
                                { attrs: { xs12: "", sm12: "", md4: "" } },
                                [
                                  _c(
                                    "v-flex",
                                    { attrs: { xs12: "", sm12: "", md12: "" } },
                                    [
                                      _c("v-hover", {
                                        attrs: {
                                          "open-delay": "100",
                                          "close-delay": "100",
                                        },
                                        scopedSlots: _vm._u(
                                          [
                                            {
                                              key: "default",
                                              fn: function (ref) {
                                                var hover = ref.hover
                                                return [
                                                  _c(
                                                    "v-card",
                                                    {
                                                      staticClass:
                                                        "not_working",
                                                      attrs: {
                                                        elevation: hover
                                                          ? 16
                                                          : 2,
                                                      },
                                                      on: {
                                                        click: function (
                                                          $event
                                                        ) {
                                                          return _vm.$router.push(
                                                            { name: "archives" }
                                                          )
                                                        },
                                                      },
                                                    },
                                                    [
                                                      _c("v-card-text", [
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "text-md-center mt-2",
                                                          },
                                                          [
                                                            _c(
                                                              "p",
                                                              {
                                                                staticStyle: {
                                                                  "font-size":
                                                                    "18px",
                                                                  color:
                                                                    "#06706d",
                                                                },
                                                                attrs: {
                                                                  "x-large": "",
                                                                },
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n                                                    " +
                                                                    _vm._s(
                                                                      _vm.trans(
                                                                        "data.archive"
                                                                      )
                                                                    ) +
                                                                    "  \n                                                    "
                                                                ),
                                                                _c(
                                                                  "v-icon",
                                                                  {
                                                                    attrs: {
                                                                      color:
                                                                        "#06706d",
                                                                    },
                                                                  },
                                                                  [
                                                                    _vm._v(
                                                                      "settings"
                                                                    ),
                                                                  ]
                                                                ),
                                                              ],
                                                              1
                                                            ),
                                                          ]
                                                        ),
                                                      ]),
                                                    ],
                                                    1
                                                  ),
                                                ]
                                              },
                                            },
                                          ],
                                          null,
                                          false,
                                          4220640691
                                        ),
                                      }),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              )
                            : _vm._e(),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm12: "", md4: "" } },
                            [
                              _c(
                                "v-flex",
                                { attrs: { xs12: "", sm12: "", md12: "" } },
                                [
                                  _c("v-hover", {
                                    attrs: {
                                      "open-delay": "100",
                                      "close-delay": "100",
                                    },
                                    scopedSlots: _vm._u([
                                      {
                                        key: "default",
                                        fn: function (ref) {
                                          var hover = ref.hover
                                          return [
                                            _c(
                                              "v-card",
                                              {
                                                staticClass: "not_working",
                                                attrs: {
                                                  elevation: hover ? 16 : 2,
                                                },
                                              },
                                              [
                                                _c("v-card-text", [
                                                  _c(
                                                    "div",
                                                    {
                                                      staticClass:
                                                        "text-md-center mt-2",
                                                    },
                                                    [
                                                      _c(
                                                        "p",
                                                        {
                                                          staticStyle: {
                                                            "font-size": "18px",
                                                            color: "#06706d",
                                                          },
                                                          attrs: {
                                                            "x-large": "",
                                                          },
                                                        },
                                                        [
                                                          _vm._v(
                                                            "\n                                                    " +
                                                              _vm._s(
                                                                _vm.trans(
                                                                  "data.accounting"
                                                                )
                                                              ) +
                                                              "  \n                                                    "
                                                          ),
                                                          _c(
                                                            "v-icon",
                                                            {
                                                              attrs: {
                                                                color:
                                                                  "#06706d",
                                                              },
                                                            },
                                                            [_vm._v("settings")]
                                                          ),
                                                        ],
                                                        1
                                                      ),
                                                    ]
                                                  ),
                                                ]),
                                              ],
                                              1
                                            ),
                                          ]
                                        },
                                      },
                                    ]),
                                  }),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _vm.$can("report.view")
                            ? _c(
                                "v-flex",
                                { attrs: { xs12: "", sm12: "", md4: "" } },
                                [
                                  _c(
                                    "v-flex",
                                    { attrs: { xs12: "", sm12: "", md12: "" } },
                                    [
                                      _c("v-hover", {
                                        attrs: {
                                          "open-delay": "100",
                                          "close-delay": "100",
                                        },
                                        scopedSlots: _vm._u(
                                          [
                                            {
                                              key: "default",
                                              fn: function (ref) {
                                                var hover = ref.hover
                                                return [
                                                  _c(
                                                    "v-card",
                                                    {
                                                      staticClass:
                                                        "not_working",
                                                      attrs: {
                                                        elevation: hover
                                                          ? 16
                                                          : 2,
                                                      },
                                                      on: {
                                                        click: function (
                                                          $event
                                                        ) {
                                                          return _vm.$router.push(
                                                            {
                                                              name: "reports_list",
                                                            }
                                                          )
                                                        },
                                                      },
                                                    },
                                                    [
                                                      _c("v-card-text", [
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "text-md-center mt-2",
                                                          },
                                                          [
                                                            _c(
                                                              "p",
                                                              {
                                                                staticStyle: {
                                                                  "font-size":
                                                                    "18px",
                                                                  color:
                                                                    "#06706d",
                                                                },
                                                                attrs: {
                                                                  "x-large": "",
                                                                },
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n                                                    " +
                                                                    _vm._s(
                                                                      _vm.trans(
                                                                        "data.reports"
                                                                      )
                                                                    ) +
                                                                    "  \n                                                    "
                                                                ),
                                                                _c(
                                                                  "v-icon",
                                                                  {
                                                                    attrs: {
                                                                      color:
                                                                        "#06706d",
                                                                    },
                                                                  },
                                                                  [
                                                                    _vm._v(
                                                                      "settings"
                                                                    ),
                                                                  ]
                                                                ),
                                                              ],
                                                              1
                                                            ),
                                                          ]
                                                        ),
                                                      ]),
                                                    ],
                                                    1
                                                  ),
                                                ]
                                              },
                                            },
                                          ],
                                          null,
                                          false,
                                          4158631165
                                        ),
                                      }),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              )
                            : _vm._e(),
                          _vm._v(" "),
                           false
                            ? 0
                            : _vm._e(),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm12: "", md4: "" } },
                            [
                              _c(
                                "v-flex",
                                { attrs: { xs12: "", sm12: "", md12: "" } },
                                [
                                  _c("v-hover", {
                                    attrs: {
                                      "open-delay": "100",
                                      "close-delay": "100",
                                    },
                                    scopedSlots: _vm._u([
                                      {
                                        key: "default",
                                        fn: function (ref) {
                                          var hover = ref.hover
                                          return [
                                            _c(
                                              "v-card",
                                              {
                                                attrs: {
                                                  elevation: hover ? 16 : 2,
                                                },
                                                on: {
                                                  click: function ($event) {
                                                    return _vm.$router.push({
                                                      name: "project_management_estate_owner",
                                                    })
                                                  },
                                                },
                                              },
                                              [
                                                _c("v-card-text", [
                                                  _c(
                                                    "div",
                                                    {
                                                      staticClass:
                                                        "text-md-center mt-2",
                                                    },
                                                    [
                                                      _c(
                                                        "p",
                                                        {
                                                          staticStyle: {
                                                            "font-size": "18px",
                                                            color: "#06706d",
                                                          },
                                                          attrs: {
                                                            "x-large": "",
                                                          },
                                                        },
                                                        [
                                                          _vm._v(
                                                            "\n                                                    " +
                                                              _vm._s(
                                                                _vm.trans(
                                                                  "data.project_management"
                                                                )
                                                              ) +
                                                              "  \n                                                    "
                                                          ),
                                                          _c(
                                                            "v-icon",
                                                            {
                                                              attrs: {
                                                                color:
                                                                  "#06706d",
                                                              },
                                                            },
                                                            [_vm._v("settings")]
                                                          ),
                                                        ],
                                                        1
                                                      ),
                                                    ]
                                                  ),
                                                ]),
                                              ],
                                              1
                                            ),
                                          ]
                                        },
                                      },
                                    ]),
                                  }),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm12: "", md4: "" } },
                            [
                              _c(
                                "v-flex",
                                { attrs: { xs12: "", sm12: "", md12: "" } },
                                [
                                  _c("v-hover", {
                                    attrs: {
                                      "open-delay": "100",
                                      "close-delay": "100",
                                    },
                                    scopedSlots: _vm._u([
                                      {
                                        key: "default",
                                        fn: function (ref) {
                                          var hover = ref.hover
                                          return [
                                            _c(
                                              "v-card",
                                              {
                                                attrs: {
                                                  elevation: hover ? 16 : 2,
                                                },
                                                on: {
                                                  click: function ($event) {
                                                    return _vm.$router.push({})
                                                  },
                                                },
                                              },
                                              [
                                                _c("v-card-text", [
                                                  _c(
                                                    "div",
                                                    {
                                                      staticClass:
                                                        "text-md-center mt-2",
                                                    },
                                                    [
                                                      _c(
                                                        "p",
                                                        {
                                                          staticStyle: {
                                                            "font-size": "18px",
                                                            color: "#06706d",
                                                          },
                                                          attrs: {
                                                            "x-large": "",
                                                          },
                                                        },
                                                        [
                                                          _vm._v(
                                                            "\n                                                    " +
                                                              _vm._s(
                                                                _vm.trans(
                                                                  "data.public_bills"
                                                                )
                                                              ) +
                                                              "  \n                                                    "
                                                          ),
                                                          _c(
                                                            "v-icon",
                                                            {
                                                              attrs: {
                                                                color:
                                                                  "#06706d",
                                                              },
                                                            },
                                                            [_vm._v("settings")]
                                                          ),
                                                        ],
                                                        1
                                                      ),
                                                    ]
                                                  ),
                                                ]),
                                              ],
                                              1
                                            ),
                                          ]
                                        },
                                      },
                                    ]),
                                  }),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm12: "", md4: "" } },
                            [
                              _c(
                                "v-flex",
                                { attrs: { xs12: "", sm12: "", md12: "" } },
                                [
                                  _c("v-hover", {
                                    attrs: {
                                      "open-delay": "100",
                                      "close-delay": "100",
                                    },
                                    scopedSlots: _vm._u([
                                      {
                                        key: "default",
                                        fn: function (ref) {
                                          var hover = ref.hover
                                          return [
                                            _c(
                                              "v-card",
                                              {
                                                attrs: {
                                                  elevation: hover ? 16 : 2,
                                                },
                                                on: {
                                                  click: function ($event) {
                                                    return _vm.$router.push({})
                                                  },
                                                },
                                              },
                                              [
                                                _c("v-card-text", [
                                                  _c(
                                                    "div",
                                                    {
                                                      staticClass:
                                                        "text-md-center mt-2",
                                                    },
                                                    [
                                                      _c(
                                                        "p",
                                                        {
                                                          staticStyle: {
                                                            "font-size": "18px",
                                                            color: "#06706d",
                                                          },
                                                          attrs: {
                                                            "x-large": "",
                                                          },
                                                        },
                                                        [
                                                          _vm._v(
                                                            "\n                                                    " +
                                                              _vm._s(
                                                                _vm.trans(
                                                                  "data.statistics"
                                                                )
                                                              ) +
                                                              "  \n                                                    "
                                                          ),
                                                          _c(
                                                            "v-icon",
                                                            {
                                                              attrs: {
                                                                color:
                                                                  "#06706d",
                                                              },
                                                            },
                                                            [_vm._v("settings")]
                                                          ),
                                                        ],
                                                        1
                                                      ),
                                                    ]
                                                  ),
                                                ]),
                                              ],
                                              1
                                            ),
                                          ]
                                        },
                                      },
                                    ]),
                                  }),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _vm.$can("employee.view")
                            ? _c(
                                "v-flex",
                                { attrs: { xs12: "", sm12: "", md4: "" } },
                                [
                                  _c(
                                    "v-flex",
                                    { attrs: { xs12: "", sm12: "", md12: "" } },
                                    [
                                      _c("v-hover", {
                                        attrs: {
                                          "open-delay": "100",
                                          "close-delay": "100",
                                        },
                                        scopedSlots: _vm._u(
                                          [
                                            {
                                              key: "default",
                                              fn: function (ref) {
                                                var hover = ref.hover
                                                return [
                                                  _c(
                                                    "v-card",
                                                    {
                                                      attrs: {
                                                        elevation: hover
                                                          ? 16
                                                          : 2,
                                                      },
                                                      on: {
                                                        click: function (
                                                          $event
                                                        ) {
                                                          return _vm.$router.push(
                                                            {
                                                              name: "users_estate.list",
                                                            }
                                                          )
                                                        },
                                                      },
                                                    },
                                                    [
                                                      _c("v-card-text", [
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "text-md-center mt-2",
                                                          },
                                                          [
                                                            _c(
                                                              "p",
                                                              {
                                                                staticStyle: {
                                                                  "font-size":
                                                                    "18px",
                                                                  color:
                                                                    "#06706d",
                                                                },
                                                                attrs: {
                                                                  "x-large": "",
                                                                },
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n                                                    " +
                                                                    _vm._s(
                                                                      _vm.trans(
                                                                        "data.users"
                                                                      )
                                                                    ) +
                                                                    "  \n                                                    "
                                                                ),
                                                                _c(
                                                                  "v-icon",
                                                                  {
                                                                    attrs: {
                                                                      color:
                                                                        "#06706d",
                                                                    },
                                                                  },
                                                                  [
                                                                    _vm._v(
                                                                      "settings"
                                                                    ),
                                                                  ]
                                                                ),
                                                              ],
                                                              1
                                                            ),
                                                          ]
                                                        ),
                                                      ]),
                                                    ],
                                                    1
                                                  ),
                                                ]
                                              },
                                            },
                                          ],
                                          null,
                                          false,
                                          1444825642
                                        ),
                                      }),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              )
                            : _vm._e(),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm12: "", md4: "" } },
                            [
                              _c(
                                "v-flex",
                                { attrs: { xs12: "", sm12: "", md12: "" } },
                                [
                                  _c("v-hover", {
                                    attrs: {
                                      "open-delay": "100",
                                      "close-delay": "100",
                                    },
                                    scopedSlots: _vm._u([
                                      {
                                        key: "default",
                                        fn: function (ref) {
                                          var hover = ref.hover
                                          return [
                                            _c(
                                              "v-card",
                                              {
                                                attrs: {
                                                  elevation: hover ? 16 : 2,
                                                },
                                                on: {
                                                  click: function ($event) {
                                                    return _vm.askforpermission()
                                                  },
                                                },
                                              },
                                              [
                                                _c("v-card-text", [
                                                  _c(
                                                    "div",
                                                    {
                                                      staticClass:
                                                        "text-md-center mt-2",
                                                    },
                                                    [
                                                      _c(
                                                        "p",
                                                        {
                                                          staticStyle: {
                                                            "font-size": "18px",
                                                            color: "#06706d",
                                                          },
                                                          attrs: {
                                                            "x-large": "",
                                                          },
                                                        },
                                                        [
                                                          _vm._v(
                                                            "\n                                                    " +
                                                              _vm._s(
                                                                _vm.trans(
                                                                  "data.ask_for_permission"
                                                                )
                                                              ) +
                                                              "  \n                                                    "
                                                          ),
                                                          _c(
                                                            "v-icon",
                                                            {
                                                              attrs: {
                                                                color:
                                                                  "#06706d",
                                                              },
                                                            },
                                                            [_vm._v("settings")]
                                                          ),
                                                        ],
                                                        1
                                                      ),
                                                    ]
                                                  ),
                                                ]),
                                              ],
                                              1
                                            ),
                                          ]
                                        },
                                      },
                                    ]),
                                  }),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c("br"),
          _vm._v(" "),
          _c(
            "div",
            { attrs: { align: "center" } },
            [
              _c(
                "v-btn",
                {
                  staticStyle: {
                    "background-color": "#06706d",
                    color: "white",
                  },
                  on: {
                    click: function ($event) {
                      return _vm.$router.go(-1)
                    },
                  },
                },
                [
                  _vm._v(
                    "\n                " +
                      _vm._s(_vm.trans("messages.back")) +
                      "\n            "
                  ),
                ]
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c("br"),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/contracing_company/main/components/AskPermissionModal.vue?vue&type=template&id=79f638aa&scoped=true&":
/*!******************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/contracing_company/main/components/AskPermissionModal.vue?vue&type=template&id=79f638aa&scoped=true& ***!
  \******************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { attrs: { justify: "center" } },
    [
      _c(
        "v-dialog",
        {
          attrs: { persistent: "", "max-width": "500px" },
          model: {
            value: _vm.dialog,
            callback: function ($$v) {
              _vm.dialog = $$v
            },
            expression: "dialog",
          },
        },
        [
          _c(
            "v-card",
            [
              _c(
                "v-card-text",
                [
                  _c(
                    "v-form",
                    {
                      ref: "form",
                      attrs: { "lazy-validation": "" },
                      model: {
                        value: _vm.valid,
                        callback: function ($$v) {
                          _vm.valid = $$v
                        },
                        expression: "valid",
                      },
                    },
                    [
                      _c("v-container", [
                        _c(
                          "div",
                          { staticClass: "row" },
                          [
                            _c(
                              "v-flex",
                              { attrs: { xs12: "", sm12: "", md12: "" } },
                              [
                                _c("v-autocomplete", {
                                  attrs: {
                                    "item-text": "name",
                                    "item-value": "id",
                                    items: _vm.permissions,
                                    rules: [
                                      function (v) {
                                        return (
                                          !!v ||
                                          _vm.trans("messages.required", {
                                            name: _vm.trans("data.role_name"),
                                          })
                                        )
                                      },
                                    ],
                                    label: _vm.trans("data.choose_permission"),
                                    "error-messages":
                                      _vm.errors.collect("permission"),
                                    required: "",
                                  },
                                  model: {
                                    value: _vm.permission,
                                    callback: function ($$v) {
                                      _vm.permission = $$v
                                    },
                                    expression: "permission",
                                  },
                                }),
                              ],
                              1
                            ),
                            _vm._v(" "),
                            _c(
                              "v-flex",
                              { attrs: { xs12: "", sm12: "", md12: "" } },
                              [
                                _c("v-text-field", {
                                  attrs: {
                                    label: _vm.trans("data.select_document"),
                                  },
                                  on: { click: _vm.onPickFile },
                                  model: {
                                    value: _vm.fileName,
                                    callback: function ($$v) {
                                      _vm.fileName = $$v
                                    },
                                    expression: "fileName",
                                  },
                                }),
                                _vm._v(" "),
                                _c("input", {
                                  ref: "fileInput",
                                  staticStyle: { display: "none" },
                                  attrs: { type: "file", accept: "*/*" },
                                  on: { change: _vm.onFilePicked },
                                }),
                              ],
                              1
                            ),
                            _vm._v(" "),
                            _c(
                              "v-flex",
                              { attrs: { xs12: "", sm12: "", md12: "" } },
                              [
                                _c("v-text-field", {
                                  attrs: { label: _vm.trans("data.note") },
                                  model: {
                                    value: _vm.note,
                                    callback: function ($$v) {
                                      _vm.note = $$v
                                    },
                                    expression: "note",
                                  },
                                }),
                              ],
                              1
                            ),
                          ],
                          1
                        ),
                      ]),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "v-card-actions",
                [
                  _c("v-spacer"),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      staticStyle: { color: "#06706d" },
                      attrs: { text: "" },
                      on: {
                        click: function ($event) {
                          return _vm.close()
                        },
                      },
                    },
                    [
                      _vm._v(
                        "\n                        " +
                          _vm._s(_vm.trans("data.cancel")) +
                          "\n                    "
                      ),
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      staticStyle: {
                        "background-color": "#06706d",
                        color: "white",
                      },
                      attrs: {
                        color: "darken-1",
                        loading: _vm.loading,
                        disabled: _vm.loading || !_vm.checkActive(),
                        text: "",
                      },
                      on: {
                        click: function ($event) {
                          return _vm.save()
                        },
                      },
                    },
                    [
                      _vm._v(
                        "\n                        " +
                          _vm._s(_vm.trans("data.save")) +
                          "\n                    "
                      ),
                    ]
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);