"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_common_archives_ArchivesData_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/ArchivesData.vue?vue&type=script&lang=js&":
/*!************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/ArchivesData.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components_ProjectsFilters_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./components/ProjectsFilters.vue */ "./resources/js/common/archives/components/ProjectsFilters.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  components: {
    ProjectFilters: _components_ProjectsFilters_vue__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  data: function data() {
    return {
      tab: null
    };
  },
  methods: {}
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/components/ProjectsFilters.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/components/ProjectsFilters.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _projectDetailes_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./projectDetailes.vue */ "./resources/js/common/archives/components/projectDetailes.vue");
/* harmony import */ var _ReportDetailes_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ReportDetailes.vue */ "./resources/js/common/archives/components/ReportDetailes.vue");
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }
function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter); }
function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  components: {
    ProjectDetailes: _projectDetailes_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    ReportDetailes: _ReportDetailes_vue__WEBPACK_IMPORTED_MODULE_1__["default"]
  },
  props: {
    projects: {
      type: Boolean,
      "default": true
    },
    reports: {
      type: Boolean,
      "default": false
    }
  },
  data: function data() {
    var self = this;
    return {
      projectID: null,
      locationSearch: false,
      projectData: [],
      province_municipalities: [],
      municipalities: [],
      filterColumnsList: [],
      reportData: [],
      tableRelation: false,
      province_municipality: false,
      municipality: false,
      plan_id: false,
      piece_number: false,
      statuses: [],
      filterTypeList: [{
        id: 'owners',
        name: self.trans('data.searchBy.customer')
      }, {
        id: 'location',
        name: self.trans('data.searchBy.location')
      }, {
        id: 'id',
        name: self.trans('data.id')
      }],
      lists: {
        owners: [{
          id: 'name',
          name: self.trans('data.name')
        }, {
          id: 'email',
          name: self.trans('data.email_address')
        }, {
          id: 'mobile',
          name: self.trans('data.mobile')
        }, {
          id: 'id_card_number',
          name: self.trans('data.id_card_number')
        }],
        location: [{
          id: 'province_municipality',
          name: self.trans('data.province_municipality')
        }, {
          id: 'municipality',
          name: self.trans('data.municipality')
        }, {
          id: 'category',
          name: self.trans('data.searchBy.category')
        }, {
          id: 'piece_number',
          name: self.trans('data.piece_number')
        }, {
          id: 'size_number',
          name: self.trans('data.size_number')
        }, {
          id: 'instrument_number',
          name: self.trans('data.instrument_number')
        }, {
          id: 'status',
          name: self.trans('data.searchBy.status')
        }]
      },
      url: null,
      users: [{
        id: 0,
        name: self.trans('messages.all')
      }],
      filters: [],
      statistics: [],
      loading: false,
      searchBy: null
    };
  },
  created: function created() {
    var self = this;
    self.url = '/project/dataFilters';
    self.getDataFromApi();
    self.getFilterData();
    self.getLocationInfo();
    self.$eventBus.$on('updateProjectTable', function (data) {
      self.url = '/project/dataFilters';
      self.projectData = [];
      self.reportData = [];
      self.getDataFromApi();
    });
  },
  methods: {
    selectData: function selectData(event) {
      this.searchBy = event;
      this.locationSearch = false;
      this.province_municipality = false;
      this.municipality = false;
      this.plan_id = false;
      this.tableRelation = this.lists[event];
      this.filterColumnsList = this.lists[event];
      this.filters.columnTable = null;
      if (event === 'location') {
        this.locationSearch = true;
      }
    },
    getLocationInfo: function getLocationInfo() {
      var self = this;
      axios.get('/get-location-info').then(function (response) {
        self.province_municipalities = response.data.provinceMunicipalities;
        self.municipalities = response.data.municipalities;
      })["catch"](function (err) {
        console.log(err.response.status);
        if (err.response.status === 401) {
          store.dispatch('auth/handleResponse', err.response);
        }
      });
    },
    clearInputs: function clearInputs() {
      this.filters = [];
    },
    getDataFromApi: function getDataFromApi() {
      var self = this;
      self.loading = true;
      var params = {};
      if (self.filters.searchInTable) {
        params['search'] = self.filters.searchInTable;
      }
      if (self.reports) {
        params['searchIn'] = 'reports';
      }
      if (self.filters.type) {
        params['type'] = self.filters.type;
      }
      if (self.filters.columnTable) {
        params['columnTable'] = self.filters.columnTable;
      }
      if (self.filters.startDate) {
        params['startDate'] = self.filters.startDate;
      }
      if (self.filters.endDate) {
        params['endDate'] = self.filters.endDate;
      }
      if (self.filters.province_municipality) {
        params['province_municipality'] = self.filters.province_municipality;
      }
      if (self.filters.municipality) {
        params['municipality'] = self.filters.municipality;
      }
      if (self.filters.plan_id) {
        params['plan_id'] = self.filters.plan_id;
      }
      if (self.filters.piece_number) {
        params['piece_number'] = self.filters.piece_number;
      }
      axios.get(self.url, {
        params: params
      }).then(function (response) {
        self.loading = false;
        self.projectData = _.concat(self.projectData, response.data.projects);
        self.projectData.forEach(function (val) {
          var _self$reportData;
          val.report.map(function (x) {
            return x.owners = val.owners;
          });
          (_self$reportData = self.reportData).push.apply(_self$reportData, _toConsumableArray(val.report));
        });
        if (self.searchBy == 'id' && self.reports) {
          self.reportData = self.reportData.filter(function (val) {
            return val.id == self.filters.searchInTable;
          });
        }
        self.statuses = response.data.status;
        self.url = _.get(response, 'data.projects.next_page_url', null);
        self.getStatistics();
      })["catch"](function (error) {
        console.log(error);
      });
    },
    getFilterData: function getFilterData() {
      var self = this;
      //   if (self.$can('superadmin')) {
      axios.get('/projects/create').then(function (response) {
        self.users = _.concat(self.users, response.data.data.users);
        self.customers = _.concat(self.customers, response.data.data.customers);
        self.status = _.concat(self.status, response.data.data.status);
        self.categories = _.concat(self.categories, response.data.data.categories);
        self.tasks = _.concat(self.categories, response.data.data.tasks);
      })["catch"](function (error) {
        console.log(error);
      });
      //   }
    },
    filterChanged: function filterChanged() {
      var self = this;
      self.url = '/project/dataFilters';
      self.projectData = [];
      self.reportData = [];
      self.getDataFromApi();
    },
    getStatistics: function getStatistics() {
      var self = this;
      if (self.$can('superadmin')) {
        axios.get('/projects-statistics').then(function (response) {
          self.statistics = response.data;
        })["catch"](function (error) {
          console.log(error);
        });
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/components/ReportDetailes.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/components/ReportDetailes.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  props: {
    reportData: {
      type: Array,
      "default": []
    }
  },
  data: function data() {
    return {
      selected: [2],
      language: null
    };
  },
  created: function created() {
    this.language = localStorage.getItem('currentLange');
  },
  methods: {
    view: function view(id) {
      var self = this;
      self.$router.push({
        name: 'view_project',
        params: {
          id: id
        }
      });

      // self.$refs.projectEdit.edit(id);
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/components/projectDetailes.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/components/projectDetailes.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  props: {
    projectData: {
      type: Array,
      "default": []
    }
  },
  data: function data() {
    return {
      selected: [2]
    };
  },
  methods: {
    markAsFavorite: function markAsFavorite(project) {
      var self = this;
      axios.get('/projects/mark-favorite', {
        params: {
          id: project.id,
          favorite: project.is_favorited
        }
      }).then(function (response) {
        self.$store.commit('showSnackbar', {
          message: response.data.msg,
          color: response.data.success
        });
        project.is_favorited = response.data.favorite;
      })["catch"](function (err) {
        console.log(err.response.status);
        if (err.response.status === 401) {
          store.dispatch('auth/handleResponse', err.response);
        }
      });
    },
    view: function view(id) {
      var self = this;
      self.$router.push({
        name: 'view_project',
        params: {
          id: id
        }
      });

      // self.$refs.projectEdit.edit(id);
    },
    toggleFavorite: function toggleFavorite(project) {
      if (project.is_favorited) {
        return 'yellow darken-2';
      } else {
        return 'grey lighten-1';
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/ArchivesData.vue?vue&type=style&index=0&id=24930c93&scoped=true&lang=css&":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/ArchivesData.vue?vue&type=style&index=0&id=24930c93&scoped=true&lang=css& ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "\n.content[data-v-24930c93]{\r\n  display: flex;\r\n  flex-direction: row!important;\r\n  height: 100%;\r\n  width: 100%;\n}\r\n", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/components/ReportDetailes.vue?vue&type=style&index=0&id=3ebb06c4&scoped=true&lang=css&":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/components/ReportDetailes.vue?vue&type=style&index=0&id=3ebb06c4&scoped=true&lang=css& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "\n.element[data-v-3ebb06c4]{\r\n    display: flex;\r\n    align-items: center;\n}\n.col-title[data-v-3ebb06c4]{\r\n    background: rgb(207 205 242 / 44%);\r\n    height: 100%;\r\n    padding: 0.5rem;\r\n    font-size:12px;\r\n    width: 20rem;\r\n    text-align: center;\n}\n.content[data-v-3ebb06c4]{\r\n    padding-right:1rem;\r\n       padding-left:1rem;\r\n    width:100%;\r\n    font-size:14px!important;\r\n    border-bottom: 1px solid rgb(228, 228, 228);\n}\n.btn-bar[data-v-3ebb06c4]{\r\n    display: flex;\r\n    justify-content: flex-end;\n}\n.container-list[data-v-3ebb06c4]\r\n{\r\n    max-height: 25rem;\r\n    overflow-y: auto;\n}\r\n", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/components/projectDetailes.vue?vue&type=style&index=0&id=0ca80137&scoped=true&lang=css&":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/components/projectDetailes.vue?vue&type=style&index=0&id=0ca80137&scoped=true&lang=css& ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "\n.element[data-v-0ca80137]{\r\n    display: flex;\r\n    align-items: center;\n}\n.col-title[data-v-0ca80137]{\r\n     background: rgb(207 205 242 / 44%);\r\n    height: 100%;\r\n    padding: 0.5rem;\r\n    font-size:12px;\r\n    width: 20rem;\r\n    text-align: center;\n}\n.content[data-v-0ca80137]{\r\n    padding-right:1rem;\r\n       padding-left:1rem;\r\n    width:100%;\r\n    font-size:14px!important;\r\n    border-bottom: 1px solid rgb(228, 228, 228);\n}\n.btn-bar[data-v-0ca80137]{\r\n    display: flex;\r\n    justify-content: flex-end;\n}\n.container-list[data-v-0ca80137]\r\n{\r\n    max-height: 25rem;\r\n    overflow-y: auto;\n}\r\n", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/ArchivesData.vue?vue&type=style&index=0&id=24930c93&scoped=true&lang=css&":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/ArchivesData.vue?vue&type=style&index=0&id=24930c93&scoped=true&lang=css& ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_ArchivesData_vue_vue_type_style_index_0_id_24930c93_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./ArchivesData.vue?vue&type=style&index=0&id=24930c93&scoped=true&lang=css& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/ArchivesData.vue?vue&type=style&index=0&id=24930c93&scoped=true&lang=css&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_ArchivesData_vue_vue_type_style_index_0_id_24930c93_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_ArchivesData_vue_vue_type_style_index_0_id_24930c93_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/components/ReportDetailes.vue?vue&type=style&index=0&id=3ebb06c4&scoped=true&lang=css&":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/components/ReportDetailes.vue?vue&type=style&index=0&id=3ebb06c4&scoped=true&lang=css& ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_ReportDetailes_vue_vue_type_style_index_0_id_3ebb06c4_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./ReportDetailes.vue?vue&type=style&index=0&id=3ebb06c4&scoped=true&lang=css& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/components/ReportDetailes.vue?vue&type=style&index=0&id=3ebb06c4&scoped=true&lang=css&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_ReportDetailes_vue_vue_type_style_index_0_id_3ebb06c4_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_ReportDetailes_vue_vue_type_style_index_0_id_3ebb06c4_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/components/projectDetailes.vue?vue&type=style&index=0&id=0ca80137&scoped=true&lang=css&":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/components/projectDetailes.vue?vue&type=style&index=0&id=0ca80137&scoped=true&lang=css& ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_projectDetailes_vue_vue_type_style_index_0_id_0ca80137_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./projectDetailes.vue?vue&type=style&index=0&id=0ca80137&scoped=true&lang=css& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/components/projectDetailes.vue?vue&type=style&index=0&id=0ca80137&scoped=true&lang=css&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_projectDetailes_vue_vue_type_style_index_0_id_0ca80137_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_projectDetailes_vue_vue_type_style_index_0_id_0ca80137_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./resources/js/common/archives/ArchivesData.vue":
/*!*******************************************************!*\
  !*** ./resources/js/common/archives/ArchivesData.vue ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _ArchivesData_vue_vue_type_template_id_24930c93_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ArchivesData.vue?vue&type=template&id=24930c93&scoped=true& */ "./resources/js/common/archives/ArchivesData.vue?vue&type=template&id=24930c93&scoped=true&");
/* harmony import */ var _ArchivesData_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ArchivesData.vue?vue&type=script&lang=js& */ "./resources/js/common/archives/ArchivesData.vue?vue&type=script&lang=js&");
/* harmony import */ var _ArchivesData_vue_vue_type_style_index_0_id_24930c93_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ArchivesData.vue?vue&type=style&index=0&id=24930c93&scoped=true&lang=css& */ "./resources/js/common/archives/ArchivesData.vue?vue&type=style&index=0&id=24930c93&scoped=true&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _ArchivesData_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _ArchivesData_vue_vue_type_template_id_24930c93_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render,
  _ArchivesData_vue_vue_type_template_id_24930c93_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  "24930c93",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/common/archives/ArchivesData.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/common/archives/components/ProjectsFilters.vue":
/*!*********************************************************************!*\
  !*** ./resources/js/common/archives/components/ProjectsFilters.vue ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _ProjectsFilters_vue_vue_type_template_id_98be9080___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ProjectsFilters.vue?vue&type=template&id=98be9080& */ "./resources/js/common/archives/components/ProjectsFilters.vue?vue&type=template&id=98be9080&");
/* harmony import */ var _ProjectsFilters_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ProjectsFilters.vue?vue&type=script&lang=js& */ "./resources/js/common/archives/components/ProjectsFilters.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _ProjectsFilters_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _ProjectsFilters_vue_vue_type_template_id_98be9080___WEBPACK_IMPORTED_MODULE_0__.render,
  _ProjectsFilters_vue_vue_type_template_id_98be9080___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/common/archives/components/ProjectsFilters.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/common/archives/components/ReportDetailes.vue":
/*!********************************************************************!*\
  !*** ./resources/js/common/archives/components/ReportDetailes.vue ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _ReportDetailes_vue_vue_type_template_id_3ebb06c4_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ReportDetailes.vue?vue&type=template&id=3ebb06c4&scoped=true& */ "./resources/js/common/archives/components/ReportDetailes.vue?vue&type=template&id=3ebb06c4&scoped=true&");
/* harmony import */ var _ReportDetailes_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ReportDetailes.vue?vue&type=script&lang=js& */ "./resources/js/common/archives/components/ReportDetailes.vue?vue&type=script&lang=js&");
/* harmony import */ var _ReportDetailes_vue_vue_type_style_index_0_id_3ebb06c4_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ReportDetailes.vue?vue&type=style&index=0&id=3ebb06c4&scoped=true&lang=css& */ "./resources/js/common/archives/components/ReportDetailes.vue?vue&type=style&index=0&id=3ebb06c4&scoped=true&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _ReportDetailes_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _ReportDetailes_vue_vue_type_template_id_3ebb06c4_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render,
  _ReportDetailes_vue_vue_type_template_id_3ebb06c4_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  "3ebb06c4",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/common/archives/components/ReportDetailes.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/common/archives/components/projectDetailes.vue":
/*!*********************************************************************!*\
  !*** ./resources/js/common/archives/components/projectDetailes.vue ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _projectDetailes_vue_vue_type_template_id_0ca80137_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./projectDetailes.vue?vue&type=template&id=0ca80137&scoped=true& */ "./resources/js/common/archives/components/projectDetailes.vue?vue&type=template&id=0ca80137&scoped=true&");
/* harmony import */ var _projectDetailes_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./projectDetailes.vue?vue&type=script&lang=js& */ "./resources/js/common/archives/components/projectDetailes.vue?vue&type=script&lang=js&");
/* harmony import */ var _projectDetailes_vue_vue_type_style_index_0_id_0ca80137_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./projectDetailes.vue?vue&type=style&index=0&id=0ca80137&scoped=true&lang=css& */ "./resources/js/common/archives/components/projectDetailes.vue?vue&type=style&index=0&id=0ca80137&scoped=true&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _projectDetailes_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _projectDetailes_vue_vue_type_template_id_0ca80137_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render,
  _projectDetailes_vue_vue_type_template_id_0ca80137_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  "0ca80137",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/common/archives/components/projectDetailes.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/common/archives/ArchivesData.vue?vue&type=script&lang=js&":
/*!********************************************************************************!*\
  !*** ./resources/js/common/archives/ArchivesData.vue?vue&type=script&lang=js& ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ArchivesData_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./ArchivesData.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/ArchivesData.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ArchivesData_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/common/archives/components/ProjectsFilters.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************!*\
  !*** ./resources/js/common/archives/components/ProjectsFilters.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ProjectsFilters_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./ProjectsFilters.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/components/ProjectsFilters.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ProjectsFilters_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/common/archives/components/ReportDetailes.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************!*\
  !*** ./resources/js/common/archives/components/ReportDetailes.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReportDetailes_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./ReportDetailes.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/components/ReportDetailes.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ReportDetailes_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/common/archives/components/projectDetailes.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************!*\
  !*** ./resources/js/common/archives/components/projectDetailes.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_projectDetailes_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./projectDetailes.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/components/projectDetailes.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_projectDetailes_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/common/archives/ArchivesData.vue?vue&type=style&index=0&id=24930c93&scoped=true&lang=css&":
/*!****************************************************************************************************************!*\
  !*** ./resources/js/common/archives/ArchivesData.vue?vue&type=style&index=0&id=24930c93&scoped=true&lang=css& ***!
  \****************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_ArchivesData_vue_vue_type_style_index_0_id_24930c93_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./ArchivesData.vue?vue&type=style&index=0&id=24930c93&scoped=true&lang=css& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/ArchivesData.vue?vue&type=style&index=0&id=24930c93&scoped=true&lang=css&");


/***/ }),

/***/ "./resources/js/common/archives/components/ReportDetailes.vue?vue&type=style&index=0&id=3ebb06c4&scoped=true&lang=css&":
/*!*****************************************************************************************************************************!*\
  !*** ./resources/js/common/archives/components/ReportDetailes.vue?vue&type=style&index=0&id=3ebb06c4&scoped=true&lang=css& ***!
  \*****************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_ReportDetailes_vue_vue_type_style_index_0_id_3ebb06c4_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/style-loader/dist/cjs.js!../../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./ReportDetailes.vue?vue&type=style&index=0&id=3ebb06c4&scoped=true&lang=css& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/components/ReportDetailes.vue?vue&type=style&index=0&id=3ebb06c4&scoped=true&lang=css&");


/***/ }),

/***/ "./resources/js/common/archives/components/projectDetailes.vue?vue&type=style&index=0&id=0ca80137&scoped=true&lang=css&":
/*!******************************************************************************************************************************!*\
  !*** ./resources/js/common/archives/components/projectDetailes.vue?vue&type=style&index=0&id=0ca80137&scoped=true&lang=css& ***!
  \******************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_projectDetailes_vue_vue_type_style_index_0_id_0ca80137_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/style-loader/dist/cjs.js!../../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./projectDetailes.vue?vue&type=style&index=0&id=0ca80137&scoped=true&lang=css& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/components/projectDetailes.vue?vue&type=style&index=0&id=0ca80137&scoped=true&lang=css&");


/***/ }),

/***/ "./resources/js/common/archives/ArchivesData.vue?vue&type=template&id=24930c93&scoped=true&":
/*!**************************************************************************************************!*\
  !*** ./resources/js/common/archives/ArchivesData.vue?vue&type=template&id=24930c93&scoped=true& ***!
  \**************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ArchivesData_vue_vue_type_template_id_24930c93_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ArchivesData_vue_vue_type_template_id_24930c93_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ArchivesData_vue_vue_type_template_id_24930c93_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./ArchivesData.vue?vue&type=template&id=24930c93&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/ArchivesData.vue?vue&type=template&id=24930c93&scoped=true&");


/***/ }),

/***/ "./resources/js/common/archives/components/ProjectsFilters.vue?vue&type=template&id=98be9080&":
/*!****************************************************************************************************!*\
  !*** ./resources/js/common/archives/components/ProjectsFilters.vue?vue&type=template&id=98be9080& ***!
  \****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ProjectsFilters_vue_vue_type_template_id_98be9080___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ProjectsFilters_vue_vue_type_template_id_98be9080___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ProjectsFilters_vue_vue_type_template_id_98be9080___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./ProjectsFilters.vue?vue&type=template&id=98be9080& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/components/ProjectsFilters.vue?vue&type=template&id=98be9080&");


/***/ }),

/***/ "./resources/js/common/archives/components/ReportDetailes.vue?vue&type=template&id=3ebb06c4&scoped=true&":
/*!***************************************************************************************************************!*\
  !*** ./resources/js/common/archives/components/ReportDetailes.vue?vue&type=template&id=3ebb06c4&scoped=true& ***!
  \***************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ReportDetailes_vue_vue_type_template_id_3ebb06c4_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ReportDetailes_vue_vue_type_template_id_3ebb06c4_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_ReportDetailes_vue_vue_type_template_id_3ebb06c4_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./ReportDetailes.vue?vue&type=template&id=3ebb06c4&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/components/ReportDetailes.vue?vue&type=template&id=3ebb06c4&scoped=true&");


/***/ }),

/***/ "./resources/js/common/archives/components/projectDetailes.vue?vue&type=template&id=0ca80137&scoped=true&":
/*!****************************************************************************************************************!*\
  !*** ./resources/js/common/archives/components/projectDetailes.vue?vue&type=template&id=0ca80137&scoped=true& ***!
  \****************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_projectDetailes_vue_vue_type_template_id_0ca80137_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_projectDetailes_vue_vue_type_template_id_0ca80137_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_projectDetailes_vue_vue_type_template_id_0ca80137_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./projectDetailes.vue?vue&type=template&id=0ca80137&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/components/projectDetailes.vue?vue&type=template&id=0ca80137&scoped=true&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/ArchivesData.vue?vue&type=template&id=24930c93&scoped=true&":
/*!*****************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/ArchivesData.vue?vue&type=template&id=24930c93&scoped=true& ***!
  \*****************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { class: _vm.$vuetify.breakpoint.xsOnly ? "pt-2" : "" },
    [
      _c(
        "v-tabs",
        {
          class: _vm.$vuetify.breakpoint.xsOnly ? "" : "mx-5",
          attrs: {
            "background-color": "transparent",
            color: "basil",
            grow: "",
          },
          model: {
            value: _vm.tab,
            callback: function ($$v) {
              _vm.tab = $$v
            },
            expression: "tab",
          },
        },
        [
          _c("v-tab", [
            _c("h3", [_vm._v(" " + _vm._s(_vm.trans("data.projects")))]),
          ]),
          _vm._v(" "),
          _c("v-tab", [
            _c("h3", [_vm._v(" " + _vm._s(_vm.trans("data.reports")))]),
          ]),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "v-tabs-items",
        {
          model: {
            value: _vm.tab,
            callback: function ($$v) {
              _vm.tab = $$v
            },
            expression: "tab",
          },
        },
        [
          _c(
            "v-tab-item",
            [
              _c(
                "v-card",
                {
                  staticClass: "elevation-2 pt-1 pb-3 my-2",
                  class: _vm.$vuetify.breakpoint.xsOnly
                    ? "mx-auto"
                    : "px-5 mx-5",
                  staticStyle: { "min-width": "70%", flex: "4" },
                  attrs: { flat: "" },
                },
                [
                  _c("ProjectFilters", {
                    attrs: { projects: true, reports: false },
                  }),
                  _vm._v(" "),
                  _c(
                    "div",
                    { staticClass: "flex justify-center" },
                    [
                      _c(
                        "v-btn",
                        {
                          staticStyle: {
                            "background-color": "#06706d",
                            color: "white",
                          },
                          on: {
                            click: function ($event) {
                              return _vm.$router.go(-1)
                            },
                          },
                        },
                        [
                          _vm._v(
                            "\n                      " +
                              _vm._s(_vm.trans("messages.back")) +
                              "\n                  "
                          ),
                        ]
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "v-tab-item",
            [
              _c(
                "v-card",
                {
                  staticClass: "elevation-2 pt-1 pb-3 my-2",
                  class: _vm.$vuetify.breakpoint.xsOnly
                    ? "mx-auto"
                    : "px-5 mx-5",
                  staticStyle: { "min-width": "70%", flex: "4" },
                  attrs: { flat: "" },
                },
                [
                  _c("ProjectFilters", {
                    attrs: { reports: true, projects: false },
                  }),
                  _vm._v(" "),
                  _c(
                    "div",
                    { staticClass: "flex justify-center" },
                    [
                      _c(
                        "v-btn",
                        {
                          staticStyle: {
                            "background-color": "#06706d",
                            color: "white",
                          },
                          on: {
                            click: function ($event) {
                              return _vm.$router.go(-1)
                            },
                          },
                        },
                        [
                          _vm._v(
                            "\n                      " +
                              _vm._s(_vm.trans("messages.back")) +
                              "\n                  "
                          ),
                        ]
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/components/ProjectsFilters.vue?vue&type=template&id=98be9080&":
/*!*******************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/components/ProjectsFilters.vue?vue&type=template&id=98be9080& ***!
  \*******************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "v-layout",
        {
          staticClass: "mx-auto",
          staticStyle: { "max-width": "80%" },
          attrs: { wrap: "" },
        },
        [
          _c(
            "v-flex",
            { staticClass: "mx-auto", attrs: { xs12: "", md5: "" } },
            [
              _c("v-autocomplete", {
                attrs: {
                  "item-text": "name",
                  "item-value": "id",
                  items: _vm.filterTypeList,
                  label: _vm.trans("data.searchBy.searchBy"),
                },
                on: { change: _vm.selectData },
                model: {
                  value: _vm.filters.type,
                  callback: function ($$v) {
                    _vm.$set(_vm.filters, "type", $$v)
                  },
                  expression: "filters.type",
                },
              }),
            ],
            1
          ),
          _vm._v(" "),
          _vm.tableRelation && !_vm.locationSearch
            ? _c(
                "v-flex",
                { staticClass: "mx-auto", attrs: { xs12: "", md5: "" } },
                [
                  _c("v-autocomplete", {
                    attrs: {
                      "item-text": "name",
                      "item-value": "id",
                      items: _vm.filterColumnsList,
                      label: _vm.trans("data.searchBy.selectData"),
                    },
                    model: {
                      value: _vm.filters.columnTable,
                      callback: function ($$v) {
                        _vm.$set(_vm.filters, "columnTable", $$v)
                      },
                      expression: "filters.columnTable",
                    },
                  }),
                ],
                1
              )
            : _vm._e(),
          _vm._v(" "),
          _vm.locationSearch
            ? _c(
                "v-flex",
                { staticClass: "mx-auto", attrs: { xs12: "", md5: "" } },
                [
                  _c("v-select", {
                    attrs: {
                      "item-text": "value",
                      "item-value": "key",
                      items: _vm.province_municipalities,
                      label: _vm.trans("data.province_municipality"),
                      "data-vv-as": _vm.trans("data.province_municipality"),
                    },
                    on: {
                      change: function ($event) {
                        _vm.province_municipality = true
                      },
                    },
                    model: {
                      value: _vm.filters.province_municipality,
                      callback: function ($$v) {
                        _vm.$set(_vm.filters, "province_municipality", $$v)
                      },
                      expression: "filters.province_municipality",
                    },
                  }),
                ],
                1
              )
            : _vm._e(),
          _vm._v(" "),
          _vm.province_municipality
            ? _c(
                "v-flex",
                { staticClass: "mx-auto", attrs: { xs12: "", md5: "" } },
                [
                  _c("v-select", {
                    attrs: {
                      "item-text": "value",
                      "item-value": "key",
                      items: _vm.municipalities,
                      label: _vm.trans("data.municipality"),
                      "data-vv-name": _vm.filters.municipality,
                      "data-vv-as": _vm.trans("data.municipality"),
                    },
                    on: {
                      change: function ($event) {
                        _vm.municipality = true
                      },
                    },
                    model: {
                      value: _vm.filters.municipality,
                      callback: function ($$v) {
                        _vm.$set(_vm.filters, "municipality", $$v)
                      },
                      expression: "filters.municipality",
                    },
                  }),
                ],
                1
              )
            : _vm._e(),
          _vm._v(" "),
          _vm.municipality
            ? _c(
                "v-flex",
                { staticClass: "mx-auto", attrs: { xs12: "", md5: "" } },
                [
                  _c("v-text-field", {
                    attrs: { label: _vm.trans("data.plan_id") },
                    on: {
                      change: function ($event) {
                        _vm.plan_id = true
                      },
                    },
                    model: {
                      value: _vm.filters.plan_id,
                      callback: function ($$v) {
                        _vm.$set(_vm.filters, "plan_id", $$v)
                      },
                      expression: "filters.plan_id",
                    },
                  }),
                ],
                1
              )
            : _vm._e(),
          _vm._v(" "),
          _vm.plan_id
            ? _c(
                "v-flex",
                { staticClass: "mx-auto", attrs: { xs12: "", md5: "" } },
                [
                  _c("v-text-field", {
                    attrs: { label: _vm.trans("data.piece_number") },
                    model: {
                      value: _vm.filters.piece_number,
                      callback: function ($$v) {
                        _vm.$set(_vm.filters, "piece_number", $$v)
                      },
                      expression: "filters.piece_number",
                    },
                  }),
                ],
                1
              )
            : _vm._e(),
          _vm._v(" "),
          !_vm.locationSearch
            ? _c(
                "v-flex",
                { staticClass: "mx-auto", attrs: { xs12: "", md5: "" } },
                [
                  _c("v-text-field", {
                    attrs: {
                      "append-icon": "search",
                      label: _vm.trans("data.searchBy.searchWord"),
                      "single-line": "",
                      "hide-details": "",
                    },
                    model: {
                      value: _vm.filters.searchInTable,
                      callback: function ($$v) {
                        _vm.$set(_vm.filters, "searchInTable", $$v)
                      },
                      expression: "filters.searchInTable",
                    },
                  }),
                ],
                1
              )
            : _vm._e(),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "v-layout",
        {
          staticClass: "mx-auto",
          staticStyle: { "max-width": "80%" },
          attrs: { wrap: "" },
        },
        [
          _c(
            "v-flex",
            { staticClass: "mx-auto", attrs: { xs12: "", md5: "" } },
            [
              _c("v-datetime-picker", {
                staticClass: "w-full",
                attrs: {
                  "append-icon": "time",
                  label: _vm.trans("data.startDate"),
                  "single-line": "",
                  "hide-details": "",
                },
                model: {
                  value: _vm.filters.startDate,
                  callback: function ($$v) {
                    _vm.$set(_vm.filters, "startDate", $$v)
                  },
                  expression: "filters.startDate",
                },
              }),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "v-flex",
            { staticClass: "mx-auto", attrs: { xs12: "", md5: "" } },
            [
              _c("v-datetime-picker", {
                staticClass: "w-full",
                attrs: {
                  "append-icon": "time",
                  label: _vm.trans("data.endDate"),
                  "single-line": "",
                  "hide-details": "",
                },
                model: {
                  value: _vm.filters.endDate,
                  callback: function ($$v) {
                    _vm.$set(_vm.filters, "endDate", $$v)
                  },
                  expression: "filters.endDate",
                },
              }),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "v-flex",
            { staticClass: "mx-auto mt-3", attrs: { xs12: "", md4: "" } },
            [
              _c(
                "v-btn",
                {
                  attrs: { color: "primary" },
                  on: { click: _vm.filterChanged },
                },
                [_vm._v(_vm._s(_vm.trans("data.search")))]
              ),
              _vm._v(" "),
              _c(
                "v-btn",
                {
                  attrs: { color: "secondary" },
                  on: { click: _vm.clearInputs },
                },
                [_vm._v(_vm._s(_vm.trans("data.clear")))]
              ),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _vm.projects
        ? _c("project-detailes", {
            staticClass: "mt-5 mx-auto w-full",
            staticStyle: { "max-width": "80%" },
            attrs: { projectData: _vm.projectData },
          })
        : _vm._e(),
      _vm._v(" "),
      _vm.reports
        ? _c("report-detailes", {
            staticClass: "mt-5 mx-auto w-full",
            staticStyle: { "max-width": "80%" },
            attrs: { reportData: _vm.reportData },
          })
        : _vm._e(),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/components/ReportDetailes.vue?vue&type=template&id=3ebb06c4&scoped=true&":
/*!******************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/components/ReportDetailes.vue?vue&type=template&id=3ebb06c4&scoped=true& ***!
  \******************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "v-layout",
    { attrs: { row: "" } },
    [
      _c(
        "v-flex",
        { attrs: { xs12: "", sm12: "" } },
        [
          _c(
            "v-card",
            { staticClass: "pa-2 container-list w-full" },
            _vm._l(_vm.reportData, function (item, index) {
              return _c("v-card", { key: index, attrs: { flat: "" } }, [
                _c(
                  "div",
                  { staticClass: "btn-bar" },
                  [
                    _vm.$can("project.list")
                      ? _c(
                          "v-btn",
                          {
                            attrs: { outline: "", color: "indigo" },
                            on: {
                              click: function ($event) {
                                return _vm.$router.push({
                                  name: "edit_report",
                                  params: {
                                    id: item.id,
                                  },
                                })
                              },
                            },
                          },
                          [
                            _c("v-icon", [_vm._v("list")]),
                            _vm._v(
                              "\n                                                                  " +
                                _vm._s(_vm.trans("data.view")) +
                                "\n                                                                  "
                            ),
                          ],
                          1
                        )
                      : _vm._e(),
                  ],
                  1
                ),
                _vm._v(" "),
                _c("div", { staticClass: "element" }, [
                  _c("div", { staticClass: "col-title" }, [
                    _vm._v(_vm._s(_vm.trans("data.owner"))),
                  ]),
                  _c("div", { staticClass: "content" }, [
                    _vm._v(
                      _vm._s(
                        item.owners.map(function (x) {
                          return x.name
                        }) + ", "
                      ) + " "
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "element" }, [
                  _c("div", { staticClass: "col-title" }, [
                    _vm._v(_vm._s(_vm.trans("data.type"))),
                  ]),
                  _c("div", { staticClass: "content" }, [
                    _vm._v(
                      _vm._s(
                        _vm.language == "ar"
                          ? item.type.type_name_ar
                          : item.type.type_name_en
                      )
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "element" }, [
                  _c("div", { staticClass: "col-title" }, [
                    _vm._v(_vm._s(_vm.trans("data.created_by"))),
                  ]),
                  _c("div", { staticClass: "content" }, [
                    _vm._v(_vm._s(item.report_creator.name)),
                  ]),
                ]),
              ])
            }),
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/components/projectDetailes.vue?vue&type=template&id=0ca80137&scoped=true&":
/*!*******************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/archives/components/projectDetailes.vue?vue&type=template&id=0ca80137&scoped=true& ***!
  \*******************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "v-layout",
    { attrs: { row: "" } },
    [
      _c(
        "v-flex",
        { attrs: { xs12: "", sm12: "" } },
        [
          _c(
            "v-card",
            { staticClass: "pa-2 container-list w-full" },
            _vm._l(_vm.projectData, function (item, index) {
              return _c("v-card", { key: index, attrs: { flat: "" } }, [
                _c(
                  "div",
                  { staticClass: "btn-bar" },
                  [
                    _vm.$can("project.list")
                      ? _c(
                          "v-btn",
                          {
                            attrs: { outline: "", color: "indigo" },
                            on: {
                              click: function ($event) {
                                return _vm.view(item.id)
                              },
                            },
                          },
                          [
                            _c("v-icon", [_vm._v("list")]),
                            _vm._v(
                              "\n                                                                  " +
                                _vm._s(_vm.trans("data.view")) +
                                "\n                                                                  "
                            ),
                          ],
                          1
                        )
                      : _vm._e(),
                    _vm._v(" "),
                    _vm.$can("report.create")
                      ? _c(
                          "v-btn",
                          {
                            attrs: {
                              outline: "",
                              color: "teal",
                              disabled: !_vm.checkActive(),
                            },
                            on: {
                              click: function ($event) {
                                return _vm.$router.push({
                                  name: "add_report",
                                  params: { project: item },
                                })
                              },
                            },
                          },
                          [
                            _c("v-icon", [_vm._v("print")]),
                            _vm._v(
                              "\n                                                                  " +
                                _vm._s(_vm.trans("data.create_a_report")) +
                                "\n                                                                  "
                            ),
                          ],
                          1
                        )
                      : _vm._e(),
                  ],
                  1
                ),
                _vm._v(" "),
                _c("div", { staticClass: "element" }, [
                  _c("div", { staticClass: "col-title" }, [
                    _vm._v(_vm._s(_vm.trans("data.name"))),
                  ]),
                  _c("div", { staticClass: "content" }, [
                    _vm._v(_vm._s(item.name) + " "),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "element" }, [
                  _c("div", { staticClass: "col-title" }, [
                    _vm._v(_vm._s(_vm.trans("data.owner_name"))),
                  ]),
                  _c("div", { staticClass: "content" }, [
                    _vm._v(
                      _vm._s(
                        item.owners.map(function (x) {
                          return x.name
                        }) + ", "
                      )
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "element" }, [
                  _c("div", { staticClass: "col-title" }, [
                    _vm._v(_vm._s(_vm.trans("data.searchBy.location"))),
                  ]),
                  _c("div", { staticClass: "content" }, [
                    _vm._v(
                      _vm._s(
                        item.location.province_municipality +
                          "-" +
                          item.location.municipality +
                          "-" +
                          item.location.municipality +
                          "-" +
                          item.location.piece_number
                      )
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "element" }, [
                  _c("div", { staticClass: "col-title" }, [
                    _vm._v(_vm._s(_vm.trans("data.start_date"))),
                  ]),
                  _c("div", { staticClass: "content" }, [
                    _vm._v(_vm._s(_vm._f("formatDateTime")(item.start_date))),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "element" }, [
                  _c("div", { staticClass: "col-title" }, [
                    _vm._v(_vm._s(_vm.trans("data.endDate"))),
                  ]),
                  _c("div", { staticClass: "content" }, [
                    _vm._v(_vm._s(_vm._f("formatDateTime")(item.end_date))),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "element" }, [
                  _c("div", { staticClass: "col-title" }, [
                    _vm._v(_vm._s(_vm.trans("data.searchBy.status"))),
                  ]),
                  _c(
                    "div",
                    {
                      staticClass: "content",
                      staticStyle: { "padding-bottom": "0" },
                    },
                    [
                      _c("v-progress-linear", {
                        staticClass: "ma-0",
                        attrs: {
                          striped: "",
                          value: _vm.getprogress(item.status),
                        },
                      }),
                    ],
                    1
                  ),
                ]),
              ])
            }),
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);