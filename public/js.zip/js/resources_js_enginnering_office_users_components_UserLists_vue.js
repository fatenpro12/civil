"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_enginnering_office_users_components_UserLists_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/users/UserList.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/users/UserList.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../store */ "./resources/js/store/index.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  props: {
    headers: [],
    edit_url: null
  },
  data: function data() {
    return {
      items: [],
      totalItems: null,
      pagination: {
        rowsPerPage: 10
      }
    };
  },
  watch: {
    'pagination.page': function paginationPage() {
      this.$emit('page', this.pagination);
    },
    'pagination.rowsPerPage': function paginationRowsPerPage() {
      this.$emit('rowsPerPage', this.pagination);
    }
  },
  methods: {
    roleName: function roleName(role) {
      var name = [];
      name.push(role.name[0].toUpperCase() + role.name.slice(1));
      return name.join();
    },
    loadUsers: function loadUsers(url, name, email) {
      var self = this;
      var params = {
        name: name,
        email: email,
        page: self.pagination.page,
        per_page: self.pagination.rowsPerPage
      };
      axios.get(url, {
        params: params
      }).then(function (response) {
        self.items = response.data; //.data;
        self.totalItems = response.data.total;
        self.pagination.totalItems = response.data.total;
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/enginnering_office/users/components/AddEmployeeById.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/enginnering_office/users/components/AddEmployeeById.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../store */ "./resources/js/store/index.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  data: function data() {
    return {
      dialog: false,
      id_card_number: null,
      name: null,
      email: null,
      customer: null,
      valid: true,
      message: null,
      customers: [],
      enginnering_types: [],
      specialty_id: null
    };
  },
  methods: {
    create: function create() {
      this.getCustomers();
      this.dialog = true;
      this.$refs.form.reset();
      this.customer = null;
    },
    findCustomer: function findCustomer() {
      var _this = this;
      this.message = null;
      this.getCustomers();
      this.customer = this.customers.find(function (val) {
        return val.id_card_number == _this.id_card_number;
      });
      if (this.customer) {
        this.name = this.customer.name;
        this.email = this.customer.email;
        this.getEnginneringTypes(7);
        if (this.customer.parent_id === this.getCurrentUser().id) {
          this.message = this.trans('messages.employee_work_same_office');
        }
        if (tthis.customer.parent_id && his.customer.parent_id !== this.getCurrentUser().id) {
          this.message = this.trans('messages.employee_busy');
        }
      } else {
        this.message = this.trans('messages.not_found');
      }
    },
    getEnginneringTypes: function getEnginneringTypes(event) {
      var self = this;
      var url = '/get-enginnering-types-by-role/' + event;
      axios.get(url).then(function (response) {
        self.enginnering_types = response.data;
      })["catch"](function (err) {
        console.log(err.response.status);
        if (err.response.status === 401) {
          _store__WEBPACK_IMPORTED_MODULE_0__["default"].dispatch('auth/handleResponse', err.response);
        }
      });
      ;
    },
    getCustomers: function getCustomers() {
      var self = this;
      axios.get('/customers').then(function (response) {
        self.customers = response.data;
      })["catch"](function (error) {
        console.log(error);
      });
    },
    save: function save() {
      var self = this;
      self.dialog = false;
      axios.post('/enginner_office/addNewEmployee', {
        id: self.customer.id,
        specialty_id: self.specialty_id
      }).then(function (response) {
        self.$store.commit('showSnackbar', {
          message: response.data.msg,
          color: response.data.success
        });
        self.$store.commit('hideLoader');
        if (response.data.success === true) {
          self.$refs.form.reset();
          self.customer = null;
        }
        self.$emit('addUser');
      })["catch"](function (error) {
        self.$store.commit('hideLoader');
        self.$store.commit('showSnackbar', {
          message: error.response,
          color: 'error',
          duration: 50000
        });
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/enginnering_office/users/components/UserLists.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/enginnering_office/users/components/UserLists.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _AddEmployeeById_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./AddEmployeeById.vue */ "./resources/js/enginnering_office/users/components/AddEmployeeById.vue");
/* harmony import */ var _common_users_UserList__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../common/users/UserList */ "./resources/js/common/users/UserList.vue");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../store */ "./resources/js/store/index.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  components: {
    AddEmployeeById: _AddEmployeeById_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    UsersList: _common_users_UserList__WEBPACK_IMPORTED_MODULE_1__["default"]
  },
  data: function data() {
    var self = this;
    return {
      loading: false,
      headers: [{
        text: self.trans('messages.action'),
        value: false,
        align: 'center',
        sortable: false
      }, {
        text: self.trans('data.id'),
        value: 'id',
        align: 'center',
        sortable: true
      }, {
        text: self.trans('messages.name'),
        value: 'name',
        align: 'center',
        sortable: true
      }, {
        text: self.trans('messages.email'),
        value: 'email',
        align: 'center',
        sortable: true
      }, {
        text: self.trans('messages.roles'),
        value: 'roles',
        align: 'center',
        sortable: true
      }, {
        text: self.trans('data.enginnering_office_name'),
        value: 'parent',
        align: 'center',
        sortable: true
      }, {
        text: self.trans('data.enginnering_type'),
        value: 'specialty_id',
        align: 'center',
        sortable: true
      }, {
        text: self.trans('messages.last_login'),
        value: 'last_login',
        align: 'center',
        sortable: true
      }, {
        text: self.trans('messages.active'),
        value: 'active',
        align: 'center',
        sortable: false
      }],
      enginnering_types: [],
      filters: {
        name: '',
        email: ''
      },
      tabs: 'tab-1',
      statistics: []
    };
  },
  mounted: function mounted() {
    var self = this;
    self.getStatistics();
    self.getEnginneringTypes();
    // self.$refs.usersData.loadUsers('/enginner_office/users',self.filters.name,self.filters.email)
    self.$eventBus.$on(['USER_ADDED', 'USER_UPDATED', 'USER_DELETED', 'GROUP_ADDED'], function () {
      self.$refs.usersData.loadUsers('/enginner_office/users', self.filters.name, self.filters.email);
    });
  },
  watch: {
    'filters.name': {
      handler: function handler() {
        var self = this;
        self.$refs.usersData.loadUsers('/enginner_office/users', self.filters.name, self.filters.email);
      }
    },
    'filters.email': {
      handler: function handler() {
        //   _.debounce(() => {
        var self = this;
        self.$refs.usersData.loadUsers('/enginner_office/users', self.filters.name, self.filters.email);
        // }, 700)
      }
    }
  },

  methods: {
    trash: function trash(user) {
      var self = this;
      self.$store.commit('showDialog', {
        type: 'confirm',
        icon: 'warning',
        title: self.trans('messages.are_you_sure'),
        message: self.trans('messages.you_cant_restore_it'),
        okCb: function okCb() {
          axios["delete"]('/enginner_office/users/' + user.id).then(function (response) {
            self.$store.commit('showSnackbar', {
              message: response.data.msg,
              color: response.data.success
            });
            self.getStatistics();
            self.$eventBus.$emit('USER_DELETED');
          })["catch"](function (error) {
            self.$store.commit('hideLoader');
            if (error.response) {
              self.$store.commit('showSnackbar', {
                message: error.response.data.msg,
                color: response.data.success
              });
            } else if (error.request) {
              console.log(error.request);
            } else {
              console.log('Error', error.message);
            }
          });
        },
        cancelCb: function cancelCb() {
          console.log('CANCEL');
        }
      });
    },
    addEmployee: function addEmployee() {
      this.$refs.addEmployeeById.create();
    },
    getEnginneringTypes: function getEnginneringTypes() {
      var self = this;
      axios.get('/get-enginnering-types').then(function (response) {
        self.enginnering_types = response.data;
      })["catch"](function (err) {
        console.log(err.response.status);
        if (err.response.status === 401) {
          _store__WEBPACK_IMPORTED_MODULE_3__["default"].dispatch('auth/handleResponse', err.response);
        }
      });
      ;
    },
    getTypeEnginner: function getTypeEnginner(type) {
      var self = this;
      return self.enginnering_types.find(function (x) {
        return x.key == type;
      }).value;
    },
    /* loadUsers(cb) {
         const self = this;
           let params = {
             name: self.filters.name,
             email: self.filters.email,
             page: self.pagination.page,
             per_page: self.pagination.rowsPerPage,
         };
           axios.get('/enginner_office/users', { params: params }).then(function (response) {
             self.items = response.data.data;
             self.totalItems = response.data.total;
             self.pagination.totalItems = response.data.total;
         });
     },*/
    getStatistics: function getStatistics() {
      var self = this;
      axios.get('/enginner_office/user-statistics').then(function (response) {
        self.statistics['active'] = response.data.active;
        self.statistics['in_active'] = response.data.in_active;
        self.statistics['users'] = response.data.users;
      })["catch"](function (err) {
        console.log(err.response.status);
        if (err.response.status === 401) {
          _store__WEBPACK_IMPORTED_MODULE_3__["default"].dispatch('auth/handleResponse', err.response);
        }
      });
      ;
    }
  }
});

/***/ }),

/***/ "./resources/js/common/users/UserList.vue":
/*!************************************************!*\
  !*** ./resources/js/common/users/UserList.vue ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _UserList_vue_vue_type_template_id_7c89ae66___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./UserList.vue?vue&type=template&id=7c89ae66& */ "./resources/js/common/users/UserList.vue?vue&type=template&id=7c89ae66&");
/* harmony import */ var _UserList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./UserList.vue?vue&type=script&lang=js& */ "./resources/js/common/users/UserList.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _UserList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _UserList_vue_vue_type_template_id_7c89ae66___WEBPACK_IMPORTED_MODULE_0__.render,
  _UserList_vue_vue_type_template_id_7c89ae66___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/common/users/UserList.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/enginnering_office/users/components/AddEmployeeById.vue":
/*!******************************************************************************!*\
  !*** ./resources/js/enginnering_office/users/components/AddEmployeeById.vue ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _AddEmployeeById_vue_vue_type_template_id_bb921e02___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./AddEmployeeById.vue?vue&type=template&id=bb921e02& */ "./resources/js/enginnering_office/users/components/AddEmployeeById.vue?vue&type=template&id=bb921e02&");
/* harmony import */ var _AddEmployeeById_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./AddEmployeeById.vue?vue&type=script&lang=js& */ "./resources/js/enginnering_office/users/components/AddEmployeeById.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _AddEmployeeById_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _AddEmployeeById_vue_vue_type_template_id_bb921e02___WEBPACK_IMPORTED_MODULE_0__.render,
  _AddEmployeeById_vue_vue_type_template_id_bb921e02___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/enginnering_office/users/components/AddEmployeeById.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/enginnering_office/users/components/UserLists.vue":
/*!************************************************************************!*\
  !*** ./resources/js/enginnering_office/users/components/UserLists.vue ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _UserLists_vue_vue_type_template_id_7db48ca8___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./UserLists.vue?vue&type=template&id=7db48ca8& */ "./resources/js/enginnering_office/users/components/UserLists.vue?vue&type=template&id=7db48ca8&");
/* harmony import */ var _UserLists_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./UserLists.vue?vue&type=script&lang=js& */ "./resources/js/enginnering_office/users/components/UserLists.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _UserLists_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _UserLists_vue_vue_type_template_id_7db48ca8___WEBPACK_IMPORTED_MODULE_0__.render,
  _UserLists_vue_vue_type_template_id_7db48ca8___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/enginnering_office/users/components/UserLists.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/common/users/UserList.vue?vue&type=script&lang=js&":
/*!*************************************************************************!*\
  !*** ./resources/js/common/users/UserList.vue?vue&type=script&lang=js& ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./UserList.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/users/UserList.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/enginnering_office/users/components/AddEmployeeById.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************************!*\
  !*** ./resources/js/enginnering_office/users/components/AddEmployeeById.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AddEmployeeById_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AddEmployeeById.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/enginnering_office/users/components/AddEmployeeById.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AddEmployeeById_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/enginnering_office/users/components/UserLists.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************!*\
  !*** ./resources/js/enginnering_office/users/components/UserLists.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserLists_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./UserLists.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/enginnering_office/users/components/UserLists.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserLists_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/common/users/UserList.vue?vue&type=template&id=7c89ae66&":
/*!*******************************************************************************!*\
  !*** ./resources/js/common/users/UserList.vue?vue&type=template&id=7c89ae66& ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_UserList_vue_vue_type_template_id_7c89ae66___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_UserList_vue_vue_type_template_id_7c89ae66___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_UserList_vue_vue_type_template_id_7c89ae66___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./UserList.vue?vue&type=template&id=7c89ae66& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/users/UserList.vue?vue&type=template&id=7c89ae66&");


/***/ }),

/***/ "./resources/js/enginnering_office/users/components/AddEmployeeById.vue?vue&type=template&id=bb921e02&":
/*!*************************************************************************************************************!*\
  !*** ./resources/js/enginnering_office/users/components/AddEmployeeById.vue?vue&type=template&id=bb921e02& ***!
  \*************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_AddEmployeeById_vue_vue_type_template_id_bb921e02___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_AddEmployeeById_vue_vue_type_template_id_bb921e02___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_AddEmployeeById_vue_vue_type_template_id_bb921e02___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./AddEmployeeById.vue?vue&type=template&id=bb921e02& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/enginnering_office/users/components/AddEmployeeById.vue?vue&type=template&id=bb921e02&");


/***/ }),

/***/ "./resources/js/enginnering_office/users/components/UserLists.vue?vue&type=template&id=7db48ca8&":
/*!*******************************************************************************************************!*\
  !*** ./resources/js/enginnering_office/users/components/UserLists.vue?vue&type=template&id=7db48ca8& ***!
  \*******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_UserLists_vue_vue_type_template_id_7db48ca8___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_UserLists_vue_vue_type_template_id_7db48ca8___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_UserLists_vue_vue_type_template_id_7db48ca8___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./UserLists.vue?vue&type=template&id=7db48ca8& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/enginnering_office/users/components/UserLists.vue?vue&type=template&id=7db48ca8&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/users/UserList.vue?vue&type=template&id=7c89ae66&":
/*!**********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/users/UserList.vue?vue&type=template&id=7c89ae66& ***!
  \**********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("v-data-table", {
    staticClass: "elevation-3",
    attrs: {
      headers: _vm.headers,
      pagination: _vm.pagination,
      items: _vm.items,
      "total-items": _vm.totalItems,
    },
    on: {
      "update:pagination": function ($event) {
        _vm.pagination = $event
      },
    },
    scopedSlots: _vm._u([
      {
        key: "headerCell",
        fn: function (props) {
          return [
            props.header.value == "name"
              ? _c(
                  "span",
                  [
                    _c("v-icon", { attrs: { small: "" } }, [_vm._v("person")]),
                    _vm._v(" " + _vm._s(props.header.text) + "\n             "),
                  ],
                  1
                )
              : props.header.value == "email"
              ? _c(
                  "span",
                  [
                    _c("v-icon", { attrs: { small: "" } }, [_vm._v("email")]),
                    _vm._v(" " + _vm._s(props.header.text) + "\n             "),
                  ],
                  1
                )
              : props.header.value == "roles"
              ? _c(
                  "span",
                  [
                    _c("v-icon", { attrs: { small: "" } }, [
                      _vm._v("control_point"),
                    ]),
                    _vm._v(" " + _vm._s(props.header.text) + "\n             "),
                  ],
                  1
                )
              : props.header.value == "last_login"
              ? _c(
                  "span",
                  [
                    _c("v-icon", { attrs: { small: "" } }, [
                      _vm._v("av_timer"),
                    ]),
                    _vm._v(" " + _vm._s(props.header.text) + "\n             "),
                  ],
                  1
                )
              : _c("span", [_vm._v(_vm._s(props.header.text))]),
          ]
        },
      },
      {
        key: "items",
        fn: function (props) {
          return [
            _c("td", [
              _c(
                "div",
                { attrs: { align: "center" } },
                [
                  _c(
                    "v-menu",
                    [
                      _c(
                        "v-btn",
                        {
                          attrs: { slot: "activator", icon: "" },
                          slot: "activator",
                        },
                        [_c("v-icon", [_vm._v("more_vert")])],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "v-list",
                        [
                          _vm.$can("employee.view")
                            ? _c(
                                "v-list-tile",
                                {
                                  on: {
                                    click: function ($event) {
                                      return _vm.$router.push({
                                        name: "users.view",
                                        params: { id: props.item.id },
                                      })
                                    },
                                  },
                                },
                                [
                                  _c(
                                    "v-list-tile-title",
                                    [
                                      _c(
                                        "v-icon",
                                        {
                                          staticClass: "mr-2",
                                          attrs: { small: "" },
                                        },
                                        [_vm._v(" visibility ")]
                                      ),
                                      _vm._v(
                                        "\n                                 " +
                                          _vm._s(_vm.trans("messages.view")) +
                                          "\n                             "
                                      ),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              )
                            : _vm._e(),
                          _vm._v(" "),
                          _vm.$can("employee.edit")
                            ? _c(
                                "v-list-tile",
                                {
                                  attrs: { disabled: !_vm.checkActive() },
                                  on: {
                                    click: function ($event) {
                                      return _vm.$router.push({
                                        name: _vm.edit_url,
                                        params: { id: props.item.id },
                                      })
                                    },
                                  },
                                },
                                [
                                  _c(
                                    "v-list-tile-title",
                                    [
                                      _c(
                                        "v-icon",
                                        {
                                          staticClass: "mr-2",
                                          attrs: { small: "" },
                                        },
                                        [_vm._v(" edit ")]
                                      ),
                                      _vm._v(
                                        "\n                                 " +
                                          _vm._s(_vm.trans("messages.edit")) +
                                          "\n                             "
                                      ),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              )
                            : _vm._e(),
                          _vm._v(" "),
                          _vm.$can("employee.delete")
                            ? _c(
                                "v-list-tile",
                                {
                                  attrs: { disabled: !_vm.checkActive() },
                                  on: {
                                    click: function ($event) {
                                      return _vm.$emit("trash", props.item)
                                    },
                                  },
                                },
                                [
                                  _c(
                                    "v-list-tile-title",
                                    [
                                      _c(
                                        "v-icon",
                                        {
                                          staticClass: "mr-2",
                                          attrs: { small: "" },
                                        },
                                        [_vm._v(" delete_forever ")]
                                      ),
                                      _vm._v(
                                        "\n                                 " +
                                          _vm._s(_vm.trans("messages.delete")) +
                                          "\n                             "
                                      ),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              )
                            : _vm._e(),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ]),
            _vm._v(" "),
            _c("td", [
              _c("div", { attrs: { align: "center" } }, [
                _vm._v(" " + _vm._s(props.item.id)),
              ]),
            ]),
            _vm._v(" "),
            _c("td", [
              _c("div", { attrs: { align: "center" } }, [
                _vm._v(" " + _vm._s(props.item.name)),
              ]),
            ]),
            _vm._v(" "),
            _c("td", [
              _c("div", { attrs: { align: "center" } }, [
                _vm._v(_vm._s(props.item.email)),
              ]),
            ]),
            _vm._v(" "),
            _vm.getCurrentUser().user_type_log !== "ESTATE_OWNER"
              ? _c("td", [
                  _c(
                    "div",
                    { attrs: { align: "center" } },
                    _vm._l(props.item.role, function (rol, index) {
                      return _c("span", { key: index }, [
                        _vm._v(
                          "\n                     " +
                            _vm._s(rol) +
                            "\n                 "
                        ),
                      ])
                    }),
                    0
                  ),
                ])
              : _vm._e(),
            _vm._v(" "),
            _vm.getCurrentUser().user_type_log !== "ESTATE_OWNER"
              ? _c("td", [
                  _c("div", { attrs: { align: "center" } }, [
                    _vm._v(
                      _vm._s(
                        props.item.parent &&
                          props.item.parent.roles.find(function (x) {
                            return x.name === "Engineering Office Manager"
                          })
                          ? props.item.parent.name
                          : null
                      )
                    ),
                  ]),
                ])
              : _vm._e(),
            _vm._v(" "),
            _vm.getCurrentUser().user_type_log === "ENGINEERING_OFFICE_MANAGER"
              ? _c("td", [
                  _c("div", { attrs: { align: "center" } }, [
                    _c("span", [
                      _vm._v(
                        "\n                         " +
                          _vm._s(
                            props.item.specialty != null
                              ? props.item.specialty.name
                              : ""
                          ) +
                          "\n                     "
                      ),
                    ]),
                  ]),
                ])
              : _vm._e(),
            _vm._v(" "),
            _c("td", [
              _c("div", { attrs: { align: "center" } }, [
                _vm._v(
                  " " +
                    _vm._s(_vm._f("formatDateTime")(props.item.last_login)) +
                    " "
                ),
              ]),
            ]),
            _vm._v(" "),
            _c("td", [
              _c(
                "div",
                { attrs: { align: "center" } },
                [
                  _c(
                    "v-avatar",
                    { attrs: { outline: "" } },
                    [
                      props.item.active != null
                        ? _c("v-icon", { staticClass: "green--text" }, [
                            _vm._v("check_circle"),
                          ])
                        : _c("v-icon", { staticClass: "grey--text" }, [
                            _vm._v("error_outline"),
                          ]),
                    ],
                    1
                  ),
                ],
                1
              ),
            ]),
          ]
        },
      },
    ]),
  })
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/enginnering_office/users/components/AddEmployeeById.vue?vue&type=template&id=bb921e02&":
/*!****************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/enginnering_office/users/components/AddEmployeeById.vue?vue&type=template&id=bb921e02& ***!
  \****************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "v-layout",
    { attrs: { row: "", "justify-center": "" } },
    [
      _c(
        "v-dialog",
        {
          attrs: { "max-width": "400" },
          model: {
            value: _vm.dialog,
            callback: function ($$v) {
              _vm.dialog = $$v
            },
            expression: "dialog",
          },
        },
        [
          _c(
            "v-card",
            [
              _c(
                "v-card-title",
                { staticClass: "headline" },
                [
                  _vm._v(
                    _vm._s(_vm.trans("data.customer_info")) +
                      "\n               "
                  ),
                  _c("v-spacer"),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      attrs: { flat: "", icon: "" },
                      on: {
                        click: function ($event) {
                          _vm.dialog = false
                          _vm.$refs.form.reset()
                          _vm.customer = null
                        },
                      },
                    },
                    [_c("v-icon", [_vm._v("clear")])],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "v-form",
                {
                  ref: "form",
                  attrs: { "lazy-validation": "" },
                  model: {
                    value: _vm.valid,
                    callback: function ($$v) {
                      _vm.valid = $$v
                    },
                    expression: "valid",
                  },
                },
                [
                  _c(
                    "v-card-text",
                    [
                      _c(
                        "v-layout",
                        { attrs: { row: "", wrap: "" } },
                        [
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", md12: "" } },
                            [
                              _c("v-text-field", {
                                attrs: {
                                  type: "number",
                                  label: _vm.trans("data.id_card_number"),
                                  "append-icon": "search",
                                },
                                on: { "click:append": _vm.findCustomer },
                                model: {
                                  value: _vm.id_card_number,
                                  callback: function ($$v) {
                                    _vm.id_card_number = $$v
                                  },
                                  expression: "id_card_number",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _vm.customer && !_vm.customer.parent_id
                            ? _c(
                                "v-flex",
                                { attrs: { xs12: "", md12: "" } },
                                [
                                  _c("v-text-field", {
                                    attrs: {
                                      label: _vm.trans("data.name"),
                                      readonly: "",
                                    },
                                    model: {
                                      value: _vm.name,
                                      callback: function ($$v) {
                                        _vm.name = $$v
                                      },
                                      expression: "name",
                                    },
                                  }),
                                ],
                                1
                              )
                            : _vm._e(),
                          _vm._v(" "),
                          _vm.customer && !_vm.customer.parent_id
                            ? _c(
                                "v-flex",
                                { attrs: { xs12: "", md12: "" } },
                                [
                                  _c("v-text-field", {
                                    attrs: {
                                      label: _vm.trans("messages.email"),
                                      readonly: "",
                                    },
                                    model: {
                                      value: _vm.email,
                                      callback: function ($$v) {
                                        _vm.email = $$v
                                      },
                                      expression: "email",
                                    },
                                  }),
                                ],
                                1
                              )
                            : _vm._e(),
                          _vm._v(" "),
                          _vm.customer && !_vm.customer.parent_id
                            ? _c(
                                "v-flex",
                                { attrs: { xs12: "", sm12: "", md12: "" } },
                                [
                                  _c("v-autocomplete", {
                                    attrs: {
                                      "item-text": "value",
                                      clearable: true,
                                      "deletable-chips": true,
                                      dense: true,
                                      "search-input": "",
                                      "solo-inverted": false,
                                      eager: true,
                                      loading: false,
                                      "validate-on-blur": false,
                                      "persistent-placeholder": false,
                                      chips: true,
                                      "item-value": "key",
                                      items: _vm.enginnering_types,
                                      label: _vm.trans("data.enginnering_type"),
                                      rules: [
                                        function (v) {
                                          return (
                                            !!v ||
                                            _vm.trans("messages.required", {
                                              name: _vm.trans(
                                                "data.enginnering_type"
                                              ),
                                            })
                                          )
                                        },
                                      ],
                                      required: "",
                                    },
                                    model: {
                                      value: _vm.specialty_id,
                                      callback: function ($$v) {
                                        _vm.specialty_id = $$v
                                      },
                                      expression: "specialty_id",
                                    },
                                  }),
                                ],
                                1
                              )
                            : _vm._e(),
                          _vm._v(" "),
                          _vm.message
                            ? _c(
                                "v-flex",
                                { attrs: { xs12: "", sm12: "", md12: "" } },
                                [_c("v-chip", [_vm._v(_vm._s(_vm.message))])],
                                1
                              )
                            : _vm._e(),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "v-card-actions",
                    [
                      _c("v-spacer"),
                      _vm._v(" "),
                      _vm.customer && !_vm.customer.parent_id
                        ? _c(
                            "v-btn",
                            {
                              attrs: { color: "green darken-1", flat: "flat" },
                              on: { click: _vm.save },
                            },
                            [
                              _vm._v(
                                "\n           " +
                                  _vm._s(_vm.trans("data.save")) +
                                  "\n         "
                              ),
                            ]
                          )
                        : _vm._e(),
                      _vm._v(" "),
                      _c(
                        "v-btn",
                        {
                          attrs: { color: "green darken-1", flat: "flat" },
                          on: {
                            click: function ($event) {
                              _vm.dialog = false
                              _vm.$refs.form.reset()
                              _vm.customer = null
                            },
                          },
                        },
                        [
                          _vm._v(
                            "\n            " +
                              _vm._s(_vm.trans("data.close")) +
                              "\n         "
                          ),
                        ]
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/enginnering_office/users/components/UserLists.vue?vue&type=template&id=7db48ca8&":
/*!**********************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/enginnering_office/users/components/UserLists.vue?vue&type=template&id=7db48ca8& ***!
  \**********************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    {
      staticClass: "component-wrap",
      class: _vm.$vuetify.breakpoint.xsOnly ? "pt-4" : "",
    },
    [
      _c(
        "v-tabs",
        {
          staticClass: "elevation-3",
          attrs: { "fixed-tabs": "", height: "47" },
          model: {
            value: _vm.tabs,
            callback: function ($$v) {
              _vm.tabs = $$v
            },
            expression: "tabs",
          },
        },
        [
          _c(
            "v-tab",
            { attrs: { href: "#tab-1" }, on: { click: _vm.getStatistics } },
            [
              _c("v-icon", [_vm._v("bar_chart")]),
              _vm._v(
                "\n            " +
                  _vm._s(_vm.trans("messages.statistics")) +
                  "\n        "
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "v-tab",
            { attrs: { href: "#tab-2" } },
            [
              _c("v-icon", [_vm._v("filter_list")]),
              _vm._v(
                "\n            " +
                  _vm._s(_vm.trans("messages.filters")) +
                  "\n        "
              ),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "v-tabs-items",
        {
          model: {
            value: _vm.tabs,
            callback: function ($$v) {
              _vm.tabs = $$v
            },
            expression: "tabs",
          },
        },
        [
          _c("v-divider"),
          _vm._v(" "),
          _c(
            "v-tab-item",
            { attrs: { value: "tab-1" } },
            [
              _c(
                "v-card",
                { staticClass: "elevation-2", attrs: { flat: "" } },
                [
                  _c(
                    "v-card-text",
                    [
                      _c(
                        "v-container",
                        { attrs: { "grid-list-md": "" } },
                        [
                          _c(
                            "v-layout",
                            { attrs: { row: "", wrap: "" } },
                            [
                              _vm.statistics.users > 0
                                ? _c(
                                    "v-flex",
                                    { attrs: { xs12: "", sm3: "", md3: "" } },
                                    [
                                      _c(
                                        "span",
                                        {
                                          staticClass:
                                            "subheading font-weight-medium info--text",
                                        },
                                        [
                                          _vm._v(
                                            "\n                                    " +
                                              _vm._s(
                                                _vm.trans("messages.total")
                                              ) +
                                              ": " +
                                              _vm._s(_vm.statistics.users) +
                                              "\n                                "
                                          ),
                                        ]
                                      ),
                                    ]
                                  )
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.statistics.active > 0
                                ? _c(
                                    "v-flex",
                                    { attrs: { xs12: "", sm3: "", md3: "" } },
                                    [
                                      _c(
                                        "span",
                                        {
                                          staticClass:
                                            "subheading font-weight-medium success--text",
                                        },
                                        [
                                          _vm._v(
                                            "\n                                    " +
                                              _vm._s(
                                                _vm.trans("messages.active")
                                              ) +
                                              ": " +
                                              _vm._s(_vm.statistics.active) +
                                              "\n                                "
                                          ),
                                        ]
                                      ),
                                    ]
                                  )
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.statistics.in_active > 0
                                ? _c(
                                    "v-flex",
                                    { attrs: { xs12: "", sm3: "", md3: "" } },
                                    [
                                      _c(
                                        "span",
                                        {
                                          staticClass:
                                            "subheading font-weight-medium warning--text",
                                        },
                                        [
                                          _vm._v(
                                            "\n                                    " +
                                              _vm._s(
                                                _vm.trans("messages.in_active")
                                              ) +
                                              ":\n                                    " +
                                              _vm._s(_vm.statistics.in_active) +
                                              "\n                                "
                                          ),
                                        ]
                                      ),
                                    ]
                                  )
                                : _vm._e(),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "v-tab-item",
            { attrs: { value: "tab-2" } },
            [
              _c(
                "v-card",
                { staticClass: "elevation-2", attrs: { flat: "" } },
                [
                  _c(
                    "v-card-text",
                    [
                      _c(
                        "v-layout",
                        [
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm12: "" } },
                            [
                              _c(
                                "v-container",
                                { attrs: { "grid-list-md": "" } },
                                [
                                  _c(
                                    "v-layout",
                                    { attrs: { row: "", wrap: "" } },
                                    [
                                      _c(
                                        "v-flex",
                                        {
                                          attrs: { xs12: "", sm6: "", md6: "" },
                                        },
                                        [
                                          _c("v-text-field", {
                                            attrs: {
                                              "prepend-icon": "search",
                                              label: _vm.trans(
                                                "messages.filter_by_name"
                                              ),
                                            },
                                            model: {
                                              value: _vm.filters.name,
                                              callback: function ($$v) {
                                                _vm.$set(
                                                  _vm.filters,
                                                  "name",
                                                  $$v
                                                )
                                              },
                                              expression: "filters.name",
                                            },
                                          }),
                                        ],
                                        1
                                      ),
                                      _vm._v(" "),
                                      _c(
                                        "v-flex",
                                        {
                                          attrs: { xs12: "", sm6: "", md6: "" },
                                        },
                                        [
                                          _c("v-text-field", {
                                            attrs: {
                                              "prepend-icon": "search",
                                              label: _vm.trans(
                                                "messages.filter_by_email"
                                              ),
                                            },
                                            model: {
                                              value: _vm.filters.email,
                                              callback: function ($$v) {
                                                _vm.$set(
                                                  _vm.filters,
                                                  "email",
                                                  $$v
                                                )
                                              },
                                              expression: "filters.email",
                                            },
                                          }),
                                        ],
                                        1
                                      ),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "v-card",
        { staticClass: "mt-3" },
        [
          _c(
            "v-card-title",
            [
              _c("div", [
                _c("div", { staticClass: "headline" }, [
                  _vm._v(
                    "\n                    " +
                      _vm._s(_vm.trans("data.all_employees")) +
                      "\n                "
                  ),
                ]),
              ]),
              _vm._v(" "),
              _c("v-spacer"),
              _vm._v(" "),
              _vm.$can("employee.create")
                ? _c(
                    "v-btn",
                    {
                      staticClass: "lighten-1",
                      staticStyle: {
                        "background-color": "#06706d",
                        color: "white",
                      },
                      attrs: { disabled: !_vm.checkActive() },
                      on: {
                        click: function ($event) {
                          return _vm.$router.push({
                            name: "users_enginner_office.create",
                          })
                        },
                      },
                    },
                    [
                      _vm._v(
                        "\n                " +
                          _vm._s(_vm.trans("data.new_employee_off")) +
                          "\n                "
                      ),
                      _c("v-icon", { attrs: { right: "", dark: "" } }, [
                        _vm._v("add"),
                      ]),
                    ],
                    1
                  )
                : _vm._e(),
              _vm._v(" "),
              _vm.$can("employee.create")
                ? _c(
                    "v-btn",
                    {
                      staticClass: "lighten-1",
                      staticStyle: {
                        "background-color": "#06706d",
                        color: "white",
                      },
                      attrs: { disabled: !_vm.checkActive() },
                      on: { click: _vm.addEmployee },
                    },
                    [
                      _vm._v(
                        "\n                " +
                          _vm._s(_vm.trans("data.add_employee_off")) +
                          "\n                "
                      ),
                      _c("v-icon", { attrs: { right: "", dark: "" } }, [
                        _vm._v("add"),
                      ]),
                    ],
                    1
                  )
                : _vm._e(),
            ],
            1
          ),
          _vm._v(" "),
          _c("v-divider"),
          _vm._v(" "),
          _c("UsersList", {
            ref: "usersData",
            attrs: {
              edit_url: "users_enginner_office.edit",
              headers: _vm.headers,
            },
            on: {
              page: function ($event) {
                return _vm.$refs.usersData.loadUsers(
                  "/enginner_office/users",
                  _vm.filters.name,
                  _vm.filters.email
                )
              },
              rowsPerPage: function ($event) {
                return _vm.$refs.usersData.loadUsers(
                  "/enginner_office/users",
                  _vm.filters.name,
                  _vm.filters.email
                )
              },
              trash: function ($event) {
                return _vm.trash($event)
              },
            },
          }),
        ],
        1
      ),
      _vm._v(" "),
      _c("br"),
      _vm._v(" "),
      _c(
        "div",
        { attrs: { align: "center" } },
        [
          _c(
            "v-btn",
            {
              staticStyle: { "background-color": "#06706d", color: "white" },
              attrs: { loading: _vm.loading, disabled: _vm.loading },
              on: {
                click: function ($event) {
                  return _vm.$router.go(-1)
                },
              },
            },
            [
              _vm._v(
                "\n            " +
                  _vm._s(_vm.trans("messages.back")) +
                  "\n        "
              ),
            ]
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c("br"),
      _vm._v(" "),
      _c("AddEmployeeById", {
        ref: "addEmployeeById",
        on: {
          addUser: function ($event) {
            return _vm.$refs.usersData.loadUsers(
              "/enginner_office/users",
              _vm.filters.name,
              _vm.filters.email
            )
          },
        },
      }),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);