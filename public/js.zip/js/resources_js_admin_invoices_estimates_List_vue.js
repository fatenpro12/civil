"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_admin_invoices_estimates_List_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/invoices/estimates/List.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/invoices/estimates/List.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _common_projects_invoices_Show__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../common/projects/invoices/Show */ "./resources/js/common/projects/invoices/Show.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  components: {
    InvoiceShow: _common_projects_invoices_Show__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  data: function data() {
    var self = this;
    return {
      projectId: null,
      total_items: 0,
      loading: true,
      pagination: {
        totalItems: 0
      },
      headers: [{
        text: self.trans('messages.action'),
        value: false,
        align: 'left',
        sortable: false
      }, {
        text: self.trans('messages.date'),
        value: 'invoice_date',
        align: 'left',
        sortable: true
      }, {
        text: self.trans('messages.invoice_number'),
        value: 'invoice_number',
        align: 'left',
        sortable: true
      }, {
        text: self.trans('messages.project'),
        value: 'project',
        align: 'left',
        sortable: true
      }, {
        text: self.trans('messages.customer'),
        value: 'customer',
        align: 'left',
        sortable: true
      }, {
        text: self.trans('messages.due_date'),
        value: 'due_date',
        align: 'left',
        sortable: true
      }],
      items: [],
      filters: [],
      projectList: [],
      customers: []
    };
  },
  created: function created() {
    var self = this;
    self.getFilterData();
  },
  watch: {
    pagination: {
      handler: function handler() {
        this.getInvoiceFromApi();
      }
    }
  },
  methods: {
    getInvoiceFromApi: function getInvoiceFromApi() {
      var self = this;
      self.loading = true;
      var _self$pagination = self.pagination,
        sortBy = _self$pagination.sortBy,
        descending = _self$pagination.descending,
        page = _self$pagination.page,
        rowsPerPage = _self$pagination.rowsPerPage;
      var params = {
        sort_by: sortBy,
        descending: descending,
        page: page,
        rowsPerPage: rowsPerPage,
        project_id: self.projectId,
        status: 'estimate'
      };
      if (self.filters.project_id) {
        params['project_id'] = self.filters.project_id;
      }
      if (self.filters.customer_id) {
        params['customer_id'] = self.filters.customer_id;
      }
      axios.get('/invoices', {
        params: params
      }).then(function (response) {
        self.total_items = response.data.transactions.total;
        self.items = response.data.transactions.data;
        self.loading = false;
      })["catch"](function (err) {
        console.log(err.response.status);
        if (err.response.status === 401) {
          store.dispatch('auth/handleResponse', err.response);
        }
      });
    },
    deleteInvoice: function deleteInvoice(invoice) {
      var self = this;
      self.$store.commit('showDialog', {
        type: 'confirm',
        icon: 'warning',
        title: self.trans('messages.are_you_sure'),
        message: self.trans('messages.you_cant_restore_it'),
        okCb: function okCb() {
          axios["delete"]('/invoices/' + invoice.id, {
            params: {
              project_id: invoice.project_id
            }
          }).then(function (response) {
            self.$store.commit('showSnackbar', {
              message: response.data.msg,
              color: response.data.success
            });
            if (response.data.success === true) {
              self.getInvoiceFromApi();
            }
          })["catch"](function (err) {
            console.log(err.response.status);
            if (err.response.status === 401) {
              store.dispatch('auth/handleResponse', err.response);
            }
          });
        },
        cancelCb: function cancelCb() {
          console.log('CANCEL');
        }
      });
    },
    view: function view(invoice) {
      var self = this;
      var data = {
        transaction_id: invoice.id,
        project_id: invoice.project_id
      };
      self.$refs.invoiceShow.view(data);
    },
    edit: function edit(invoice) {
      var self = this;
      self.$router.push({
        name: 'invoices.edit',
        params: {
          id: invoice.id,
          project_id: invoice.project_id
        }
      });
    },
    getFilterData: function getFilterData() {
      var self = this;
      axios.get('invoices/get-filter-data').then(function (response) {
        self.projectList = response.data.projects;
        self.customers = response.data.customers;
      })["catch"](function (error) {
        console.log(error);
      });
    },
    filterChanged: function filterChanged() {
      var self = this;
      self.getInvoiceFromApi();
    },
    convertToInvoice: function convertToInvoice(item) {
      var self = this;
      axios.get('invoices/' + item.id + '/convert-to-invoice', {
        params: {
          project_id: item.project_id
        }
      }).then(function (response) {
        self.$store.commit('showSnackbar', {
          message: response.data.msg,
          color: response.data.success
        });
        if (response.data.success === true) {
          self.getInvoiceFromApi();
        }
      })["catch"](function (error) {
        console.log(error);
      });
    }
  }
});

/***/ }),

/***/ "./resources/js/admin/invoices/estimates/List.vue":
/*!********************************************************!*\
  !*** ./resources/js/admin/invoices/estimates/List.vue ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _List_vue_vue_type_template_id_c4444706___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./List.vue?vue&type=template&id=c4444706& */ "./resources/js/admin/invoices/estimates/List.vue?vue&type=template&id=c4444706&");
/* harmony import */ var _List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./List.vue?vue&type=script&lang=js& */ "./resources/js/admin/invoices/estimates/List.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _List_vue_vue_type_template_id_c4444706___WEBPACK_IMPORTED_MODULE_0__.render,
  _List_vue_vue_type_template_id_c4444706___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/admin/invoices/estimates/List.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/admin/invoices/estimates/List.vue?vue&type=script&lang=js&":
/*!*********************************************************************************!*\
  !*** ./resources/js/admin/invoices/estimates/List.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./List.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/invoices/estimates/List.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/admin/invoices/estimates/List.vue?vue&type=template&id=c4444706&":
/*!***************************************************************************************!*\
  !*** ./resources/js/admin/invoices/estimates/List.vue?vue&type=template&id=c4444706& ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_c4444706___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_c4444706___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_c4444706___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./List.vue?vue&type=template&id=c4444706& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/invoices/estimates/List.vue?vue&type=template&id=c4444706&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/invoices/estimates/List.vue?vue&type=template&id=c4444706&":
/*!******************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/invoices/estimates/List.vue?vue&type=template&id=c4444706& ***!
  \******************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "component-wrap" },
    [
      _c("InvoiceShow", { ref: "invoiceShow" }),
      _vm._v(" "),
      _c(
        "v-layout",
        { staticClass: "mb-3", attrs: { row: "" } },
        [
          _c(
            "v-flex",
            { attrs: { xs12: "", sm12: "" } },
            [
              _c(
                "v-card",
                [
                  _c(
                    "v-list",
                    [
                      _c(
                        "v-list-group",
                        { attrs: { "prepend-icon": "filter_list" } },
                        [
                          _c(
                            "v-list-tile",
                            { attrs: { slot: "activator" }, slot: "activator" },
                            [
                              _c(
                                "v-list-tile-content",
                                [
                                  _c("v-list-tile-title", [
                                    _vm._v(
                                      _vm._s(_vm.trans("messages.filters"))
                                    ),
                                  ]),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-list-tile-content",
                            [
                              _c(
                                "v-layout",
                                [
                                  _c(
                                    "v-flex",
                                    { attrs: { xs12: "", sm12: "" } },
                                    [
                                      _c(
                                        "v-card",
                                        [
                                          _c(
                                            "v-container",
                                            { attrs: { "grid-list-md": "" } },
                                            [
                                              _c(
                                                "v-layout",
                                                {
                                                  attrs: { row: "", wrap: "" },
                                                },
                                                [
                                                  _c(
                                                    "v-flex",
                                                    {
                                                      attrs: {
                                                        xs12: "",
                                                        md4: "",
                                                      },
                                                    },
                                                    [
                                                      _c("v-autocomplete", {
                                                        attrs: {
                                                          "item-text": "name",
                                                          "item-value": "id",
                                                          items:
                                                            _vm.projectList,
                                                          label:
                                                            _vm.trans(
                                                              "messages.project"
                                                            ),
                                                        },
                                                        on: {
                                                          change:
                                                            _vm.filterChanged,
                                                        },
                                                        model: {
                                                          value:
                                                            _vm.filters
                                                              .project_id,
                                                          callback: function (
                                                            $$v
                                                          ) {
                                                            _vm.$set(
                                                              _vm.filters,
                                                              "project_id",
                                                              $$v
                                                            )
                                                          },
                                                          expression:
                                                            "filters.project_id",
                                                        },
                                                      }),
                                                    ],
                                                    1
                                                  ),
                                                  _vm._v(" "),
                                                  _c(
                                                    "v-flex",
                                                    {
                                                      attrs: {
                                                        xs12: "",
                                                        md4: "",
                                                      },
                                                    },
                                                    [
                                                      _c("v-autocomplete", {
                                                        attrs: {
                                                          "item-text":
                                                            "company",
                                                          "item-value": "id",
                                                          items: _vm.customers,
                                                          label:
                                                            _vm.trans(
                                                              "messages.customer"
                                                            ),
                                                        },
                                                        on: {
                                                          change:
                                                            _vm.filterChanged,
                                                        },
                                                        model: {
                                                          value:
                                                            _vm.filters
                                                              .customer_id,
                                                          callback: function (
                                                            $$v
                                                          ) {
                                                            _vm.$set(
                                                              _vm.filters,
                                                              "customer_id",
                                                              $$v
                                                            )
                                                          },
                                                          expression:
                                                            "filters.customer_id",
                                                        },
                                                      }),
                                                    ],
                                                    1
                                                  ),
                                                ],
                                                1
                                              ),
                                            ],
                                            1
                                          ),
                                        ],
                                        1
                                      ),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "v-card",
        [
          _c(
            "v-card-title",
            [
              _c("div", [
                _vm._v(
                  "\n                    " +
                    _vm._s(_vm.trans("messages.all_estimates")) +
                    "\n            "
                ),
              ]),
              _vm._v(" "),
              _c("v-spacer"),
              _vm._v(" "),
              _vm.$can("project." + _vm.projectId + ".invoice.create")
                ? _c(
                    "v-btn",
                    {
                      staticClass: "primary lighten-1",
                      attrs: { dark: "" },
                      on: {
                        click: function ($event) {
                          return _vm.$router.push({ name: "estimates.create" })
                        },
                      },
                    },
                    [
                      _vm._v(
                        "\n                " +
                          _vm._s(_vm.trans("messages.new_invoice")) +
                          "\n                "
                      ),
                      _c("v-icon", { attrs: { right: "", dark: "" } }, [
                        _vm._v("add"),
                      ]),
                    ],
                    1
                  )
                : _vm._e(),
            ],
            1
          ),
          _vm._v(" "),
          _c("v-divider"),
          _vm._v(" "),
          _c("v-data-table", {
            staticClass: "elevation-3 w-full",
            attrs: {
              headers: _vm.headers,
              pagination: _vm.pagination,
              "total-items": _vm.total_items,
              loading: _vm.loading,
              items: _vm.items,
            },
            on: {
              "update:pagination": function ($event) {
                _vm.pagination = $event
              },
            },
            scopedSlots: _vm._u([
              {
                key: "headerCell",
                fn: function (props) {
                  return [
                    props.header.value == "invoice_date"
                      ? _c(
                          "span",
                          [
                            _c("v-icon", [_vm._v("date_range")]),
                            _vm._v(
                              " " +
                                _vm._s(props.header.text) +
                                "\n                "
                            ),
                          ],
                          1
                        )
                      : props.header.value == "invoice_number"
                      ? _c(
                          "span",
                          [
                            _c("v-icon", [_vm._v("receipt")]),
                            _vm._v(
                              " " +
                                _vm._s(props.header.text) +
                                "\n                "
                            ),
                          ],
                          1
                        )
                      : props.header.value == "customer"
                      ? _c(
                          "span",
                          [
                            _c("v-icon", [_vm._v("business_center")]),
                            _vm._v(
                              " " +
                                _vm._s(props.header.text) +
                                "\n                "
                            ),
                          ],
                          1
                        )
                      : props.header.value == "due_date"
                      ? _c(
                          "span",
                          [
                            _c("v-icon", [_vm._v("date_range")]),
                            _vm._v(
                              " " +
                                _vm._s(props.header.text) +
                                "\n                "
                            ),
                          ],
                          1
                        )
                      : _c("span", [_vm._v(_vm._s(props.header.text))]),
                  ]
                },
              },
              {
                key: "items",
                fn: function (props) {
                  return [
                    _c(
                      "td",
                      [
                        _c(
                          "v-menu",
                          [
                            _c(
                              "v-btn",
                              {
                                attrs: { slot: "activator", icon: "" },
                                slot: "activator",
                              },
                              [_c("v-icon", [_vm._v("more_vert")])],
                              1
                            ),
                            _vm._v(" "),
                            _c(
                              "v-list",
                              [
                                _vm.$can(
                                  "project." + _vm.projectId + ".invoice.view"
                                )
                                  ? _c(
                                      "v-list-tile",
                                      {
                                        on: {
                                          click: function ($event) {
                                            return _vm.view(props.item)
                                          },
                                        },
                                      },
                                      [
                                        _c(
                                          "v-list-tile-title",
                                          [
                                            _c(
                                              "v-icon",
                                              {
                                                staticClass: "mr-2",
                                                attrs: { small: "" },
                                              },
                                              [_vm._v(" visibility ")]
                                            ),
                                            _vm._v(
                                              "\n                                    " +
                                                _vm._s(
                                                  _vm.trans("messages.view")
                                                ) +
                                                "\n                                "
                                            ),
                                          ],
                                          1
                                        ),
                                      ],
                                      1
                                    )
                                  : _vm._e(),
                                _vm._v(" "),
                                _vm.$can(
                                  "project." + _vm.projectId + ".invoice.edit"
                                )
                                  ? _c(
                                      "v-list-tile",
                                      {
                                        on: {
                                          click: function ($event) {
                                            return _vm.edit(props.item)
                                          },
                                        },
                                      },
                                      [
                                        _c(
                                          "v-list-tile-title",
                                          [
                                            _c(
                                              "v-icon",
                                              {
                                                staticClass: "mr-2",
                                                attrs: { small: "" },
                                              },
                                              [_vm._v(" edit ")]
                                            ),
                                            _vm._v(
                                              "\n                                    " +
                                                _vm._s(
                                                  _vm.trans("messages.edit")
                                                ) +
                                                "\n                                "
                                            ),
                                          ],
                                          1
                                        ),
                                      ],
                                      1
                                    )
                                  : _vm._e(),
                                _vm._v(" "),
                                _c(
                                  "v-list-tile",
                                  { attrs: { href: props.item.download_url } },
                                  [
                                    _c(
                                      "v-list-tile-title",
                                      [
                                        _c(
                                          "v-icon",
                                          {
                                            staticClass: "mr-2",
                                            attrs: { small: "" },
                                          },
                                          [_vm._v(" save_alt ")]
                                        ),
                                        _vm._v(
                                          "\n                                    " +
                                            _vm._s(
                                              _vm.trans(
                                                "messages.download_estimate"
                                              )
                                            ) +
                                            "\n                                "
                                        ),
                                      ],
                                      1
                                    ),
                                  ],
                                  1
                                ),
                                _vm._v(" "),
                                _vm.$can(
                                  "project." + _vm.projectId + ".invoice.delete"
                                )
                                  ? _c(
                                      "v-list-tile",
                                      {
                                        on: {
                                          click: function ($event) {
                                            return _vm.deleteInvoice(props.item)
                                          },
                                        },
                                      },
                                      [
                                        _c(
                                          "v-list-tile-title",
                                          [
                                            _c(
                                              "v-icon",
                                              {
                                                staticClass: "mr-2",
                                                attrs: { small: "" },
                                              },
                                              [_vm._v(" delete_forever ")]
                                            ),
                                            _vm._v(
                                              "\n                                    " +
                                                _vm._s(
                                                  _vm.trans("messages.delete")
                                                ) +
                                                "\n                                "
                                            ),
                                          ],
                                          1
                                        ),
                                      ],
                                      1
                                    )
                                  : _vm._e(),
                                _vm._v(" "),
                                _vm.$can(
                                  "project." + _vm.projectId + ".invoice.create"
                                ) && props.item.type !== "final"
                                  ? _c(
                                      "v-list-tile",
                                      {
                                        on: {
                                          click: function ($event) {
                                            return _vm.convertToInvoice(
                                              props.item
                                            )
                                          },
                                        },
                                      },
                                      [
                                        _c(
                                          "v-list-tile-title",
                                          [
                                            _c(
                                              "v-icon",
                                              {
                                                staticClass: "mr-2",
                                                attrs: { small: "" },
                                              },
                                              [_vm._v(" redo ")]
                                            ),
                                            _vm._v(
                                              "\n                                    " +
                                                _vm._s(
                                                  _vm.trans(
                                                    "messages.convert_to_invoice"
                                                  )
                                                ) +
                                                "\n                                "
                                            ),
                                          ],
                                          1
                                        ),
                                      ],
                                      1
                                    )
                                  : _vm._e(),
                              ],
                              1
                            ),
                          ],
                          1
                        ),
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c("td", [
                      _vm._v(
                        _vm._s(_vm._f("formatDate")(props.item.invoice_date))
                      ),
                    ]),
                    _vm._v(" "),
                    _c("td", [_vm._v(_vm._s(props.item.invoice_number))]),
                    _vm._v(" "),
                    _c("td", [_vm._v(_vm._s(props.item.project))]),
                    _vm._v(" "),
                    _c("td", [_vm._v(_vm._s(props.item.customer))]),
                    _vm._v(" "),
                    _c("td", [
                      _vm._v(_vm._s(_vm._f("formatDate")(props.item.due_date))),
                    ]),
                  ]
                },
              },
            ]),
          }),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);