"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_admin_settings_Create_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/settings/Create.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/settings/Create.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _customers_components_currency_Add__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../customers/components/currency/Add */ "./resources/js/admin/customers/components/currency/Add.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  components: {
    CurrencyAdd: _customers_components_currency_Add__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  data: function data() {
    return {
      form_fields: [],
      dropzone: null,
      logo: null,
      favicon: null,
      languages: [],
      dateFormats: [],
      timeFormats: [],
      timezones: [],
      loading: false,
      currencies: [],
      week_days: [],
      dropzoneFav: null,
      cron_job_command: '',
      email_templates: []
    };
  },
  created: function created() {
    var _this = this;
    this.getSystemDataFromApi();
    this.$eventBus.$on('updateCurrenciesList', function (data) {
      _this.getCurrenciesListFromApi();
      _this.form_fields.currency_id = data.id;
    });
  },
  beforeDestroy: function beforeDestroy() {
    this.$eventBus.$off('updateCurrenciesList');
  },
  methods: {
    getSystemDataFromApi: function getSystemDataFromApi() {
      var self = this;
      axios.get('/admin/system-settings/create').then(function (response) {
        self.getCurrenciesListFromApi();
        self.form_fields = response.data.system;
        self.form_fields.currency_id = Number(response.data.system.currency_id);
        self.logo = response.data.logo;
        self.favicon = response.data.favicon;
        self.languages = response.data.languages;
        self.timezones = response.data.timezone_list;
        self.dateFormats = response.data.date_formats;
        self.timeFormats = response.data.time_formats;
        self.form_fields.APP_LOCALE = response.data.default_values.APP_LOCALE;
        self.form_fields.APP_NAME = response.data.default_values.APP_NAME;
        self.form_fields.ENABLE_CLIENT_SIGNUP = response.data.default_values.ENABLE_CLIENT_SIGNUP;
        self.form_fields.APP_TIMEZONE = response.data.default_values.APP_TIMEZONE;
        self.form_fields.APP_TITLE = response.data.default_values.APP_TITLE;
        self.week_days = response.data.week_days;
        self.cron_job_command = response.data.cron_job_command;
        self.email_templates = response.data.email_templates;
        self.initDropzone();
      })["catch"](function (error) {
        console.log(error);
      });
    },
    initDropzone: function initDropzone() {
      var self = this;
      if (self.dropzone) {
        self.dropzone.destroy();
      }
      self.dropzone = new Dropzone('div#uploadLogo', {
        url: APP.APP_URL + '/admin/system-settings-upload-logo',
        paramName: 'file',
        params: {
          type: 'logo'
        },
        uploadMultiple: false,
        maxFiles: 1,
        acceptedFiles: '.jpeg,.jpg,.png,.gif,.JPEG,.JPG,.PNG,.GIF',
        dictDefaultMessage: self.trans('messages.drop_image_here'),
        headers: {
          'X-CSRF-TOKEN': _token
        },
        autoProcessQueue: true,
        init: function init() {
          var prevFile;
          this.on('addedfile', function () {
            if (typeof prevFile !== 'undefined') {
              this.removeFile(prevFile);
            }
          });
          this.on('success', function (file, response) {
            prevFile = file;
          });
        },
        success: function success(file, response) {
          self.form_fields.logo = response;
        }
      });
      if (self.dropzoneFav) {
        self.dropzoneFav.destroy();
      }
      self.dropzoneFav = new Dropzone('div#uploadFavicon', {
        url: APP.APP_URL + '/admin/system-settings-upload-logo',
        paramName: 'file',
        params: {
          type: 'favicon'
        },
        uploadMultiple: false,
        maxFiles: 1,
        acceptedFiles: '.jpeg,.jpg,.png,.gif,.JPEG,.JPG,.PNG,.GIF',
        dictDefaultMessage: self.trans('messages.drop_image_here'),
        headers: {
          'X-CSRF-TOKEN': _token
        },
        autoProcessQueue: true,
        init: function init() {
          var prevFile;
          this.on('addedfile', function () {
            if (typeof prevFile !== 'undefined') {
              this.removeFile(prevFile);
            }
          });
          this.on('success', function (file, response) {
            prevFile = file;
          });
        },
        success: function success(file, response) {
          self.form_fields.favicon = response;
        }
      });
    },
    store: function (_store) {
      function store() {
        return _store.apply(this, arguments);
      }
      store.toString = function () {
        return _store.toString();
      };
      return store;
    }(function () {
      var self = this;
      var data = _.pick(self.form_fields, ['tax_number', 'mobile', 'alternate_contact_no', 'email', 'city', 'state', 'country', 'zip_code', 'logo', 'APP_NAME', 'APP_TITLE', 'APP_LOCALE', 'date_format', 'time_format', 'APP_TIMEZONE', 'currency_id', 'first_day_of_week', 'address_line_1', 'address_line_2', 'favicon', 'ENABLE_CLIENT_SIGNUP']);
      data.email_templates = self.email_templates;
      self.$validator.validateAll().then(function (result) {
        if (result == true) {
          self.loading = true;
          axios.post('/admin/system-settings', data).then(function (response) {
            self.loading = false;
            self.$store.commit('showSnackbar', {
              message: response.data.msg,
              color: response.data.success
            });
            if (response.data.success === true) {
              window.location.reload();
            }
          })["catch"](function (err) {
            console.log(err.response.status);
            if (err.response.status === 401) {
              store.dispatch('auth/handleResponse', err.response);
            }
          });
        }
      });
    }),
    addCurrency: function addCurrency() {
      this.$refs.currencyAdd.create();
    },
    getCurrenciesListFromApi: function getCurrenciesListFromApi() {
      var self = this;
      axios.get('/admin/currencies').then(function (response) {
        self.currencies = response.data;
      })["catch"](function (error) {
        console.log(error);
      });
    }
  }
});

/***/ }),

/***/ "./resources/js/admin/settings/Create.vue":
/*!************************************************!*\
  !*** ./resources/js/admin/settings/Create.vue ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Create_vue_vue_type_template_id_5a89a23a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Create.vue?vue&type=template&id=5a89a23a& */ "./resources/js/admin/settings/Create.vue?vue&type=template&id=5a89a23a&");
/* harmony import */ var _Create_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Create.vue?vue&type=script&lang=js& */ "./resources/js/admin/settings/Create.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Create_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Create_vue_vue_type_template_id_5a89a23a___WEBPACK_IMPORTED_MODULE_0__.render,
  _Create_vue_vue_type_template_id_5a89a23a___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/admin/settings/Create.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/admin/settings/Create.vue?vue&type=script&lang=js&":
/*!*************************************************************************!*\
  !*** ./resources/js/admin/settings/Create.vue?vue&type=script&lang=js& ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Create_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Create.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/settings/Create.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Create_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/admin/settings/Create.vue?vue&type=template&id=5a89a23a&":
/*!*******************************************************************************!*\
  !*** ./resources/js/admin/settings/Create.vue?vue&type=template&id=5a89a23a& ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Create_vue_vue_type_template_id_5a89a23a___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Create_vue_vue_type_template_id_5a89a23a___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Create_vue_vue_type_template_id_5a89a23a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Create.vue?vue&type=template&id=5a89a23a& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/settings/Create.vue?vue&type=template&id=5a89a23a&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/settings/Create.vue?vue&type=template&id=5a89a23a&":
/*!**********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/settings/Create.vue?vue&type=template&id=5a89a23a& ***!
  \**********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "v-layout",
        { attrs: { wrap: "" } },
        [
          _c("CurrencyAdd", { ref: "currencyAdd" }),
          _vm._v(" "),
          _c(
            "v-flex",
            { attrs: { xs12: "", sm12: "", md12: "" } },
            [
              _c(
                "v-card",
                [
                  _c(
                    "v-card-text",
                    [
                      _c(
                        "v-tabs",
                        {
                          attrs: {
                            color: "cyan",
                            dark: "",
                            "slider-color": "yellow",
                            grow: "",
                          },
                        },
                        [
                          _c(
                            "v-tab",
                            { attrs: { ripple: "" } },
                            [
                              _c("v-icon", [_vm._v("settings")]),
                              _vm._v(
                                "\n                            " +
                                  _vm._s(
                                    _vm.trans("messages.system_settings")
                                  ) +
                                  "\n                        "
                              ),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-tab",
                            { attrs: { ripple: "" } },
                            [
                              _c("v-icon", [_vm._v("settings")]),
                              _vm._v(
                                "\n                            " +
                                  _vm._s(
                                    _vm.trans("messages.business_settings")
                                  ) +
                                  "\n                        "
                              ),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-tab",
                            { attrs: { ripple: "" } },
                            [
                              _c("v-icon", [_vm._v("receipt")]),
                              _vm._v(
                                "\n                            " +
                                  _vm._s(
                                    _vm.trans("messages.email_templates")
                                  ) +
                                  "\n                        "
                              ),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _vm.$can("superadmin")
                            ? _c(
                                "v-tab",
                                { attrs: { ripple: "" } },
                                [
                                  _c("v-icon", [_vm._v("settings")]),
                                  _vm._v(
                                    "\n                            Cron\n                        "
                                  ),
                                ],
                                1
                              )
                            : _vm._e(),
                          _vm._v(" "),
                          _c(
                            "v-tab-item",
                            [
                              _c(
                                "v-card",
                                { attrs: { flat: "" } },
                                [
                                  _c(
                                    "v-card-text",
                                    [
                                      _c(
                                        "v-container",
                                        { attrs: { "grid-list-md": "" } },
                                        [
                                          _c(
                                            "v-layout",
                                            { attrs: { row: "", wrap: "" } },
                                            [
                                              _c(
                                                "v-flex",
                                                {
                                                  attrs: { xs12: "", sm6: "" },
                                                },
                                                [
                                                  _c("v-text-field", {
                                                    directives: [
                                                      {
                                                        name: "validate",
                                                        rawName: "v-validate",
                                                        value: "required",
                                                        expression:
                                                          "'required'",
                                                      },
                                                    ],
                                                    attrs: {
                                                      label:
                                                        _vm.trans(
                                                          "messages.app_title"
                                                        ),
                                                      "data-vv-name":
                                                        "app_title",
                                                      "data-vv-as":
                                                        _vm.trans(
                                                          "messages.app_title"
                                                        ),
                                                      "error-messages":
                                                        _vm.errors.collect(
                                                          "app_title"
                                                        ),
                                                      required: "",
                                                    },
                                                    model: {
                                                      value:
                                                        _vm.form_fields
                                                          .APP_TITLE,
                                                      callback: function ($$v) {
                                                        _vm.$set(
                                                          _vm.form_fields,
                                                          "APP_TITLE",
                                                          $$v
                                                        )
                                                      },
                                                      expression:
                                                        "form_fields.APP_TITLE",
                                                    },
                                                  }),
                                                ],
                                                1
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "v-flex",
                                                {
                                                  attrs: { xs12: "", md6: "" },
                                                },
                                                [
                                                  _c("v-autocomplete", {
                                                    directives: [
                                                      {
                                                        name: "validate",
                                                        rawName: "v-validate",
                                                        value: "required",
                                                        expression:
                                                          "'required'",
                                                      },
                                                    ],
                                                    attrs: {
                                                      items: _vm.languages,
                                                      label: _vm.trans(
                                                        "messages.app_default_lang"
                                                      ),
                                                      "data-vv-name":
                                                        "app_default_lang",
                                                      "data-vv-as": _vm.trans(
                                                        "messages.app_default_lang"
                                                      ),
                                                      "error-messages":
                                                        _vm.errors.collect(
                                                          "app_default_lang"
                                                        ),
                                                      required: "",
                                                    },
                                                    model: {
                                                      value:
                                                        _vm.form_fields
                                                          .APP_LOCALE,
                                                      callback: function ($$v) {
                                                        _vm.$set(
                                                          _vm.form_fields,
                                                          "APP_LOCALE",
                                                          $$v
                                                        )
                                                      },
                                                      expression:
                                                        "form_fields.APP_LOCALE",
                                                    },
                                                  }),
                                                ],
                                                1
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "v-flex",
                                                {
                                                  attrs: { xs12: "", md4: "" },
                                                },
                                                [
                                                  _c("v-autocomplete", {
                                                    directives: [
                                                      {
                                                        name: "validate",
                                                        rawName: "v-validate",
                                                        value: "required",
                                                        expression:
                                                          "'required'",
                                                      },
                                                    ],
                                                    attrs: {
                                                      items: _vm.dateFormats,
                                                      label: _vm.trans(
                                                        "messages.date_format"
                                                      ),
                                                      "data-vv-name":
                                                        "date_format",
                                                      "data-vv-as": _vm.trans(
                                                        "messages.date_format"
                                                      ),
                                                      "error-messages":
                                                        _vm.errors.collect(
                                                          "date_format"
                                                        ),
                                                      required: "",
                                                    },
                                                    model: {
                                                      value:
                                                        _vm.form_fields
                                                          .date_format,
                                                      callback: function ($$v) {
                                                        _vm.$set(
                                                          _vm.form_fields,
                                                          "date_format",
                                                          $$v
                                                        )
                                                      },
                                                      expression:
                                                        "form_fields.date_format",
                                                    },
                                                  }),
                                                ],
                                                1
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "v-flex",
                                                {
                                                  attrs: { xs12: "", md4: "" },
                                                },
                                                [
                                                  _c("v-autocomplete", {
                                                    directives: [
                                                      {
                                                        name: "validate",
                                                        rawName: "v-validate",
                                                        value: "required",
                                                        expression:
                                                          "'required'",
                                                      },
                                                    ],
                                                    attrs: {
                                                      items: _vm.timeFormats,
                                                      label: _vm.trans(
                                                        "messages.time_format"
                                                      ),
                                                      "data-vv-name":
                                                        "time_format",
                                                      "data-vv-as": _vm.trans(
                                                        "messages.time_format"
                                                      ),
                                                      "error-messages":
                                                        _vm.errors.collect(
                                                          "time_format"
                                                        ),
                                                      required: "",
                                                    },
                                                    model: {
                                                      value:
                                                        _vm.form_fields
                                                          .time_format,
                                                      callback: function ($$v) {
                                                        _vm.$set(
                                                          _vm.form_fields,
                                                          "time_format",
                                                          $$v
                                                        )
                                                      },
                                                      expression:
                                                        "form_fields.time_format",
                                                    },
                                                  }),
                                                ],
                                                1
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "v-flex",
                                                {
                                                  attrs: { xs12: "", md4: "" },
                                                },
                                                [
                                                  _c("v-autocomplete", {
                                                    directives: [
                                                      {
                                                        name: "validate",
                                                        rawName: "v-validate",
                                                        value: "required",
                                                        expression:
                                                          "'required'",
                                                      },
                                                    ],
                                                    attrs: {
                                                      items: _vm.timezones,
                                                      label:
                                                        _vm.trans(
                                                          "messages.timezone"
                                                        ),
                                                      "data-vv-name":
                                                        "timezone",
                                                      "data-vv-as":
                                                        _vm.trans(
                                                          "messages.timezone"
                                                        ),
                                                      "error-messages":
                                                        _vm.errors.collect(
                                                          "timezone"
                                                        ),
                                                      required: "",
                                                    },
                                                    model: {
                                                      value:
                                                        _vm.form_fields
                                                          .APP_TIMEZONE,
                                                      callback: function ($$v) {
                                                        _vm.$set(
                                                          _vm.form_fields,
                                                          "APP_TIMEZONE",
                                                          $$v
                                                        )
                                                      },
                                                      expression:
                                                        "form_fields.APP_TIMEZONE",
                                                    },
                                                  }),
                                                ],
                                                1
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "v-flex",
                                                {
                                                  attrs: { xs12: "", md4: "" },
                                                },
                                                [
                                                  _c("v-autocomplete", {
                                                    directives: [
                                                      {
                                                        name: "validate",
                                                        rawName: "v-validate",
                                                        value: "required",
                                                        expression:
                                                          "'required'",
                                                      },
                                                    ],
                                                    attrs: {
                                                      items: _vm.week_days,
                                                      label: _vm.trans(
                                                        "messages.first_day_of_week"
                                                      ),
                                                      "data-vv-name":
                                                        "first_day_of_week",
                                                      "data-vv-as": _vm.trans(
                                                        "messages.first_day_of_week"
                                                      ),
                                                      "error-messages":
                                                        _vm.errors.collect(
                                                          "first_day_of_week"
                                                        ),
                                                      required: "",
                                                    },
                                                    model: {
                                                      value:
                                                        _vm.form_fields
                                                          .first_day_of_week,
                                                      callback: function ($$v) {
                                                        _vm.$set(
                                                          _vm.form_fields,
                                                          "first_day_of_week",
                                                          $$v
                                                        )
                                                      },
                                                      expression:
                                                        "form_fields.first_day_of_week",
                                                    },
                                                  }),
                                                ],
                                                1
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "v-flex",
                                                {
                                                  attrs: { xs12: "", sm4: "" },
                                                },
                                                [
                                                  _c("v-checkbox", {
                                                    attrs: {
                                                      label: _vm.trans(
                                                        "messages.enable_client_signup"
                                                      ),
                                                      color: "primary",
                                                      value: "1",
                                                    },
                                                    model: {
                                                      value:
                                                        _vm.form_fields
                                                          .ENABLE_CLIENT_SIGNUP,
                                                      callback: function ($$v) {
                                                        _vm.$set(
                                                          _vm.form_fields,
                                                          "ENABLE_CLIENT_SIGNUP",
                                                          $$v
                                                        )
                                                      },
                                                      expression:
                                                        "form_fields.ENABLE_CLIENT_SIGNUP",
                                                    },
                                                  }),
                                                ],
                                                1
                                              ),
                                            ],
                                            1
                                          ),
                                        ],
                                        1
                                      ),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-tab-item",
                            [
                              _c(
                                "v-card",
                                { attrs: { flat: "" } },
                                [
                                  _c(
                                    "v-card-text",
                                    [
                                      _c(
                                        "v-container",
                                        { attrs: { "grid-list-md": "" } },
                                        [
                                          _c(
                                            "v-layout",
                                            { attrs: { row: "", wrap: "" } },
                                            [
                                              _c(
                                                "v-flex",
                                                {
                                                  attrs: { xs12: "", sm4: "" },
                                                },
                                                [
                                                  _c("v-text-field", {
                                                    directives: [
                                                      {
                                                        name: "validate",
                                                        rawName: "v-validate",
                                                        value: "required",
                                                        expression:
                                                          "'required'",
                                                      },
                                                    ],
                                                    attrs: {
                                                      label:
                                                        _vm.trans(
                                                          "messages.company"
                                                        ),
                                                      "data-vv-name": "company",
                                                      "data-vv-as":
                                                        _vm.trans(
                                                          "messages.company"
                                                        ),
                                                      "error-messages":
                                                        _vm.errors.collect(
                                                          "company"
                                                        ),
                                                      required: "",
                                                    },
                                                    model: {
                                                      value:
                                                        _vm.form_fields
                                                          .APP_NAME,
                                                      callback: function ($$v) {
                                                        _vm.$set(
                                                          _vm.form_fields,
                                                          "APP_NAME",
                                                          $$v
                                                        )
                                                      },
                                                      expression:
                                                        "form_fields.APP_NAME",
                                                    },
                                                  }),
                                                ],
                                                1
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "v-flex",
                                                {
                                                  attrs: { xs12: "", sm4: "" },
                                                },
                                                [
                                                  _c("v-text-field", {
                                                    attrs: {
                                                      label: _vm.trans(
                                                        "messages.tax_number"
                                                      ),
                                                      "data-vv-name":
                                                        "tax_number",
                                                      required: "",
                                                    },
                                                    model: {
                                                      value:
                                                        _vm.form_fields
                                                          .tax_number,
                                                      callback: function ($$v) {
                                                        _vm.$set(
                                                          _vm.form_fields,
                                                          "tax_number",
                                                          $$v
                                                        )
                                                      },
                                                      expression:
                                                        "form_fields.tax_number",
                                                    },
                                                  }),
                                                ],
                                                1
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "v-flex",
                                                {
                                                  attrs: { xs12: "", md4: "" },
                                                },
                                                [
                                                  _c("v-text-field", {
                                                    directives: [
                                                      {
                                                        name: "validate",
                                                        rawName: "v-validate",
                                                        value: "required",
                                                        expression:
                                                          "'required'",
                                                      },
                                                    ],
                                                    attrs: {
                                                      label:
                                                        _vm.trans(
                                                          "messages.mobile"
                                                        ),
                                                      "data-vv-name": "mobile",
                                                      "data-vv-as":
                                                        _vm.trans(
                                                          "messages.mobile"
                                                        ),
                                                      "error-messages":
                                                        _vm.errors.collect(
                                                          "mobile"
                                                        ),
                                                      required: "",
                                                    },
                                                    model: {
                                                      value:
                                                        _vm.form_fields.mobile,
                                                      callback: function ($$v) {
                                                        _vm.$set(
                                                          _vm.form_fields,
                                                          "mobile",
                                                          $$v
                                                        )
                                                      },
                                                      expression:
                                                        "form_fields.mobile",
                                                    },
                                                  }),
                                                ],
                                                1
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "v-flex",
                                                {
                                                  attrs: { xs12: "", md4: "" },
                                                },
                                                [
                                                  _c("v-text-field", {
                                                    attrs: {
                                                      label: _vm.trans(
                                                        "messages.alternate_num"
                                                      ),
                                                    },
                                                    model: {
                                                      value:
                                                        _vm.form_fields
                                                          .alternate_contact_no,
                                                      callback: function ($$v) {
                                                        _vm.$set(
                                                          _vm.form_fields,
                                                          "alternate_contact_no",
                                                          $$v
                                                        )
                                                      },
                                                      expression:
                                                        "form_fields.alternate_contact_no",
                                                    },
                                                  }),
                                                ],
                                                1
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "v-flex",
                                                {
                                                  attrs: {
                                                    xs12: "",
                                                    sm6: "",
                                                    md4: "",
                                                  },
                                                },
                                                [
                                                  _c("v-text-field", {
                                                    directives: [
                                                      {
                                                        name: "validate",
                                                        rawName: "v-validate",
                                                        value: "required|email",
                                                        expression:
                                                          "'required|email'",
                                                      },
                                                    ],
                                                    attrs: {
                                                      label:
                                                        _vm.trans(
                                                          "messages.email"
                                                        ),
                                                      "data-vv-name": "email",
                                                      "data-vv-as":
                                                        _vm.trans(
                                                          "messages.email"
                                                        ),
                                                      "error-messages":
                                                        _vm.errors.collect(
                                                          "email"
                                                        ),
                                                      required: "",
                                                    },
                                                    model: {
                                                      value:
                                                        _vm.form_fields.email,
                                                      callback: function ($$v) {
                                                        _vm.$set(
                                                          _vm.form_fields,
                                                          "email",
                                                          $$v
                                                        )
                                                      },
                                                      expression:
                                                        "form_fields.email",
                                                    },
                                                  }),
                                                ],
                                                1
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "v-flex",
                                                {
                                                  attrs: { xs12: "", md4: "" },
                                                },
                                                [
                                                  _c("v-text-field", {
                                                    attrs: {
                                                      label: _vm.trans(
                                                        "messages.address_line_1"
                                                      ),
                                                    },
                                                    model: {
                                                      value:
                                                        _vm.form_fields
                                                          .address_line_1,
                                                      callback: function ($$v) {
                                                        _vm.$set(
                                                          _vm.form_fields,
                                                          "address_line_1",
                                                          $$v
                                                        )
                                                      },
                                                      expression:
                                                        "form_fields.address_line_1",
                                                    },
                                                  }),
                                                ],
                                                1
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "v-flex",
                                                {
                                                  attrs: { xs12: "", md4: "" },
                                                },
                                                [
                                                  _c("v-text-field", {
                                                    attrs: {
                                                      label: _vm.trans(
                                                        "messages.address_line_2"
                                                      ),
                                                    },
                                                    model: {
                                                      value:
                                                        _vm.form_fields
                                                          .address_line_2,
                                                      callback: function ($$v) {
                                                        _vm.$set(
                                                          _vm.form_fields,
                                                          "address_line_2",
                                                          $$v
                                                        )
                                                      },
                                                      expression:
                                                        "form_fields.address_line_2",
                                                    },
                                                  }),
                                                ],
                                                1
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "v-flex",
                                                {
                                                  attrs: { xs12: "", md4: "" },
                                                },
                                                [
                                                  _c("v-text-field", {
                                                    attrs: {
                                                      label:
                                                        _vm.trans(
                                                          "messages.city"
                                                        ),
                                                    },
                                                    model: {
                                                      value:
                                                        _vm.form_fields.city,
                                                      callback: function ($$v) {
                                                        _vm.$set(
                                                          _vm.form_fields,
                                                          "city",
                                                          $$v
                                                        )
                                                      },
                                                      expression:
                                                        "form_fields.city",
                                                    },
                                                  }),
                                                ],
                                                1
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "v-flex",
                                                {
                                                  attrs: { xs12: "", md4: "" },
                                                },
                                                [
                                                  _c("v-text-field", {
                                                    attrs: {
                                                      label:
                                                        _vm.trans(
                                                          "messages.state"
                                                        ),
                                                    },
                                                    model: {
                                                      value:
                                                        _vm.form_fields.state,
                                                      callback: function ($$v) {
                                                        _vm.$set(
                                                          _vm.form_fields,
                                                          "state",
                                                          $$v
                                                        )
                                                      },
                                                      expression:
                                                        "form_fields.state",
                                                    },
                                                  }),
                                                ],
                                                1
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "v-flex",
                                                {
                                                  attrs: { xs12: "", md4: "" },
                                                },
                                                [
                                                  _c("v-text-field", {
                                                    attrs: {
                                                      label:
                                                        _vm.trans(
                                                          "messages.country"
                                                        ),
                                                    },
                                                    model: {
                                                      value:
                                                        _vm.form_fields.country,
                                                      callback: function ($$v) {
                                                        _vm.$set(
                                                          _vm.form_fields,
                                                          "country",
                                                          $$v
                                                        )
                                                      },
                                                      expression:
                                                        "form_fields.country",
                                                    },
                                                  }),
                                                ],
                                                1
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "v-flex",
                                                {
                                                  attrs: { xs12: "", md4: "" },
                                                },
                                                [
                                                  _c("v-text-field", {
                                                    attrs: {
                                                      label:
                                                        _vm.trans(
                                                          "messages.zip_code"
                                                        ),
                                                    },
                                                    model: {
                                                      value:
                                                        _vm.form_fields
                                                          .zip_code,
                                                      callback: function ($$v) {
                                                        _vm.$set(
                                                          _vm.form_fields,
                                                          "zip_code",
                                                          $$v
                                                        )
                                                      },
                                                      expression:
                                                        "form_fields.zip_code",
                                                    },
                                                  }),
                                                ],
                                                1
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "v-flex",
                                                {
                                                  attrs: { xs12: "", md3: "" },
                                                },
                                                [
                                                  _c("v-autocomplete", {
                                                    directives: [
                                                      {
                                                        name: "validate",
                                                        rawName: "v-validate",
                                                        value: "required",
                                                        expression:
                                                          "'required'",
                                                      },
                                                    ],
                                                    attrs: {
                                                      "item-text": "currency",
                                                      "item-value": "id",
                                                      items: _vm.currencies,
                                                      label:
                                                        _vm.trans(
                                                          "messages.currency"
                                                        ),
                                                      "data-vv-name":
                                                        "currency",
                                                      "data-vv-as":
                                                        _vm.trans(
                                                          "messages.currency"
                                                        ),
                                                      "error-messages":
                                                        _vm.errors.collect(
                                                          "currency"
                                                        ),
                                                      required: "",
                                                    },
                                                    model: {
                                                      value:
                                                        _vm.form_fields
                                                          .currency_id,
                                                      callback: function ($$v) {
                                                        _vm.$set(
                                                          _vm.form_fields,
                                                          "currency_id",
                                                          $$v
                                                        )
                                                      },
                                                      expression:
                                                        "form_fields.currency_id",
                                                    },
                                                  }),
                                                ],
                                                1
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "v-flex",
                                                { attrs: { md1: "" } },
                                                [
                                                  _c(
                                                    "v-btn",
                                                    {
                                                      attrs: {
                                                        small: "",
                                                        color: "primary",
                                                        fab: "",
                                                        dark: "",
                                                      },
                                                      on: {
                                                        click: _vm.addCurrency,
                                                      },
                                                    },
                                                    [
                                                      _c("v-icon", [
                                                        _vm._v("add"),
                                                      ]),
                                                    ],
                                                    1
                                                  ),
                                                ],
                                                1
                                              ),
                                            ],
                                            1
                                          ),
                                          _vm._v(" "),
                                          _c(
                                            "v-layout",
                                            { attrs: { row: "", wrap: "" } },
                                            [
                                              _c(
                                                "v-flex",
                                                {
                                                  attrs: {
                                                    xs12: "",
                                                    sm6: "",
                                                    md6: "",
                                                  },
                                                },
                                                [
                                                  _c("strong", [
                                                    _vm._v(
                                                      _vm._s(
                                                        _vm.trans(
                                                          "messages.logo"
                                                        )
                                                      ) + ":"
                                                    ),
                                                  ]),
                                                  _c("br"),
                                                  _vm._v(" "),
                                                  _c("div", {
                                                    staticClass: "dropzone",
                                                    attrs: { id: "uploadLogo" },
                                                  }),
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "v-flex",
                                                {
                                                  attrs: {
                                                    xs12: "",
                                                    sm6: "",
                                                    md6: "",
                                                  },
                                                },
                                                [
                                                  _vm.logo
                                                    ? _c("v-img", {
                                                        attrs: {
                                                          src: _vm.logo,
                                                          height: "125px",
                                                          contain: "",
                                                        },
                                                      })
                                                    : _vm._e(),
                                                ],
                                                1
                                              ),
                                            ],
                                            1
                                          ),
                                          _vm._v(" "),
                                          _c(
                                            "v-layout",
                                            { attrs: { row: "", wrap: "" } },
                                            [
                                              _c(
                                                "v-flex",
                                                {
                                                  attrs: {
                                                    xs12: "",
                                                    sm6: "",
                                                    md6: "",
                                                  },
                                                },
                                                [
                                                  _c("strong", [
                                                    _vm._v(
                                                      _vm._s(
                                                        _vm.trans(
                                                          "messages.favicon"
                                                        )
                                                      ) + ":"
                                                    ),
                                                  ]),
                                                  _c("br"),
                                                  _vm._v(" "),
                                                  _c("div", {
                                                    staticClass: "dropzone",
                                                    attrs: {
                                                      id: "uploadFavicon",
                                                    },
                                                  }),
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "v-flex",
                                                {
                                                  attrs: {
                                                    xs12: "",
                                                    sm6: "",
                                                    md6: "",
                                                  },
                                                },
                                                [
                                                  _vm.favicon
                                                    ? _c("v-img", {
                                                        attrs: {
                                                          src: _vm.favicon,
                                                          height: "80px",
                                                          contain: "",
                                                        },
                                                      })
                                                    : _vm._e(),
                                                ],
                                                1
                                              ),
                                            ],
                                            1
                                          ),
                                        ],
                                        1
                                      ),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-tab-item",
                            [
                              _c(
                                "v-card",
                                { staticClass: "mb-3" },
                                [
                                  _c("v-card-title", [
                                    _c("span", { staticClass: "headline" }, [
                                      _vm._v(
                                        "\n                                        " +
                                          _vm._s(
                                            _vm.trans("messages.customer")
                                          ) +
                                          "\n                                    "
                                      ),
                                    ]),
                                  ]),
                                  _vm._v(" "),
                                  _c("v-divider"),
                                  _vm._v(" "),
                                  _c(
                                    "v-card-text",
                                    [
                                      _c(
                                        "v-container",
                                        { attrs: { "grid-list-md": "" } },
                                        _vm._l(
                                          _vm.email_templates,
                                          function (template) {
                                            return template.type == "customer"
                                              ? _c(
                                                  "v-layout",
                                                  {
                                                    key: template.key,
                                                    attrs: {
                                                      row: "",
                                                      wrap: "",
                                                    },
                                                  },
                                                  [
                                                    _c(
                                                      "v-flex",
                                                      {
                                                        attrs: {
                                                          xs12: "",
                                                          sm12: "",
                                                        },
                                                      },
                                                      [
                                                        _c(
                                                          "p",
                                                          {
                                                            staticClass:
                                                              "title",
                                                          },
                                                          [
                                                            _vm._v(
                                                              _vm._s(
                                                                template.name
                                                              ) + ":"
                                                            ),
                                                          ]
                                                        ),
                                                        _vm._v(" "),
                                                        _c("v-text-field", {
                                                          directives: [
                                                            {
                                                              name: "validate",
                                                              rawName:
                                                                "v-validate",
                                                              value: "required",
                                                              expression:
                                                                "'required'",
                                                            },
                                                          ],
                                                          attrs: {
                                                            label: _vm.trans(
                                                              "messages.email_subject"
                                                            ),
                                                            "data-vv-name":
                                                              "email_subject",
                                                            "data-vv-as":
                                                              _vm.trans(
                                                                "messages.email_subject"
                                                              ),
                                                            "error-messages":
                                                              _vm.errors.collect(
                                                                "email_subject"
                                                              ),
                                                            required: "",
                                                          },
                                                          model: {
                                                            value:
                                                              _vm
                                                                .email_templates[
                                                                template.key
                                                              ]["subject"],
                                                            callback: function (
                                                              $$v
                                                            ) {
                                                              _vm.$set(
                                                                _vm
                                                                  .email_templates[
                                                                  template.key
                                                                ],
                                                                "subject",
                                                                $$v
                                                              )
                                                            },
                                                            expression:
                                                              "\n                                                        email_templates[template.key]['subject']\n                                                    ",
                                                          },
                                                        }),
                                                      ],
                                                      1
                                                    ),
                                                    _vm._v(" "),
                                                    _c(
                                                      "v-flex",
                                                      {
                                                        attrs: {
                                                          xs12: "",
                                                          sm12: "",
                                                          md12: "",
                                                        },
                                                      },
                                                      [
                                                        _vm._v(
                                                          "\n                                                " +
                                                            _vm._s(
                                                              _vm.trans(
                                                                "messages.email_body"
                                                              )
                                                            ) +
                                                            "\n                                                "
                                                        ),
                                                        _c("quill-editor", {
                                                          model: {
                                                            value:
                                                              _vm
                                                                .email_templates[
                                                                template.key
                                                              ]["body"],
                                                            callback: function (
                                                              $$v
                                                            ) {
                                                              _vm.$set(
                                                                _vm
                                                                  .email_templates[
                                                                  template.key
                                                                ],
                                                                "body",
                                                                $$v
                                                              )
                                                            },
                                                            expression:
                                                              "\n                                                        email_templates[template.key]['body']\n                                                    ",
                                                          },
                                                        }),
                                                        _vm._v(" "),
                                                        _c("small", [
                                                          _vm._v(
                                                            _vm._s(
                                                              _vm.trans(
                                                                "messages.available_tags"
                                                              )
                                                            ) +
                                                              "\n                                                    " +
                                                              _vm._s(
                                                                template.tags
                                                              )
                                                          ),
                                                        ]),
                                                      ],
                                                      1
                                                    ),
                                                    _vm._v(" "),
                                                    template.add_attachment == 1
                                                      ? _c(
                                                          "v-flex",
                                                          {
                                                            attrs: {
                                                              xs12: "",
                                                              sm4: "",
                                                            },
                                                          },
                                                          [
                                                            _c("v-checkbox", {
                                                              attrs: {
                                                                label:
                                                                  _vm.trans(
                                                                    "messages.attach_pdf"
                                                                  ),
                                                                color:
                                                                  "primary",
                                                                value: "1",
                                                                "hide-details":
                                                                  "",
                                                              },
                                                              model: {
                                                                value:
                                                                  _vm
                                                                    .email_templates[
                                                                    template.key
                                                                  ][
                                                                    "attachment"
                                                                  ],
                                                                callback:
                                                                  function (
                                                                    $$v
                                                                  ) {
                                                                    _vm.$set(
                                                                      _vm
                                                                        .email_templates[
                                                                        template
                                                                          .key
                                                                      ],
                                                                      "attachment",
                                                                      $$v
                                                                    )
                                                                  },
                                                                expression:
                                                                  "\n                                                        email_templates[template.key][\n                                                            'attachment'\n                                                        ]\n                                                    ",
                                                              },
                                                            }),
                                                          ],
                                                          1
                                                        )
                                                      : _vm._e(),
                                                    _vm._v(" "),
                                                    _c(
                                                      "v-flex",
                                                      { attrs: { xs12: "" } },
                                                      [
                                                        _c("v-divider", {
                                                          staticClass:
                                                            "mb-3 mt-3",
                                                        }),
                                                      ],
                                                      1
                                                    ),
                                                  ],
                                                  1
                                                )
                                              : _vm._e()
                                          }
                                        ),
                                        1
                                      ),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              ),
                              _vm._v(" "),
                              _c(
                                "v-card",
                                { staticClass: "mb-3" },
                                [
                                  _c("v-card-title", [
                                    _c("span", { staticClass: "headline" }, [
                                      _vm._v(
                                        _vm._s(_vm.trans("messages.employee")) +
                                          "\n                                    "
                                      ),
                                    ]),
                                  ]),
                                  _vm._v(" "),
                                  _c("v-divider"),
                                  _vm._v(" "),
                                  _c(
                                    "v-card-text",
                                    [
                                      _c(
                                        "v-container",
                                        { attrs: { "grid-list-md": "" } },
                                        _vm._l(
                                          _vm.email_templates,
                                          function (template) {
                                            return template.type == "employee"
                                              ? _c(
                                                  "v-layout",
                                                  {
                                                    key: template.key,
                                                    attrs: {
                                                      row: "",
                                                      wrap: "",
                                                    },
                                                  },
                                                  [
                                                    _c(
                                                      "v-flex",
                                                      {
                                                        attrs: {
                                                          xs12: "",
                                                          sm12: "",
                                                        },
                                                      },
                                                      [
                                                        _c(
                                                          "p",
                                                          {
                                                            staticClass:
                                                              "title",
                                                          },
                                                          [
                                                            _vm._v(
                                                              _vm._s(
                                                                template.name
                                                              ) + ":"
                                                            ),
                                                          ]
                                                        ),
                                                        _vm._v(" "),
                                                        _c("v-text-field", {
                                                          directives: [
                                                            {
                                                              name: "validate",
                                                              rawName:
                                                                "v-validate",
                                                              value: "required",
                                                              expression:
                                                                "'required'",
                                                            },
                                                          ],
                                                          attrs: {
                                                            label: _vm.trans(
                                                              "messages.email_subject"
                                                            ),
                                                            "data-vv-name":
                                                              "email_subject",
                                                            "data-vv-as":
                                                              _vm.trans(
                                                                "messages.email_subject"
                                                              ),
                                                            "error-messages":
                                                              _vm.errors.collect(
                                                                "email_subject"
                                                              ),
                                                            required: "",
                                                          },
                                                          model: {
                                                            value:
                                                              _vm
                                                                .email_templates[
                                                                template.key
                                                              ]["subject"],
                                                            callback: function (
                                                              $$v
                                                            ) {
                                                              _vm.$set(
                                                                _vm
                                                                  .email_templates[
                                                                  template.key
                                                                ],
                                                                "subject",
                                                                $$v
                                                              )
                                                            },
                                                            expression:
                                                              "\n                                                        email_templates[template.key]['subject']\n                                                    ",
                                                          },
                                                        }),
                                                      ],
                                                      1
                                                    ),
                                                    _vm._v(" "),
                                                    _c(
                                                      "v-flex",
                                                      {
                                                        attrs: {
                                                          xs12: "",
                                                          sm12: "",
                                                          md12: "",
                                                        },
                                                      },
                                                      [
                                                        _vm._v(
                                                          "\n                                                " +
                                                            _vm._s(
                                                              _vm.trans(
                                                                "messages.email_body"
                                                              )
                                                            ) +
                                                            "\n                                                "
                                                        ),
                                                        _c("quill-editor", {
                                                          model: {
                                                            value:
                                                              _vm
                                                                .email_templates[
                                                                template.key
                                                              ]["body"],
                                                            callback: function (
                                                              $$v
                                                            ) {
                                                              _vm.$set(
                                                                _vm
                                                                  .email_templates[
                                                                  template.key
                                                                ],
                                                                "body",
                                                                $$v
                                                              )
                                                            },
                                                            expression:
                                                              "\n                                                        email_templates[template.key]['body']\n                                                    ",
                                                          },
                                                        }),
                                                        _vm._v(" "),
                                                        _c("small", [
                                                          _vm._v(
                                                            _vm._s(
                                                              _vm.trans(
                                                                "messages.available_tags"
                                                              )
                                                            ) +
                                                              "\n                                                    " +
                                                              _vm._s(
                                                                template.tags
                                                              )
                                                          ),
                                                        ]),
                                                      ],
                                                      1
                                                    ),
                                                    _vm._v(" "),
                                                    template.add_attachment == 1
                                                      ? _c(
                                                          "v-flex",
                                                          {
                                                            attrs: {
                                                              xs12: "",
                                                              sm4: "",
                                                            },
                                                          },
                                                          [
                                                            _c("v-checkbox", {
                                                              attrs: {
                                                                label:
                                                                  _vm.trans(
                                                                    "messages.attach_pdf"
                                                                  ),
                                                                color:
                                                                  "primary",
                                                                value: "1",
                                                                "hide-details":
                                                                  "",
                                                              },
                                                              model: {
                                                                value:
                                                                  _vm
                                                                    .email_templates[
                                                                    template.key
                                                                  ][
                                                                    "attachment"
                                                                  ],
                                                                callback:
                                                                  function (
                                                                    $$v
                                                                  ) {
                                                                    _vm.$set(
                                                                      _vm
                                                                        .email_templates[
                                                                        template
                                                                          .key
                                                                      ],
                                                                      "attachment",
                                                                      $$v
                                                                    )
                                                                  },
                                                                expression:
                                                                  "\n                                                        email_templates[template.key][\n                                                            'attachment'\n                                                        ]\n                                                    ",
                                                              },
                                                            }),
                                                          ],
                                                          1
                                                        )
                                                      : _vm._e(),
                                                    _vm._v(" "),
                                                    _c(
                                                      "v-flex",
                                                      { attrs: { xs12: "" } },
                                                      [
                                                        _c("v-divider", {
                                                          staticClass:
                                                            "mb-3 mt-3",
                                                        }),
                                                      ],
                                                      1
                                                    ),
                                                  ],
                                                  1
                                                )
                                              : _vm._e()
                                          }
                                        ),
                                        1
                                      ),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              ),
                              _vm._v(" "),
                              _c(
                                "v-card",
                                [
                                  _c("v-card-title", [
                                    _c("span", { staticClass: "headline" }, [
                                      _vm._v(
                                        _vm._s(_vm.trans("messages.leads")) +
                                          " "
                                      ),
                                    ]),
                                  ]),
                                  _vm._v(" "),
                                  _c("v-divider"),
                                  _vm._v(" "),
                                  _c(
                                    "v-card-text",
                                    [
                                      _c(
                                        "v-container",
                                        { attrs: { "grid-list-md": "" } },
                                        _vm._l(
                                          _vm.email_templates,
                                          function (template) {
                                            return template.type == "leads"
                                              ? _c(
                                                  "v-layout",
                                                  {
                                                    key: template.key,
                                                    attrs: {
                                                      row: "",
                                                      wrap: "",
                                                    },
                                                  },
                                                  [
                                                    _c(
                                                      "v-flex",
                                                      {
                                                        attrs: {
                                                          xs12: "",
                                                          sm12: "",
                                                        },
                                                      },
                                                      [
                                                        _c(
                                                          "p",
                                                          {
                                                            staticClass:
                                                              "title",
                                                          },
                                                          [
                                                            _vm._v(
                                                              _vm._s(
                                                                template.name
                                                              ) + ":"
                                                            ),
                                                          ]
                                                        ),
                                                        _vm._v(" "),
                                                        _c("v-text-field", {
                                                          directives: [
                                                            {
                                                              name: "validate",
                                                              rawName:
                                                                "v-validate",
                                                              value: "required",
                                                              expression:
                                                                "'required'",
                                                            },
                                                          ],
                                                          attrs: {
                                                            label: _vm.trans(
                                                              "messages.email_subject"
                                                            ),
                                                            "data-vv-name":
                                                              "email_subject",
                                                            "data-vv-as":
                                                              _vm.trans(
                                                                "messages.email_subject"
                                                              ),
                                                            "error-messages":
                                                              _vm.errors.collect(
                                                                "email_subject"
                                                              ),
                                                            required: "",
                                                          },
                                                          model: {
                                                            value:
                                                              _vm
                                                                .email_templates[
                                                                template.key
                                                              ]["subject"],
                                                            callback: function (
                                                              $$v
                                                            ) {
                                                              _vm.$set(
                                                                _vm
                                                                  .email_templates[
                                                                  template.key
                                                                ],
                                                                "subject",
                                                                $$v
                                                              )
                                                            },
                                                            expression:
                                                              "\n                                                        email_templates[template.key]['subject']\n                                                    ",
                                                          },
                                                        }),
                                                      ],
                                                      1
                                                    ),
                                                    _vm._v(" "),
                                                    _c(
                                                      "v-flex",
                                                      {
                                                        attrs: {
                                                          xs12: "",
                                                          sm12: "",
                                                          md12: "",
                                                        },
                                                      },
                                                      [
                                                        _vm._v(
                                                          "\n                                                " +
                                                            _vm._s(
                                                              _vm.trans(
                                                                "messages.email_body"
                                                              )
                                                            ) +
                                                            "\n                                                "
                                                        ),
                                                        _c("quill-editor", {
                                                          model: {
                                                            value:
                                                              _vm
                                                                .email_templates[
                                                                template.key
                                                              ]["body"],
                                                            callback: function (
                                                              $$v
                                                            ) {
                                                              _vm.$set(
                                                                _vm
                                                                  .email_templates[
                                                                  template.key
                                                                ],
                                                                "body",
                                                                $$v
                                                              )
                                                            },
                                                            expression:
                                                              "\n                                                        email_templates[template.key]['body']\n                                                    ",
                                                          },
                                                        }),
                                                        _vm._v(" "),
                                                        _c("small", [
                                                          _vm._v(
                                                            _vm._s(
                                                              _vm.trans(
                                                                "messages.available_tags"
                                                              )
                                                            ) +
                                                              "\n                                                    " +
                                                              _vm._s(
                                                                template.tags
                                                              )
                                                          ),
                                                        ]),
                                                      ],
                                                      1
                                                    ),
                                                    _vm._v(" "),
                                                    template.add_attachment == 1
                                                      ? _c(
                                                          "v-flex",
                                                          {
                                                            attrs: {
                                                              xs12: "",
                                                              sm4: "",
                                                            },
                                                          },
                                                          [
                                                            _c("v-checkbox", {
                                                              attrs: {
                                                                label:
                                                                  _vm.trans(
                                                                    "messages.attach_pdf"
                                                                  ),
                                                                color:
                                                                  "primary",
                                                                value: "1",
                                                                "hide-details":
                                                                  "",
                                                              },
                                                              model: {
                                                                value:
                                                                  _vm
                                                                    .email_templates[
                                                                    template.key
                                                                  ][
                                                                    "attachment"
                                                                  ],
                                                                callback:
                                                                  function (
                                                                    $$v
                                                                  ) {
                                                                    _vm.$set(
                                                                      _vm
                                                                        .email_templates[
                                                                        template
                                                                          .key
                                                                      ],
                                                                      "attachment",
                                                                      $$v
                                                                    )
                                                                  },
                                                                expression:
                                                                  "\n                                                        email_templates[template.key][\n                                                            'attachment'\n                                                        ]\n                                                    ",
                                                              },
                                                            }),
                                                          ],
                                                          1
                                                        )
                                                      : _vm._e(),
                                                  ],
                                                  1
                                                )
                                              : _vm._e()
                                          }
                                        ),
                                        1
                                      ),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _vm.$can("superadmin")
                            ? _c(
                                "v-tab-item",
                                [
                                  _c(
                                    "v-card",
                                    { attrs: { flat: "" } },
                                    [
                                      _c(
                                        "v-card-text",
                                        [
                                          _c(
                                            "v-container",
                                            { attrs: { "grid-list-md": "" } },
                                            [
                                              _c(
                                                "v-layout",
                                                {
                                                  attrs: { row: "", wrap: "" },
                                                },
                                                [
                                                  _c(
                                                    "v-flex",
                                                    {
                                                      attrs: {
                                                        xs12: "",
                                                        sm12: "",
                                                      },
                                                    },
                                                    [
                                                      _c("strong", [
                                                        _vm._v(
                                                          _vm._s(
                                                            _vm.trans(
                                                              "messages.cron_command_label"
                                                            )
                                                          ) + ":"
                                                        ),
                                                      ]),
                                                      _vm._v(" "),
                                                      _c("br"),
                                                      _vm._v(" "),
                                                      _c("code", [
                                                        _vm._v(
                                                          _vm._s(
                                                            _vm.cron_job_command
                                                          )
                                                        ),
                                                      ]),
                                                    ]
                                                  ),
                                                ],
                                                1
                                              ),
                                            ],
                                            1
                                          ),
                                        ],
                                        1
                                      ),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              )
                            : _vm._e(),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "div",
                { staticClass: "text-xs-center mt-3" },
                [
                  _c(
                    "v-flex",
                    { attrs: { xs12: "", sm4: "", "offset-sm4": "" } },
                    [
                      _c(
                        "v-btn",
                        {
                          attrs: {
                            color: "success",
                            loading: _vm.loading,
                            disabled: _vm.loading,
                            block: "",
                          },
                          on: { click: _vm.store },
                        },
                        [
                          _vm._v(
                            "\n                        " +
                              _vm._s(_vm.trans("messages.update")) +
                              "\n                    "
                          ),
                        ]
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);