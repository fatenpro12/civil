"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_common_visit-request_Create_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/Create.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/Create.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return _typeof(key) === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (_typeof(input) !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (_typeof(res) !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  data: function data() {
    var _ref;
    return _ref = {
      valid: false,
      nullDatetime: null,
      datetime: new Date(),
      datetimeString: '2019-01-01 12:00',
      formattedDatetime: '09/01/2019 12:00',
      enginnering_types: [],
      textFieldProps: {
        appendIcon: 'event'
      },
      dateProps: {
        headerColor: 'red'
      },
      timeProps: {
        useSeconds: false,
        ampmInTitle: false
      },
      type: '',
      project_id: '',
      projects: [],
      loading: false,
      title: '',
      request_type: '',
      status: 'new',
      priority: '',
      customer_id: '',
      statuses: [],
      employees: [],
      request_types: [],
      customers: [],
      priorities: []
    }, _defineProperty(_ref, "request_type", ''), _defineProperty(_ref, "engennering_offices", []), _defineProperty(_ref, "office_id", []), _defineProperty(_ref, "dead_line_date", null), _defineProperty(_ref, "enginnering_type", ''), _defineProperty(_ref, "note", ''), _defineProperty(_ref, "location_id", null), _defineProperty(_ref, "project", null), _ref;
  },
  computed: {
    computedDateFormattedDatefns: function computedDateFormattedDatefns() {
      var self = this;
      return self.dead_line_date;
    }
  },
  created: function created() {
    var self = this;
    self.reset();
    self.project_id = self.$route.params.project_id;
    self.customer_id = self.$route.params.customer_id;
    self.request_type = self.$route.params.request_type;
    self.getRequestTypes();
    self.getCustomerProject();
    self.getEnginneringTypes();
  },
  beforeDestroy: function beforeDestroy() {
    var self = this;
    self.$eventBus.$off('updateCategoryList');
  },
  mounted: function mounted() {
    var self = this;
    self.$eventBus.$on('updateRequestTypeList', function (data) {
      self.request_types = [];
      self.request_types = data;
    });
  },
  methods: {
    saveLocation: function saveLocation(event) {
      this.location_id = event;
    },
    openLocation: function openLocation() {
      this.$refs.locationInfo.openLocationDialog();
    },
    /* getCustomers() {
         const self = this;
         axios
             .get('/estate_owner/customers')
             .then(function (response) {
                 self.customers = response.data;
             })
               .catch((err)=>{
             console.log(err.response.status)
             if (err.response.status === 401) {
         store.dispatch('auth/handleResponse',err.response)
             } 
         });;
     },*/
    getOffices: function getOffices() {
      var self = this;
      console.log(self.project);
      axios.get('/get-offices').then(function (response) {
        self.engennering_offices = response.data.filter(function (val) {
          return val.location_data == self.project.location.province_municipality;
        });
      })["catch"](function (err) {
        console.log(err.response.status);
        if (err.response.status === 401) {
          store.dispatch('auth/handleResponse', err.response);
        }
      });
      ;
    },
    getEnginneringTypes: function getEnginneringTypes() {
      var self = this;
      axios.get('/get-enginnering-types').then(function (response) {
        self.enginnering_types = response.data;
      })["catch"](function (err) {
        console.log(err.response.status);
        if (err.response.status === 401) {
          store.dispatch('auth/handleResponse', err.response);
        }
      });
      ;
    },
    reset: function reset() {
      var self = this;
      self.title = '';
      self.request_type = '';
      self.project_id = '';
      self.status = '';
      self.priority = '';
      self.customer_id = '';
      self.office_id = '';
    },
    getRequestTypes: function getRequestTypes() {
      var self = this;
      axios.get('/get-request-types').then(function (response) {
        self.request_types = response.data;
      })["catch"](function (err) {
        console.log(err.response.status);
        if (err.response.status === 401) {
          store.dispatch('auth/handleResponse', err.response);
        }
      });
      ;
    },
    getCustomerProject: function getCustomerProject() {
      var self = this;
      axios.get('/projects-customer').then(function (response) {
        self.projects = response.data;
      })["catch"](function (err) {
        console.log(err.response.status);
        if (err.response.status === 401) {
          store.dispatch('auth/handleResponse', err.response);
        }
      });
      ;
    },
    createRequestType: function createRequestType() {
      var self = this;
      self.$refs.RequestTypeAdd.create();
    },
    store: function store(val) {
      var self = this;
      var data = _defineProperty({
        sent: val,
        title: self.title,
        request_type: self.request_type,
        project_id: self.project_id,
        priority: self.priority,
        customer_id: self.customer_id,
        office_id: self.office_id,
        dead_line_date: self.dead_line_date,
        location_id: self.location_id,
        note: self.note,
        //
        enginnering_type: self.enginnering_type
      }, "request_type", 'visit_request');
      if (this.$refs.form.validate()) {
        self.loading = true;
        axios.post('request', data).then(function (response) {
          self.loading = false;
          self.$store.commit('showSnackbar', {
            message: response.data.msg,
            color: response.data.success
          });
          if (response.data.success === true) {
            //   self.dialog = false;
            self.$eventBus.$emit('updateTicketsTable');
            self.goBack();
          }
        })["catch"](function (error) {
          console.log(error);
        });
      } else {
        self.$store.commit('showSnackbar', {
          message: 'املئ الحقول الضرورية',
          color: 'error',
          duration: 3000
        });
      }
      //self.reset();
    },
    updateEmployee: function updateEmployee(value) {
      var self = this;
      axios.get('get-customer-project/' + value).then(function (response) {
        self.customer_id = response.data[0].id;
        self.getProject(value);
        self.customers = response.data;
        self.getOffices();
      })["catch"](function (err) {
        console.log(err.response.status);
        if (err.response.status === 401) {
          store.dispatch('auth/handleResponse', err.response);
        }
      });
      ;
    }
  }
});

/***/ }),

/***/ "./resources/js/common/visit-request/Create.vue":
/*!******************************************************!*\
  !*** ./resources/js/common/visit-request/Create.vue ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Create_vue_vue_type_template_id_02737af4___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Create.vue?vue&type=template&id=02737af4& */ "./resources/js/common/visit-request/Create.vue?vue&type=template&id=02737af4&");
/* harmony import */ var _Create_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Create.vue?vue&type=script&lang=js& */ "./resources/js/common/visit-request/Create.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Create_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Create_vue_vue_type_template_id_02737af4___WEBPACK_IMPORTED_MODULE_0__.render,
  _Create_vue_vue_type_template_id_02737af4___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/common/visit-request/Create.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/common/visit-request/Create.vue?vue&type=script&lang=js&":
/*!*******************************************************************************!*\
  !*** ./resources/js/common/visit-request/Create.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Create_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Create.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/Create.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Create_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/common/visit-request/Create.vue?vue&type=template&id=02737af4&":
/*!*************************************************************************************!*\
  !*** ./resources/js/common/visit-request/Create.vue?vue&type=template&id=02737af4& ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Create_vue_vue_type_template_id_02737af4___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Create_vue_vue_type_template_id_02737af4___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Create_vue_vue_type_template_id_02737af4___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Create.vue?vue&type=template&id=02737af4& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/Create.vue?vue&type=template&id=02737af4&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/Create.vue?vue&type=template&id=02737af4&":
/*!****************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/visit-request/Create.vue?vue&type=template&id=02737af4& ***!
  \****************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "v-container",
    { attrs: { row: "", "justify-center": "" } },
    [
      _c(
        "v-card",
        [
          _c(
            "v-form",
            {
              ref: "form",
              attrs: { "lazy-validation": "" },
              model: {
                value: _vm.valid,
                callback: function ($$v) {
                  _vm.valid = $$v
                },
                expression: "valid",
              },
            },
            [
              _c("v-divider"),
              _vm._v(" "),
              _c(
                "v-card-text",
                [
                  _c(
                    "v-container",
                    { attrs: { "grid-list-md": "" } },
                    [
                      _c(
                        "v-layout",
                        { attrs: { row: "", wrap: "" } },
                        [
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm6: "", md6: "" } },
                            [
                              _c("v-autocomplete", {
                                attrs: {
                                  "item-text": "name",
                                  "item-value": "id",
                                  items: _vm.projects,
                                  label: _vm.trans("data.project_name"),
                                  rules: [
                                    function (v) {
                                      return (
                                        !!v ||
                                        _vm.trans("messages.required", {
                                          name: _vm.trans("data.project_name"),
                                        })
                                      )
                                    },
                                  ],
                                  required: "",
                                },
                                on: {
                                  change: function (event) {
                                    return _vm.updateEmployee(event)
                                  },
                                },
                                model: {
                                  value: _vm.project_id,
                                  callback: function ($$v) {
                                    _vm.project_id = $$v
                                  },
                                  expression: "project_id",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm6: "", md6: "" } },
                            [
                              _c("v-autocomplete", {
                                attrs: {
                                  "item-text": "name",
                                  "item-value": "id",
                                  items: _vm.customers,
                                  label: _vm.trans("messages.customer"),
                                  rules: [
                                    function (v) {
                                      return (
                                        !!v ||
                                        _vm.trans("messages.required", {
                                          name: _vm.trans("messages.customer"),
                                        })
                                      )
                                    },
                                  ],
                                  required: "",
                                },
                                model: {
                                  value: _vm.customer_id,
                                  callback: function ($$v) {
                                    _vm.customer_id = $$v
                                  },
                                  expression: "customer_id",
                                },
                              }),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "v-layout",
                        { attrs: { row: "" } },
                        [
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm6: "", md6: "" } },
                            [
                              _c("v-autocomplete", {
                                attrs: {
                                  "item-text": "name",
                                  "item-value": "id",
                                  items: _vm.engennering_offices,
                                  label: _vm.trans(
                                    "data.enginnering_office_name"
                                  ),
                                  rules: [
                                    function (v) {
                                      return (
                                        !!v ||
                                        _vm.trans("messages.required", {
                                          name: _vm.trans(
                                            "data.enginnering_office_name"
                                          ),
                                        })
                                      )
                                    },
                                  ],
                                  required: "",
                                },
                                model: {
                                  value: _vm.office_id,
                                  callback: function ($$v) {
                                    _vm.office_id = $$v
                                  },
                                  expression: "office_id",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm6: "", md6: "" } },
                            [
                              _c("v-datetime-picker", {
                                staticClass: "w-full",
                                attrs: {
                                  label: _vm.trans("data.visit_datetime"),
                                  datetime: _vm.dead_line_date,
                                  okText: _vm.trans("data.ok"),
                                  clearText: _vm.trans("data.clear"),
                                },
                                model: {
                                  value: _vm.dead_line_date,
                                  callback: function ($$v) {
                                    _vm.dead_line_date = $$v
                                  },
                                  expression: "dead_line_date",
                                },
                              }),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "v-layout",
                        { attrs: { row: "" } },
                        [
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm12: "", md12: "" } },
                            [
                              _c("v-autocomplete", {
                                attrs: {
                                  "item-text": "value",
                                  "item-value": "key",
                                  items: _vm.enginnering_types,
                                  label: _vm.trans("data.enginnering_type"),
                                  multiple: "",
                                  "data-vv-name": "enginnering_type",
                                  "data-vv-as": _vm.trans(
                                    "data.enginnering_type"
                                  ),
                                  "error-messages":
                                    _vm.errors.collect("enginnering_type"),
                                  required: "",
                                },
                                model: {
                                  value: _vm.enginnering_type,
                                  callback: function ($$v) {
                                    _vm.enginnering_type = $$v
                                  },
                                  expression: "enginnering_type",
                                },
                              }),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "v-layout",
                        { attrs: { row: "" } },
                        [
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm12: "", md12: "" } },
                            [
                              _c("v-text-field", {
                                attrs: { label: _vm.trans("data.note") },
                                model: {
                                  value: _vm.note,
                                  callback: function ($$v) {
                                    _vm.note = $$v
                                  },
                                  expression: "note",
                                },
                              }),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c("v-layout", { attrs: { row: "" } }),
                      _vm._v(" "),
                      _c("v-layout", { attrs: { row: "", wrap: "" } }),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("v-divider"),
              _vm._v(" "),
              _c(
                "v-layout",
                { attrs: { "justify-center": "" } },
                [
                  _c(
                    "v-card-actions",
                    { staticClass: "flex-wrap" },
                    [
                      _c("v-spacer"),
                      _vm._v(" "),
                      _c(
                        "v-btn",
                        {
                          staticClass: "mr-4",
                          attrs: { color: "error" },
                          on: { click: _vm.reset },
                        },
                        [
                          _vm._v(
                            "\n                        " +
                              _vm._s(_vm.trans("data.reset")) +
                              "\n                    "
                          ),
                        ]
                      ),
                      _vm._v(" "),
                      _c(
                        "v-btn",
                        {
                          staticClass: "mr-4",
                          attrs: {
                            disabled: !_vm.valid || !_vm.checkActive(),
                            color: "success",
                          },
                          on: {
                            click: function ($event) {
                              return _vm.store(1)
                            },
                          },
                        },
                        [
                          _vm._v(
                            "\n                        " +
                              _vm._s(_vm.trans("data.send")) +
                              "\n                    "
                          ),
                        ]
                      ),
                      _vm._v(" "),
                      _c(
                        "v-btn",
                        {
                          staticStyle: { color: "#06706d" },
                          on: {
                            click: function ($event) {
                              return _vm.$router.go(-1)
                            },
                          },
                        },
                        [
                          _vm._v(
                            "\n                        " +
                              _vm._s(_vm.trans("data.back")) +
                              "\n                    "
                          ),
                        ]
                      ),
                      _vm._v(" "),
                      _c(
                        "v-btn",
                        {
                          staticClass: "mr-4",
                          attrs: {
                            disabled: !_vm.valid || !_vm.checkActive(),
                            color: "success",
                          },
                          on: {
                            click: function ($event) {
                              return _vm.store(0)
                            },
                          },
                        },
                        [
                          _vm._v(
                            "\n                        " +
                              _vm._s(_vm.trans("data.draft")) +
                              "\n                    "
                          ),
                        ]
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);