"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_common_projects_components_FinishedProjects_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/components/FinishedProjects.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/components/FinishedProjects.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components_Avatar__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../components/Avatar */ "./resources/js/common/projects/components/Avatar.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  components: {
    avatar: _components_Avatar__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  data: function data() {
    var self = this;
    return {
      total_items: 0,
      progress: 80,
      items: [],
      pagination: {
        totalItems: 0
      },
      headers: [{
        text: self.trans('messages.action'),
        value: false,
        align: 'center',
        sortable: false
      }, {
        text: self.trans('data.id'),
        value: 'id',
        align: 'center',
        sortable: true
      }, {
        text: self.trans('messages.name'),
        value: 'name',
        align: 'center',
        sortable: true
      },
      // {
      //     text: self.trans('messages.company'),
      //     value: 'company',
      //     align: 'left',
      //     sortable: true,
      // },
      {
        text: self.trans('messages.status'),
        value: 'status',
        align: 'center',
        sortable: true
      }, {
        text: self.trans('messages.favorited'),
        value: 'favorited',
        align: 'center',
        sortable: true
      }, {
        text: self.trans('messages.members'),
        value: 'members',
        align: 'center',
        sortable: true
      }, {
        text: self.trans('messages.project_progress'),
        value: 'project_progress',
        align: 'center',
        sortable: true
      }],
      projectData: [],
      statuses: [],
      url: null,
      users: [{
        id: 0,
        name: self.trans('messages.all')
      }],
      customers: [{
        id: 0,
        company: self.trans('messages.all')
      }],
      status: [{
        key: '',
        value: self.trans('messages.all')
      }],
      categories: [{
        id: 0,
        name: self.trans('messages.all')
      }],
      filters: [],
      tabs: 'tab-1',
      statistics: [],
      loading: false
    };
  },
  created: function created() {
    var self = this;
    self.url = '/projects';
    self.getDataFromApi();
    self.getFilterData();
    self.$eventBus.$on('updateProjectTable', function (data) {
      self.url = '/projects';
      self.projectData = [];
      self.getDataFromApi();
    });
  },
  beforeDestroy: function beforeDestroy() {
    var self = this;
    self.$eventBus.$off('updateProjectTable');
  },
  methods: {
    /* create() {
         const self = this;
         self.$refs.projectAdd.create();
     },*/
    getDataFromApi: function getDataFromApi() {
      var self = this;
      self.loading = true;
      var params = {};
      params['status'] = 'completed';
      axios.get(self.url, {
        params: params
      }).then(function (response) {
        self.loading = false;
        self.projectData = response.data.projects; //_.concat(self.projectData, response.data.projects.data);
        self.statuses = response.data.status;
        self.url = _.get(response, 'data.projects.next_page_url', null);
        self.getStatistics();
      })["catch"](function (error) {
        console.log(error);
      });
    },
    /* edit(id) {
         const self = this;
         self.$refs.projectEdit.edit(id);
     },*/
    deleteProject: function deleteProject(id) {
      var self = this;
      self.$store.commit('showDialog', {
        type: 'confirm',
        icon: 'warning',
        title: self.trans('messages.are_you_sure'),
        message: self.trans('messages.you_cant_restore_it'),
        okCb: function okCb() {
          axios["delete"]('/projects/' + id).then(function (response) {
            self.$store.commit('showSnackbar', {
              message: response.data.msg,
              color: response.data.success
            });
            if (response.data.success === true) {
              self.url = '/projects';
              self.projectData = [];
              self.getDataFromApi();
            }
          })["catch"](function (err) {
            console.log(err.response.status);
            if (err.response.status === 401) {
              store.dispatch('auth/handleResponse', err.response);
            }
          });
        },
        cancelCb: function cancelCb() {
          console.log('CANCEL');
        }
      });
    },
    markAsFavorite: function markAsFavorite(project) {
      var self = this;
      axios.get('/projects/mark-favorite', {
        params: {
          id: project.id,
          favorite: project.is_favorited
        }
      }).then(function (response) {
        self.$store.commit('showSnackbar', {
          message: response.data.msg,
          color: response.data.success
        });
        project.is_favorited = response.data.favorite;
      })["catch"](function (error) {
        console.log(error);
      });
    },
    updateStatus: function updateStatus(status, project) {
      var self = this;
      axios.get('/projects/update-status', {
        params: {
          id: project.id,
          status: status
        }
      }).then(function (response) {
        self.$store.commit('showSnackbar', {
          message: response.data.msg,
          color: response.data.success
        });
        if (response.data.success === true) {
          project.status = status;
          self.getStatistics();
        }
      })["catch"](function (error) {
        console.log(error);
      });
    },
    toggleFavorite: function toggleFavorite(project) {
      if (project.is_favorited) {
        return 'yellow darken-2';
      } else {
        return 'grey lighten-1';
      }
    },
    getFilterData: function getFilterData() {
      var self = this;
      if (self.$can('superadmin')) {
        axios.get('/projects/create').then(function (response) {
          self.users = _.concat(self.users, response.data.users);
          self.customers = _.concat(self.customers, response.data.customers);
          self.status = _.concat(self.status, response.data.status);
          self.categories = _.concat(self.categories, response.data.categories);
        })["catch"](function (error) {
          console.log(error);
        });
      }
    },
    /*getColor(status) {
               if (status == 'not_started') {
                   return 'grey';
               } else if (status == 'in_progress') {
                   return 'blue';
               } else if (status == 'on_hold') {
                   return 'red';
               } else if (status == 'completed') {
                   return 'green';
               } else if (status == 'cancelled') {
                   return 'orange';
               }
           },*/
    getprogress: function getprogress(status) {
      if (status == 'not_started') {
        return this.projectProgress(5, 1);
      } else if (status == 'in_progress') {
        return this.projectProgress(5, 2);
      } else if (status == 'on_hold') {
        return this.projectProgress(5, 3);
      } else if (status == 'completed') {
        return this.projectProgress(5, 5);
      } else if (status == 'cancelled') {
        return this.projectProgress(5, 0);
      }
    },
    getEnginneringTypes: function getEnginneringTypes() {
      var self = this;
      axios.get('/get-enginnering-types').then(function (response) {
        self.enginnering_types = response.data;
        //alert(JSON.stringify(self.employee_data))
        //alert(JSON.stringify(response.data.find(x=>x.key==self.employee_data.enginnering_type)))
        self.enginnering_type = response.data.find(function (x) {
          return x.key == employee_data.enginnering_type;
        }) != undefined ? response.data.find(function (x) {
          return x.key == employee_data.enginnering_type;
        }).value : '';
      })["catch"](function (err) {
        console.log(err.response.status);
        if (err.response.status === 401) {
          store.dispatch('auth/handleResponse', err.response);
        }
      });
      ;
    },
    edit: function edit(id) {
      var self = this;
      self.$router.push({
        name: 'edit-project',
        params: {
          id: id
        }
      });

      // self.$refs.projectEdit.edit(id);
    },
    view: function view(id) {
      var self = this;
      self.$router.push({
        name: 'view_project',
        params: {
          id: id
        }
      });

      // self.$refs.projectEdit.edit(id);
    },
    filterChanged: function filterChanged() {
      var self = this;
      self.url = '/projects';
      self.projectData = [];
      self.getDataFromApi();
    },
    getStatistics: function getStatistics() {
      var self = this;
      if (self.$can('superadmin')) {
        axios.get('/projects-statistics').then(function (response) {
          self.statistics = response.data;
        })["catch"](function (error) {
          console.log(error);
        });
      }
    }
  }
});

/***/ }),

/***/ "./resources/js/common/projects/components/FinishedProjects.vue":
/*!**********************************************************************!*\
  !*** ./resources/js/common/projects/components/FinishedProjects.vue ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _FinishedProjects_vue_vue_type_template_id_7f6e24f4___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./FinishedProjects.vue?vue&type=template&id=7f6e24f4& */ "./resources/js/common/projects/components/FinishedProjects.vue?vue&type=template&id=7f6e24f4&");
/* harmony import */ var _FinishedProjects_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./FinishedProjects.vue?vue&type=script&lang=js& */ "./resources/js/common/projects/components/FinishedProjects.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _FinishedProjects_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _FinishedProjects_vue_vue_type_template_id_7f6e24f4___WEBPACK_IMPORTED_MODULE_0__.render,
  _FinishedProjects_vue_vue_type_template_id_7f6e24f4___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/common/projects/components/FinishedProjects.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/common/projects/components/FinishedProjects.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************!*\
  !*** ./resources/js/common/projects/components/FinishedProjects.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FinishedProjects_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./FinishedProjects.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/components/FinishedProjects.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FinishedProjects_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/common/projects/components/FinishedProjects.vue?vue&type=template&id=7f6e24f4&":
/*!*****************************************************************************************************!*\
  !*** ./resources/js/common/projects/components/FinishedProjects.vue?vue&type=template&id=7f6e24f4& ***!
  \*****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FinishedProjects_vue_vue_type_template_id_7f6e24f4___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FinishedProjects_vue_vue_type_template_id_7f6e24f4___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FinishedProjects_vue_vue_type_template_id_7f6e24f4___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./FinishedProjects.vue?vue&type=template&id=7f6e24f4& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/components/FinishedProjects.vue?vue&type=template&id=7f6e24f4&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/components/FinishedProjects.vue?vue&type=template&id=7f6e24f4&":
/*!********************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/components/FinishedProjects.vue?vue&type=template&id=7f6e24f4& ***!
  \********************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "v-container",
    { attrs: { "grid-list-md": "" } },
    [
      _c(
        "v-layout",
        { attrs: { row: "", "pt-3": "" } },
        [
          _c(
            "v-flex",
            { attrs: { xs12: "", sm12: "" } },
            [
              _c(
                "v-card",
                { staticClass: "elevation-3 w-full" },
                [
                  _c(
                    "v-card-title",
                    { attrs: { "primary-title": "", xs8: "", sm8: "" } },
                    [
                      _c("div", [
                        _c("div", { staticClass: "headline" }, [
                          _vm._v(
                            "\n                                   " +
                              _vm._s(_vm.trans("data.finished_projects")) +
                              "\n                               "
                          ),
                        ]),
                      ]),
                    ]
                  ),
                  _vm._v(" "),
                  _c("v-divider"),
                  _vm._v(" "),
                  _c(
                    "v-card-text",
                    [
                      _c(
                        "v-container",
                        { attrs: { "grid-list-md": "" } },
                        [
                          _c(
                            "v-layout",
                            { attrs: { wrap: "" } },
                            [
                              _c(
                                "v-flex",
                                { attrs: { xs12: "", sm12: "", md12: "" } },
                                [
                                  _c("v-data-table", {
                                    staticClass: "elevation-3 w-full",
                                    attrs: {
                                      headers: _vm.headers,
                                      pagination: _vm.pagination,
                                      "total-items": _vm.total_items,
                                      loading: _vm.loading,
                                      items: _vm.projectData,
                                    },
                                    on: {
                                      "update:pagination": function ($event) {
                                        _vm.pagination = $event
                                      },
                                    },
                                    scopedSlots: _vm._u([
                                      {
                                        key: "items",
                                        fn: function (props) {
                                          return [
                                            _c("td", [
                                              _c(
                                                "div",
                                                { attrs: { align: "center" } },
                                                [
                                                  _c(
                                                    "v-menu",
                                                    [
                                                      _c(
                                                        "v-btn",
                                                        {
                                                          attrs: {
                                                            slot: "activator",
                                                            icon: "",
                                                          },
                                                          slot: "activator",
                                                        },
                                                        [
                                                          _c("v-icon", [
                                                            _vm._v("more_vert"),
                                                          ]),
                                                        ],
                                                        1
                                                      ),
                                                      _vm._v(" "),
                                                      _c(
                                                        "v-list",
                                                        [
                                                          _vm.$can(
                                                            "tickets.create"
                                                          )
                                                            ? _c(
                                                                "v-list-tile",
                                                                {
                                                                  attrs: {
                                                                    disabled:
                                                                      !_vm.checkActive(),
                                                                  },
                                                                  on: {
                                                                    click:
                                                                      function (
                                                                        $event
                                                                      ) {
                                                                        return _vm.$router.push(
                                                                          {
                                                                            name: "create_visit_request_list",
                                                                            params:
                                                                              {
                                                                                project_id:
                                                                                  props
                                                                                    .item
                                                                                    .id,
                                                                                customer_id:
                                                                                  props
                                                                                    .item
                                                                                    .customer_id,
                                                                                request_type:
                                                                                  "visit_request",
                                                                              },
                                                                          }
                                                                        )
                                                                      },
                                                                  },
                                                                },
                                                                [
                                                                  _c(
                                                                    "v-list-tile-title",
                                                                    [
                                                                      _vm._v(
                                                                        "\n                                                                       " +
                                                                          _vm._s(
                                                                            _vm.trans(
                                                                              "data.create_a_visit_request"
                                                                            )
                                                                          ) +
                                                                          "\n                                                                   "
                                                                      ),
                                                                    ]
                                                                  ),
                                                                ],
                                                                1
                                                              )
                                                            : _vm._e(),
                                                          _vm._v(" "),
                                                          _vm.$can(
                                                            "project.delete"
                                                          )
                                                            ? _c(
                                                                "v-list-tile",
                                                                {
                                                                  attrs: {
                                                                    disabled:
                                                                      !_vm.checkActive(),
                                                                  },
                                                                  on: {
                                                                    click:
                                                                      function (
                                                                        $event
                                                                      ) {
                                                                        return _vm.deleteProject(
                                                                          props
                                                                            .item
                                                                            .id
                                                                        )
                                                                      },
                                                                  },
                                                                },
                                                                [
                                                                  _c(
                                                                    "v-list-tile-title",
                                                                    [
                                                                      _vm._v(
                                                                        "\n                                                                       " +
                                                                          _vm._s(
                                                                            _vm.trans(
                                                                              "messages.delete"
                                                                            )
                                                                          ) +
                                                                          "\n                                                                   "
                                                                      ),
                                                                    ]
                                                                  ),
                                                                ],
                                                                1
                                                              )
                                                            : _vm._e(),
                                                          _vm._v(" "),
                                                          _vm.$can(
                                                            "project.edit"
                                                          )
                                                            ? _c(
                                                                "v-list-tile",
                                                                {
                                                                  attrs: {
                                                                    disabled:
                                                                      !_vm.checkActive(),
                                                                  },
                                                                  on: {
                                                                    click:
                                                                      function (
                                                                        $event
                                                                      ) {
                                                                        return _vm.edit(
                                                                          props
                                                                            .item
                                                                            .id
                                                                        )
                                                                      },
                                                                  },
                                                                },
                                                                [
                                                                  _c(
                                                                    "v-list-tile-title",
                                                                    [
                                                                      _vm._v(
                                                                        "\n                                                                       " +
                                                                          _vm._s(
                                                                            _vm.trans(
                                                                              "messages.edit"
                                                                            )
                                                                          ) +
                                                                          "\n                                                                   "
                                                                      ),
                                                                    ]
                                                                  ),
                                                                ],
                                                                1
                                                              )
                                                            : _vm._e(),
                                                          _vm._v(" "),
                                                          _vm.$can(
                                                            "project.list"
                                                          )
                                                            ? _c(
                                                                "v-list-tile",
                                                                {
                                                                  on: {
                                                                    click:
                                                                      function (
                                                                        $event
                                                                      ) {
                                                                        return _vm.view(
                                                                          props
                                                                            .item
                                                                            .id
                                                                        )
                                                                      },
                                                                  },
                                                                },
                                                                [
                                                                  _c(
                                                                    "v-list-tile-title",
                                                                    [
                                                                      _vm._v(
                                                                        "\n                                                                       " +
                                                                          _vm._s(
                                                                            _vm.trans(
                                                                              "data.view"
                                                                            )
                                                                          ) +
                                                                          "\n                                                                   "
                                                                      ),
                                                                    ]
                                                                  ),
                                                                ],
                                                                1
                                                              )
                                                            : _vm._e(),
                                                          _vm._v(" "),
                                                          _c(
                                                            "v-list-tile",
                                                            {
                                                              attrs: {
                                                                disabled:
                                                                  !_vm.checkActive(),
                                                              },
                                                              on: {
                                                                click:
                                                                  function (
                                                                    $event
                                                                  ) {
                                                                    return _vm.$router.push(
                                                                      {
                                                                        name: "add_report",
                                                                        params:
                                                                          {
                                                                            project:
                                                                              props.item,
                                                                          },
                                                                      }
                                                                    )
                                                                  },
                                                              },
                                                            },
                                                            [
                                                              _c(
                                                                "v-list-tile-title",
                                                                [
                                                                  _vm._v(
                                                                    "\n                                                                       " +
                                                                      _vm._s(
                                                                        _vm.trans(
                                                                          "data.create_a_report"
                                                                        )
                                                                      ) +
                                                                      "\n                                                                   "
                                                                  ),
                                                                ]
                                                              ),
                                                            ],
                                                            1
                                                          ),
                                                          _vm._v(" "),
                                                          _c(
                                                            "v-list-tile",
                                                            [
                                                              _c(
                                                                "v-list-tile-title",
                                                                [
                                                                  _vm._v(
                                                                    "\n                                                                       " +
                                                                      _vm._s(
                                                                        _vm.trans(
                                                                          "data.reports_review"
                                                                        )
                                                                      ) +
                                                                      "\n                                                                   "
                                                                  ),
                                                                ]
                                                              ),
                                                            ],
                                                            1
                                                          ),
                                                          _vm._v(" "),
                                                          _c(
                                                            "v-list-tile",
                                                            {
                                                              attrs: {
                                                                disabled:
                                                                  !_vm.checkActive(),
                                                              },
                                                              on: {
                                                                click:
                                                                  function (
                                                                    $event
                                                                  ) {
                                                                    return _vm.$router.push(
                                                                      {
                                                                        name: "project.schedule",
                                                                        params:
                                                                          {
                                                                            project_id:
                                                                              props
                                                                                .item
                                                                                .id,
                                                                          },
                                                                      }
                                                                    )
                                                                  },
                                                              },
                                                            },
                                                            [
                                                              _c(
                                                                "v-list-tile-title",
                                                                [
                                                                  _vm._v(
                                                                    "\n                                                                       " +
                                                                      _vm._s(
                                                                        _vm.trans(
                                                                          "data.schedule"
                                                                        )
                                                                      ) +
                                                                      "\n                                                                   "
                                                                  ),
                                                                ]
                                                              ),
                                                            ],
                                                            1
                                                          ),
                                                          _vm._v(" "),
                                                          _c(
                                                            "v-list-tile",
                                                            {
                                                              attrs: {
                                                                disabled:
                                                                  !_vm.checkActive(),
                                                              },
                                                              on: {
                                                                click:
                                                                  function (
                                                                    $event
                                                                  ) {
                                                                    return _vm.$router.push(
                                                                      {
                                                                        name: "project.attachments",
                                                                        params:
                                                                          {
                                                                            project_id:
                                                                              props
                                                                                .item
                                                                                .id,
                                                                          },
                                                                      }
                                                                    )
                                                                  },
                                                              },
                                                            },
                                                            [
                                                              _c(
                                                                "v-list-tile-title",
                                                                [
                                                                  _vm._v(
                                                                    "\n                                                                       " +
                                                                      _vm._s(
                                                                        _vm.trans(
                                                                          "data.attachments"
                                                                        )
                                                                      ) +
                                                                      "\n                                                                   "
                                                                  ),
                                                                ]
                                                              ),
                                                            ],
                                                            1
                                                          ),
                                                          _vm._v(" "),
                                                          _c(
                                                            "v-list-tile",
                                                            {
                                                              attrs: {
                                                                disabled:
                                                                  !_vm.checkActive(),
                                                              },
                                                              on: {
                                                                click:
                                                                  function (
                                                                    $event
                                                                  ) {
                                                                    return _vm.$router.push(
                                                                      {}
                                                                    )
                                                                  },
                                                              },
                                                            },
                                                            [
                                                              _c(
                                                                "v-list-tile-title",
                                                                [
                                                                  _vm._v(
                                                                    "\n                                                                       " +
                                                                      _vm._s(
                                                                        _vm.trans(
                                                                          "messages.invoices"
                                                                        )
                                                                      ) +
                                                                      "\n                                                                   "
                                                                  ),
                                                                ]
                                                              ),
                                                            ],
                                                            1
                                                          ),
                                                        ],
                                                        1
                                                      ),
                                                    ],
                                                    1
                                                  ),
                                                ],
                                                1
                                              ),
                                            ]),
                                            _vm._v(" "),
                                            _c("td", [
                                              _c(
                                                "div",
                                                { attrs: { align: "center" } },
                                                [
                                                  _vm._v(
                                                    "\n                                                       " +
                                                      _vm._s(props.item.id) +
                                                      "\n                                                   "
                                                  ),
                                                ]
                                              ),
                                            ]),
                                            _vm._v(" "),
                                            _c("td", [
                                              _c(
                                                "div",
                                                { attrs: { align: "center" } },
                                                [
                                                  _vm._v(
                                                    "\n                                                       " +
                                                      _vm._s(props.item.name) +
                                                      "\n                                                   "
                                                  ),
                                                ]
                                              ),
                                            ]),
                                            _vm._v(" "),
                                            _c("td", [
                                              _c(
                                                "div",
                                                { attrs: { align: "center" } },
                                                [
                                                  _c(
                                                    "v-chip",
                                                    {
                                                      staticClass: "ma-2",
                                                      attrs: {
                                                        color: _vm.getColor(
                                                          props.item.status
                                                        ),
                                                        "text-color": "white",
                                                      },
                                                    },
                                                    [
                                                      _vm._v(
                                                        "\n                                                         " +
                                                          _vm._s(
                                                            _vm.trans(
                                                              "messages." +
                                                                props.item
                                                                  .status
                                                            )
                                                          ) +
                                                          "\n                                                       "
                                                      ),
                                                    ]
                                                  ),
                                                ],
                                                1
                                              ),
                                            ]),
                                            _vm._v(" "),
                                            _c("td", [
                                              _c(
                                                "div",
                                                { attrs: { align: "center" } },
                                                [
                                                  _c(
                                                    "v-btn",
                                                    {
                                                      attrs: { icon: "" },
                                                      on: {
                                                        click: function (
                                                          $event
                                                        ) {
                                                          return _vm.markAsFavorite(
                                                            props.item
                                                          )
                                                        },
                                                      },
                                                    },
                                                    [
                                                      _c(
                                                        "v-icon",
                                                        {
                                                          attrs: {
                                                            color:
                                                              _vm.toggleFavorite(
                                                                props.item
                                                              ),
                                                          },
                                                        },
                                                        [
                                                          _vm._v(
                                                            "\n                                                               star\n                                                           "
                                                          ),
                                                        ]
                                                      ),
                                                    ],
                                                    1
                                                  ),
                                                ],
                                                1
                                              ),
                                            ]),
                                            _vm._v(" "),
                                            _c("td", [
                                              _c(
                                                "div",
                                                { attrs: { align: "center" } },
                                                [
                                                  _c("avatar", {
                                                    staticClass: "mr-2",
                                                    attrs: {
                                                      members:
                                                        props.item.members,
                                                    },
                                                  }),
                                                ],
                                                1
                                              ),
                                            ]),
                                            _vm._v(" "),
                                            _c(
                                              "td",
                                              [
                                                _c("v-progress-linear", {
                                                  attrs: {
                                                    striped: "",
                                                    value: _vm.getprogress(
                                                      props.item.status
                                                    ),
                                                  },
                                                }),
                                              ],
                                              1
                                            ),
                                          ]
                                        },
                                      },
                                    ]),
                                  }),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c("br"),
      _vm._v(" "),
      _c(
        "div",
        { attrs: { align: "center" } },
        [
          _c(
            "v-btn",
            {
              staticStyle: { "background-color": "#06706d", color: "white" },
              on: {
                click: function ($event) {
                  return _vm.$router.go(-1)
                },
              },
            },
            [
              _vm._v(
                "\n                   " +
                  _vm._s(_vm.trans("messages.back")) +
                  "\n               "
              ),
            ]
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c("br"),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);