"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_common_projects_invoices_Add_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/invoices/Add.vue?vue&type=script&lang=js&":
/*!************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/invoices/Add.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _admin_popover_Popover__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../admin/popover/Popover */ "./resources/js/admin/popover/Popover.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  components: {
    Popover: _admin_popover_Popover__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  data: function data() {
    return {
      invoice: [],
      projectId: null,
      customers: [],
      invoice_schemes: [],
      project: {},
      transaction_date: '',
      due_date: '',
      discountType: [],
      rows: [{
        short_description: '',
        long_description: '',
        display_long_description: false,
        rate: 0,
        quantity: 0,
        unit: '',
        tax: 0,
        total: 0
      }],
      total_tax: 0.0,
      invoice_total: 0.0,
      sub_total: 0.0,
      mailToCustomer: false,
      displayContact: false,
      contacts: [],
      projectList: [],
      customer_id: null,
      loading: false,
      invoice_types: [],
      invoice_scheme_id: null
    };
  },
  mounted: function mounted() {
    var self = this;
    self.projectId = Number(self.$route.params.id);
    self.getProjects();
    self.getInvoicedataFromApi(self.projectId);
  },
  methods: {
    getInvoicedataFromApi: function getInvoicedataFromApi(projectId) {
      var self = this;
      axios.get('/invoices/create', {
        params: {
          project_id: projectId
        }
      }).then(function (response) {
        self.customers = response.data.customers;
        self.discountType = response.data.discount_type;
        self.invoice_types = response.data.invoice_type;
        self.project = response.data.project;
        self.invoice_schemes = response.data.invoice_schemes;
        self.customer_id = response.data.project ? response.data.project.customer_id : null;
        self.invoice_scheme_id = response.data.default_invoice_scheme;
      })["catch"](function (error) {
        console.log(error);
      });
    },
    addRow: function addRow() {
      var self = this;
      var row = {
        short_description: '',
        display_long_description: false,
        rate: 0,
        quantity: 0,
        unit: '',
        tax: 0,
        total: 0
      };
      self.rows.unshift(row);
    },
    removeRow: function removeRow(index) {
      var self = this;
      if (index != 0) {
        self.rows.splice(index, 1);
      }
      self.updateSubTotal();
      self.calculateTotaltax();
      self.updateInvoiceTotal();
    },
    updateRowTotal: function updateRowTotal(index) {
      var self = this;
      var rows = self.rows;
      var qty = self.rows[index].quantity;
      var rate = self.rows[index].rate;
      var total = _.multiply(qty, rate);
      self.rows[index].total = _.floor(total, 2);
      self.updateSubTotal();
      self.calculateTotaltax();
    },
    updateSubTotal: function updateSubTotal() {
      var self = this;
      var rows = self.rows;
      var total = 0.0;
      _.forEach(rows, function (row) {
        total = _.add(row.total, total);
      });
      self.sub_total = _.floor(total, 2);
    },
    calculateTotaltax: function calculateTotaltax() {
      var self = this;
      var rows = self.rows;
      var tax = 0.0;
      var total_tax = self.total_tax;
      var row_total_inc_tax = 0.0;
      _.forEach(rows, function (row) {
        tax = _.divide(row.tax, 100);
        row_total_inc_tax = _.multiply(tax, row.total);
        total_tax = _.add(row_total_inc_tax, total_tax);
      });
      self.total_tax = _.floor(total_tax, 2);
      self.updateInvoiceTotal();
    },
    updateInvoiceTotal: function updateInvoiceTotal() {
      var self = this;
      var discount_type = self.invoice.discount_type;
      var discount_amount = self.invoice.discount_amount;
      var total_tax = self.total_tax;
      var sub_total = self.sub_total;
      self.invoice_total = sub_total + total_tax;

      //Apply discount
      if (discount_type == 'fixed') {
        self.invoice_total = self.invoice_total - discount_amount;
      }
      if (discount_type == 'percentage') {
        self.invoice_total = self.invoice_total - discount_amount / 100 * self.invoice_total;
      }
      self.invoice_total = _.floor(self.invoice_total, 2);
    },
    store: function (_store) {
      function store() {
        return _store.apply(this, arguments);
      }
      store.toString = function () {
        return _store.toString();
      };
      return store;
    }(function () {
      var self = this;
      var invoice = {
        project_id: self.projectId,
        title: self.invoice.title,
        customer_id: self.customer_id,
        contact_id: self.invoice.contact_id ? self.invoice.contact_id : null,
        transaction_date: self.transaction_date,
        due_date: self.due_date,
        discount_type: self.invoice.discount_type,
        discount_amount: self.invoice.discount_amount,
        total: self.invoice_total,
        terms: self.invoice.terms,
        notes: self.invoice.notes,
        status: self.invoice.status,
        invoice_lines: self.rows,
        do_mail: self.mailToCustomer,
        invoice_scheme_id: self.invoice_scheme_id
      };
      self.$validator.validateAll().then(function (result) {
        if (result == true) {
          self.loading = true;
          axios.post('/invoices', invoice).then(function (response) {
            self.$validator.reset();
            self.invoice = [];
            self.project = [];
            self.discountType = self.discountType;
            self.rows = [{
              short_description: '',
              long_description: '',
              display_long_description: false,
              rate: 0,
              quantity: 0,
              unit: '',
              tax: 0,
              total: 0
            }];
            self.transaction_date = '';
            self.due_date = '';
            self.total_tax = 0.0;
            self.invoice_total = 0.0;
            self.sub_total = 0.0;
            self.mailToCustomer = false;
            self.displayContact = false;
            self.loading = false;
            self.$store.commit('showSnackbar', {
              message: response.data.msg,
              color: response.data.success
            });
            if (response.data.success === true) {
              self.goBack();
            }
          })["catch"](function (err) {
            console.log(err.response.status);
            if (err.response.status === 401) {
              store.dispatch('auth/handleResponse', err.response);
            }
          });
        }
      });
    }),
    getContact: function getContact() {
      var self = this;
      var mailToCustomer = self.mailToCustomer;
      var customer_id = self.customer_id;
      if (mailToCustomer == true) {
        axios.get('/admin/customers/' + customer_id + '/contacts').then(function (response) {
          self.contacts = response.data;
          self.displayContact = true;
        })["catch"](function (error) {
          console.log(error);
        });
      } else if (mailToCustomer == false) {
        self.invoice.contact_id = null, self.displayContact = false;
      }
    },
    getProjects: function getProjects() {
      var self = this;
      axios.get('projects/projects-list').then(function (response) {
        self.projectList = response.data;
      })["catch"](function (error) {
        console.log(error);
      });
    },
    getCustomerId: function getCustomerId() {
      var self = this;
      axios.get('projects/' + self.projectId + '/customer').then(function (response) {
        self.customer_id = response.data.customer_id;
        self.getContact();
      })["catch"](function (error) {
        console.log(error);
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/invoices/Add.vue?vue&type=style&index=0&id=2b3291b2&scoped=true&lang=css&":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/invoices/Add.vue?vue&type=style&index=0&id=2b3291b2&scoped=true&lang=css& ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "\n.back[data-v-2b3291b2] {\n    --tw-text-opacity: 1;\n    color: rgb(22 163 74 / var(--tw-text-opacity))\n}\r\n", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/invoices/Add.vue?vue&type=style&index=0&id=2b3291b2&scoped=true&lang=css&":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/invoices/Add.vue?vue&type=style&index=0&id=2b3291b2&scoped=true&lang=css& ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Add_vue_vue_type_style_index_0_id_2b3291b2_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Add.vue?vue&type=style&index=0&id=2b3291b2&scoped=true&lang=css& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/invoices/Add.vue?vue&type=style&index=0&id=2b3291b2&scoped=true&lang=css&");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Add_vue_vue_type_style_index_0_id_2b3291b2_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Add_vue_vue_type_style_index_0_id_2b3291b2_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./resources/js/common/projects/invoices/Add.vue":
/*!*******************************************************!*\
  !*** ./resources/js/common/projects/invoices/Add.vue ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Add_vue_vue_type_template_id_2b3291b2_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Add.vue?vue&type=template&id=2b3291b2&scoped=true& */ "./resources/js/common/projects/invoices/Add.vue?vue&type=template&id=2b3291b2&scoped=true&");
/* harmony import */ var _Add_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Add.vue?vue&type=script&lang=js& */ "./resources/js/common/projects/invoices/Add.vue?vue&type=script&lang=js&");
/* harmony import */ var _Add_vue_vue_type_style_index_0_id_2b3291b2_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Add.vue?vue&type=style&index=0&id=2b3291b2&scoped=true&lang=css& */ "./resources/js/common/projects/invoices/Add.vue?vue&type=style&index=0&id=2b3291b2&scoped=true&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Add_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Add_vue_vue_type_template_id_2b3291b2_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render,
  _Add_vue_vue_type_template_id_2b3291b2_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  "2b3291b2",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/common/projects/invoices/Add.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/common/projects/invoices/Add.vue?vue&type=script&lang=js&":
/*!********************************************************************************!*\
  !*** ./resources/js/common/projects/invoices/Add.vue?vue&type=script&lang=js& ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Add_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Add.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/invoices/Add.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Add_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/common/projects/invoices/Add.vue?vue&type=style&index=0&id=2b3291b2&scoped=true&lang=css&":
/*!****************************************************************************************************************!*\
  !*** ./resources/js/common/projects/invoices/Add.vue?vue&type=style&index=0&id=2b3291b2&scoped=true&lang=css& ***!
  \****************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_10_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_Add_vue_vue_type_style_index_0_id_2b3291b2_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/style-loader/dist/cjs.js!../../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Add.vue?vue&type=style&index=0&id=2b3291b2&scoped=true&lang=css& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-10[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/invoices/Add.vue?vue&type=style&index=0&id=2b3291b2&scoped=true&lang=css&");


/***/ }),

/***/ "./resources/js/common/projects/invoices/Add.vue?vue&type=template&id=2b3291b2&scoped=true&":
/*!**************************************************************************************************!*\
  !*** ./resources/js/common/projects/invoices/Add.vue?vue&type=template&id=2b3291b2&scoped=true& ***!
  \**************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Add_vue_vue_type_template_id_2b3291b2_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Add_vue_vue_type_template_id_2b3291b2_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Add_vue_vue_type_template_id_2b3291b2_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Add.vue?vue&type=template&id=2b3291b2&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/invoices/Add.vue?vue&type=template&id=2b3291b2&scoped=true&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/invoices/Add.vue?vue&type=template&id=2b3291b2&scoped=true&":
/*!*****************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/common/projects/invoices/Add.vue?vue&type=template&id=2b3291b2&scoped=true& ***!
  \*****************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "component-wrap" },
    [
      _c(
        "v-card",
        { staticClass: "elevation-3" },
        [
          _c(
            "v-card-title",
            [
              _c("v-icon", [_vm._v("receipt")]),
              _vm._v(" "),
              _c("span", { staticClass: "headline" }, [
                _vm._v(
                  " " + _vm._s(_vm.trans("messages.create_invoice")) + " "
                ),
              ]),
            ],
            1
          ),
          _vm._v(" "),
          _c("v-divider"),
          _vm._v(" "),
          _c(
            "v-card-text",
            [
              _c(
                "v-container",
                { attrs: { "grid-list-md": "" } },
                [
                  _c(
                    "v-layout",
                    { attrs: { wrap: "" } },
                    [
                      _c(
                        "v-flex",
                        { attrs: { xs12: "", md4: "" } },
                        [
                          _c("v-text-field", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "required",
                                expression: "'required'",
                              },
                            ],
                            attrs: {
                              label: _vm.trans("messages.title"),
                              "data-vv-name": "title",
                              "data-vv-as": _vm.trans("messages.title"),
                              "error-messages": _vm.errors.collect("title"),
                              required: "",
                            },
                            model: {
                              value: _vm.invoice.title,
                              callback: function ($$v) {
                                _vm.$set(_vm.invoice, "title", $$v)
                              },
                              expression: "invoice.title",
                            },
                          }),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "v-flex",
                        { attrs: { xs12: "", md4: "" } },
                        [
                          _c("v-autocomplete", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "required",
                                expression: "'required'",
                              },
                            ],
                            attrs: {
                              "item-text": "name",
                              "item-value": "id",
                              items: _vm.projectList,
                              label: _vm.trans("messages.project"),
                              "data-vv-name": "project",
                              "data-vv-as": _vm.trans("messages.project"),
                              "error-messages": _vm.errors.collect("project"),
                              required: "",
                            },
                            on: { change: _vm.getCustomerId },
                            model: {
                              value: _vm.projectId,
                              callback: function ($$v) {
                                _vm.projectId = $$v
                              },
                              expression: "projectId",
                            },
                          }),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "v-flex",
                        { attrs: { xs12: "", md4: "" } },
                        [
                          _c("v-autocomplete", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "required",
                                expression: "'required'",
                              },
                            ],
                            attrs: {
                              "item-text": "name",
                              "item-value": "id",
                              items: _vm.customers,
                              label: _vm.trans("messages.customer"),
                              "data-vv-name": "customer",
                              "data-vv-as": _vm.trans("messages.customer"),
                              "error-messages": _vm.errors.collect("customer"),
                              required: "",
                            },
                            on: { change: _vm.getContact },
                            model: {
                              value: _vm.customer_id,
                              callback: function ($$v) {
                                _vm.customer_id = $$v
                              },
                              expression: "customer_id",
                            },
                          }),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c("v-flex", { attrs: { xs12: "", md4: "" } }, [
                        _c(
                          "div",
                          { staticClass: "v-input v-text-field theme--light" },
                          [
                            _c("div", { staticClass: "v-input__control" }, [
                              _c("div", { staticClass: "v-input__slot" }, [
                                _c(
                                  "div",
                                  { staticClass: "v-text-field__slot" },
                                  [
                                    _c(
                                      "label",
                                      {
                                        staticClass:
                                          "v-label v-label--active theme--light flat_picker_label",
                                        attrs: { "aria-hidden": "true" },
                                      },
                                      [
                                        _vm._v(
                                          "\n                                            " +
                                            _vm._s(_vm.trans("messages.date")) +
                                            "\n                                        "
                                        ),
                                      ]
                                    ),
                                    _vm._v(" "),
                                    _c("flat-pickr", {
                                      directives: [
                                        {
                                          name: "validate",
                                          rawName: "v-validate",
                                          value: "required",
                                          expression: "'required'",
                                        },
                                      ],
                                      attrs: {
                                        name: "date",
                                        required: "",
                                        config: _vm.flatPickerDate(),
                                        "data-vv-as":
                                          _vm.trans("messages.date"),
                                      },
                                      model: {
                                        value: _vm.transaction_date,
                                        callback: function ($$v) {
                                          _vm.transaction_date = $$v
                                        },
                                        expression: "transaction_date",
                                      },
                                    }),
                                  ],
                                  1
                                ),
                              ]),
                              _vm._v(" "),
                              _c(
                                "div",
                                {
                                  staticClass:
                                    "v-messages theme--light error--text",
                                },
                                [
                                  _vm._v(
                                    "\n                                    " +
                                      _vm._s(_vm.errors.first("date")) +
                                      "\n                                "
                                  ),
                                ]
                              ),
                            ]),
                          ]
                        ),
                      ]),
                      _vm._v(" "),
                      _c("v-flex", { attrs: { xs12: "", md4: "" } }, [
                        _c(
                          "div",
                          { staticClass: "v-input v-text-field theme--light" },
                          [
                            _c("div", { staticClass: "v-input__control" }, [
                              _c("div", { staticClass: "v-input__slot" }, [
                                _c(
                                  "div",
                                  { staticClass: "v-text-field__slot" },
                                  [
                                    _c(
                                      "label",
                                      {
                                        staticClass:
                                          "v-label v-label--active theme--light flat_picker_label",
                                        attrs: { "aria-hidden": "true" },
                                      },
                                      [
                                        _vm._v(
                                          "\n                                            " +
                                            _vm._s(
                                              _vm.trans("messages.due_date")
                                            ) +
                                            "\n                                        "
                                        ),
                                      ]
                                    ),
                                    _vm._v(" "),
                                    _c("flat-pickr", {
                                      attrs: {
                                        name: "due_date",
                                        config: _vm.flatPickerDate(),
                                      },
                                      model: {
                                        value: _vm.due_date,
                                        callback: function ($$v) {
                                          _vm.due_date = $$v
                                        },
                                        expression: "due_date",
                                      },
                                    }),
                                  ],
                                  1
                                ),
                              ]),
                            ]),
                          ]
                        ),
                      ]),
                      _vm._v(" "),
                      _c(
                        "v-flex",
                        { attrs: { xs12: "", md4: "" } },
                        [
                          _c("v-autocomplete", {
                            directives: [
                              {
                                name: "validate",
                                rawName: "v-validate",
                                value: "required",
                                expression: "'required'",
                              },
                            ],
                            attrs: {
                              items: _vm.invoice_types,
                              label: _vm.trans("messages.type"),
                              "data-vv-name": "type",
                              "data-vv-as": _vm.trans("messages.type"),
                              "error-messages": _vm.errors.collect("type"),
                              required: "",
                            },
                            model: {
                              value: _vm.invoice.status,
                              callback: function ($$v) {
                                _vm.$set(_vm.invoice, "status", $$v)
                              },
                              expression: "invoice.status",
                            },
                          }),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "v-flex",
                        { attrs: { xs12: "", md4: "" } },
                        [
                          _c(
                            "v-autocomplete",
                            {
                              directives: [
                                {
                                  name: "validate",
                                  rawName: "v-validate",
                                  value: "required",
                                  expression: "'required'",
                                },
                              ],
                              attrs: {
                                "item-text": "name",
                                "item-value": "id",
                                items: _vm.invoice_schemes,
                                label: _vm.trans("messages.invoice_scheme"),
                                "data-vv-name": "invoice_scheme",
                                "data-vv-as": _vm.trans(
                                  "messages.invoice_scheme"
                                ),
                                "error-messages":
                                  _vm.errors.collect("invoice_scheme"),
                                required: "",
                              },
                              model: {
                                value: _vm.invoice_scheme_id,
                                callback: function ($$v) {
                                  _vm.invoice_scheme_id = $$v
                                },
                                expression: "invoice_scheme_id",
                              },
                            },
                            [
                              _c("Popover", {
                                attrs: {
                                  slot: "append",
                                  helptext: _vm.trans(
                                    "messages.invoice_scheme_tooltip"
                                  ),
                                },
                                slot: "append",
                              }),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c("br"),
      _vm._v(" "),
      _c(
        "v-card",
        { staticClass: "elevation-3" },
        [
          _c(
            "v-card-text",
            [
              _c(
                "v-flex",
                { attrs: { xs12: "", md12: "" } },
                [
                  _c(
                    "v-container",
                    { attrs: { "grid-list-md": "", "text-xs-center": "" } },
                    [
                      _c(
                        "v-layout",
                        { attrs: { row: "", wrap: "" } },
                        [
                          _c("v-flex", { attrs: { md3: "" } }, [
                            _c("h4", [
                              _vm._v(_vm._s(_vm.trans("messages.task"))),
                            ]),
                          ]),
                          _vm._v(" "),
                          _c("v-flex", { attrs: { md2: "" } }, [
                            _c("h4", [
                              _vm._v(_vm._s(_vm.trans("messages.rate"))),
                            ]),
                          ]),
                          _vm._v(" "),
                          _c("v-flex", { attrs: { md2: "" } }, [
                            _c("h4", [
                              _vm._v(_vm._s(_vm.trans("messages.quantity"))),
                            ]),
                          ]),
                          _vm._v(" "),
                          _c("v-flex", { attrs: { md1: "" } }, [
                            _c("h4", [
                              _vm._v(_vm._s(_vm.trans("messages.unit"))),
                            ]),
                          ]),
                          _vm._v(" "),
                          _c("v-flex", { attrs: { md2: "" } }, [
                            _c("h4", [
                              _vm._v(
                                _vm._s(_vm.trans("messages.tax")) + " (%)"
                              ),
                            ]),
                          ]),
                          _vm._v(" "),
                          _c("v-flex", { attrs: { md1: "" } }, [
                            _c("h4", [
                              _vm._v(_vm._s(_vm.trans("messages.total"))),
                            ]),
                          ]),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { md1: "" } },
                            [
                              _c(
                                "v-tooltip",
                                { attrs: { top: "" } },
                                [
                                  _c(
                                    "template",
                                    { slot: "activator" },
                                    [
                                      _c(
                                        "v-btn",
                                        {
                                          attrs: { small: "", flat: "" },
                                          on: { click: _vm.addRow },
                                        },
                                        [
                                          _vm._v(
                                            "\n                                        " +
                                              _vm._s(
                                                _vm.trans("messages.add_a_row")
                                              ) +
                                              "\n                                        "
                                          ),
                                          _c(
                                            "v-icon",
                                            { attrs: { small: "" } },
                                            [_vm._v("add_circle_outline")]
                                          ),
                                        ],
                                        1
                                      ),
                                    ],
                                    1
                                  ),
                                  _vm._v(" "),
                                  _c("span", [
                                    _vm._v(
                                      _vm._s(_vm.trans("messages.add_a_row"))
                                    ),
                                  ]),
                                ],
                                2
                              ),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "v-layout",
                        { attrs: { row: "", wrap: "" } },
                        [
                          _vm._l(_vm.rows, function (row, index) {
                            return [
                              _c(
                                "v-flex",
                                { attrs: { md3: "" } },
                                [
                                  _c(
                                    "v-text-field",
                                    {
                                      directives: [
                                        {
                                          name: "validate",
                                          rawName: "v-validate",
                                          value: "required",
                                          expression: "'required'",
                                        },
                                      ],
                                      attrs: {
                                        label: _vm.trans("messages.task"),
                                        "data-vv-name": "task",
                                        "data-vv-as":
                                          _vm.trans("messages.task"),
                                        "error-messages":
                                          _vm.errors.collect("task"),
                                        required: "",
                                      },
                                      model: {
                                        value: row.short_description,
                                        callback: function ($$v) {
                                          _vm.$set(
                                            row,
                                            "short_description",
                                            $$v
                                          )
                                        },
                                        expression: "row.short_description",
                                      },
                                    },
                                    [
                                      _c(
                                        "v-tooltip",
                                        {
                                          attrs: { slot: "append", top: "" },
                                          slot: "append",
                                        },
                                        [
                                          [
                                            [
                                              _c(
                                                "v-icon",
                                                {
                                                  attrs: {
                                                    slot: "activator",
                                                    small: "",
                                                  },
                                                  on: {
                                                    click: function ($event) {
                                                      row.display_long_description =
                                                        !row.display_long_description
                                                    },
                                                  },
                                                  slot: "activator",
                                                },
                                                [
                                                  _vm._v(
                                                    "\n                                                    info\n                                                "
                                                  ),
                                                ]
                                              ),
                                            ],
                                          ],
                                          _vm._v(" "),
                                          _c("span", [
                                            _vm._v(
                                              _vm._s(
                                                _vm.trans(
                                                  "messages.toggle_description"
                                                )
                                              )
                                            ),
                                          ]),
                                        ],
                                        2
                                      ),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              ),
                              _vm._v(" "),
                              _c(
                                "v-flex",
                                { attrs: { md2: "" } },
                                [
                                  _c("v-text-field", {
                                    directives: [
                                      {
                                        name: "validate",
                                        rawName: "v-validate",
                                        value: "required",
                                        expression: "'required'",
                                      },
                                    ],
                                    attrs: {
                                      type: "number",
                                      label: _vm.trans("messages.rate"),
                                      "data-vv-name": "rate",
                                      "data-vv-as": _vm.trans("messages.rate"),
                                      "error-messages":
                                        _vm.errors.collect("rate"),
                                      required: "",
                                    },
                                    on: {
                                      change: function ($event) {
                                        return _vm.updateRowTotal(index)
                                      },
                                    },
                                    model: {
                                      value: row.rate,
                                      callback: function ($$v) {
                                        _vm.$set(row, "rate", $$v)
                                      },
                                      expression: "row.rate",
                                    },
                                  }),
                                ],
                                1
                              ),
                              _vm._v(" "),
                              _c(
                                "v-flex",
                                { attrs: { md2: "" } },
                                [
                                  _c("v-text-field", {
                                    directives: [
                                      {
                                        name: "validate",
                                        rawName: "v-validate",
                                        value: "required",
                                        expression: "'required'",
                                      },
                                    ],
                                    attrs: {
                                      type: "number",
                                      label: _vm.trans("messages.quantity"),
                                      "data-vv-name": "quantity",
                                      "data-vv-as":
                                        _vm.trans("messages.quantity"),
                                      "error-messages":
                                        _vm.errors.collect("quantity"),
                                      required: "",
                                    },
                                    on: {
                                      change: function ($event) {
                                        return _vm.updateRowTotal(index)
                                      },
                                    },
                                    model: {
                                      value: row.quantity,
                                      callback: function ($$v) {
                                        _vm.$set(row, "quantity", $$v)
                                      },
                                      expression: "row.quantity",
                                    },
                                  }),
                                ],
                                1
                              ),
                              _vm._v(" "),
                              _c(
                                "v-flex",
                                { attrs: { md1: "" } },
                                [
                                  _c("v-text-field", {
                                    directives: [
                                      {
                                        name: "validate",
                                        rawName: "v-validate",
                                        value: "required",
                                        expression: "'required'",
                                      },
                                    ],
                                    attrs: {
                                      label: _vm.trans("messages.unit"),
                                      "data-vv-name": "unit",
                                      "data-vv-as": _vm.trans("messages.unit"),
                                      "error-messages":
                                        _vm.errors.collect("unit"),
                                      required: "",
                                    },
                                    model: {
                                      value: row.unit,
                                      callback: function ($$v) {
                                        _vm.$set(row, "unit", $$v)
                                      },
                                      expression: "row.unit",
                                    },
                                  }),
                                ],
                                1
                              ),
                              _vm._v(" "),
                              _c(
                                "v-flex",
                                { attrs: { md2: "" } },
                                [
                                  _c("v-text-field", {
                                    directives: [
                                      {
                                        name: "validate",
                                        rawName: "v-validate",
                                        value: "required",
                                        expression: "'required'",
                                      },
                                    ],
                                    attrs: {
                                      type: "number",
                                      label: _vm.trans("messages.tax"),
                                      "data-vv-name": "tax",
                                      "data-vv-as": _vm.trans("messages.tax"),
                                      "error-messages":
                                        _vm.errors.collect("tax"),
                                      required: "",
                                    },
                                    on: {
                                      change: function ($event) {
                                        return _vm.calculateTotaltax(index)
                                      },
                                    },
                                    model: {
                                      value: row.tax,
                                      callback: function ($$v) {
                                        _vm.$set(row, "tax", $$v)
                                      },
                                      expression: "row.tax",
                                    },
                                  }),
                                ],
                                1
                              ),
                              _vm._v(" "),
                              _c(
                                "v-flex",
                                { attrs: { md1: "" } },
                                [
                                  _c("v-text-field", {
                                    directives: [
                                      {
                                        name: "validate",
                                        rawName: "v-validate",
                                        value: "required",
                                        expression: "'required'",
                                      },
                                    ],
                                    attrs: {
                                      readonly: "",
                                      label: _vm.trans("messages.total"),
                                      "data-vv-name": "total",
                                      "data-vv-as": _vm.trans("messages.total"),
                                      "error-messages":
                                        _vm.errors.collect("total"),
                                      required: "",
                                    },
                                    model: {
                                      value: row.total,
                                      callback: function ($$v) {
                                        _vm.$set(row, "total", $$v)
                                      },
                                      expression: "row.total",
                                    },
                                  }),
                                ],
                                1
                              ),
                              _vm._v(" "),
                              index != 0
                                ? _c(
                                    "v-flex",
                                    { attrs: { md1: "" } },
                                    [
                                      _c(
                                        "v-tooltip",
                                        { attrs: { top: "" } },
                                        [
                                          _c(
                                            "template",
                                            { slot: "activator" },
                                            [
                                              _c(
                                                "v-btn",
                                                {
                                                  attrs: {
                                                    small: "",
                                                    flat: "",
                                                    icon: "",
                                                  },
                                                  on: {
                                                    click: function ($event) {
                                                      return _vm.removeRow(
                                                        index
                                                      )
                                                    },
                                                  },
                                                },
                                                [
                                                  _c(
                                                    "v-icon",
                                                    { attrs: { small: "" } },
                                                    [_vm._v("clear")]
                                                  ),
                                                ],
                                                1
                                              ),
                                            ],
                                            1
                                          ),
                                          _vm._v(" "),
                                          _c("span", [
                                            _vm._v(
                                              _vm._s(
                                                _vm.trans(
                                                  "messages.remove_a_row"
                                                )
                                              )
                                            ),
                                          ]),
                                        ],
                                        2
                                      ),
                                    ],
                                    1
                                  )
                                : _vm._e(),
                              _vm._v(" "),
                              _c(
                                "v-flex",
                                {
                                  directives: [
                                    {
                                      name: "show",
                                      rawName: "v-show",
                                      value: row.display_long_description,
                                      expression:
                                        "row.display_long_description",
                                    },
                                  ],
                                  attrs: { md11: "" },
                                },
                                [
                                  _c("v-textarea", {
                                    attrs: {
                                      rows: "1",
                                      label: _vm.trans("messages.description"),
                                    },
                                    model: {
                                      value: row.long_description,
                                      callback: function ($$v) {
                                        _vm.$set(row, "long_description", $$v)
                                      },
                                      expression: "row.long_description",
                                    },
                                  }),
                                ],
                                1
                              ),
                              _vm._v(" "),
                              _c("v-flex", {
                                directives: [
                                  {
                                    name: "show",
                                    rawName: "v-show",
                                    value: row.display_long_description,
                                    expression: "row.display_long_description",
                                  },
                                ],
                                attrs: { md1: "" },
                              }),
                            ]
                          }),
                        ],
                        2
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c("br"),
      _vm._v(" "),
      _c(
        "v-card",
        { staticClass: "elevation-3" },
        [
          _c(
            "v-card-text",
            [
              _c(
                "v-container",
                { attrs: { "grid-list-md": "" } },
                [
                  _c(
                    "v-layout",
                    { attrs: { row: "", wrap: "" } },
                    [
                      _c("v-flex", { attrs: { xs12: "", md4: "" } }, [
                        _c("strong", [
                          _vm._v(
                            _vm._s(_vm.trans("messages.sub_total")) + " :"
                          ),
                        ]),
                        _vm._v(" "),
                        _c("span", [_vm._v(_vm._s(_vm.sub_total))]),
                      ]),
                      _vm._v(" "),
                      _c("v-flex", { attrs: { xs12: "", md4: "" } }, [
                        _c("strong", [
                          _vm._v(_vm._s(_vm.trans("messages.tax")) + " :"),
                        ]),
                        _vm._v(" "),
                        _c("span", [_vm._v(_vm._s(_vm.total_tax))]),
                      ]),
                      _vm._v(" "),
                      _c("v-flex", { attrs: { xs12: "", md4: "" } }, [
                        _c("strong", [
                          _vm._v(_vm._s(_vm.trans("messages.total")) + " :"),
                        ]),
                        _vm._v(" "),
                        _c("span", [_vm._v(_vm._s(_vm.invoice_total))]),
                        _vm._v(" "),
                        _c("input", {
                          directives: [
                            {
                              name: "model",
                              rawName: "v-model",
                              value: _vm.invoice_total,
                              expression: "invoice_total",
                            },
                          ],
                          attrs: { type: "hidden", name: "invoice_total" },
                          domProps: { value: _vm.invoice_total },
                          on: {
                            input: function ($event) {
                              if ($event.target.composing) {
                                return
                              }
                              _vm.invoice_total = $event.target.value
                            },
                          },
                        }),
                      ]),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "v-layout",
                    { attrs: { wrap: "" } },
                    [
                      _c(
                        "v-flex",
                        { attrs: { xs12: "", md6: "" } },
                        [
                          _c("v-select", {
                            attrs: {
                              "item-text": "value",
                              "item-value": "key",
                              items: _vm.discountType,
                              label: _vm.trans("messages.discount_type"),
                            },
                            model: {
                              value: _vm.invoice.discount_type,
                              callback: function ($$v) {
                                _vm.$set(_vm.invoice, "discount_type", $$v)
                              },
                              expression: "invoice.discount_type",
                            },
                          }),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "v-flex",
                        { attrs: { xs12: "", md6: "" } },
                        [
                          _c("v-text-field", {
                            attrs: {
                              type: "number",
                              label: _vm.trans("messages.discount_amount"),
                            },
                            on: { change: _vm.updateInvoiceTotal },
                            model: {
                              value: _vm.invoice.discount_amount,
                              callback: function ($$v) {
                                _vm.$set(_vm.invoice, "discount_amount", $$v)
                              },
                              expression: "invoice.discount_amount",
                            },
                          }),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "v-layout",
                    { attrs: { row: "", wrap: "" } },
                    [
                      _c(
                        "v-flex",
                        { attrs: { xs12: "", md12: "" } },
                        [
                          _c(
                            "v-textarea",
                            {
                              attrs: {
                                rows: "3",
                                label: _vm.trans("messages.terms"),
                              },
                              model: {
                                value: _vm.invoice.terms,
                                callback: function ($$v) {
                                  _vm.$set(_vm.invoice, "terms", $$v)
                                },
                                expression: "invoice.terms",
                              },
                            },
                            [
                              _c("Popover", {
                                attrs: {
                                  slot: "append",
                                  helptext: _vm.trans(
                                    "messages.will_be_displayed_in_invoice"
                                  ),
                                },
                                slot: "append",
                              }),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "v-layout",
                    { attrs: { row: "", wrap: "" } },
                    [
                      _c(
                        "v-flex",
                        { attrs: { xs12: "", md12: "" } },
                        [
                          _c("v-textarea", {
                            attrs: {
                              rows: "3",
                              label: _vm.trans("messages.notes"),
                            },
                            model: {
                              value: _vm.invoice.notes,
                              callback: function ($$v) {
                                _vm.$set(_vm.invoice, "notes", $$v)
                              },
                              expression: "invoice.notes",
                            },
                          }),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "v-layout",
                    { attrs: { "row-wrap": "" } },
                    [
                      _c(
                        "v-flex",
                        { attrs: { xs12: "", md4: "" } },
                        [
                          _c("v-checkbox", {
                            attrs: {
                              label: _vm.trans(
                                "messages.send_email_to_customer"
                              ),
                            },
                            on: { change: _vm.getContact },
                            model: {
                              value: _vm.mailToCustomer,
                              callback: function ($$v) {
                                _vm.mailToCustomer = $$v
                              },
                              expression: "mailToCustomer",
                            },
                          }),
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "v-flex",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.displayContact,
                              expression: "displayContact",
                            },
                          ],
                          attrs: { xs12: "", md4: "" },
                        },
                        [
                          _c("v-select", {
                            attrs: {
                              items: _vm.contacts,
                              "item-text": "name",
                              "item-value": "id",
                              label: _vm.trans("messages.contact"),
                            },
                            model: {
                              value: _vm.invoice.contact_id,
                              callback: function ($$v) {
                                _vm.$set(_vm.invoice, "contact_id", $$v)
                              },
                              expression: "invoice.contact_id",
                            },
                          }),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "v-card-actions",
            [
              _c("v-spacer"),
              _vm._v(" "),
              _c(
                "v-btn",
                {
                  staticClass: "mx-1 back",
                  on: {
                    click: function ($event) {
                      return _vm.$router.go(-1)
                    },
                  },
                },
                [
                  _vm._v(
                    "\n                    " +
                      _vm._s(_vm.trans("messages.back")) +
                      "\n                "
                  ),
                ]
              ),
              _vm._v(" "),
              _c(
                "v-btn",
                {
                  attrs: {
                    color: "success",
                    loading: _vm.loading,
                    disabled: _vm.loading,
                  },
                  on: { click: _vm.store },
                },
                [
                  _vm._v(
                    "\n                " +
                      _vm._s(_vm.trans("messages.save")) +
                      "\n            "
                  ),
                ]
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);