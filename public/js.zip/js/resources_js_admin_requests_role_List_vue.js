"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_admin_requests_role_List_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/requests_role/List.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/requests_role/List.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  components: {},
  data: function data() {
    var self = this;
    return {
      total_items: 0,
      loading: true,
      roles: [],
      pagination: {
        totalItems: 0,
        sortBy: 'created_at',
        descending: true
      },
      items: [],
      headers: [{
        text: self.trans('messages.action'),
        value: false,
        align: 'center',
        sortable: false
      }, {
        text: self.trans('data.id'),
        value: 'id',
        align: 'center',
        sortable: true
      }, {
        text: self.trans('data.requester'),
        value: 'requester',
        align: 'center',
        sortable: true
      }, {
        text: self.trans('data.role_name'),
        value: 'role_name',
        align: 'center',
        sortable: false
      }, {
        text: self.trans('messages.status'),
        value: 'status',
        align: 'center',
        sortable: true
      }, {
        text: self.trans('data.document'),
        value: 'document',
        align: 'center',
        sortable: false
      }, {
        text: self.trans('data.note'),
        value: 'note',
        align: 'center',
        sortable: false
      }, {
        text: self.trans('data.created_at'),
        value: 'created_at',
        align: 'center',
        sortable: true
      }]
    };
  },
  watch: {
    pagination: {
      handler: function handler() {
        var self = this;
        self.getRequestsRole();
      }
    }
  },
  created: function created() {
    var self = this;
    self.getRequestsRole();
    self.loadRoles();
  },
  methods: {
    getRequestsRole: function getRequestsRole() {
      var self = this;
      self.loading = true;
      var _self$pagination = self.pagination,
        sortBy = _self$pagination.sortBy,
        descending = _self$pagination.descending,
        page = _self$pagination.page,
        rowsPerPage = _self$pagination.rowsPerPage;
      axios.get('/requests-role', {
        params: {
          sort_by: sortBy,
          descending: descending,
          page: page,
          rowsPerPage: rowsPerPage
        }
      }).then(function (response) {
        console.log(response.data.data);
        //  if(!response.data.error_code){
        self.total_items = response.data.total;
        self.items = response.data.data;
        self.loading = false;
        //  }
        // else{

        // }
      })["catch"](function (err) {
        console.log(err.response.status);
        if (err.response.status === 401) {
          store.dispatch('auth/handleResponse', err.response);
        }
      });
    },
    loadRoles: function loadRoles() {
      var self = this;
      axios
      //.get('/admin/users/create')
      .get('/create-user').then(function (response) {
        self.roles = response.data.roles;
      })["catch"](function (err) {
        console.log(err.response.status);
        if (err.response.status === 401) {
          store.dispatch('auth/handleResponse', err.response);
        }
      });
    },
    getType: function getType(role_id) {
      var self = this;
      return self.roles.find(function (o) {
        return o.id == role_id;
      }) != null ? self.roles.find(function (o) {
        return o.id == role_id;
      }).name : null;
    },
    deleteRequest: function deleteRequest(id) {
      var self = this;
      self.$store.commit('showDialog', {
        type: 'confirm',
        icon: 'warning',
        title: self.trans('messages.are_you_sure'),
        message: self.trans('messages.you_cant_restore_it'),
        okCb: function okCb() {
          axios["delete"]('requests-role/' + id, {
            // params: { project_id: self.projectId },
          }).then(function (response) {
            if (!response.data.error_code) {
              self.$store.commit('showSnackbar', {
                message: self.trans('messages.deleted_successfully'),
                color: 'green'
              });
              self.getRequestsRole();
            } else {
              self.$store.commit('showSnackbar', {
                message: response.data.error_description,
                color: 'red'
              });
            }
          });
        },
        cancelCb: function cancelCb() {
          console.log('CANCEL');
        }
      });
    },
    acceptRequest: function acceptRequest(id) {
      var self = this;
      self.$store.commit('showDialog', {
        type: 'confirm',
        icon: 'warning',
        title: self.trans('messages.are_you_sure'),
        message: self.trans('messages.you_cant_restore_it'),
        okCb: function okCb() {
          axios.get('accept-requests-role/' + id, {
            // params: { project_id: self.projectId },
          }).then(function (response) {
            if (!response.data.error_code) {
              self.$store.commit('showSnackbar', {
                message: self.trans('messages.accepted_successfully'),
                color: 'green'
              });
              self.getRequestsRole();
            } else {
              self.$store.commit('showSnackbar', {
                message: response.data.error_description,
                color: 'red'
              });
            }
          });
        },
        cancelCb: function cancelCb() {
          console.log('CANCEL');
        }
      });
    },
    rejectRequest: function rejectRequest(id) {
      var self = this;
      self.$store.commit('showDialog', {
        type: 'confirm',
        icon: 'warning',
        title: self.trans('messages.are_you_sure'),
        message: self.trans('messages.you_cant_restore_it'),
        okCb: function okCb() {
          axios.get('reject-requests-role/' + id, {
            // params: { project_id: self.projectId },
          }).then(function (response) {
            if (!response.data.error_code) {
              self.$store.commit('showSnackbar', {
                message: self.trans('messages.rejected_successfully'),
                color: 'green'
              });
              self.getRequestsRole();
            } else {
              self.$store.commit('showSnackbar', {
                message: response.data.error_description,
                color: 'red'
              });
            }
          });
        },
        cancelCb: function cancelCb() {
          console.log('CANCEL');
        }
      });
    }
  }
});

/***/ }),

/***/ "./resources/js/admin/requests_role/List.vue":
/*!***************************************************!*\
  !*** ./resources/js/admin/requests_role/List.vue ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _List_vue_vue_type_template_id_7c98eb3a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./List.vue?vue&type=template&id=7c98eb3a& */ "./resources/js/admin/requests_role/List.vue?vue&type=template&id=7c98eb3a&");
/* harmony import */ var _List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./List.vue?vue&type=script&lang=js& */ "./resources/js/admin/requests_role/List.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _List_vue_vue_type_template_id_7c98eb3a___WEBPACK_IMPORTED_MODULE_0__.render,
  _List_vue_vue_type_template_id_7c98eb3a___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/admin/requests_role/List.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/admin/requests_role/List.vue?vue&type=script&lang=js&":
/*!****************************************************************************!*\
  !*** ./resources/js/admin/requests_role/List.vue?vue&type=script&lang=js& ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./List.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/requests_role/List.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/admin/requests_role/List.vue?vue&type=template&id=7c98eb3a&":
/*!**********************************************************************************!*\
  !*** ./resources/js/admin/requests_role/List.vue?vue&type=template&id=7c98eb3a& ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_7c98eb3a___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_7c98eb3a___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_7c98eb3a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./List.vue?vue&type=template&id=7c98eb3a& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/requests_role/List.vue?vue&type=template&id=7c98eb3a&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/requests_role/List.vue?vue&type=template&id=7c98eb3a&":
/*!*************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/requests_role/List.vue?vue&type=template&id=7c98eb3a& ***!
  \*************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "v-container",
    { attrs: { "grid-list-md": "" } },
    [
      _c(
        "v-card",
        [
          _c("v-card-title", [
            _c("div", [
              _c("div", { staticClass: "headline" }, [
                _vm._v(
                  "\n                    " +
                    _vm._s(_vm.trans("data.request_role")) +
                    "\n                "
                ),
              ]),
            ]),
          ]),
          _vm._v(" "),
          _c("v-divider"),
          _vm._v(" "),
          _c("v-data-table", {
            staticClass: "elevation-3",
            attrs: {
              headers: _vm.headers,
              pagination: _vm.pagination,
              "total-items": _vm.total_items,
              loading: _vm.loading,
              items: _vm.items,
            },
            on: {
              "update:pagination": function ($event) {
                _vm.pagination = $event
              },
            },
            scopedSlots: _vm._u([
              {
                key: "items",
                fn: function (props) {
                  return [
                    _c("td", [
                      _c(
                        "div",
                        {
                          staticStyle: {
                            display: "flex",
                            "justify-content": "center",
                          },
                          attrs: { align: "center" },
                        },
                        [
                          _c(
                            "div",
                            [
                              props.item.status !== "accepted"
                                ? _c(
                                    "v-btn",
                                    {
                                      attrs: {
                                        color: "primary",
                                        small: "",
                                        fab: "",
                                        dark: "",
                                      },
                                      on: {
                                        click: function ($event) {
                                          return _vm.acceptRequest(
                                            props.item.id
                                          )
                                        },
                                      },
                                    },
                                    [
                                      _c(
                                        "v-icon",
                                        { attrs: { color: "white" } },
                                        [_vm._v("check")]
                                      ),
                                    ],
                                    1
                                  )
                                : _vm._e(),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "div",
                            [
                              props.item.status !== "rejected"
                                ? _c(
                                    "v-btn",
                                    {
                                      attrs: {
                                        color: "primary",
                                        small: "",
                                        fab: "",
                                        dark: "",
                                      },
                                      on: {
                                        click: function ($event) {
                                          return _vm.rejectRequest(
                                            props.item.id
                                          )
                                        },
                                      },
                                    },
                                    [
                                      _c(
                                        "v-icon",
                                        { attrs: { color: "white" } },
                                        [_vm._v("close")]
                                      ),
                                    ],
                                    1
                                  )
                                : _vm._e(),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-btn",
                            {
                              attrs: {
                                color: "error",
                                small: "",
                                fab: "",
                                dark: "",
                              },
                              on: {
                                click: function ($event) {
                                  return _vm.deleteRequest(props.item.id)
                                },
                              },
                            },
                            [
                              _c("v-icon", { attrs: { color: "white" } }, [
                                _vm._v("delete"),
                              ]),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ]),
                    _vm._v(" "),
                    _c("td", [
                      _c("div", { attrs: { align: "center" } }, [
                        _vm._v(
                          "\n                        " +
                            _vm._s(props.item.id) +
                            "\n                    "
                        ),
                      ]),
                    ]),
                    _vm._v(" "),
                    _c(
                      "td",
                      { staticClass: "mx-auto flex justify-center" },
                      [
                        _vm.$can("employee.view")
                          ? _c(
                              "v-btn",
                              {
                                attrs: { flat: "", align: "center" },
                                on: {
                                  click: function ($event) {
                                    return _vm.$router.push({
                                      name: "users.view",
                                      params: { id: props.item.user.id },
                                    })
                                  },
                                },
                              },
                              [
                                _vm._v(
                                  "\n                        " +
                                    _vm._s(props.item.user.name) +
                                    "\n                    "
                                ),
                              ]
                            )
                          : _vm._e(),
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c("td", [
                      _c("div", { attrs: { align: "center" } }, [
                        _vm._v(
                          "\n                        " +
                            _vm._s(_vm.getType(props.item.role_id)) +
                            "\n                    "
                        ),
                      ]),
                    ]),
                    _vm._v(" "),
                    _c("td", [
                      _c("div", { attrs: { align: "center" } }, [
                        _vm._v(
                          "\n                        " +
                            _vm._s(props.item.status) +
                            "\n                    "
                        ),
                      ]),
                    ]),
                    _vm._v(" "),
                    _c("td", [
                      props.item.document && props.item.document.media[0]
                        ? _c("div", { attrs: { align: "center" } }, [
                            _c(
                              "a",
                              {
                                attrs: {
                                  href: props.item.document.media[0].full_url,
                                  download: "",
                                },
                              },
                              [_c("v-icon", [_vm._v("download")])],
                              1
                            ),
                          ])
                        : _vm._e(),
                    ]),
                    _vm._v(" "),
                    _c("td", [
                      _c("div", { attrs: { align: "center" } }, [
                        _vm._v(
                          "\n                        " +
                            _vm._s(props.item.note) +
                            "\n                    "
                        ),
                      ]),
                    ]),
                    _vm._v(" "),
                    _c("td", [
                      _c("div", { attrs: { align: "center" } }, [
                        _vm._v(
                          "\n                        " +
                            _vm._s(
                              _vm._f("formatDate")(props.item.created_at)
                            ) +
                            "\n                    "
                        ),
                      ]),
                    ]),
                  ]
                },
              },
            ]),
          }),
        ],
        1
      ),
      _vm._v(" "),
      _c("br"),
      _vm._v(" "),
      _c(
        "div",
        { attrs: { align: "center" } },
        [
          _c(
            "v-btn",
            {
              staticStyle: { "background-color": "#06706d", color: "white" },
              on: {
                click: function ($event) {
                  return _vm.$router.go(-1)
                },
              },
            },
            [
              _vm._v(
                "\n            " +
                  _vm._s(_vm.trans("messages.back")) +
                  "\n        "
              ),
            ]
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);