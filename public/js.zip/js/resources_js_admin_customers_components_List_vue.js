"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_admin_customers_components_List_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/customers/components/Edit.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/customers/components/Edit.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components_currency_Add__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../components/currency/Add */ "./resources/js/admin/customers/components/currency/Add.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  components: {
    CurrencyAdd: _components_currency_Add__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  data: function data() {
    return {
      dialog: false,
      customerData: [],
      currencies: [],
      loading: false
    };
  },
  created: function created() {
    var _this = this;
    this.$eventBus.$on('updateCurrenciesList', function (data) {
      _this.getCurrenciesListFromApi();
      _this.customerData.currency_id = data.id;
    });
  },
  beforeDestroy: function beforeDestroy() {
    this.$eventBus.$off('updateCurrenciesList');
  },
  methods: {
    edit: function edit(data) {
      var self = this;
      self.$validator.reset();
      axios.get('/admin/customers/' + data + '/edit').then(function (response) {
        self.customerData = response.data;
        self.getCurrenciesListFromApi();
        self.dialog = true;
      })["catch"](function (error) {
        console.log(error);
      });
    },
    update: function update(id) {
      var self = this;
      self.$validator.validateAll().then(function (result) {
        if (result == true) {
          self.loading = true;
          axios.put('/admin/customers/' + id, self.customerData).then(function (response) {
            self.loading = false;
            self.$validator.reset();
            self.customerData = [];
            self.dialog = false;
            self.$store.commit('showSnackbar', {
              message: response.data.msg,
              color: response.data.success
            });
            if (response.data.success === true) {
              self.$eventBus.$emit('updateCustomerTable');
            }
          })["catch"](function (err) {
            console.log(err.response.status);
            if (err.response.status === 401) {
              store.dispatch('auth/handleResponse', err.response);
            }
          });
        }
      });
    },
    addCurrency: function addCurrency() {
      this.$refs.currencyAdd.create();
    },
    getCurrenciesListFromApi: function getCurrenciesListFromApi() {
      var self = this;
      axios.get('/admin/currencies').then(function (response) {
        self.currencies = response.data;
      })["catch"](function (error) {
        console.log(error);
      });
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/customers/components/List.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/customers/components/List.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components_Edit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../components/Edit */ "./resources/js/admin/customers/components/Edit.vue");
/* harmony import */ var _components_Add__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../components/Add */ "./resources/js/admin/customers/components/Add.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  components: {
    CustomerFormEdit: _components_Edit__WEBPACK_IMPORTED_MODULE_0__["default"],
    CustomerFormAdd: _components_Add__WEBPACK_IMPORTED_MODULE_1__["default"]
  },
  data: function data() {
    var self = this;
    return {
      total_items: 0,
      loading: true,
      pagination: {
        totalItems: 0
      },
      headers: [{
        text: self.trans('messages.action'),
        value: false,
        align: 'left',
        sortable: false
      }, {
        text: self.trans('data.id'),
        value: 'id',
        align: 'left',
        sortable: true
      }, {
        text: self.trans('messages.company'),
        value: 'company',
        align: 'left',
        sortable: true
      }, {
        text: self.trans('messages.tax_number'),
        value: 'tax_number',
        align: 'left',
        sortable: true
      }, {
        text: self.trans('messages.mobile'),
        value: 'mobile',
        align: 'left',
        sortable: true
      }, {
        text: self.trans('messages.website'),
        value: 'website',
        align: 'left',
        sortable: true
      }],
      items: [],
      search: ''
    };
  },
  watch: {
    pagination: {
      handler: function handler() {
        this.getDataFromApi();
      }
    }
  },
  mounted: function mounted() {
    var self = this;
    self.$eventBus.$on('updateCustomerTable', function (data) {
      self.getDataFromApi();
    });
  },
  beforeDestroy: function beforeDestroy() {
    var self = this;
    self.$eventBus.$off('updateCustomerTable');
  },
  methods: {
    getDataFromApi: function getDataFromApi() {
      this.loading = true;
      var _this$pagination = this.pagination,
        sortBy = _this$pagination.sortBy,
        descending = _this$pagination.descending,
        page = _this$pagination.page,
        rowsPerPage = _this$pagination.rowsPerPage;
      var self = this;
      var params = {
        sort_by: sortBy,
        descending: descending,
        page: page,
        rowsPerPage: rowsPerPage
      };
      if (self.search) {
        params['term'] = self.search;
      }
      axios.get('/admin/customers', {
        params: params
      }).then(function (response) {
        self.total_items = response.data.total;
        self.items = response.data.data;
        self.loading = false;
      })["catch"](function (error) {
        console.log(error);
      });
    },
    create: function create() {
      var self = this;
      var templateType = {
        template: 'customer'
      };
      self.$refs.customerAdd.create(templateType);
    },
    edit: function edit(id) {
      var self = this;
      self.$refs.customerEdit.edit(id);
    },
    deleteCustomer: function deleteCustomer(item) {
      var self = this;
      self.$store.commit('showDialog', {
        type: 'confirm',
        icon: 'warning',
        title: self.trans('messages.are_you_sure'),
        message: self.trans('messages.you_cant_restore_it'),
        okCb: function okCb() {
          axios["delete"]('/admin/customers/' + item.id).then(function (response) {
            self.$store.commit('showSnackbar', {
              message: response.data.msg,
              color: response.data.success
            });
            if (response.data.success === true) {
              self.getDataFromApi();
            }
          })["catch"](function (err) {
            console.log(err.response.status);
            if (err.response.status === 401) {
              store.dispatch('auth/handleResponse', err.response);
            }
          });
        },
        cancelCb: function cancelCb() {
          console.log('CANCEL');
        }
      });
    },
    customerContact: function customerContact(item) {
      var self = this;
      self.$router.push({
        name: 'customers.contacts.list',
        params: {
          id: item.id
        }
      });
    },
    searchCustomer: function searchCustomer() {
      var self = this;
      self.getDataFromApi();
    }
  }
});

/***/ }),

/***/ "./resources/js/admin/customers/components/Edit.vue":
/*!**********************************************************!*\
  !*** ./resources/js/admin/customers/components/Edit.vue ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Edit_vue_vue_type_template_id_5b43487b___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Edit.vue?vue&type=template&id=5b43487b& */ "./resources/js/admin/customers/components/Edit.vue?vue&type=template&id=5b43487b&");
/* harmony import */ var _Edit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Edit.vue?vue&type=script&lang=js& */ "./resources/js/admin/customers/components/Edit.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Edit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Edit_vue_vue_type_template_id_5b43487b___WEBPACK_IMPORTED_MODULE_0__.render,
  _Edit_vue_vue_type_template_id_5b43487b___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/admin/customers/components/Edit.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/admin/customers/components/List.vue":
/*!**********************************************************!*\
  !*** ./resources/js/admin/customers/components/List.vue ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _List_vue_vue_type_template_id_4bfb210f___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./List.vue?vue&type=template&id=4bfb210f& */ "./resources/js/admin/customers/components/List.vue?vue&type=template&id=4bfb210f&");
/* harmony import */ var _List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./List.vue?vue&type=script&lang=js& */ "./resources/js/admin/customers/components/List.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _List_vue_vue_type_template_id_4bfb210f___WEBPACK_IMPORTED_MODULE_0__.render,
  _List_vue_vue_type_template_id_4bfb210f___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/admin/customers/components/List.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/admin/customers/components/Edit.vue?vue&type=script&lang=js&":
/*!***********************************************************************************!*\
  !*** ./resources/js/admin/customers/components/Edit.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Edit.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/customers/components/Edit.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/admin/customers/components/List.vue?vue&type=script&lang=js&":
/*!***********************************************************************************!*\
  !*** ./resources/js/admin/customers/components/List.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./List.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/customers/components/List.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/admin/customers/components/Edit.vue?vue&type=template&id=5b43487b&":
/*!*****************************************************************************************!*\
  !*** ./resources/js/admin/customers/components/Edit.vue?vue&type=template&id=5b43487b& ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_template_id_5b43487b___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_template_id_5b43487b___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Edit_vue_vue_type_template_id_5b43487b___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Edit.vue?vue&type=template&id=5b43487b& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/customers/components/Edit.vue?vue&type=template&id=5b43487b&");


/***/ }),

/***/ "./resources/js/admin/customers/components/List.vue?vue&type=template&id=4bfb210f&":
/*!*****************************************************************************************!*\
  !*** ./resources/js/admin/customers/components/List.vue?vue&type=template&id=4bfb210f& ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_4bfb210f___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_4bfb210f___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_4bfb210f___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./List.vue?vue&type=template&id=4bfb210f& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/customers/components/List.vue?vue&type=template&id=4bfb210f&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/customers/components/Edit.vue?vue&type=template&id=5b43487b&":
/*!********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/customers/components/Edit.vue?vue&type=template&id=5b43487b& ***!
  \********************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "v-layout",
    { attrs: { row: "", "justify-center": "" } },
    [
      _c("CurrencyAdd", { ref: "currencyAdd" }),
      _vm._v(" "),
      _c(
        "v-dialog",
        {
          attrs: { "full-width": "" },
          model: {
            value: _vm.dialog,
            callback: function ($$v) {
              _vm.dialog = $$v
            },
            expression: "dialog",
          },
        },
        [
          _c(
            "v-card",
            [
              _c(
                "v-card-title",
                [
                  _c("v-icon", { attrs: { medium: "" } }, [_vm._v("person")]),
                  _vm._v(" "),
                  _c("span", { staticClass: "headline" }, [
                    _vm._v(
                      "\n                    " +
                        _vm._s(_vm.trans("messages.edit_cutomer")) +
                        "\n                "
                    ),
                  ]),
                  _vm._v(" "),
                  _c("v-spacer"),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      attrs: { flat: "", icon: "" },
                      on: {
                        click: function ($event) {
                          _vm.dialog = false
                        },
                      },
                    },
                    [_c("v-icon", [_vm._v("clear")])],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("v-divider"),
              _vm._v(" "),
              _c(
                "v-form",
                { ref: "customerFormEdit" },
                [
                  _c(
                    "v-container",
                    { attrs: { "grid-list-md": "" } },
                    [
                      _c(
                        "v-layout",
                        { attrs: { row: "", wrap: "" } },
                        [
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", md3: "" } },
                            [
                              _c("v-text-field", {
                                directives: [
                                  {
                                    name: "validate",
                                    rawName: "v-validate",
                                    value: "required",
                                    expression: "'required'",
                                  },
                                ],
                                attrs: {
                                  label: _vm.trans("messages.company"),
                                  "data-vv-name": "company",
                                  "data-vv-as": _vm.trans("messages.company"),
                                  "error-messages":
                                    _vm.errors.collect("company"),
                                  required: "",
                                },
                                model: {
                                  value: _vm.customerData.company,
                                  callback: function ($$v) {
                                    _vm.$set(_vm.customerData, "company", $$v)
                                  },
                                  expression: "customerData.company",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", md3: "" } },
                            [
                              _c("v-text-field", {
                                attrs: {
                                  label: _vm.trans("messages.tax_number"),
                                  "data-vv-name": "tax_number",
                                },
                                model: {
                                  value: _vm.customerData.tax_number,
                                  callback: function ($$v) {
                                    _vm.$set(
                                      _vm.customerData,
                                      "tax_number",
                                      $$v
                                    )
                                  },
                                  expression: "customerData.tax_number",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", md3: "" } },
                            [
                              _c("v-text-field", {
                                directives: [
                                  {
                                    name: "validate",
                                    rawName: "v-validate",
                                    value: "required",
                                    expression: "'required'",
                                  },
                                ],
                                attrs: {
                                  label: _vm.trans("messages.mobile"),
                                  "data-vv-name": "mobile",
                                  "data-vv-as": _vm.trans("messages.mobile"),
                                  "error-messages":
                                    _vm.errors.collect("mobile"),
                                  required: "",
                                },
                                model: {
                                  value: _vm.customerData.mobile,
                                  callback: function ($$v) {
                                    _vm.$set(_vm.customerData, "mobile", $$v)
                                  },
                                  expression: "customerData.mobile",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", md2: "" } },
                            [
                              _c("v-autocomplete", {
                                directives: [
                                  {
                                    name: "validate",
                                    rawName: "v-validate",
                                    value: "required",
                                    expression: "'required'",
                                  },
                                ],
                                attrs: {
                                  "item-text": "currency",
                                  "item-value": "id",
                                  items: _vm.currencies,
                                  label: _vm.trans("messages.currency"),
                                  "data-vv-name": "currency",
                                  "data-vv-as": _vm.trans("messages.currency"),
                                  "error-messages":
                                    _vm.errors.collect("currency"),
                                  required: "",
                                },
                                model: {
                                  value: _vm.customerData.currency_id,
                                  callback: function ($$v) {
                                    _vm.$set(
                                      _vm.customerData,
                                      "currency_id",
                                      $$v
                                    )
                                  },
                                  expression: "customerData.currency_id",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { md1: "" } },
                            [
                              _c(
                                "v-btn",
                                {
                                  attrs: {
                                    small: "",
                                    color: "primary",
                                    fab: "",
                                    dark: "",
                                  },
                                  on: { click: _vm.addCurrency },
                                },
                                [_c("v-icon", [_vm._v("add")])],
                                1
                              ),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", md4: "" } },
                            [
                              _c("v-text-field", {
                                attrs: {
                                  label: _vm.trans("messages.alternate_num"),
                                },
                                model: {
                                  value: _vm.customerData.alternate_contact_no,
                                  callback: function ($$v) {
                                    _vm.$set(
                                      _vm.customerData,
                                      "alternate_contact_no",
                                      $$v
                                    )
                                  },
                                  expression:
                                    "customerData.alternate_contact_no",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", sm6: "", md4: "" } },
                            [
                              _c("v-text-field", {
                                directives: [
                                  {
                                    name: "validate",
                                    rawName: "v-validate",
                                    value: "required|email",
                                    expression: "'required|email'",
                                  },
                                ],
                                attrs: {
                                  label: _vm.trans("messages.email"),
                                  "data-vv-name": "email",
                                  "data-vv-as": _vm.trans("messages.email"),
                                  "error-messages": _vm.errors.collect("email"),
                                  required: "",
                                },
                                model: {
                                  value: _vm.customerData.email,
                                  callback: function ($$v) {
                                    _vm.$set(_vm.customerData, "email", $$v)
                                  },
                                  expression: "customerData.email",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", md4: "" } },
                            [
                              _c("v-text-field", {
                                directives: [
                                  {
                                    name: "validate",
                                    rawName: "v-validate",
                                    value: { url: { require_protocol: true } },
                                    expression:
                                      "{ url: { require_protocol: true } }",
                                  },
                                ],
                                attrs: {
                                  "data-vv-name": "website",
                                  "data-vv-as": _vm.trans("messages.website"),
                                  "error-messages":
                                    _vm.errors.collect("website"),
                                  label: _vm.trans("messages.website"),
                                },
                                model: {
                                  value: _vm.customerData.website,
                                  callback: function ($$v) {
                                    _vm.$set(_vm.customerData, "website", $$v)
                                  },
                                  expression: "customerData.website",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", md3: "" } },
                            [
                              _c("v-text-field", {
                                attrs: { label: _vm.trans("messages.city") },
                                model: {
                                  value: _vm.customerData.city,
                                  callback: function ($$v) {
                                    _vm.$set(_vm.customerData, "city", $$v)
                                  },
                                  expression: "customerData.city",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", md3: "" } },
                            [
                              _c("v-text-field", {
                                attrs: { label: _vm.trans("messages.state") },
                                model: {
                                  value: _vm.customerData.state,
                                  callback: function ($$v) {
                                    _vm.$set(_vm.customerData, "state", $$v)
                                  },
                                  expression: "customerData.state",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", md3: "" } },
                            [
                              _c("v-text-field", {
                                attrs: { label: _vm.trans("messages.country") },
                                model: {
                                  value: _vm.customerData.country,
                                  callback: function ($$v) {
                                    _vm.$set(_vm.customerData, "country", $$v)
                                  },
                                  expression: "customerData.country",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", md3: "" } },
                            [
                              _c("v-text-field", {
                                attrs: {
                                  label: _vm.trans("messages.zip_code"),
                                },
                                model: {
                                  value: _vm.customerData.zip_code,
                                  callback: function ($$v) {
                                    _vm.$set(_vm.customerData, "zip_code", $$v)
                                  },
                                  expression: "customerData.zip_code",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", md6: "" } },
                            [
                              _c("v-textarea", {
                                attrs: {
                                  "auto-grow": "",
                                  label: _vm.trans("messages.billing_address"),
                                  rows: "3",
                                },
                                model: {
                                  value: _vm.customerData.billing_address,
                                  callback: function ($$v) {
                                    _vm.$set(
                                      _vm.customerData,
                                      "billing_address",
                                      $$v
                                    )
                                  },
                                  expression: "customerData.billing_address",
                                },
                              }),
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "v-flex",
                            { attrs: { xs12: "", md6: "" } },
                            [
                              _c("v-textarea", {
                                attrs: {
                                  "auto-grow": "",
                                  label: _vm.trans("messages.shipping_address"),
                                  rows: "3",
                                },
                                model: {
                                  value: _vm.customerData.shipping_address,
                                  callback: function ($$v) {
                                    _vm.$set(
                                      _vm.customerData,
                                      "shipping_address",
                                      $$v
                                    )
                                  },
                                  expression: "customerData.shipping_address",
                                },
                              }),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "v-card-actions",
                [
                  _c("v-spacer"),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      attrs: { color: "green darken-1", flat: "" },
                      on: {
                        click: function ($event) {
                          _vm.dialog = false
                        },
                      },
                    },
                    [
                      _vm._v(
                        "\n                    " +
                          _vm._s(_vm.trans("messages.close")) +
                          "\n                "
                      ),
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "v-btn",
                    {
                      attrs: {
                        color: "success",
                        loading: _vm.loading,
                        disabled: _vm.loading,
                      },
                      on: {
                        click: function ($event) {
                          return _vm.update(_vm.customerData.id)
                        },
                      },
                    },
                    [
                      _vm._v(
                        "\n                    " +
                          _vm._s(_vm.trans("messages.update")) +
                          "\n                "
                      ),
                    ]
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/customers/components/List.vue?vue&type=template&id=4bfb210f&":
/*!********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/admin/customers/components/List.vue?vue&type=template&id=4bfb210f& ***!
  \********************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "component-wrap" },
    [
      _c("CustomerFormEdit", { ref: "customerEdit" }),
      _vm._v(" "),
      _c("CustomerFormAdd", { ref: "customerAdd" }),
      _vm._v(" "),
      _c(
        "v-card",
        { staticClass: "mb-3" },
        [
          _c(
            "v-layout",
            { attrs: { row: "", wrap: "" } },
            [
              _c(
                "v-flex",
                { attrs: { xs12: "", sm6: "", md6: "" } },
                [
                  _c("v-text-field", {
                    staticClass: "ml-2",
                    attrs: {
                      "prepend-icon": "search",
                      label: _vm.trans("messages.search"),
                      "single-line": "",
                    },
                    on: { keyup: _vm.searchCustomer },
                    model: {
                      value: _vm.search,
                      callback: function ($$v) {
                        _vm.search = $$v
                      },
                      expression: "search",
                    },
                  }),
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "v-flex",
                {
                  staticClass: "text-xs-right pt-1",
                  attrs: { xs12: "", sm6: "", md6: "" },
                },
                [
                  _vm.$can("customer.create")
                    ? _c(
                        "v-btn",
                        {
                          staticClass: "primary lighten-1",
                          attrs: { dark: "" },
                          on: { click: _vm.create },
                        },
                        [
                          _vm._v(
                            "\n                    " +
                              _vm._s(_vm.trans("messages.new_customer")) +
                              "\n                    "
                          ),
                          _c("v-icon", { attrs: { right: "", dark: "" } }, [
                            _vm._v("add"),
                          ]),
                        ],
                        1
                      )
                    : _vm._e(),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "v-card",
        [
          _c("v-card-title", [
            _c("div", [
              _c("div", { staticClass: "headline" }, [
                _vm._v(
                  "\n                    " +
                    _vm._s(_vm.trans("messages.all_customers")) +
                    "\n                "
                ),
              ]),
            ]),
          ]),
          _vm._v(" "),
          _c("v-divider"),
          _vm._v(" "),
          _c("v-data-table", {
            staticClass: "elevation-3 w-full",
            attrs: {
              headers: _vm.headers,
              pagination: _vm.pagination,
              "total-items": _vm.total_items,
              loading: _vm.loading,
              items: _vm.items,
            },
            on: {
              "update:pagination": function ($event) {
                _vm.pagination = $event
              },
            },
            scopedSlots: _vm._u([
              {
                key: "headerCell",
                fn: function (props) {
                  return [
                    props.header.value == "company"
                      ? _c(
                          "span",
                          [
                            _c("v-icon", [_vm._v("business_center")]),
                            _vm._v(
                              " " +
                                _vm._s(props.header.text) +
                                "\n                "
                            ),
                          ],
                          1
                        )
                      : props.header.value == "tax_number"
                      ? _c(
                          "span",
                          [
                            _c("v-icon", [_vm._v("receipt")]),
                            _vm._v(
                              " " +
                                _vm._s(props.header.text) +
                                "\n                "
                            ),
                          ],
                          1
                        )
                      : props.header.value == "mobile"
                      ? _c(
                          "span",
                          [
                            _c("v-icon", [_vm._v("phone")]),
                            _vm._v(
                              " " +
                                _vm._s(props.header.text) +
                                "\n                "
                            ),
                          ],
                          1
                        )
                      : props.header.value == "website"
                      ? _c(
                          "span",
                          [
                            _c("v-icon", [_vm._v("web")]),
                            _vm._v(
                              " " +
                                _vm._s(props.header.text) +
                                "\n                "
                            ),
                          ],
                          1
                        )
                      : _c("span", [_vm._v(_vm._s(props.header.text))]),
                  ]
                },
              },
              {
                key: "items",
                fn: function (props) {
                  return [
                    _c(
                      "td",
                      [
                        _c(
                          "v-menu",
                          [
                            _c(
                              "v-btn",
                              {
                                attrs: { slot: "activator", icon: "" },
                                slot: "activator",
                              },
                              [_c("v-icon", [_vm._v("more_vert")])],
                              1
                            ),
                            _vm._v(" "),
                            _c(
                              "v-list",
                              [
                                _vm.$can("customer.view")
                                  ? _c(
                                      "v-list-tile",
                                      {
                                        on: {
                                          click: function ($event) {
                                            return _vm.$router.push({
                                              name: "customers.show",
                                              params: { id: props.item.id },
                                            })
                                          },
                                        },
                                      },
                                      [
                                        _c(
                                          "v-list-tile-title",
                                          [
                                            _c(
                                              "v-icon",
                                              {
                                                staticClass: "mr-2",
                                                attrs: { small: "" },
                                              },
                                              [_vm._v(" visibility ")]
                                            ),
                                            _vm._v(
                                              "\n                                    " +
                                                _vm._s(
                                                  _vm.trans("messages.view")
                                                ) +
                                                "\n                                "
                                            ),
                                          ],
                                          1
                                        ),
                                      ],
                                      1
                                    )
                                  : _vm._e(),
                                _vm._v(" "),
                                _vm.$can("customer.edit")
                                  ? _c(
                                      "v-list-tile",
                                      {
                                        on: {
                                          click: function ($event) {
                                            return _vm.edit(props.item.id)
                                          },
                                        },
                                      },
                                      [
                                        _c(
                                          "v-list-tile-title",
                                          [
                                            _c(
                                              "v-icon",
                                              {
                                                staticClass: "mr-2",
                                                attrs: { small: "" },
                                              },
                                              [_vm._v(" edit ")]
                                            ),
                                            _vm._v(
                                              "\n                                    " +
                                                _vm._s(
                                                  _vm.trans("messages.edit")
                                                ) +
                                                "\n                                "
                                            ),
                                          ],
                                          1
                                        ),
                                      ],
                                      1
                                    )
                                  : _vm._e(),
                                _vm._v(" "),
                                _vm.$can("customer.delete")
                                  ? _c(
                                      "v-list-tile",
                                      {
                                        on: {
                                          click: function ($event) {
                                            return _vm.deleteCustomer(
                                              props.item
                                            )
                                          },
                                        },
                                      },
                                      [
                                        _c(
                                          "v-list-tile-title",
                                          [
                                            _c(
                                              "v-icon",
                                              {
                                                staticClass: "mr-2",
                                                attrs: { small: "" },
                                              },
                                              [_vm._v(" delete_forever ")]
                                            ),
                                            _vm._v(
                                              "\n                                    " +
                                                _vm._s(
                                                  _vm.trans("messages.delete")
                                                ) +
                                                "\n                                "
                                            ),
                                          ],
                                          1
                                        ),
                                      ],
                                      1
                                    )
                                  : _vm._e(),
                              ],
                              1
                            ),
                          ],
                          1
                        ),
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c("td", [_vm._v(_vm._s(props.item.id))]),
                    _vm._v(" "),
                    _c("td", [_vm._v(_vm._s(props.item.company))]),
                    _vm._v(" "),
                    _c("td", [_vm._v(_vm._s(props.item.tax_number))]),
                    _vm._v(" "),
                    _c("td", [_vm._v(_vm._s(props.item.mobile))]),
                    _vm._v(" "),
                    _c("td", [_vm._v(_vm._s(props.item.website))]),
                  ]
                },
              },
            ]),
          }),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);