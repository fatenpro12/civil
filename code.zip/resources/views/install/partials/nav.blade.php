<ul class="nav nav-pills nav-justified">
  <li class="nav-item">
    <a class="nav-link @if($active == 'install') active @endif" href="#">Instructions</a>
  </li>
  <li class="nav-item">
    <a class="nav-link @if($active == 'app_details') active @endif" href="#">Application Details</a>
  </li>
  <li class="nav-item">
    <a class="nav-link @if($active == 'success') active @endif" href="#">Success</a>
  </li>
</ul>
<br/>