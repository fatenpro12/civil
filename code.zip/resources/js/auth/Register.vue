<template>
    
    <userformadd class="mx-auto" style="max-width:75%;margin:3rem">
    </userformadd>
</template>
<script>
import { mapActions } from 'vuex'
export default {
    name:'register',
    data(){
        return {
           
        }
    },
}
</script>