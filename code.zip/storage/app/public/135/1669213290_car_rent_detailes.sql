-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 15 سبتمبر 2022 الساعة 22:24
-- إصدار الخادم: 10.4.22-MariaDB
-- PHP Version: 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `contract`
--

-- --------------------------------------------------------

--
-- بنية الجدول `car_rent_detailes`
--

CREATE TABLE `car_rent_detailes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `transport_company_id` bigint(20) UNSIGNED DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `version_year` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `distance` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `register_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rent_duration` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rent_date` date DEFAULT NULL,
  `warning_cancel_duration` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rent_price_duration_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rent_price_duration_writing` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_price_date` date DEFAULT NULL,
  `first_price_months` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cancel_contract_cost` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `bank_account` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- إرجاع أو استيراد بيانات الجدول `car_rent_detailes`
--

INSERT INTO `car_rent_detailes` (`id`, `transport_company_id`, `type`, `version_year`, `distance`, `register_id`, `rent_duration`, `rent_date`, `warning_cancel_duration`, `rent_price_duration_number`, `rent_price_duration_writing`, `first_price_date`, `first_price_months`, `cancel_contract_cost`, `created_at`, `updated_at`, `bank_account`) VALUES
(1, 32, 'Mercedes-Benz 906 KA35', '2010', '261792 km', '4-VGT-14', 'onbepaalde tijd', '2022-09-28', '3 (drie) maanden', '260', 'Tweehonderdzestig Euro', '2022-09-21', 'vc', NULL, '2022-09-15 22:58:57', '2022-09-16 02:56:36', 'NL36INGB0007292802');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `car_rent_detailes`
--
ALTER TABLE `car_rent_detailes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `car_rent_detailes_transport_company_id_foreign` (`transport_company_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `car_rent_detailes`
--
ALTER TABLE `car_rent_detailes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- قيود الجداول المحفوظة
--

--
-- القيود للجدول `car_rent_detailes`
--
ALTER TABLE `car_rent_detailes`
  ADD CONSTRAINT `car_rent_detailes_transport_company_id_foreign` FOREIGN KEY (`transport_company_id`) REFERENCES `transport_companies` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
